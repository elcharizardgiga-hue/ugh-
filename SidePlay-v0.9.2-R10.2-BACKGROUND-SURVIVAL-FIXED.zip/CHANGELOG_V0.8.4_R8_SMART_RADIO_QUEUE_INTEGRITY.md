# SidePlay 0.8.4-r8 — Smart Radio + Queue Integrity

R8 is a reliability and listening-experience release built on top of R7's legacy queue sanitizer.

## Playback atomicity

- A Play request now claims its request token **before any async metadata hydration**. An older request can no longer finish late and steal playback back from a newer tap.
- Resolver completion can update the selected item inside the **live queue** instead of restoring a stale queue snapshot.
- Lightweight next-track prefetch and full Play resolution now have separate in-flight identities. A real Play can still escalate to the full resolver even while a lightweight prefetch is running.
- Media Catcher is explicit/manual-only; normal Play never surprises the listener by opening another browser/webview.

## Queue integrity

- Every queue ingestion boundary repairs legacy YouTube identity, including Add to queue, Play next, persisted state, imported history and playback replacement.
- Re-queueing an item that already sits before the current track adjusts `currentIndex` safely.
- The currently playing item is never moved by Add to queue / Play next.
- Manual picks are inserted ahead of future Autoplay entries.
- Queue UI now separates **Queued by you** from **SidePlay Radio**.

## Smart Radio

- Android can request YouTube's watch-next graph directly for the current video ID and use that as the primary related-content pool.
- Search is now an expander/fallback instead of the primary definition of “related”.
- SidePlay reranks candidates locally using:
  - seed-song/artist relationship,
  - recent listening,
  - favorites and playlists,
  - repeat/completion behavior,
  - skip behavior,
  - official/Topic/VEVO signals,
  - artist diversity.
- Same-song reuploads and common noisy variants (reaction, karaoke, cover, slowed/reverb, nightcore, etc.) are filtered or heavily penalized unless the seed itself represents that flavor.
- Recommendation rows can explain themselves with reasons such as **Related to…**, **More from…**, **Fits your rotation**, and **Based on…**.
- Any track action sheet now includes **Start radio**.

## Taste feedback

- State schema v2 adds skip and completion counters.
- Manual Next before roughly 80% completion records a skip.
- Natural end-of-track records a completion.
- Those signals feed future local ranking; they are not sent to an external recommendation service by SidePlay.

## State migration

- Persisted state is now `sideplay.state.v2` with explicit migration from v1.
- Queue/history/playlists are repaired during migration and persistence.

## Build / regression hardening

- Source package version: `0.8.4-r8`
- Android versionCode: `815`
- Exact top-level npm versions replace caret ranges.
- Added Node core regression tests for music identity / duplicate / noisy-variant filtering.
- GitHub build runs the core tests before the web build.

