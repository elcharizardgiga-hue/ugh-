@echo off
call "%~dp0BUILD_SIDEPLAY_R10_2.bat"
