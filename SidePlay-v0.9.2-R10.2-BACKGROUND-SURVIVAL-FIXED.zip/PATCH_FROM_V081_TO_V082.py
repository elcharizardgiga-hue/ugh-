from pathlib import Path
import json, re

# ---------- package version ----------
p = Path('package.json')
pkg = json.loads(p.read_text(encoding='utf-8'))
pkg['version'] = '0.8.2'
p.write_text(json.dumps(pkg, indent=2) + '\n', encoding='utf-8')

# ---------- React app: fast search + stay-inside playback ----------
p = Path('src/App.tsx')
s = p.read_text(encoding='utf-8')

# Replace the yt-dlp-first YouTube catalog search block. The v0.8.1 source has a
# native branch that calls searchWithYtDlp first and falls back to searchYouTube.
# v0.8.2 always uses the lightweight HTTP/keyless catalog path for results.
pat = re.compile(
    r"        if \(scope === 'all' \|\| scope === 'youtube'\) \{.*?\n        \}\n\n        // On Android, \"All\" also searches SoundCloud through yt-dlp itself\.",
    re.S,
)
replacement = '''        if (scope === 'all' || scope === 'youtube') {
          // FAST PATH: catalog search must not boot Python/yt-dlp. Extraction
          // starts only when the user actually taps a result.
          jobs.push(searchYouTube(q, sp.state.youtubeApiKey)
            .then((found) => ({
              name: 'YouTube',
              tracks: found.slice(0, scope === 'all' ? 18 : 30).map((track) => ({
                ...track,
                provider: 'youtube' as const,
                sourceUrl: `https://www.youtube.com/watch?v=${track.videoId}`,
                ...(scope === 'all' ? { mediaKind: 'audio' as const, audioPreferred: true } : {})
              }))
            }))
            .catch((e: any) => ({ name: 'YouTube', tracks: [], error: e?.message || 'unavailable' })))
        }

        // Provider-specific heavy discovery remains opt-in through its own tab.'''
s, n = pat.subn(replacement, s, count=1)
if n != 1:
    raise SystemExit(f'FAST SEARCH: expected YouTube block once, found {n}')

# Do not make the default Music search wait for slower provider searches.
for old, new, label in [
    (r"if \(\(scope === 'all' \|\| scope === 'soundcloud'\) && isNative\(\)\) jobs\.push\(searchWithYtDlp\(q, 'soundcloud', scope === 'all' \? 8 : 25\)",
     "if (scope === 'soundcloud' && isNative()) jobs.push(searchWithYtDlp(q, 'soundcloud', 25)", 'SoundCloud'),
    (r"if \(scope === 'all' \|\| scope === 'audius'\) jobs\.push", "if (scope === 'audius') jobs.push", 'Audius'),
    (r"if \(scope === 'all' \|\| scope === 'peertube'\) jobs\.push", "if (scope === 'peertube') jobs.push", 'PeerTube'),
]:
    s, count = re.subn(old, new, s, count=1)
    if count != 1:
        raise SystemExit(f'FAST SEARCH: {label} scope patch count={count}')

# After narrowing scope to a provider-specific literal, TypeScript correctly knows
# scope can no longer be 'all'. Remove the now-impossible ternaries so tsc does not
# emit TS2367 ("types have no overlap").
s = s.replace(
    "if (scope === 'audius') jobs.push(searchAudius(q, scope === 'all' ? 6 : 18)",
    "if (scope === 'audius') jobs.push(searchAudius(q, 18)",
    1,
)
s = s.replace(
    "if (scope === 'peertube') jobs.push(searchPeerTube(q, scope === 'all' ? 5 : 18)",
    "if (scope === 'peertube') jobs.push(searchPeerTube(q, 18)",
    1,
)

# Normal Android Play is headless. Explicit advanced/manual capture tools can
# remain elsewhere, but play() itself must never launch MediaCaptureActivity.
play_start = s.find('  async function play(')
play_end = s.find('  function previous()', play_start)
if play_start < 0 or play_end < 0:
    raise SystemExit('Could not locate App.tsx play()')
play = s[play_start:play_end]
auto_catcher = "captureUniversalUrl(track.sourceUrl, { auto: true })"
if auto_catcher not in play:
    raise SystemExit('Expected automatic MediaCaptureActivity fallback in play()')
play = play.replace(
    auto_catcher,
    "Promise.reject(new Error('SidePlay could not resolve a native playable stream for this result.'))",
)
# Belt-and-suspenders: normal Android play must not call provider/browser escape helpers.
for forbidden in ['handoffYouTubePremium(track', 'trySpotifyPlayback(track', 'openExternalUrl(track.sourceUrl']:
    if forbidden in play:
        raise SystemExit(f'Unsafe automatic playback escape remains: {forbidden}')
s = s[:play_start] + play + s[play_end:]

s = s.replace(
    'Search songs, artists, videos, or paste a link. SidePlay resolves playback automatically.',
    'Search instantly. SidePlay extracts only after you tap a result.'
)
p.write_text(s, encoding='utf-8')

# ---------- yt-dlp: lighter startup + bounded failure ----------
p = Path('native/android/YtDlpPlugin.java')
s = p.read_text(encoding='utf-8')

marker = 'private static volatile boolean initialized = false;'
if marker not in s:
    raise SystemExit('YtDlpPlugin initialized marker missing')
if 'ffmpegInitialized' not in s:
    s = s.replace(
        marker,
        marker + '\n    private static final Object FFMPEG_INIT_LOCK = new Object();\n    private static volatile boolean ffmpegInitialized = false;',
        1,
    )

# Streaming extraction does not need FFmpeg. Avoid loading it during first play.
old_init = '''            YoutubeDL.getInstance().init(context);
            FFmpeg.getInstance().init(context);
            initialized = true;
            maybeUpdateExtractor(context, false);'''
new_init = '''            YoutubeDL.getInstance().init(context.getApplicationContext());
            initialized = true;'''
if old_init not in s:
    raise SystemExit('YtDlpPlugin heavy init block not found')
s = s.replace(old_init, new_init, 1)

# Explicit provider-tab search also must not synchronously update yt-dlp and retry.
old_search_retry = '''                JSArray results;
                try {
                    results = searchInternal(query, engine, limit);
                } catch (Exception first) {
                    maybeUpdateExtractor(getContext(), true);
                    results = searchInternal(query, engine, limit);
                }
'''
new_search_retry = '''                JSArray results;
                try {
                    results = searchInternal(query, engine, limit);
                } catch (Exception first) {
                    Context appContext = getContext().getApplicationContext();
                    new Thread(() -> maybeUpdateExtractor(appContext, true), "SidePlayYtDlpSearchUpdater").start();
                    throw first;
                }
'''
if old_search_retry not in s:
    raise SystemExit('YtDlpPlugin synchronous search retry block not found')
s = s.replace(old_search_retry, new_search_retry, 1)

# A Play tap must not synchronously download/update yt-dlp and retry. Return the
# failure promptly, and let an updater run outside the critical path.
old_retry = '''        try {
            return resolveInternal(source, audioOnly);
        } catch (Exception first) {
            maybeUpdateExtractor(context, true);
            return resolveInternal(source, audioOnly);
        }'''
new_retry = '''        try {
            return resolveInternal(source, audioOnly);
        } catch (Exception first) {
            Context appContext = context.getApplicationContext();
            new Thread(() -> maybeUpdateExtractor(appContext, true), "SidePlayYtDlpUpdater").start();
            throw first;
        }'''
if old_retry not in s:
    raise SystemExit('YtDlpPlugin synchronous retry block not found')
s = s.replace(old_retry, new_retry, 1)

# FFmpeg initializes only when a download/merge operation actually needs it.
anchor = '    public static JSObject resolveForPlayback(Context context, String source) throws Exception {'
helper = '''    private static void ensureFfmpegInitialized(Context context) throws Exception {
        if (ffmpegInitialized) return;
        synchronized (FFMPEG_INIT_LOCK) {
            if (ffmpegInitialized) return;
            FFmpeg.getInstance().init(context.getApplicationContext());
            ffmpegInitialized = true;
        }
    }

'''
if 'ensureFfmpegInitialized' not in s:
    if anchor not in s:
        raise SystemExit('resolveForPlayback anchor missing')
    s = s.replace(anchor, helper + anchor, 1)

download_idx = s.find('public void download(PluginCall call)')
if download_idx < 0:
    raise SystemExit('download() missing')
next_method = s.find('\n    @PluginMethod', download_idx + 20)
if next_method < 0:
    next_method = len(s)
download_block = s[download_idx:next_method]
if 'ensureFfmpegInitialized(getContext())' not in download_block:
    pos = download_block.find('ensureInitialized();')
    if pos < 0:
        raise SystemExit('download ensureInitialized() missing')
    pos += len('ensureInitialized();')
    download_block = download_block[:pos] + '\n                ensureFfmpegInitialized(getContext());' + download_block[pos:]
    s = s[:download_idx] + download_block + s[next_method:]

# Bound network waits and retries in yt-dlp requests. v0.8.1 already had
# larger values, so replace them explicitly rather than only adding when absent.
for old, new in [
    ('request.addOption("--socket-timeout", "25");', 'request.addOption("--socket-timeout", "10");'),
    ('request.addOption("--retries", "5");', 'request.addOption("--retries", "1");'),
    ('request.addOption("--fragment-retries", "5");', 'request.addOption("--fragment-retries", "1");'),
    ('request.addOption("--extractor-retries", "3");', 'request.addOption("--extractor-retries", "1");'),
]:
    if old not in s:
        raise SystemExit(f'Expected yt-dlp request option missing: {old}')
    s = s.replace(old, new, 1)

p.write_text(s, encoding='utf-8')

# ---------- native version marker ----------
p = Path('native/android/PlaybackService.java')
s = p.read_text(encoding='utf-8')
if 'SidePlay/0.8.1 Android' not in s:
    raise SystemExit('PlaybackService v0.8.1 marker missing')
s = s.replace('SidePlay/0.8.1 Android', 'SidePlay/0.8.2 Android')
p.write_text(s, encoding='utf-8')

Path('CHANGELOG_V0.8.2.md').write_text('''# SidePlay v0.8.2 — Fast / Stable / Headless

- Main YouTube/Music catalog search no longer initializes Python/yt-dlp.
- Default Music search no longer waits for SoundCloud/Audius/PeerTube.
- Heavy extraction starts only after a result is tapped.
- FFmpeg is lazy-loaded only for offline download/merge work.
- yt-dlp updater no longer blocks the playback tap.
- yt-dlp socket/retry behavior is bounded.
- Normal Android Play never launches MediaCaptureActivity, browser, YouTube, or Spotify.
- Existing Media3 service remains the background playback owner after resolution.
- Intended release build is ARM64-only to eliminate unused native ABIs.
''', encoding='utf-8')

print('SidePlay v0.8.2 FINAL patch applied successfully')
