# SidePlay 0.9.0-r10 — Tune V2

Tune is now a real queue-control system instead of a mostly cosmetic radio panel.

- Presets set mode + Discovery + Variety together.
- Discovery changes candidate sourcing: high values reduce watch-next dominance and expand new-artist search candidates.
- Variety changes same-artist pull as well as the artist cap.
- Applying Tune replaces only SidePlay-generated autoplay tracks; manual Up Next choices are preserved.
- Preset taps apply immediately to Up Next.
- Slider edits are staged until `Apply to Up Next`, avoiding a network rebuild on every drag tick.
- Tune changes use generation guards so a slow old radio request cannot overwrite the newest tune.
- `Restart radio from this song` remains available as an explicit secondary action.
