# SidePlay 0.8.4-r7 — Legacy Queue Sanitizer

R7 is a hardening release on top of R6. An on-device R5 screenshot showed end-of-track autoplay falling through to the generic Web resolver and rendering `Untitled media · www.youtube.com`. The root cause is legacy/lightweight YouTube recommendation rows which can contain a YouTube videoId/title/thumbnail but no `provider` or `sourceUrl`.

## Changes

- Added `trackIdentity.ts` to repair YouTube identity before playback and persistence.
- Any recognizable YouTube track is canonicalized to `provider: youtube` and `https://www.youtube.com/watch?v=<id>`.
- The sanitizer runs on Play, queue input, persisted queue/history/favorites/playlists, and recommendation discovery.
- Generic YouTube metadata (`Untitled media`, `www.youtube.com`) is hydrated through the existing metadata resolver only when needed.
- Existing R5/R6 MediaSession, Radio autoplay, direct NewPipe download, Process Shield, Zero Wait and Engine Doctor changes remain intact.
- versionName: `0.8.4-r7`
- versionCode: `814`
