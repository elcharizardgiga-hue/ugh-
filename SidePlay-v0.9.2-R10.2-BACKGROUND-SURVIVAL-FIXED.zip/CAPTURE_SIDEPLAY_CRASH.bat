@echo off
setlocal
cd /d "%~dp0"
set "ADB="
where adb >nul 2>&1 && set "ADB=adb"
if not defined ADB if exist "%LOCALAPPDATA%\SidePlay\tools\android-sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\SidePlay\tools\android-sdk\platform-tools\adb.exe"
if not defined ADB (
  echo [FAIL] adb not found. Build SidePlay once first.
  pause
  exit /b 1
)
set "OUT=%~dp0sideplay-crash-log.txt"
set "CRASH=%~dp0sideplay-crash-buffer.txt"
set "EXIT=%~dp0sideplay-exit-info.txt"
"%ADB%" logcat -c
"%ADB%" logcat -b crash -c
cls
echo Reproduce the kick-out / playback crash now.
echo When SidePlay disappears or playback dies, come back here and press any key.
pause >nul
"%ADB%" logcat -d -v threadtime > "%OUT%"
"%ADB%" logcat -b crash -d -v threadtime > "%CRASH%"
"%ADB%" shell dumpsys activity exit-info app.sideplay.mobile > "%EXIT%" 2>&1
echo.
echo Saved diagnostics:
echo   %OUT%
echo   %CRASH%
echo   %EXIT%
echo.
echo Engine Doctor inside SidePlay also shows recent Android process exits on Android 11+.
pause
