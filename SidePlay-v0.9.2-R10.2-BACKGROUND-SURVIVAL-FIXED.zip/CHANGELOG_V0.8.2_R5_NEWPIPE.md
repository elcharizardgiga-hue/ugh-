# SidePlay 0.8.2 R5 — NewPipe native Play

R5 keeps the stable R4 rule that a normal Play tap MUST NOT initialize yt-dlp/Python/QuickJS.

## YouTube playback
- Adds NewPipeExtractor 0.26.5 as the primary YouTube stream resolver.
- Uses a small SidePlay HttpURLConnection downloader adapter; no Python runtime is involved.
- Serializes Play resolution through one executor to prevent double-tap/concurrent extraction spikes.
- Prefers a direct high-bitrate audio stream for Music/audio-first results.
- For video-first results, prefers a progressive A/V stream, then audio, HLS, or DASH.
- R4's direct InnerTube URL resolver remains a no-Python fallback.
- If both resolvers fail, the error stays inline inside SidePlay instead of opening another app.

## Android build
- Adds JitPack repository and `com.github.teamnewpipe:newpipeextractor:0.26.5`.
- Enables core-library desugaring with `desugar_jdk_libs_nio:2.1.5` for minSdk < 33.
- Adds NewPipe/Rhino keep rules.
- Generic `BUILD_SIDEPLAY_APK.bat` now always launches the R5 builder.
