# SidePlay v0.8.2 — Fast / Stable / Headless

- Main YouTube/Music catalog search no longer initializes Python/yt-dlp.
- Default Music search no longer waits for SoundCloud/Audius/PeerTube.
- Heavy extraction starts only after a result is tapped.
- FFmpeg is lazy-loaded only for offline download/merge work.
- yt-dlp updater no longer blocks the playback tap.
- yt-dlp socket/retry behavior is bounded.
- Normal Android Play never launches MediaCaptureActivity, browser, YouTube, or Spotify.
- Existing Media3 service remains the background playback owner after resolution.
- Intended release build is ARM64-only to eliminate unused native ABIs.

## Compile fix — 2026-09-16
- Fixed TypeScript TS2367 in `src/App.tsx` provider-specific search branches.
- Once `scope === 'audius'` or `scope === 'peertube'`, TypeScript narrows the union and `scope === 'all'` is impossible. The redundant ternaries were replaced with the provider-tab limits directly (`18`).

## Windows builder r2
- Fixed TS2367 Audius/PeerTube narrowed-scope comparisons.
- Gradle wrapper is now invoked by absolute path with -p to the Android project.
- Added BUILD_SIDEPLAY_V082_R2.bat to prevent accidentally launching stale v0.5.1 builders.
