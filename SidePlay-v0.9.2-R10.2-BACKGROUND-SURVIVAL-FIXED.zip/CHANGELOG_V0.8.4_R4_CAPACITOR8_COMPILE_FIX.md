# SidePlay v0.8.4-r4 — Capacitor 8 Compile Fix

This release keeps the R3 Process Shield architecture and fixes the Android javac failure caused by passing a `Throwable` directly to `PluginCall.reject(...)` under Capacitor 8.

## Fix
- `BackgroundAudioPlugin` keeps `catch (Throwable t)` around risky Android service handoffs.
- Before crossing the Capacitor bridge, `Throwable` is converted to `Exception` via `asException(Throwable t)`.
- Both failing call sites (`play` and `seek`) now use the bridge.
- The Windows builder fails early if a direct `call.reject(..., t)` is reintroduced.
- `patch-android.mjs` performs the same post-copy compile guard.
- GitHub Actions checks were updated from stale r2/809 metadata to r4/811.

## Architecture retained
- Main UI process: `app.sideplay.mobile`
- Media3 process: `app.sideplay.mobile:playback`
- yt-dlp/Python/QuickJS process: `app.sideplay.mobile:extractor`
- Zero Wait cache/prefetch and Engine Doctor remain enabled.

## Version
- versionName `0.8.4-r4`
- versionCode `811`
