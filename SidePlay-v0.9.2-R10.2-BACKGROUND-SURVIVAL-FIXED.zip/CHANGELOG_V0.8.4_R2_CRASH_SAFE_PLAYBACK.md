# SidePlay v0.8.4-r2 — Crash-Safe Playback

This release targets the native process exit that occurred immediately after a successful resolver handoff.

## Playback handoff
- Normal UI playback starts `MediaSessionService` with `startService()` instead of `startForegroundService()`.
- Media3 remains responsible for promoting the playback service and publishing its media notification.
- Removes the foreground-service promotion deadline that can terminate the entire app process.

## Native stability
- Audio offload preferences are disabled until they can be capability-tested per device.
- ExoPlayer and MediaSession creation are guarded; Java-side startup failures are persisted and reported instead of escaping `onCreate()`.
- Playback startup stages are persisted in `sideplay-native-playback-diagnostics`.
- Engine Doctor includes the last native playback stage/message.
- Resolver Fortress, isolated yt-dlp, Zero Wait cache and prefetch remain intact.

## Android identity
- versionName: `0.8.4-r2`
- versionCode: `809`
