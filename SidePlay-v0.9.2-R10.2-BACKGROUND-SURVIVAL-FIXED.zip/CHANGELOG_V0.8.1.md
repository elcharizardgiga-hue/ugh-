# SidePlay v0.8.1 — Stay Inside

- Normal Android Play taps no longer auto-launch YouTube, a browser, or Spotify.
- Android playback chain is SidePlay-owned: local/direct → yt-dlp/native resolver → in-app auto media catcher → Media3.
- Removed Android hidden/foreground YouTube fallback from normal playback.
- Resolver progress is per-track instead of duplicated global error banners.
- Search results hide recent-search clutter while results are present.
- Media Catcher can auto-return after validating a strong clear-media candidate.
- Explicit **Open source** remains available as a manual user action.
- Background Media3 service remains `stopWithTask=false`, sticky, resumable, and source-refresh capable.

Protected DRM streams are not decrypted or bypassed.
