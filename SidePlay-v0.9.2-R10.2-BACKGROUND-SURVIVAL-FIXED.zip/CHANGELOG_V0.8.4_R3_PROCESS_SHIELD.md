# SidePlay v0.8.4-r3 — Process Shield

## Why this exists
The reported runtime sequence was: resolve completes -> SidePlay UI disappears -> playback continues briefly in the background -> playback process later dies. That is consistent with a native playback crash in the same process as the Activity followed by START_STICKY service resurrection.

## Changes
- `PlaybackService` now runs in its own Android `:playback` process. Media3/codec/service failures can no longer directly kill the SidePlay WebView/Activity process.
- yt-dlp remains isolated separately in `:extractor`.
- Removed sticky crash-loop resurrection from playback commands (`START_NOT_STICKY`). Explicit MediaSession playback resumption remains available.
- `onTaskRemoved` now defers to MediaSessionService's documented default after checkpointing state.
- BackgroundAudio no longer depends on same-process static access to PlaybackService; pause/resume/seek/stop use explicit service commands and status is fed back by package-scoped broadcasts.
- Playback heartbeat broadcasts keep UI status current across process boundaries.
- Engine Doctor now shows `:playback` isolation and recent Android `ApplicationExitInfo` records on Android 11+, making Java/native/LMK exit reasons visible after a restart.
- Fixed the Engine Doctor `pdiag` render bug.
- versionName `0.8.4-r3`, versionCode `810`.
