export type MediaProvider = 'youtube' | 'peertube' | 'audius' | 'direct' | 'soundcloud' | 'spotify' | 'local' | 'unknown'
export type MediaKind = 'audio' | 'video'

export type Track = {
  /** Legacy name kept so old SidePlay libraries remain compatible. For non-YouTube
   * sources this is a stable SidePlay media id, not necessarily a YouTube id. */
  videoId: string
  title: string
  channel: string
  thumbnail: string
  publishedAt?: string

  /** v0.4 universal-source metadata. All fields are optional for backwards compatibility. */
  provider?: MediaProvider
  sourceUrl?: string
  /** Direct/authorized URL that SidePlay's native Media3 engine can play itself. */
  playbackUrl?: string
  /** Direct/authorized progressive file URL SidePlay may save into its private offline vault. */
  downloadUrl?: string
  mediaKind?: MediaKind
  mimeType?: string
  /** Request context captured from the source page when a CDN requires browser headers/cookies. */
  requestHeaders?: Record<string, string>
  /** True when playback URL came from a live browser session and should be re-captured after restart/session loss. */
  sessionBound?: boolean
  capturedAt?: number
  /** How an ephemeral playback URL should be refreshed when it expires. */
  refreshMode?: 'extractor' | 'capture' | 'youtube-native'
  /** Prefer provider audio-only extraction for music-first playback. */
  audioPreferred?: boolean
  /** Offline engine used when the durable source is a provider page rather than a direct file. */
  downloadEngine?: 'direct' | 'ytdlp'
  durationMs?: number
  /** Exact provider URI when a provider supports an external/session handoff (for example spotify:track:...). */
  providerUri?: string
  /** Resolver diagnostics retained for troubleshooting difficult provider changes. */
  resolverEngine?: string
  resolverTrail?: string
  resolverDelivery?: string
  resolverRecovery?: string
  resolvedAt?: number

  /** R8 recommendation/queue provenance. These are hints only; playback never depends on them. */
  recommendationReason?: string
  recommendationSeedId?: string
  queueOrigin?: 'manual' | 'autoplay' | 'collection'
}

export type Playlist = {
  id: string
  name: string
  tracks: Track[]
  createdAt: number
  updatedAt: number
}

export type HistoryEntry = Track & {
  playedAt: number
}

export type RepeatMode = 'off' | 'all' | 'one'

export type TasteEventKind = 'play' | 'complete' | 'skip' | 'dislike' | 'like' | 'unlike' | 'queue' | 'playlist'
export type TasteEvent = {
  videoId: string
  kind: TasteEventKind
  at: number
  /** Optional playback ratio (0..1) when the event was recorded. */
  progress?: number
  /** Identity snapshot keeps taste useful even after history/queue entries rotate out. */
  artistKey?: string
  canonicalKey?: string
  title?: string
  channel?: string
}

export type RadioMode = 'balanced' | 'stay' | 'deeper' | 'surprise' | 'energy' | 'chill'
export type RadioTuning = {
  mode: RadioMode
  /** 0 = mostly familiar, 100 = aggressively explore new artists. */
  discovery: number
  /** 0 = coherent/same-artist friendly, 100 = high artist diversity. */
  variety: number
}

export type LyricsLine = {
  startMs: number
  text: string
}

export type LyricsResult = {
  videoId: string
  /** Cache/request fingerprint: video id + healed song identity. Prevents stale lyrics crossing tracks. */
  identityKey?: string
  text: string
  source: string
  synced?: boolean
  lines?: LyricsLine[]
  fetchedAt?: number
}

export type OfflineCopy = {
  videoId: string
  localUri: string
  filename: string
  mimeType?: string
  bytes?: number
  addedAt: number
  platform: 'android' | 'pc'
  title?: string
  channel?: string
  thumbnail?: string
  provider?: MediaProvider
  sourceUrl?: string
  mediaKind?: MediaKind
}

export type SidePlayState = {
  schemaVersion: number
  favorites: Track[]
  playlists: Playlist[]
  history: HistoryEntry[]
  queue: Track[]
  currentIndex: number
  repeat: RepeatMode
  shuffle: boolean
  youtubeApiKey: string
  playCounts: Record<string, number>
  skipCounts: Record<string, number>
  completionCounts: Record<string, number>
  /** R9 event stream used by the decaying taste/session model. Capped in store.tsx. */
  tasteEvents: TasteEvent[]
  offline: Record<string, OfflineCopy>
  preferOffline: boolean
}
