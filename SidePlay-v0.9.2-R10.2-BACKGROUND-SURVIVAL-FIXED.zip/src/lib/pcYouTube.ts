import type { Track } from '../types'

const DEFAULT_BRIDGE = 'http://127.0.0.1:4783'

export async function pcSearchYouTube(query: string, limit = 25): Promise<Track[]> {
  const url = new URL('/api/search', DEFAULT_BRIDGE)
  url.searchParams.set('q', query)
  url.searchParams.set('limit', String(limit))
  const res = await fetch(url, { cache: 'no-store' })
  const data = await safeJson(res)
  if (!res.ok) throw new Error(data?.error || `PC search bridge error (${res.status})`)
  if (!Array.isArray(data?.tracks) || !data.tracks.length) throw new Error('No YouTube results found.')
  return data.tracks
}


export async function pcSuggestYouTube(query: string, limit = 10, hl = 'en', gl = 'US'): Promise<string[]> {
  const url = new URL('/api/suggest', DEFAULT_BRIDGE)
  url.searchParams.set('q', query)
  url.searchParams.set('limit', String(limit))
  url.searchParams.set('hl', hl)
  url.searchParams.set('gl', gl)
  const res = await fetch(url, { cache: 'no-store' })
  const data = await safeJson(res)
  if (!res.ok) throw new Error(data?.error || `PC suggestion bridge error (${res.status})`)
  return Array.isArray(data?.suggestions) ? data.suggestions.filter((x: unknown) => typeof x === 'string') : []
}

export async function pcGetVideo(videoId: string): Promise<Track> {
  const url = new URL('/api/video', DEFAULT_BRIDGE)
  url.searchParams.set('id', videoId)
  const res = await fetch(url, { cache: 'no-store' })
  const data = await safeJson(res)
  if (!res.ok) throw new Error(data?.error || `PC metadata bridge error (${res.status})`)
  if (!data?.track) throw new Error('Video metadata was unavailable.')
  return data.track
}

export async function pcBridgeHealthy(): Promise<boolean> {
  try {
    const res = await fetch(`${DEFAULT_BRIDGE}/health`, { cache: 'no-store' })
    return res.ok
  } catch {
    return false
  }
}

async function safeJson(res: Response): Promise<any> {
  try { return await res.json() } catch { return null }
}
