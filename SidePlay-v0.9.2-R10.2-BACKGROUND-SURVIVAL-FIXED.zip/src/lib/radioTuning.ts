import type { RadioMode, RadioTuning } from '../types'

export const DEFAULT_RADIO_TUNING: RadioTuning = {
  mode: 'balanced',
  discovery: 42,
  variety: 62,
}

export type RadioTunePreset = {
  id: RadioMode
  label: string
  description: string
  tuning: RadioTuning
}

export const RADIO_TUNING_PRESETS: RadioTunePreset[] = [
  {
    id: 'stay',
    label: 'Stay here',
    description: 'Very close to this artist and this exact pocket.',
    tuning: { mode: 'stay', discovery: 12, variety: 24 },
  },
  {
    id: 'deeper',
    label: 'Go deeper',
    description: 'Deep cuts, album tracks and nearby songs without going random.',
    tuning: { mode: 'deeper', discovery: 30, variety: 44 },
  },
  {
    id: 'surprise',
    label: 'Surprise me',
    description: 'Push into new artists and less obvious neighbors.',
    tuning: { mode: 'surprise', discovery: 88, variety: 88 },
  },
  {
    id: 'energy',
    label: 'Energy',
    description: 'Bias toward harder, faster and more energetic picks.',
    tuning: { mode: 'energy', discovery: 56, variety: 70 },
  },
  {
    id: 'chill',
    label: 'Chill',
    description: 'Keep the neighborhood smoother and lower-energy.',
    tuning: { mode: 'chill', discovery: 38, variety: 54 },
  },
  {
    id: 'balanced',
    label: 'Balanced',
    description: 'A stable mix of familiar music and controlled discovery.',
    tuning: { ...DEFAULT_RADIO_TUNING },
  },
]

const MODES = new Set<RadioMode>(['balanced', 'stay', 'deeper', 'surprise', 'energy', 'chill'])

export function clampRadioTuning(input?: Partial<RadioTuning>): RadioTuning {
  const mode = input?.mode && MODES.has(input.mode) ? input.mode : DEFAULT_RADIO_TUNING.mode
  return {
    mode,
    discovery: Math.max(0, Math.min(100, Number(input?.discovery ?? DEFAULT_RADIO_TUNING.discovery))),
    variety: Math.max(0, Math.min(100, Number(input?.variety ?? DEFAULT_RADIO_TUNING.variety))),
  }
}

export function presetRadioTuning(mode: RadioMode): RadioTuning {
  const preset = RADIO_TUNING_PRESETS.find((item) => item.id === mode)
  return { ...(preset?.tuning || DEFAULT_RADIO_TUNING) }
}

export function radioTuningKey(tuningInput?: Partial<RadioTuning>) {
  const tuning = clampRadioTuning(tuningInput)
  return `${tuning.mode}:${Math.round(tuning.discovery)}:${Math.round(tuning.variety)}`
}

export function radioTuningSummary(tuningInput?: Partial<RadioTuning>) {
  const tuning = clampRadioTuning(tuningInput)
  const discovery = tuning.discovery >= 75 ? 'adventurous' : tuning.discovery >= 45 ? 'mixed discovery' : 'familiar'
  const variety = tuning.variety >= 75 ? 'wide artist mix' : tuning.variety >= 45 ? 'balanced variety' : 'tight neighborhood'
  const preset = RADIO_TUNING_PRESETS.find((item) => item.id === tuning.mode)
  return `${preset?.label || 'Balanced'} · ${discovery} · ${variety}`
}

/**
 * Pure scoring controls for the tune engine. Keeping these biases separate makes
 * the sliders testable and prevents a huge related-source bonus from making
 * Discovery/Variety look like placebo controls.
 */
export function radioTuneBias(
  tuningInput: Partial<RadioTuning> | undefined,
  traits: { sameArtist: boolean; knownArtist: boolean; related: boolean },
) {
  const tuning = clampRadioTuning(tuningInput)
  const discovery = tuning.discovery / 100
  const variety = tuning.variety / 100

  let score = 0

  if (traits.sameArtist) {
    // High variety/discovery should be able to overcome the default same-artist pull.
    score += (1 - variety) * 5.2 - variety * 2.8
    score += (1 - discovery) * 2.2 - discovery * 1.2
  }

  if (traits.knownArtist) score += (1 - discovery) * 4.8 - discovery * 0.6
  else score += discovery * 5.6 - (1 - discovery) * 1.4

  // Related/watch-next remains useful, but its dominance falls as discovery rises.
  if (traits.related) score += 4.8 * (1 - discovery * 0.72)
  else score += 1.4 + discovery * 3.4

  if (tuning.mode === 'stay') {
    if (traits.sameArtist) score += 7.5
    if (traits.related) score += 3.2
    if (!traits.knownArtist) score -= 2.0
  } else if (tuning.mode === 'deeper') {
    if (traits.sameArtist) score += 4.5
    if (traits.related) score += 1.2
    if (traits.knownArtist && !traits.sameArtist) score -= 0.8
  } else if (tuning.mode === 'surprise') {
    if (traits.sameArtist) score -= 6.0
    if (!traits.knownArtist) score += 5.0
    if (!traits.related) score += 2.2
  }

  return score
}

export function radioSourceBase(tuningInput: Partial<RadioTuning> | undefined, related: boolean) {
  const tuning = clampRadioTuning(tuningInput)
  const discovery = tuning.discovery / 100
  if (related) return 15.5 - discovery * 5.5
  return 10.5 + discovery * 5.5
}
