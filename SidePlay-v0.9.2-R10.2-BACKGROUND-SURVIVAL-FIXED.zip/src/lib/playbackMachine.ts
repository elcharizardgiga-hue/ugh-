export type PlaybackPhase =
  | 'idle'
  | 'resolving'
  | 'preparing'
  | 'buffering'
  | 'playing'
  | 'paused'
  | 'recovering'
  | 'ended'
  | 'failed'

export type PlaybackMachineSnapshot = {
  phase: PlaybackPhase
  trackId: string
  since: number
  previous?: PlaybackPhase
  reason?: string
  transitions: number
}

class PlaybackMachine {
  private state: PlaybackMachineSnapshot = {
    phase: 'idle',
    trackId: '',
    since: Date.now(),
    transitions: 0,
  }

  transition(phase: PlaybackPhase, trackId = this.state.trackId, reason = '') {
    if (phase === this.state.phase && trackId === this.state.trackId && reason === (this.state.reason || '')) return this.snapshot()
    this.state = {
      phase,
      trackId,
      since: Date.now(),
      previous: this.state.phase,
      reason: reason || undefined,
      transitions: this.state.transitions + 1,
    }
    return this.snapshot()
  }

  snapshot(): PlaybackMachineSnapshot {
    return { ...this.state }
  }
}

/** Single app-level playback state authority for UI/diagnostics. Native Media3 still
 * owns actual audio; this machine prevents React booleans from becoming the source of truth. */
export const playbackMachine = new PlaybackMachine()
