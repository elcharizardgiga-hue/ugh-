import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import type { OfflineCopy, Playlist, RepeatMode, SidePlayState, TasteEventKind, Track } from '../types'
import { isGenericTrackChannel, isGenericTrackTitle, mergeTrackMetadata, repairTrackIdentity, repairTrackList } from './trackIdentity'
import { canonicalTrackKey, musicIdentity } from './musicIdentity'

const KEY = 'sideplay.state.v4'
const LEGACY_KEYS = ['sideplay.state.v3', 'sideplay.state.v2', 'sideplay.state.v1']
const STATE_SCHEMA_VERSION = 4

const initial: SidePlayState = {
  schemaVersion: STATE_SCHEMA_VERSION,
  favorites: [],
  playlists: [],
  history: [],
  queue: [],
  currentIndex: -1,
  repeat: 'off',
  shuffle: false,
  youtubeApiKey: '',
  playCounts: {},
  skipCounts: {},
  completionCounts: {},
  tasteEvents: [],
  offline: {},
  preferOffline: true,
}

type Ctx = {
  state: SidePlayState
  current: Track | null
  setApiKey: (key: string) => void
  playNow: (track: Track, queue?: Track[], options?: { preserveQueue?: boolean }) => void
  addQueue: (track: Track) => void
  appendQueue: (tracks: Track[]) => void
  replaceAutoplayQueue: (tracks: Track[]) => void
  playNext: (track: Track) => void
  removeQueue: (index: number) => void
  moveQueue: (from: number, to: number) => void
  clearQueue: () => void
  next: () => Track | null
  previous: () => Track | null
  toggleFavorite: (track: Track) => void
  isFavorite: (videoId: string) => boolean
  createPlaylist: (name: string) => Playlist
  renamePlaylist: (id: string, name: string) => void
  deletePlaylist: (id: string) => void
  addToPlaylist: (id: string, track: Track) => void
  removeFromPlaylist: (id: string, videoId: string) => void
  movePlaylistTrack: (id: string, from: number, to: number) => void
  setRepeat: (mode: RepeatMode) => void
  setShuffle: (value: boolean) => void
  setOfflineCopy: (copy: OfflineCopy) => void
  removeOfflineCopy: (videoId: string) => void
  getOfflineCopy: (videoId: string) => OfflineCopy | null
  setPreferOffline: (value: boolean) => void
  recordSkip: (videoId: string, progress?: number) => void
  recordDislike: (track: Track) => void
  recordCompletion: (videoId: string, progress?: number) => void
  updateTrackMetadata: (track: Track) => void
  mergeHistory: (tracks: Track[]) => void
  clearHistory: () => void
  exportLibrary: () => string
  importLibrary: (json: string) => void
}

const SidePlayContext = createContext<Ctx | null>(null)

const MAX_TASTE_EVENTS = 1200
const addTasteEvent = (events: SidePlayState['tasteEvents'], track: Pick<Track, 'videoId' | 'title' | 'channel'> | null | undefined, kind: TasteEventKind, progress?: number) => {
  if (!track?.videoId) return events || []
  const hasTitle = !isGenericTrackTitle(track.title, track.videoId)
  const hasChannel = !isGenericTrackChannel(track.channel)
  const hasIdentity = hasTitle && hasChannel
  const identity = hasIdentity ? musicIdentity(track as Track) : null
  const event = {
    videoId: track.videoId,
    kind,
    at: Date.now(),
    // Never freeze placeholder metadata into Taste. A video-id-only event can be
    // enriched later from the healed catalog; "unknown artist" must not become a
    // permanent artist bucket shared by unrelated songs.
    artistKey: identity?.artistKey || undefined,
    canonicalKey: identity ? canonicalTrackKey(track as Track) || undefined : undefined,
    title: hasTitle ? track.title : undefined,
    channel: hasChannel ? track.channel : undefined,
    ...(typeof progress === 'number' ? { progress: Math.max(0, Math.min(1, progress)) } : {}),
  }
  return [event, ...(events || [])].slice(0, MAX_TASTE_EVENTS)
}

const findTrackById = (state: SidePlayState, videoId: string): Track | null => {
  if (!videoId) return null
  return state.queue.find((t) => t.videoId === videoId)
    || state.history.find((t) => t.videoId === videoId)
    || state.favorites.find((t) => t.videoId === videoId)
    || state.playlists.flatMap((p) => p.tracks).find((t) => t.videoId === videoId)
    || null
}

const mergeEverywhere = (state: SidePlayState, incoming: Track): SidePlayState => {
  const repaired = repairTrackIdentity(incoming)
  const merge = <T extends Track>(track: T): T => track.videoId === repaired.videoId ? mergeTrackMetadata(track, repaired) as T : track
  const identity = !isGenericTrackTitle(repaired.title, repaired.videoId) && !isGenericTrackChannel(repaired.channel)
    ? musicIdentity(repaired)
    : null
  const canonical = identity ? canonicalTrackKey(repaired) : ''
  const offline = { ...(state.offline || {}) }
  const saved = offline[repaired.videoId]
  if (saved) {
    offline[repaired.videoId] = {
      ...saved,
      title: !isGenericTrackTitle(repaired.title, repaired.videoId) ? repaired.title : saved.title,
      channel: !isGenericTrackChannel(repaired.channel) ? repaired.channel : saved.channel,
      thumbnail: repaired.thumbnail || saved.thumbnail,
      provider: repaired.provider || saved.provider,
      sourceUrl: repaired.sourceUrl || saved.sourceUrl,
      mediaKind: repaired.mediaKind || saved.mediaKind,
    }
  }
  return {
    ...state,
    queue: state.queue.map(merge),
    history: state.history.map(merge),
    favorites: state.favorites.map(merge),
    playlists: state.playlists.map((playlist) => ({ ...playlist, tracks: playlist.tracks.map(merge) })),
    offline,
    // Heal old Taste snapshots too. Otherwise a historical "unknown artist"
    // snapshot remains truthy forever and can override newly repaired metadata.
    tasteEvents: state.tasteEvents.map((event) => event.videoId === repaired.videoId && identity ? {
      ...event,
      artistKey: identity.artistKey || event.artistKey,
      canonicalKey: canonical || event.canonicalKey,
      title: repaired.title || event.title,
      channel: repaired.channel || event.channel,
    } : event),
  }
}

const uniqueTracks = (tracks: Track[]) => {
  const order: string[] = []
  const merged = new Map<string, Track>()
  for (const track of tracks) {
    if (!track?.videoId) continue
    const existing = merged.get(track.videoId)
    if (!existing) {
      order.push(track.videoId)
      merged.set(track.videoId, track)
    } else {
      // Preserve first-seen ordering while allowing later, better resolver/catalog
      // metadata to repair the existing entry instead of being silently discarded.
      merged.set(track.videoId, mergeTrackMetadata(existing, track))
    }
  }
  return order.map((id) => merged.get(id)!).filter(Boolean)
}

// R10 Queue v2: queue identity is musical identity when metadata is healthy, not
// merely a provider/video id. Manual intent also wins over autoplay provenance.
const uniqueQueueTracks = (tracks: Track[]) => {
  const order: string[] = []
  const merged = new Map<string, Track>()
  for (const raw of repairTrackList(tracks)) {
    if (!raw?.videoId) continue
    const key = (!isGenericTrackTitle(raw.title, raw.videoId) && !isGenericTrackChannel(raw.channel))
      ? (canonicalTrackKey(raw) || raw.videoId)
      : raw.videoId
    const existing = merged.get(key)
    if (!existing) {
      order.push(key)
      merged.set(key, raw)
      continue
    }
    const repaired = mergeTrackMetadata(existing, raw)
    merged.set(key, {
      ...repaired,
      queueOrigin: existing.queueOrigin === 'manual' || raw.queueOrigin === 'manual'
        ? 'manual'
        : (existing.queueOrigin || raw.queueOrigin),
    })
  }
  return order.map((key) => merged.get(key)!).filter(Boolean)
}

const appendQueueV2 = (state: SidePlayState, incoming: Track[]) => {
  const repaired = repairTrackList(incoming).map(stripRequestContext)
  const currentPrefix = state.currentIndex >= 0 ? state.queue.slice(0, state.currentIndex + 1) : []
  const upcoming = state.currentIndex >= 0 ? state.queue.slice(state.currentIndex + 1) : state.queue
  const manual = upcoming.filter((item) => item.queueOrigin !== 'autoplay')
  const autoplay = upcoming.filter((item) => item.queueOrigin === 'autoplay')
  const incomingManual = repaired.filter((item) => item.queueOrigin !== 'autoplay')
  const incomingAutoplay = repaired.filter((item) => item.queueOrigin === 'autoplay')
  return uniqueQueueTracks([
    ...currentPrefix,
    ...manual,
    ...incomingManual,
    ...autoplay,
    ...incomingAutoplay,
  ])
}

// Browser-captured request context may contain cookies/session tokens and must
// remain runtime-only. Extractor resolutions are different: SidePlay itself
// generated the clear media URL, and App.tsx already treats it as stale after
// 20 minutes. Preserve that short-lived resolver cache across an Android process
// restart so a crash/relaunch does not immediately force another heavy yt-dlp run.
const stripRequestContext = <T extends Track>(track: T): T => {
  const allowed = new Set(['user-agent', 'referer', 'origin', 'accept', 'accept-language'])
  const safeHeaders = Object.fromEntries(Object.entries(track.requestHeaders || {}).filter(([key]) => allowed.has(key.toLowerCase())))

  if (track.sessionBound) {
    if (track.refreshMode === 'extractor' || track.refreshMode === 'youtube-native') {
      // Extractor results may be cached briefly; App.tsx refreshes them after ~20m.
      // Persist only ordinary replay headers, never Cookie/Authorization/session state.
      if (Object.keys(safeHeaders).length) return { ...track, requestHeaders: safeHeaders }
      const { requestHeaders: _requestHeaders, ...safe } = track
      return safe as T
    }
    // Interactive browser captures remain ephemeral because they can carry session state.
    const { requestHeaders: _requestHeaders, playbackUrl: _playbackUrl, downloadUrl: _downloadUrl, capturedAt: _capturedAt, ...safe } = track
    return safe as T
  }

  if (Object.keys(safeHeaders).length) return { ...track, requestHeaders: safeHeaders }
  const { requestHeaders: _requestHeaders, ...safe } = track
  return safe as T
}

const migrateState = (value: unknown): SidePlayState => {
  const parsed = value && typeof value === 'object' ? value as Partial<SidePlayState> : {}
  const migrated: SidePlayState = {
    ...initial,
    ...parsed,
    schemaVersion: STATE_SCHEMA_VERSION,
    playCounts: { ...(parsed.playCounts || {}) },
    skipCounts: { ...(parsed.skipCounts || {}) },
    completionCounts: { ...(parsed.completionCounts || {}) },
    tasteEvents: Array.isArray(parsed.tasteEvents) ? parsed.tasteEvents
      .filter((event) => event && typeof event.videoId === 'string' && typeof event.kind === 'string')
      .slice(0, MAX_TASTE_EVENTS)
      .map((event) => ({
        ...event,
        artistKey: event.artistKey && !/^(?:unknown|unknown artist|youtube|web|direct)$/.test(event.artistKey) ? event.artistKey : undefined,
        canonicalKey: event.canonicalKey && !/(?:^unknown::|untitled|youtube video)/.test(event.canonicalKey) ? event.canonicalKey : undefined,
        title: event.title && !isGenericTrackTitle(event.title, event.videoId) ? event.title : undefined,
        channel: event.channel && !isGenericTrackChannel(event.channel) ? event.channel : undefined,
      })) : [],
    offline: { ...(parsed.offline || {}) },
    favorites: repairTrackList(parsed.favorites || []),
    history: repairTrackList(parsed.history || []) as SidePlayState['history'],
    queue: repairTrackList(parsed.queue || []),
    playlists: (parsed.playlists || []).map((playlist) => ({ ...playlist, tracks: repairTrackList(playlist.tracks || []) })),
  }
  if (migrated.currentIndex >= migrated.queue.length) migrated.currentIndex = migrated.queue.length ? migrated.queue.length - 1 : -1
  if (migrated.currentIndex < -1) migrated.currentIndex = -1
  return migrated
}

const loadPersistedState = (): SidePlayState => {
  try {
    const raw = localStorage.getItem(KEY) || LEGACY_KEYS.map((key) => localStorage.getItem(key)).find(Boolean)
    return raw ? migrateState(JSON.parse(raw)) : initial
  } catch {
    return initial
  }
}

const persistableState = (state: SidePlayState): SidePlayState => ({
  ...state,
  schemaVersion: STATE_SCHEMA_VERSION,
  favorites: repairTrackList(state.favorites).map(stripRequestContext),
  history: repairTrackList(state.history).map(stripRequestContext),
  queue: repairTrackList(state.queue).map(stripRequestContext),
  playlists: state.playlists.map((playlist) => ({ ...playlist, tracks: repairTrackList(playlist.tracks).map(stripRequestContext) })),
})

export function SidePlayProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<SidePlayState>(() => persistableState(loadPersistedState()))

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(persistableState(state)))
  }, [state])

  const current = state.currentIndex >= 0 ? state.queue[state.currentIndex] ?? null : null

  const api = useMemo<Ctx>(() => ({
    state,
    current,
    setApiKey: (youtubeApiKey) => setState((s) => ({ ...s, youtubeApiKey })),
    playNow: (track, queue, options) => setState((s) => {
      const repairedTrack = repairTrackIdentity(track)
      let nextQueue: Track[]
      if (options?.preserveQueue) {
        const live = repairTrackList(s.queue)
        const existing = live.findIndex((item) => item.videoId === repairedTrack.videoId)
        if (existing >= 0) {
          nextQueue = live.map((item, index) => index === existing ? { ...mergeTrackMetadata(item, repairedTrack), queueOrigin: item.queueOrigin || repairedTrack.queueOrigin } : item)
        } else {
          nextQueue = uniqueQueueTracks([...live, repairedTrack])
        }
      } else if (queue?.length) {
        nextQueue = uniqueQueueTracks(repairTrackList(queue)).map((item) => item.videoId === repairedTrack.videoId ? { ...mergeTrackMetadata(item, repairedTrack), queueOrigin: item.queueOrigin || repairedTrack.queueOrigin } : item)
      } else {
        nextQueue = [repairedTrack]
      }
      const index = Math.max(0, nextQueue.findIndex((x) => x.videoId === repairedTrack.videoId))
      return {
        ...s,
        queue: nextQueue,
        currentIndex: index,
        history: [{ ...stripRequestContext(repairedTrack), playedAt: Date.now() }, ...s.history.filter((h) => h.videoId !== repairedTrack.videoId)].slice(0, 200),
        playCounts: { ...s.playCounts, [repairedTrack.videoId]: (s.playCounts?.[repairedTrack.videoId] ?? 0) + 1 },
        tasteEvents: addTasteEvent(s.tasteEvents, repairedTrack, 'play'),
      }
    }),
    // Queueing is passive: adding something to an empty queue must not start playback.
    addQueue: (track) => setState((s) => {
      const manual = { ...stripRequestContext(repairTrackIdentity(track)), queueOrigin: 'manual' as const }
      const existingIndex = s.queue.findIndex((item) => item.videoId === manual.videoId)
      // Never move the song that is already playing just because the user taps Add to queue.
      if (existingIndex === s.currentIndex && existingIndex >= 0) return s
      const without = s.queue.filter((item) => item.videoId !== manual.videoId)
      const currentIndex = s.currentIndex - (existingIndex >= 0 && existingIndex < s.currentIndex ? 1 : 0)
      const firstAutoplay = without.findIndex((item, index) => index > currentIndex && item.queueOrigin === 'autoplay')
      const insertAt = firstAutoplay >= 0 ? firstAutoplay : without.length
      const queue = [...without]
      queue.splice(insertAt, 0, manual)
      return { ...s, queue, currentIndex, tasteEvents: addTasteEvent(s.tasteEvents, manual, 'queue') }
    }),
    appendQueue: (tracks) => setState((s) => {
      const currentId = s.currentIndex >= 0 ? s.queue[s.currentIndex]?.videoId : ''
      const queue = appendQueueV2(s, tracks)
      const currentIndex = currentId ? Math.max(0, queue.findIndex((item) => item.videoId === currentId)) : s.currentIndex
      return { ...s, queue, currentIndex }
    }),
    // R10 TUNE V2: replace only the generated/autoplay tail. The current track,
    // already-played prefix and every manual Up Next choice stay exactly where the
    // listener put them. This makes Tune apply immediately without restarting music.
    replaceAutoplayQueue: (tracks) => setState((s) => {
      const currentId = s.currentIndex >= 0 ? s.queue[s.currentIndex]?.videoId : ''
      const prefix = s.currentIndex >= 0 ? s.queue.slice(0, s.currentIndex + 1) : []
      const upcoming = s.currentIndex >= 0 ? s.queue.slice(s.currentIndex + 1) : s.queue
      const manual = upcoming.filter((item) => item.queueOrigin !== 'autoplay')
      const tunedAutoplay = repairTrackList(tracks)
        .map(stripRequestContext)
        .map((item) => ({ ...item, queueOrigin: 'autoplay' as const }))
      const queue = uniqueQueueTracks([...prefix, ...manual, ...tunedAutoplay])
      const currentIndex = currentId ? Math.max(0, queue.findIndex((item) => item.videoId === currentId)) : s.currentIndex
      return { ...s, queue, currentIndex }
    }),
    playNext: (track) => setState((s) => {
      const repaired = { ...stripRequestContext(repairTrackIdentity(track)), queueOrigin: 'manual' as const }
      const existingIndex = s.queue.findIndex((x) => x.videoId === repaired.videoId)
      // Re-queueing the currently playing item must not corrupt currentIndex.
      if (existingIndex === s.currentIndex && existingIndex >= 0) return s
      if (s.currentIndex < 0) {
        const without = s.queue.filter((x) => x.videoId !== repaired.videoId)
        return { ...s, queue: [repaired, ...without], tasteEvents: addTasteEvent(s.tasteEvents, repaired, 'queue') }
      }
      const without = s.queue.filter((x) => x.videoId !== repaired.videoId)
      const currentIndex = s.currentIndex - (existingIndex >= 0 && existingIndex < s.currentIndex ? 1 : 0)
      const q = [...without]
      q.splice(currentIndex + 1, 0, repaired)
      return { ...s, queue: q, currentIndex, tasteEvents: addTasteEvent(s.tasteEvents, repaired, 'queue') }
    }),
    removeQueue: (index) => setState((s) => {
      const q = s.queue.filter((_, i) => i !== index)
      let currentIndex = s.currentIndex
      if (!q.length) currentIndex = -1
      else if (index < s.currentIndex) currentIndex -= 1
      else if (index === s.currentIndex) currentIndex = Math.min(currentIndex, q.length - 1)
      return { ...s, queue: q, currentIndex }
    }),
    moveQueue: (from, to) => setState((s) => {
      if (to < 0 || to >= s.queue.length || from === to) return s
      const q = [...s.queue]
      const [item] = q.splice(from, 1)
      q.splice(to, 0, item)
      let idx = s.currentIndex
      if (idx === from) idx = to
      else if (from < idx && to >= idx) idx -= 1
      else if (from > idx && to <= idx) idx += 1
      return { ...s, queue: q, currentIndex: idx }
    }),
    // 'Clear queue' means clear Up Next, not stop the song that is already playing.
    clearQueue: () => setState((s) => {
      if (s.currentIndex < 0) return { ...s, queue: [] }
      return { ...s, queue: s.queue.slice(0, s.currentIndex + 1) }
    }),
    // Queue navigation only chooses the target. `playNow` is the single place
    // that records history/play counts, avoiding double-counts when Next/Previous
    // immediately hand the selected item back through the resolver/player path.
    // Navigation must choose synchronously. React may defer functional state updaters,
    // so assigning `chosen` inside setState() and returning it immediately can return
    // null at end-of-track even when the queue has a valid next item.
    next: () => {
      if (!state.queue.length) return null
      let idx = state.currentIndex
      let chosen: Track | null = null
      if (idx < 0) {
        idx = 0
        chosen = state.queue[0] || null
      } else if (state.repeat === 'one') {
        chosen = state.queue[idx] || null
      } else if (state.shuffle && state.queue.length > 1) {
        do idx = Math.floor(Math.random() * state.queue.length)
        while (idx === state.currentIndex)
        chosen = state.queue[idx] || null
      } else if (idx + 1 < state.queue.length) {
        idx += 1
        chosen = state.queue[idx] || null
      } else if (state.repeat === 'all') {
        idx = 0
        chosen = state.queue[0] || null
      }
      if (!chosen) return null
      const targetId = chosen.videoId
      setState((s) => {
        const targetIndex = s.queue.findIndex((item) => item.videoId === targetId)
        return targetIndex >= 0 ? { ...s, currentIndex: targetIndex } : s
      })
      return chosen
    },
    previous: () => {
      if (!state.queue.length || state.currentIndex < 0) return null
      const idx = state.currentIndex > 0 ? state.currentIndex - 1 : (state.repeat === 'all' ? state.queue.length - 1 : 0)
      const chosen = state.queue[idx] || null
      if (!chosen) return null
      const targetId = chosen.videoId
      setState((s) => {
        const targetIndex = s.queue.findIndex((item) => item.videoId === targetId)
        return targetIndex >= 0 ? { ...s, currentIndex: targetIndex } : s
      })
      return chosen
    },
    toggleFavorite: (track) => setState((s) => {
      track = repairTrackIdentity(track)
      const exists = s.favorites.some((x) => x.videoId === track.videoId)
      return { ...s, favorites: exists ? s.favorites.filter((x) => x.videoId !== track.videoId) : [stripRequestContext(track), ...s.favorites], tasteEvents: addTasteEvent(s.tasteEvents, track, exists ? 'unlike' : 'like') }
    }),
    isFavorite: (videoId) => state.favorites.some((x) => x.videoId === videoId),
    createPlaylist: (name) => {
      const playlist: Playlist = { id: crypto.randomUUID(), name: name.trim() || 'Untitled playlist', tracks: [], createdAt: Date.now(), updatedAt: Date.now() }
      setState((s) => ({ ...s, playlists: [playlist, ...s.playlists] }))
      return playlist
    },
    renamePlaylist: (id, name) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, name: name.trim() || p.name, updatedAt: Date.now() } : p) })),
    deletePlaylist: (id) => setState((s) => ({ ...s, playlists: s.playlists.filter((p) => p.id !== id) })),
    addToPlaylist: (id, track) => setState((s) => {
      const repaired = repairTrackIdentity(track)
      return { ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, tracks: uniqueTracks([...p.tracks, stripRequestContext(repaired)]), updatedAt: Date.now() } : p), tasteEvents: addTasteEvent(s.tasteEvents, repaired, 'playlist') }
    }),
    removeFromPlaylist: (id, videoId) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, tracks: p.tracks.filter((t) => t.videoId !== videoId), updatedAt: Date.now() } : p) })),
    movePlaylistTrack: (id, from, to) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => {
      if (p.id !== id || to < 0 || to >= p.tracks.length) return p
      const tracks = [...p.tracks]
      const [item] = tracks.splice(from, 1)
      tracks.splice(to, 0, item)
      return { ...p, tracks, updatedAt: Date.now() }
    }) })),
    setRepeat: (repeat) => setState((s) => ({ ...s, repeat })),
    setShuffle: (shuffle) => setState((s) => ({ ...s, shuffle })),
    setOfflineCopy: (copy) => setState((s) => ({ ...s, offline: { ...(s.offline || {}), [copy.videoId]: copy } })),
    removeOfflineCopy: (videoId) => setState((s) => { const offline = { ...(s.offline || {}) }; delete offline[videoId]; return { ...s, offline } }),
    getOfflineCopy: (videoId) => state.offline?.[videoId] || null,
    setPreferOffline: (preferOffline) => setState((s) => ({ ...s, preferOffline })),
    recordSkip: (videoId, progress) => setState((s) => {
      if (!videoId) return s
      const track = findTrackById(s, videoId)
      return { ...s, skipCounts: { ...s.skipCounts, [videoId]: (s.skipCounts?.[videoId] ?? 0) + 1 }, tasteEvents: addTasteEvent(s.tasteEvents, track || { videoId, title: '', channel: '' }, 'skip', progress) }
    }),
    recordDislike: (track) => setState((s) => {
      const repaired = repairTrackIdentity(track)
      return { ...s, tasteEvents: addTasteEvent(s.tasteEvents, repaired, 'dislike', 0) }
    }),
    recordCompletion: (videoId, progress) => setState((s) => {
      if (!videoId) return s
      const track = findTrackById(s, videoId)
      return { ...s, completionCounts: { ...s.completionCounts, [videoId]: (s.completionCounts?.[videoId] ?? 0) + 1 }, tasteEvents: addTasteEvent(s.tasteEvents, track || { videoId, title: '', channel: '' }, 'complete', progress) }
    }),
    updateTrackMetadata: (track) => setState((s) => mergeEverywhere(s, track)),
    clearHistory: () => setState((s) => ({ ...s, history: [] })),
    mergeHistory: (tracks) => setState((s) => {
      const now = Date.now()
      const imported = uniqueTracks(repairTrackList(tracks)).map((t, i) => ({ ...stripRequestContext(t), playedAt: now - i }))
      const seen = new Set(imported.map(t => t.videoId))
      return { ...s, history: [...imported, ...s.history.filter(h => !seen.has(h.videoId))].slice(0, 500) }
    }),
    exportLibrary: () => JSON.stringify(persistableState(state), null, 2),
    importLibrary: (json) => {
      const parsed = JSON.parse(json)
      setState(persistableState(migrateState(parsed)))
    },
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [state, current])

  return <SidePlayContext.Provider value={api}>{children}</SidePlayContext.Provider>
}

export function useSidePlay() {
  const ctx = useContext(SidePlayContext)
  if (!ctx) throw new Error('useSidePlay must be used inside SidePlayProvider')
  return ctx
}
