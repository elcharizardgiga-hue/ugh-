import type { RadioTuning, SidePlayState, Track } from '../types'
import { getRelatedYouTube, searchYouTube } from './youtube'
import { canonicalTrackKey, isNearDuplicateSong, isNoisyVariant, musicIdentity, normalizeMusicText, rankAndDedupeMusicSearch } from './musicIdentity'
import { buildTasteProfile, sessionAffinity, tasteScoreForTrack, type TasteProfile } from './tasteEngine'
import { isGenericTrackChannel, isGenericTrackTitle } from './trackIdentity'
import { DEFAULT_RADIO_TUNING, clampRadioTuning, radioSourceBase, radioTuneBias } from './radioTuning'

export type Mix = {
  id: string
  title: string
  subtitle: string
  tracks: Track[]
  accent: 'rose' | 'amber' | 'peach' | 'berry'
}

type Candidate = {
  track: Track
  score: number
  related: boolean
  reason?: string
}

export { DEFAULT_RADIO_TUNING } from './radioTuning'

const unique = (tracks: Track[]) => {
  const seen = new Set<string>()
  return tracks.filter((t) => t?.videoId && !seen.has(t.videoId) && seen.add(t.videoId))
}

const hasUsableMusicIdentity = (track: Track) => !!track?.videoId && !isGenericTrackTitle(track.title, track.videoId) && !isGenericTrackChannel(track.channel)

function hash(input: string) {
  let h = 2166136261
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

function seededShuffle<T>(items: T[], seed: string) {
  const out = [...items]
  let s = hash(seed) || 1
  const rand = () => {
    s ^= s << 13; s ^= s >>> 17; s ^= s << 5
    return (s >>> 0) / 4294967296
  }
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1))
    ;[out[i], out[j]] = [out[j], out[i]]
  }
  return out
}

function scoreCandidate(seed: Track, candidate: Track, state: SidePlayState, profile: TasteProfile, sourceBoost: number, rank: number, related: boolean, tuning: RadioTuning) {
  const seedId = musicIdentity(seed)
  const candidateId = musicIdentity(candidate)
  let score = sourceBoost + Math.max(0, 8 - rank * .28)
  const sameArtist = !!candidateId.artistKey && candidateId.artistKey === seedId.artistKey
  const knownArtist = profile.knownArtists.has(candidateId.artistKey)
  const discovery = tuning.discovery / 100
  const variety = tuning.variety / 100

  // Long-term + session taste. The latter is deliberately stronger so this session
  // can steer the next few tracks without rewriting the user's permanent taste.
  score += Math.max(-8, Math.min(11, tasteScoreForTrack(candidate, profile) * .42))
  score += Math.max(-5, Math.min(7, sessionAffinity(candidate, profile) * .58))

  // R10 TUNE V2: Discovery/Variety are real ranking controls, not cosmetic.
  // Previously the watch-next source boost + unconditional same-artist bonus was
  // large enough that moving the sliders barely changed the actual queue.
  score += radioTuneBias(tuning, { sameArtist, knownArtist, related })

  // A tiny coherence nudge remains at low variety, but it disappears as the
  // user asks for a wider artist mix.
  if (related) score += (1 - variety) * 1.1
  // R10.1 taste refinement: session affinity can otherwise become a feedback
  // loop where SidePlay keeps recommending the same artist because it just played
  // that artist. Recent exposure adds a fatigue counterweight unless Tune explicitly
  // asks to stay/deepen.
  const exposure = candidateId.artistKey ? (profile.recentArtistExposure.get(candidateId.artistKey) || 0) : 0
  if (exposure > 1.25 && tuning.mode !== 'stay' && tuning.mode !== 'deeper') {
    const fatigueStrength = 0.55 + variety * 0.95 + discovery * 0.40
    score -= Math.min(5.5, (exposure - 1.25) * fatigueStrength)
  }


  const channel = normalizeMusicText(candidate.channel)
  const title = normalizeMusicText(candidate.title)
  if (/ topic$/.test(channel) || /vevo/.test(channel) || (candidateId.artistKey && channel.includes(candidateId.artistKey))) score += 1.5
  if (/official audio|official music video|official video/.test(title)) score += .9
  if (isNoisyVariant(seed, candidate)) score -= 14

  if (tuning.mode === 'energy') {
    if (/remix|dance|club|edit|live|party|bass/.test(title)) score += 2.4
    if (/acoustic|sleep|slow|chill|lofi/.test(title)) score -= 2.2
  } else if (tuning.mode === 'chill') {
    if (/acoustic|chill|lofi|live session|unplugged|slow/.test(title)) score += 2.5
    if (/hardstyle|nightcore|bass boosted|sped up/.test(title)) score -= 2.5
  }

  const skips = state.skipCounts?.[candidate.videoId] || 0
  const completions = state.completionCounts?.[candidate.videoId] || 0
  score += Math.min(3, completions) * 1.1
  score -= Math.min(5, skips) * 2.2
  if (profile.stronglySkipped.has(candidate.videoId)) score -= 8

  let reason = related ? `Related to ${seedId.song || seed.title}` : `Based on ${seedId.song || seed.title}`
  if (sameArtist) reason = tuning.mode === 'deeper' ? `Deeper into ${candidateId.artist}` : `More from ${candidateId.artist}`
  else if ((profile.sessionArtistScores.get(candidateId.artistKey) || 0) >= 2.5) reason = 'Fits this session'
  else if ((profile.artistScores.get(candidateId.artistKey) || 0) >= 8) reason = 'Fits your rotation'
  else if (!knownArtist && tuning.discovery >= 60) reason = 'A little outside your rotation'
  else if (tuning.mode === 'surprise') reason = `A left turn from ${seedId.song || seed.title}`
  else if (tuning.mode === 'energy') reason = 'More energy for this radio'
  else if (tuning.mode === 'chill') reason = 'Keeping this radio laid-back'
  return { score, reason }
}

function normalizeRecommendation(track: Track, seed: Track, reason: string): Track {
  return {
    ...track,
    provider: track.provider || 'youtube',
    sourceUrl: track.sourceUrl || (/^[A-Za-z0-9_-]{11}$/.test(track.videoId) ? `https://www.youtube.com/watch?v=${track.videoId}` : track.sourceUrl),
    audioPreferred: track.audioPreferred ?? true,
    mediaKind: track.mediaKind || 'audio',
    recommendationReason: reason,
    recommendationSeedId: seed.videoId,
  }
}

function rankCandidates(seed: Track, state: SidePlayState, candidates: Candidate[], limit: number, tuningInput?: Partial<RadioTuning>) {
  const tuning = clampRadioTuning(tuningInput)
  const recentCanonical = new Set(state.history.slice(0, tuning.discovery >= 70 ? 18 : 35).map(canonicalTrackKey))
  const queueCanonical = new Set(state.queue.map(canonicalTrackKey))
  const profile = buildTasteProfile(state)
  const merged = new Map<string, Candidate>()

  for (const item of candidates) {
    const track = item.track
    const canonical = track ? canonicalTrackKey(track) : ''
    if (!track?.videoId || isGenericTrackTitle(track.title, track.videoId) || recentCanonical.has(canonical) || queueCanonical.has(canonical) || isNearDuplicateSong(seed, track)) continue
    const scored = scoreCandidate(seed, track, state, profile, item.score, 0, item.related, tuning)
    const normalized: Candidate = { ...item, score: scored.score, reason: scored.reason }
    const existing = merged.get(canonical || track.videoId)
    if (!existing || normalized.score > existing.score) merged.set(canonical || track.videoId, normalized)
  }

  const sorted = [...merged.values()].sort((a, b) => b.score - a.score)
  const artistCounts = new Map<string, number>()
  const out: Track[] = []
  const artistCap = tuning.mode === 'stay' ? 5 : tuning.variety >= 75 ? 1 : tuning.variety >= 40 ? 2 : 3
  for (const item of sorted) {
    const id = musicIdentity(item.track)
    const count = artistCounts.get(id.artistKey) || 0
    if (id.artistKey && count >= artistCap) continue
    if (id.artistKey) artistCounts.set(id.artistKey, count + 1)
    out.push(normalizeRecommendation(item.track, seed, item.reason || `Based on ${musicIdentity(seed).song}`))
    if (out.length >= limit) break
  }
  return out
}

export function localMixes(state: SidePlayState): Mix[] {
  const day = new Date().toISOString().slice(0, 10)
  const playlistPool = state.playlists.flatMap((p) => p.tracks)
  const profile = buildTasteProfile(state)
  const rotation = unique([
    ...[...state.history].sort((a, b) => tasteScoreForTrack(b, profile) - tasteScoreForTrack(a, profile)),
    ...state.favorites,
    ...playlistPool,
  ]).filter(hasUsableMusicIdentity)
  const liked = unique(state.favorites).filter(hasUsableMusicIdentity)
  const everything = unique([...state.history, ...liked, ...playlistPool]).filter(hasUsableMusicIdentity)
  const offline = unique(Object.values(state.offline || {}).map((copy) => ({
    videoId: copy.videoId,
    title: copy.title || copy.filename,
    channel: copy.channel || 'Offline audio',
    thumbnail: copy.thumbnail || '',
  })))

  const mixes: Mix[] = []
  if (everything.length) mixes.push({ id: 'daily-1', title: 'Daily Mix', subtitle: 'Your recent rotation, reshuffled', tracks: seededShuffle(everything, `${day}:daily`).slice(0, 24), accent: 'rose' })
  if (liked.length) mixes.push({ id: 'liked-radio', title: 'Liked Songs Radio', subtitle: 'Built from songs you actually hearted', tracks: seededShuffle(liked, `${day}:liked`).slice(0, 24), accent: 'berry' })
  const populated = state.playlists.filter((p) => p.tracks.length)
  if (populated.length) {
    const blend = unique(populated.slice(0, 4).flatMap((p) => seededShuffle(p.tracks, `${day}:${p.id}`).slice(0, 8)))
    mixes.push({ id: 'playlist-blend', title: 'Playlist Blend', subtitle: 'A crossfade between your collections', tracks: seededShuffle(blend, `${day}:blend`).slice(0, 24), accent: 'amber' })
  }
  if (rotation.length) mixes.push({ id: 'rotation', title: 'Your Rotation', subtitle: 'Taste-weighted, not just most recently tapped', tracks: rotation.slice(0, 24), accent: 'peach' })
  if (offline.length) mixes.push({ id: 'offline-mix', title: 'No Signal Mix', subtitle: 'Everything ready without internet', tracks: seededShuffle(offline, `${day}:offline`).slice(0, 24), accent: 'amber' })
  if (liked.length >= 4) {
    const rediscover = [...liked].sort((a, b) => (state.playCounts?.[a.videoId] ?? 0) - (state.playCounts?.[b.videoId] ?? 0))
    mixes.push({ id: 'rediscover', title: 'Rediscover', subtitle: 'Liked songs you have not spun as much lately', tracks: seededShuffle(rediscover.slice(0, Math.max(8, Math.ceil(rediscover.length * .65))), `${day}:rediscover`).slice(0, 24), accent: 'berry' })
  }
  return mixes
}

function uniqueStrings(items: string[]) {
  const seen = new Set<string>()
  return items.map((x) => x.trim()).filter((x) => x && !seen.has(x.toLowerCase()) && seen.add(x.toLowerCase()))
}

function radioQueries(seed: Track, tuning: RadioTuning) {
  const id = musicIdentity(seed)
  const base = [
    id.artist && id.song ? `${id.artist} ${id.song} radio` : '',
    id.artist ? `${id.artist} songs` : '',
    id.song ? `${id.song} similar songs` : '',
  ]
  if (tuning.mode === 'deeper') base.unshift(`${id.artist} deep cuts`, `${id.artist} album tracks`)
  if (tuning.mode === 'surprise') base.unshift(`${id.artist} similar artists`, `${id.song} unexpected similar songs`)
  if (tuning.mode === 'energy') base.unshift(`${id.artist} energetic songs`, `${id.song} dance remix`)
  if (tuning.mode === 'chill') base.unshift(`${id.artist} chill songs`, `${id.song} acoustic chill`)
  if (tuning.mode === 'stay') base.unshift(`${id.artist} ${id.song}`, `${id.artist} official audio`)
  return uniqueStrings(base).slice(0, tuning.discovery >= 70 ? 5 : 4)
}

/**
 * R9 tunable Context Radio.
 * Native watch-next is the primary neighborhood; search expands the candidate pool.
 * The local Taste Engine reranks with long-term + current-session signals, canonical
 * dedupe, early-skip penalties, explicit discovery/variety controls and artist caps.
 */
export async function discoverRadio(seed: Track, state: SidePlayState, limit = 18, tuningInput?: Partial<RadioTuning>): Promise<Track[]> {
  const tuning = clampRadioTuning(tuningInput)
  const candidates: Candidate[] = []

  if (seed.provider === 'youtube' || /^[A-Za-z0-9_-]{11}$/.test(seed.videoId)) {
    const related = await getRelatedYouTube(seed.videoId, Math.max(36, limit * 2)).catch(() => [])
    related.forEach((track, rank) => candidates.push({ track, score: radioSourceBase(tuning, true) + Math.max(0, 7 - rank * .20), related: true }))
  }

  const targetPool = tuning.discovery >= 70 ? limit * 3 : limit * 2
  if (candidates.length < targetPool || tuning.mode !== 'stay') {
    const queries = radioQueries(seed, tuning)
    for (let q = 0; q < queries.length; q++) {
      try {
        const found = rankAndDedupeMusicSearch(queries[q], await searchYouTube(queries[q], state.youtubeApiKey), 30)
        found.forEach((track, rank) => candidates.push({ track, score: radioSourceBase(tuning, false) - q * .75 + Math.max(0, 5 - rank * .16), related: false }))
      } catch {}
      if (candidates.length >= Math.max(100, limit * 5)) break
    }
  }

  return rankCandidates(seed, state, candidates, limit, tuning)
}

function recommendationSeeds(state: SidePlayState, limit = 4) {
  const profile = buildTasteProfile(state)
  const pool = unique([
    ...[...state.history].sort((a, b) => sessionAffinity(b, profile) - sessionAffinity(a, profile)).slice(0, 16),
    ...[...state.history].sort((a, b) => tasteScoreForTrack(b, profile) - tasteScoreForTrack(a, profile)).slice(0, 24),
    ...state.favorites,
    ...state.history.slice(0, 18),
  ]).filter(hasUsableMusicIdentity)
  const artists = new Set<string>()
  const out: Track[] = []
  for (const track of pool) {
    const key = musicIdentity(track).artistKey
    if (key && artists.has(key) && out.length < Math.max(1, limit - 1)) continue
    if (key) artists.add(key)
    out.push(track)
    if (out.length >= limit) break
  }
  return out
}

export async function discoverRecommendations(state: SidePlayState, limit = 24, tuningInput?: Partial<RadioTuning>): Promise<Track[]> {
  const tuning = clampRadioTuning(tuningInput)
  const seeds = recommendationSeeds(state, 4)
  const buckets: Track[][] = []

  for (const seed of seeds) {
    const radio = await discoverRadio(seed, state, Math.max(8, Math.ceil(limit / Math.max(1, seeds.length)) + 3), tuning).catch(() => [])
    if (radio.length) buckets.push(radio)
  }

  const out: Track[] = []
  const seen = new Set<string>()
  let cursor = 0
  while (out.length < limit && buckets.some((bucket) => cursor < bucket.length)) {
    for (const bucket of buckets) {
      const track = bucket[cursor]
      const key = track ? canonicalTrackKey(track) : ''
      if (track && !seen.has(key)) { seen.add(key); out.push(track) }
      if (out.length >= limit) break
    }
    cursor++
  }

  if (out.length < limit) {
    let subscriptions: { title?: string }[] = []
    try { subscriptions = JSON.parse(localStorage.getItem('sideplay.youtube.subscriptions') || '[]') } catch {}
    for (const subscription of subscriptions.slice(0, 2)) {
      if (!subscription.title) continue
      try {
        const found = rankAndDedupeMusicSearch(subscription.title, await searchYouTube(`${subscription.title} music`, state.youtubeApiKey), 20)
        for (const track of found) {
          const key = canonicalTrackKey(track)
          if (seen.has(key) || state.history.slice(0, 25).some((x) => canonicalTrackKey(x) === key)) continue
          seen.add(key)
          out.push({ ...track, provider: 'youtube', sourceUrl: `https://www.youtube.com/watch?v=${track.videoId}`, mediaKind: 'audio', audioPreferred: true, recommendationReason: `From ${subscription.title}` })
          if (out.length >= limit) break
        }
      } catch {}
      if (out.length >= limit) break
    }
  }

  return out.slice(0, limit)
}
