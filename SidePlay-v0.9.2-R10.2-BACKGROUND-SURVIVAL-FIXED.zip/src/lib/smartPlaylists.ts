import type { Track } from '../types'
import type { Mix } from './recommendations'
import { repairTrackList } from './trackIdentity'

const KEY = 'sideplay.smart.discovery.v1'
const MAX_TRACKS = 36
const REFRESH_AFTER_MS = 12 * 60 * 60 * 1000

type StoredDiscoveryMix = {
  version: 1
  generatedAt: number
  tracks: Track[]
}

export type SmartDiscoveryMix = Mix & {
  generatedAt: number
  smart: true
}

function storage(): Storage | null {
  try {
    return typeof localStorage === 'undefined' ? null : localStorage
  } catch {
    return null
  }
}

function cleanPersistentTrack(track: Track): Track {
  // Smart playlists persist catalog identity, never short-lived CDN/session data.
  const {
    playbackUrl: _playbackUrl,
    downloadUrl: _downloadUrl,
    requestHeaders: _requestHeaders,
    capturedAt: _capturedAt,
    resolvedAt: _resolvedAt,
    resolverRecovery: _resolverRecovery,
    ...stable
  } = track
  return stable
}

function toMix(stored: StoredDiscoveryMix): SmartDiscoveryMix {
  return {
    id: 'smart-discovery',
    title: 'Discovery Mix',
    subtitle: 'Fresh picks from your Taste profile · updated automatically',
    tracks: repairTrackList(stored.tracks || []).slice(0, MAX_TRACKS),
    accent: 'amber',
    generatedAt: stored.generatedAt,
    smart: true,
  }
}

export function loadSmartDiscoveryMix(): SmartDiscoveryMix | null {
  const store = storage()
  if (!store) return null
  try {
    const parsed = JSON.parse(store.getItem(KEY) || 'null') as StoredDiscoveryMix | null
    if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.tracks) || !parsed.tracks.length) return null
    return toMix(parsed)
  } catch {
    return null
  }
}

export function saveSmartDiscoveryMix(tracks: Track[], generatedAt = Date.now()): SmartDiscoveryMix | null {
  const clean = repairTrackList(tracks)
    .filter((track) => !!track?.videoId)
    .map(cleanPersistentTrack)
    .filter((track, index, all) => all.findIndex((candidate) => candidate.videoId === track.videoId) === index)
    .slice(0, MAX_TRACKS)

  if (!clean.length) return null
  const stored: StoredDiscoveryMix = { version: 1, generatedAt, tracks: clean }
  const store = storage()
  try { store?.setItem(KEY, JSON.stringify(stored)) } catch {}
  return toMix(stored)
}

export function smartDiscoveryNeedsRefresh(
  mix: SmartDiscoveryMix | null,
  latestTasteEventAt = 0,
  now = Date.now(),
) {
  if (!mix?.tracks?.length) return true
  if (now - mix.generatedAt >= REFRESH_AFTER_MS) return true
  // A meaningful taste event after the snapshot should eventually reshape Discovery,
  // but do not churn the playlist every few seconds during normal listening.
  return latestTasteEventAt > mix.generatedAt + 10 * 60 * 1000
}
