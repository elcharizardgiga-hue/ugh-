import type { Track } from '../types'

const NOISE_TERMS = [
  'reaction', 'reacts', 'tutorial', 'interview', 'behind the scenes', 'trailer', 'teaser',
  'karaoke', 'nightcore', '8d audio', 'sped up', 'speed up', 'slowed', 'slowed reverb',
  'reverb', 'instrumental', 'cover', 'remake', 'parody', 'shorts', 'tiktok version',
]
const TITLE_DECORATION = /\s*[\[(](?:official\s*)?(?:music\s*)?(?:video|audio|lyrics?|lyric\s*video|visualizer|visualiser|4k|hd|mv|clip|performance).*?[\])]/ig
const STOP_WORDS = new Set(['the', 'a', 'an', 'and', 'or', 'of', 'to', 'in', 'on', 'with', 'feat', 'ft', 'official', 'video', 'audio', 'lyrics', 'music'])

export function normalizeMusicText(value: string) {
  return (value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

export function cleanMusicTitle(title: string) {
  return (title || '')
    .replace(TITLE_DECORATION, '')
    .replace(/\s*[\[(](?:explicit|clean|remaster(?:ed)?(?:\s+\d{4})?|radio edit|album version).*?[\])]/ig, '')
    .replace(/\s+/g, ' ')
    .trim()
}

function cleanChannel(channel: string) {
  return (channel || '')
    .replace(/\s+-\s+Topic$/i, '')
    .replace(/VEVO$/i, '')
    .replace(/\s+Official$/i, '')
    .trim()
}

export function musicIdentity(track: Pick<Track, 'title' | 'channel'>) {
  const cleaned = cleanMusicTitle(track.title)
  const pieces = cleaned.split(/\s[-–—|]\s/).map((x) => x.trim()).filter(Boolean)
  const channel = cleanChannel(track.channel)
  let artist = channel
  let song = cleaned

  if (pieces.length >= 2) {
    const left = pieces[0]
    const right = pieces.slice(1).join(' - ')
    const channelNorm = normalizeMusicText(channel)
    const leftNorm = normalizeMusicText(left)
    const genericUploader = !channelNorm || /youtube|various artists|unknown|lyrics|lyric|music hub|records|recordings|uploads/.test(channelNorm)
    if (genericUploader || channelNorm.includes(leftNorm) || leftNorm.includes(channelNorm)) {
      artist = left
      song = right
    }
  }

  if (!artist || /youtube|unknown channel/i.test(artist)) artist = pieces[0] || channel || 'Unknown artist'
  return { artist: artist.trim(), song: song.trim(), artistKey: normalizeMusicText(artist), songKey: normalizeMusicText(song) }
}

function tokens(value: string) {
  return new Set(normalizeMusicText(value).split(' ').filter((x) => x.length > 1 && !STOP_WORDS.has(x)))
}

function tokenSimilarity(a: string, b: string) {
  const aa = tokens(a); const bb = tokens(b)
  if (!aa.size || !bb.size) return 0
  let same = 0
  for (const token of aa) if (bb.has(token)) same++
  return same / Math.max(aa.size, bb.size)
}

function modifierSet(track: Pick<Track, 'title' | 'channel'>) {
  const n = normalizeMusicText(`${track.title} ${track.channel}`)
  return new Set(NOISE_TERMS.filter((term) => n.includes(normalizeMusicText(term))))
}

export function isNoisyVariant(seed: Pick<Track, 'title' | 'channel'>, candidate: Pick<Track, 'title' | 'channel'>) {
  const seedMods = modifierSet(seed)
  const text = normalizeMusicText(`${candidate.title} ${candidate.channel}`)
  return NOISE_TERMS.some((term) => text.includes(normalizeMusicText(term)) && !seedMods.has(term))
}

export function isNearDuplicateSong(seed: Pick<Track, 'videoId' | 'title' | 'channel'>, candidate: Pick<Track, 'videoId' | 'title' | 'channel'>) {
  if (seed.videoId === candidate.videoId) return true
  const a = musicIdentity(seed); const b = musicIdentity(candidate)
  if (a.songKey && a.songKey === b.songKey) return true
  const similarity = tokenSimilarity(a.song, b.song)
  return similarity >= .82 && (!!a.artistKey && !!b.artistKey ? (a.artistKey === b.artistKey || a.artistKey.includes(b.artistKey) || b.artistKey.includes(a.artistKey)) : true)
}


const DISTINCT_VARIANTS = ['remix', 'live', 'acoustic', 'instrumental', 'cover', 'karaoke', 'sped up', 'slowed', 'nightcore']

export function canonicalTrackKey(track: Pick<Track, 'title' | 'channel'>) {
  const id = musicIdentity(track)
  const normalized = normalizeMusicText(`${track.title} ${track.channel}`)
  const variant = DISTINCT_VARIANTS.find((term) => normalized.includes(normalizeMusicText(term))) || ''
  return `${id.artistKey || 'unknown'}::${id.songKey || normalizeMusicText(track.title)}::${variant}`
}

function queryTokens(value: string) {
  return normalizeMusicText(value).split(' ').filter((x) => x.length > 1 && !STOP_WORDS.has(x))
}

export function searchRelevanceScore(query: string, track: Track) {
  const q = normalizeMusicText(query)
  const title = normalizeMusicText(track.title)
  const channel = normalizeMusicText(track.channel)
  const identity = musicIdentity(track)
  const haystack = `${title} ${channel}`
  const qTokens = queryTokens(q)
  let score = 0
  for (const token of qTokens) if (haystack.includes(token)) score += 2.2
  if (q && title === q) score += 14
  else if (q && title.startsWith(q)) score += 7
  if (identity.artistKey && q.includes(identity.artistKey)) score += 3.5
  if (identity.songKey && q.includes(identity.songKey)) score += 5
  if (/\btopic\b/.test(channel) || /vevo/.test(channel)) score += 2.4
  if (/official audio|official music video|official video/.test(title)) score += 1.7

  // Only punish variants the user did not ask for.
  for (const term of NOISE_TERMS) {
    const normalized = normalizeMusicText(term)
    if (haystack.includes(normalized) && !q.includes(normalized)) score -= term === 'cover' || term === 'karaoke' ? 12 : 7
  }
  return score
}

/** Keep the best upload for a song while preserving intentional variants (live/remix/etc.). */
export function rankAndDedupeMusicSearch(query: string, tracks: Track[], limit = 30) {
  const best = new Map<string, { track: Track; score: number; index: number }>()
  tracks.forEach((track, index) => {
    const key = canonicalTrackKey(track)
    const score = searchRelevanceScore(query, track) - index * 0.035
    const existing = best.get(key)
    if (!existing || score > existing.score) best.set(key, { track, score, index })
  })
  return [...best.values()].sort((a, b) => b.score - a.score || a.index - b.index).slice(0, limit).map((item) => item.track)
}
