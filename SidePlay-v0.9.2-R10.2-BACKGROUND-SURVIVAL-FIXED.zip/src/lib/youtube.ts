import type { Track } from '../types'
import { NativeYouTube, hasNativeYouTubeSearch } from './nativeYouTube'
import { pcGetVideo, pcSearchYouTube, pcSuggestYouTube } from './pcYouTube'
import { isGenericTrackTitle } from './trackIdentity'

export function extractVideoId(value: string): string | null {
  const raw = value.trim()
  if (/^[a-zA-Z0-9_-]{11}$/.test(raw)) return raw
  try {
    const url = new URL(raw)
    if (url.hostname === 'youtu.be') return url.pathname.split('/').filter(Boolean)[0] ?? null
    if (url.hostname.includes('youtube.com')) {
      const direct = url.searchParams.get('v')
      if (direct) return direct
      const parts = url.pathname.split('/').filter(Boolean)
      const marker = parts.findIndex((x) => ['shorts', 'embed', 'live'].includes(x))
      if (marker >= 0 && parts[marker + 1]) return parts[marker + 1]
    }
  } catch {
    return null
  }
  return null
}

export async function getTrackById(videoId: string, apiKey: string): Promise<Track> {
  if (!apiKey) {
    if (hasNativeYouTubeSearch()) {
      try {
        return (await NativeYouTube.getVideo({ videoId })).track
      } catch {
        return fallbackTrack(videoId)
      }
    }
    try {
      return await pcGetVideo(videoId)
    } catch {
      return fallbackTrack(videoId)
    }
  }
  const url = new URL('https://www.googleapis.com/youtube/v3/videos')
  url.searchParams.set('part', 'snippet')
  url.searchParams.set('id', videoId)
  url.searchParams.set('key', apiKey)
  const res = await fetch(url)
  if (!res.ok) throw new Error(await youtubeError(res))
  const data = await res.json()
  const item = data.items?.[0]
  if (!item) throw new Error('Video not found or unavailable.')
  return toTrack(item.id, item.snippet)
}


export async function getRelatedYouTube(videoId: string, limit = 30): Promise<Track[]> {
  if (!/^[a-zA-Z0-9_-]{11}$/.test(videoId)) return []
  if (!hasNativeYouTubeSearch()) return []
  try {
    const result = await NativeYouTube.related({ videoId, limit })
    return (result.tracks || []).map((track) => ({
      ...track,
      provider: 'youtube' as const,
      sourceUrl: track.sourceUrl || `https://www.youtube.com/watch?v=${track.videoId}`,
      audioPreferred: true,
      mediaKind: track.mediaKind || 'audio',
    }))
  } catch {
    return []
  }
}

export async function suggestYouTube(query: string, limit = 10): Promise<string[]> {
  const q = query.trim()
  if (!q) return []
  const locale = typeof navigator !== 'undefined' && navigator.language ? navigator.language : 'en-US'
  const [rawLanguage = 'en', rawRegion = 'US'] = locale.split('-')
  const hl = /^[A-Za-z]{2,8}$/.test(rawLanguage) ? rawLanguage : 'en'
  const gl = /^[A-Za-z]{2}$/.test(rawRegion) ? rawRegion.toUpperCase() : 'US'
  if (hasNativeYouTubeSearch()) {
    try {
      const result = await NativeYouTube.suggest({ query: q, limit, hl, gl })
      return (result.suggestions || []).slice(0, limit)
    } catch {}
  }
  try { return (await pcSuggestYouTube(q, limit, hl, gl)).slice(0, limit) } catch { return [] }
}

export async function searchYouTube(query: string, apiKey: string): Promise<Track[]> {
  if (!apiKey && hasNativeYouTubeSearch()) {
    const result = await NativeYouTube.search({ query, limit: 25 })
    const tracks = (result.tracks || []).filter((track) => !isGenericTrackTitle(track.title, track.videoId))
    if (!tracks.length) throw new Error('No YouTube results found.')
    return tracks
  }
  if (!apiKey) {
    try {
      return (await pcSearchYouTube(query, 25)).filter((track) => !isGenericTrackTitle(track.title, track.videoId))
    } catch (error: any) {
      throw new Error(error?.message || 'PC keyless search bridge is not running. Start SidePlay with START_SIDEPLAY.bat.')
    }
  }
  const url = new URL('https://www.googleapis.com/youtube/v3/search')
  url.searchParams.set('part', 'snippet')
  url.searchParams.set('type', 'video')
  url.searchParams.set('maxResults', '25')
  url.searchParams.set('q', query)
  url.searchParams.set('videoEmbeddable', 'true')
  url.searchParams.set('key', apiKey)
  const res = await fetch(url)
  if (!res.ok) throw new Error(await youtubeError(res))
  const data = await res.json()
  return (data.items ?? []).map((item: any) => toTrack(item.id.videoId, item.snippet)).filter((track: Track) => !isGenericTrackTitle(track.title, track.videoId))
}

function fallbackTrack(videoId: string): Track {
  return {
    videoId,
    title: `YouTube video ${videoId}`,
    channel: 'YouTube',
    thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
  }
}

function toTrack(videoId: string, snippet: any): Track {
  return {
    videoId,
    title: decode(snippet?.title ?? 'Untitled'),
    channel: decode(snippet?.channelTitle ?? 'Unknown channel'),
    thumbnail:
      snippet?.thumbnails?.medium?.url ??
      snippet?.thumbnails?.high?.url ??
      `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    publishedAt: snippet?.publishedAt,
  }
}

async function youtubeError(res: Response) {
  try {
    const body = await res.json()
    return body?.error?.message ?? `YouTube API error (${res.status})`
  } catch {
    return `YouTube API error (${res.status})`
  }
}

function decode(value: string) {
  const textarea = document.createElement('textarea')
  textarea.innerHTML = value
  return textarea.value
}
