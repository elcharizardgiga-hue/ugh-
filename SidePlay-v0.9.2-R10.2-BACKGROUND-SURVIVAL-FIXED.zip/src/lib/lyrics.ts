import type { LyricsLine, LyricsResult, Track } from '../types'
import { cleanMusicTitle, musicIdentity, normalizeMusicText } from './musicIdentity'
import { isGenericTrackChannel, isGenericTrackTitle } from './trackIdentity'
import { NativeYouTube, hasNativeYouTubeSearch } from './nativeYouTube'

const KEY = 'sideplay.lyrics.cache.v3'
const MAX_CACHE = 80
const TTL = 14 * 24 * 60 * 60 * 1000
const LRCLIB = 'https://lrclib.net/api'

type Cache = Record<string, LyricsResult>
type LrclibRecord = {
  trackName?: string
  artistName?: string
  albumName?: string
  duration?: number
  instrumental?: boolean
  plainLyrics?: string | null
  syncedLyrics?: string | null
}

function readCache(): Cache {
  try {
    // Deliberately do not fall back to v1/v2 here. Those caches were keyed only by
    // videoId and could preserve a poisoned/misaligned lyrics result indefinitely.
    return JSON.parse(localStorage.getItem(KEY) || '{}')
  } catch { return {} }
}

function writeCache(cache: Cache) {
  try {
    const entries = Object.values(cache)
      .filter((item) => item?.videoId && item?.text)
      .sort((a, b) => (b.fetchedAt || 0) - (a.fetchedAt || 0))
      .slice(0, MAX_CACHE)
    localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(entries.map((item) => [item.videoId, item]))))
  } catch {}
}

export function lyricsIdentityKey(track: Track) {
  const identity = musicIdentity(track)
  const artist = normalizeMusicText(identity.artist || track.channel || '')
  const song = normalizeMusicText(cleanMusicTitle(identity.song || track.title || ''))
  return `${track.videoId}|${artist}|${song}`
}

export function parseLrc(value?: string | null): LyricsLine[] {
  if (!value) return []
  const out: LyricsLine[] = []
  const pattern = /\[(\d{1,3}):(\d{2}(?:\.\d{1,3})?)\]\s*(.*)/
  for (const rawLine of value.split(/\r?\n/)) {
    const match = rawLine.match(pattern)
    if (!match) continue
    const minutes = Number(match[1])
    const seconds = Number(match[2])
    if (!Number.isFinite(minutes) || !Number.isFinite(seconds)) continue
    out.push({ startMs: Math.max(0, Math.round((minutes * 60 + seconds) * 1000)), text: match[3] || '' })
  }
  return out.sort((a, b) => a.startMs - b.startMs)
}

async function fetchJson(url: string, timeoutMs = 8500): Promise<{ status: number; data: any }> {
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    })
    if (response.status === 404) return { status: 404, data: null }
    if (!response.ok) throw new Error(`Lyrics provider HTTP ${response.status}`)
    return { status: response.status, data: await response.json() }
  } finally {
    window.clearTimeout(timeout)
  }
}

function toLyricsResult(track: Track, record: LrclibRecord): LyricsResult | null {
  if (!record || record.instrumental) return null
  const lines = parseLrc(record.syncedLyrics)
  const plain = (record.plainLyrics || '').trim()
  const text = plain || lines.map((line) => line.text).join('\n').trim()
  if (!text) return null
  return {
    videoId: track.videoId,
    identityKey: lyricsIdentityKey(track),
    text,
    source: 'LRCLIB',
    synced: lines.length > 1,
    lines: lines.length > 1 ? lines : undefined,
    fetchedAt: Date.now(),
  }
}

function similarity(a: string, b: string) {
  const aa = new Set(normalizeMusicText(a).split(' ').filter(Boolean))
  const bb = new Set(normalizeMusicText(b).split(' ').filter(Boolean))
  if (!aa.size || !bb.size) return 0
  let common = 0
  for (const token of aa) if (bb.has(token)) common++
  return common / Math.max(aa.size, bb.size)
}

async function getLrclibLyrics(track: Track): Promise<LyricsResult | null> {
  if (isGenericTrackTitle(track.title, track.videoId) || isGenericTrackChannel(track.channel)) return null
  const identity = musicIdentity(track)
  const title = cleanMusicTitle(identity.song || track.title).trim()
  const artist = identity.artist.trim()
  if (!title || !artist || /^unknown/i.test(artist)) return null

  const exact = new URL(`${LRCLIB}/get`)
  exact.searchParams.set('track_name', title)
  exact.searchParams.set('artist_name', artist)
  if (track.durationMs && track.durationMs > 10_000) exact.searchParams.set('duration', String(Math.round(track.durationMs / 1000)))

  try {
    const found = await fetchJson(exact.toString())
    if (found.status === 200) {
      const result = toLyricsResult(track, found.data as LrclibRecord)
      if (result) return result
    }
  } catch {
    // Search fallback below. Network/provider failure must not block YouTube Music fallback.
  }

  try {
    const search = new URL(`${LRCLIB}/search`)
    search.searchParams.set('track_name', title)
    search.searchParams.set('artist_name', artist)
    search.searchParams.set('q', `${artist} ${title}`)
    const found = await fetchJson(search.toString())
    const rows: LrclibRecord[] = Array.isArray(found.data) ? found.data : []
    const targetDuration = track.durationMs ? track.durationMs / 1000 : 0
    const ranked = rows
      .map((row) => {
        let score = similarity(title, row.trackName || '') * 8 + similarity(artist, row.artistName || '') * 7
        if (targetDuration && row.duration) score -= Math.min(5, Math.abs(targetDuration - row.duration) / 8)
        if (row.syncedLyrics) score += 1.5
        return { row, score }
      })
      .sort((a, b) => b.score - a.score)
    for (const { row, score } of ranked.slice(0, 5)) {
      if (score < 4.5) continue
      const result = toLyricsResult(track, row)
      if (result) return result
    }
  } catch {}

  return null
}

export async function getLyrics(track: Track): Promise<LyricsResult> {
  if (!track?.videoId) throw new Error('This track has no stable identity for lyrics lookup.')
  const identityKey = lyricsIdentityKey(track)
  const cache = readCache()
  const cached = cache[identityKey]
  if (
    cached?.text
    && cached.videoId === track.videoId
    && cached.identityKey === identityKey
    && Date.now() - (cached.fetchedAt || 0) < TTL
  ) return cached

  // Metadata-based lyrics first: it can return true synced LRC and does not depend
  // on the current state of YouTube Music's private lyrics tab.
  const lrclib = await getLrclibLyrics(track).catch(() => null)
  if (lrclib) {
    cache[identityKey] = lrclib
    writeCache(cache)
    return lrclib
  }

  // YouTube Music remains the durable video-id fallback for Android. It is useful
  // when title/artist parsing is imperfect or LRCLIB has no matching record.
  if (/^[A-Za-z0-9_-]{11}$/.test(track.videoId) && hasNativeYouTubeSearch()) {
    const identity = musicIdentity(track)
    const result = await NativeYouTube.lyrics({
      videoId: track.videoId,
      title: cleanMusicTitle(identity.song || track.title),
      artist: identity.artist,
      durationMs: track.durationMs,
    })
    if (result?.text?.trim()) {
      const nativeLines = result.lines?.length ? result.lines : parseLrc((result as any).syncedText)
      const normalized: LyricsResult = {
        ...result,
        videoId: track.videoId,
        identityKey,
        lines: nativeLines.length ? nativeLines : undefined,
        synced: nativeLines.length > 1 || !!result.synced,
        fetchedAt: Date.now(),
        source: result.source || 'YouTube Music',
      }
      cache[identityKey] = normalized
      writeCache(cache)
      return normalized
    }
  }

  throw new Error('No lyrics matched this song yet. Try Retry after the track metadata finishes loading.')
}
