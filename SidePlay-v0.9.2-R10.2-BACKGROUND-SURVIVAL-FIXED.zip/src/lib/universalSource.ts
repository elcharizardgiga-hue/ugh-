import { registerPlugin } from '@capacitor/core'
import type { MediaKind, MediaProvider, Track } from '../types'
import { isNative } from './nativeAudio'
import { NativeYouTube } from './nativeYouTube'
import { isGenericTrackTitle } from './trackIdentity'

export type SourceResolution = {
  id: string
  title: string
  artist?: string
  thumbnail?: string
  provider: MediaProvider
  sourceUrl: string
  playbackUrl?: string
  downloadUrl?: string
  providerUri?: string
  mediaKind?: MediaKind
  mimeType?: string
  requestHeaders?: Record<string, string>
  sessionBound?: boolean
  durationMs?: number
  playable: boolean
  downloadable: boolean
  downloadEngine?: 'direct' | 'ytdlp'
  refreshMode?: 'extractor' | 'capture' | 'youtube-native'
  audioPreferred?: boolean
  resolverEngine?: string
  resolverTrail?: string
  resolverDelivery?: string
  resolverRecovery?: string
  resolvedAt?: number
  note?: string
}

type SourceResolverPlugin = {
  resolve(options: { url: string }): Promise<SourceResolution>
  capture(options: { url: string; auto?: boolean }): Promise<SourceResolution>
  openExternal(options: { url: string }): Promise<void>
}

const SourceResolver = registerPlugin<SourceResolverPlugin>('SourceResolver')


type ResolutionCacheEntry = {
  value: SourceResolution
  createdAt: number
  expiresAt: number
}

export type ResolverCacheHealth = {
  entries: number
  inFlight: number
  hits: number
  misses: number
  prefetches: number
  inFlightJoins: number
  evictions: number
  failures: number
  lastPrefetchAt: number
  lastResolvedAt: number
  lastEngine: string
  lastTrail: string
  lastError: string
}

// Signed CDN URLs are intentionally cached for a short window only. This is long
// enough to make Next/Previous feel instant, but far shorter than the usual provider
// expiry window. PlaybackService still self-heals if a URL expires early.
const RESOLUTION_CACHE_TTL_MS = 7 * 60 * 1000
const RESOLUTION_CACHE_MAX = 48
const resolutionCache = new Map<string, ResolutionCacheEntry>()
const resolutionInFlight = new Map<string, Promise<SourceResolution>>()
const resolverCacheStats = {
  hits: 0,
  misses: 0,
  prefetches: 0,
  inFlightJoins: 0,
  evictions: 0,
  failures: 0,
  lastPrefetchAt: 0,
  lastResolvedAt: 0,
  lastEngine: '',
  lastTrail: '',
  lastError: '',
}

function resolutionCacheKey(url: string, audioOnly: boolean) {
  return `${audioOnly ? 'audio' : 'av'}|${url.trim()}`
}

function pruneResolverCache(now = Date.now()) {
  for (const [key, entry] of resolutionCache) {
    if (entry.expiresAt <= now) resolutionCache.delete(key)
  }
  while (resolutionCache.size > RESOLUTION_CACHE_MAX) {
    const oldest = resolutionCache.keys().next().value as string | undefined
    if (!oldest) break
    resolutionCache.delete(oldest)
    resolverCacheStats.evictions++
  }
}

function rememberResolution(key: string, value: SourceResolution) {
  if (!value.playbackUrl) return
  // Browser-captured sessions can contain sensitive/session-specific headers and stay
  // out of cache. Native YouTube resolver URLs are also signed/session-bound, but are
  // safe to cache briefly (7 min) and are exactly what Zero-Wait prefetch is for.
  const nativeYoutube = value.refreshMode === 'youtube-native' || value.resolverEngine === 'newpipe' || value.resolverEngine === 'innertube-safe'
  if (value.sessionBound && !nativeYoutube) return
  const now = Date.now()
  resolutionCache.delete(key)
  resolutionCache.set(key, { value: { ...value }, createdAt: now, expiresAt: now + RESOLUTION_CACHE_TTL_MS })
  resolverCacheStats.lastResolvedAt = now
  resolverCacheStats.lastEngine = value.resolverEngine || value.provider || 'direct'
  resolverCacheStats.lastTrail = value.resolverTrail || resolverCacheStats.lastEngine
  resolverCacheStats.lastError = ''
  pruneResolverCache(now)
}

export function getResolverCacheHealth(): ResolverCacheHealth {
  pruneResolverCache()
  return {
    entries: resolutionCache.size,
    inFlight: resolutionInFlight.size,
    ...resolverCacheStats,
  }
}

export function clearResolverCache() {
  resolutionCache.clear()
  resolutionInFlight.clear()
}

const DIRECT_MEDIA = /\.(mp3|mp2|mpga|m4a|m4b|aac|adts|ac3|eac3|ec3|ac4|amr|3ga|oga|ogg|opus|flac|wav|mp4|m4v|mov|3gp|webm|mkv|mka|flv|f4v|mpg|mpeg|mpegts|m2ts|mts|ts|m3u8|mpd)(?:$|[?#])/i
const SEGMENTED_MEDIA = /\.(m3u8|mpd)(?:$|[?#])/i

function stableId(input: string) {
  let hash = 2166136261
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i)
    hash = Math.imul(hash, 16777619)
  }
  return `src-${(hash >>> 0).toString(36)}`
}

export function isHttpUrl(value: string) {
  try {
    const u = new URL(value)
    return u.protocol === 'http:' || u.protocol === 'https:' || u.protocol === 'rtsp:'
  } catch { return false }
}

export function isWebPageUrl(value: string) {
  try {
    const u = new URL(value)
    return u.protocol === 'http:' || u.protocol === 'https:'
  } catch { return false }
}

function inferKind(url: string, mimeType = ''): MediaKind {
  const m = mimeType.toLowerCase()
  if (m.startsWith('video/') || /\.(mp4|m4v|mov|3gp|webm|mkv|flv|f4v|mpg|mpeg|mpegts|m2ts|mts|ts)(?:$|[?#])/i.test(url) || url.toLowerCase().startsWith('rtsp:')) return 'video'
  return 'audio'
}

function browserResolve(url: string): SourceResolution {
  const u = new URL(url)
  const host = u.hostname.toLowerCase()
  if (u.protocol === 'rtsp:') {
    return { id: stableId(url), title: decodeURIComponent(u.pathname.split('/').pop() || 'RTSP stream'), artist: host || 'RTSP', provider: 'direct', sourceUrl: url, playbackUrl: url, mediaKind: 'video', playable: true, downloadable: false, note: 'RTSP live playback is supported in the Android app. Live RTSP streams are not saved by the offline downloader.' }
  }
  if (host === 'open.spotify.com' || host.endsWith('.spotify.com')) {
    const m = u.pathname.match(/\/track\/([A-Za-z0-9]+)/)
    return {
      id: stableId(url), title: 'Spotify track', artist: 'Spotify', provider: 'spotify', sourceUrl: url,
      providerUri: m ? `spotify:track:${m[1]}` : undefined, playable: false, downloadable: false,
      note: 'Spotify links use provider handoff; Spotify audio is not downloaded by SidePlay.',
    }
  }
  if (host === 'soundcloud.com' || host.endsWith('.soundcloud.com')) {
    return { id: stableId(url), title: 'SoundCloud', artist: host, provider: 'soundcloud', sourceUrl: url, playable: false, downloadable: false, note: 'This SoundCloud page needs an authorized SoundCloud stream URL/API integration.' }
  }
  if (DIRECT_MEDIA.test(url)) {
    const segmented = /\.(m3u8|mpd)(?:$|[?#])/i.test(url)
    return { id: stableId(url), title: decodeURIComponent(u.pathname.split('/').pop() || 'Direct media'), artist: host, provider: 'direct', sourceUrl: url, playbackUrl: url, downloadUrl: segmented ? undefined : url, mediaKind: inferKind(url), playable: true, downloadable: !segmented }
  }
  return { id: stableId(url), title: u.hostname, artist: 'Web link', provider: 'unknown', sourceUrl: url, playable: false, downloadable: false, note: 'This page is not a direct media resource. SidePlay did not extract protected/hidden media from it.' }
}

async function resolveUniversalUrlUncached(url: string, options: { audioOnly?: boolean; allowHeavyFallback?: boolean } = {}): Promise<SourceResolution> {
  if (!isHttpUrl(url)) throw new Error('Paste a valid http(s) or rtsp URL.')
  if (isNative()) {
    // R4 SAFE PLAY: normal Play must never boot the embedded Python/QuickJS yt-dlp
    // runtime. That heavy path was the only thing consistently correlated with the
    // Samsung process death. yt-dlp remains available for explicit offline downloads.
    const lower = url.toLowerCase()
    const spotify = /https?:\/\/(?:[^/]+\.)?spotify\.com\//i.test(url)
    const youtube = /https?:\/\/(?:[^/]+\.)?(?:youtube\.com|youtu\.be)\//i.test(url)
    if (lower.startsWith('rtsp:') || spotify) return SourceResolver.resolve({ url })
    if (DIRECT_MEDIA.test(url)) {
      const direct = await SourceResolver.resolve({ url })
      if (SEGMENTED_MEDIA.test(url)) {
        return { ...direct, downloadable: true, downloadEngine: 'ytdlp' as const }
      }
      return direct
    }
    if (youtube) {
      try {
        return await NativeYouTube.resolve({ url, audioOnly: !!options.audioOnly, allowHeavyFallback: options.allowHeavyFallback !== false }) as SourceResolution
      } catch (error: any) {
        const fallback = await SourceResolver.resolve({ url })
        return {
          ...fallback,
          note: error?.message
            ? `SidePlay safe YouTube resolver could not get a direct stream: ${error.message}`
            : 'SidePlay safe YouTube resolver could not get a direct stream.',
        }
      }
    }
    // Generic pages use only the lightweight static/public resolver during Play.
    // If it cannot find clear media, fail in-app instead of escalating to yt-dlp.
    return SourceResolver.resolve({ url })
  }
  return browserResolve(url)
}


export async function resolveUniversalUrl(url: string, options: { audioOnly?: boolean; allowHeavyFallback?: boolean } = {}): Promise<SourceResolution> {
  if (!isHttpUrl(url)) throw new Error('Paste a valid http(s) or rtsp URL.')
  const audioOnly = !!options.audioOnly
  const key = resolutionCacheKey(url, audioOnly)
  // Prefetch must never weaken a real Play. Lightweight and full resolver work
  // have separate in-flight identities, while successful results still share the
  // same short-lived playback cache.
  const inFlightKey = `${key}|${options.allowHeavyFallback === false ? 'light' : 'full'}`
  const now = Date.now()
  pruneResolverCache(now)

  const cached = resolutionCache.get(key)
  if (cached && cached.expiresAt > now) {
    resolverCacheStats.hits++
    // LRU touch.
    resolutionCache.delete(key)
    resolutionCache.set(key, cached)
    return { ...cached.value, note: cached.value.note || 'Resolved from SidePlay short-lived stream cache.' }
  }

  const pending = resolutionInFlight.get(inFlightKey)
  if (pending) {
    resolverCacheStats.inFlightJoins++
    return pending
  }

  resolverCacheStats.misses++
  const work = resolveUniversalUrlUncached(url, options)
    .then((resolved) => {
      rememberResolution(key, resolved)
      return resolved
    })
    .catch((error: any) => {
      resolverCacheStats.failures++
      resolverCacheStats.lastError = error?.message || String(error)
      throw error
    })
    .finally(() => resolutionInFlight.delete(inFlightKey))

  resolutionInFlight.set(inFlightKey, work)
  return work
}

export async function prefetchUniversalUrl(url: string, options: { audioOnly?: boolean } = {}): Promise<SourceResolution | null> {
  if (!isHttpUrl(url)) return null
  resolverCacheStats.prefetches++
  resolverCacheStats.lastPrefetchAt = Date.now()
  try {
    return await resolveUniversalUrl(url, { ...options, allowHeavyFallback: false })
  } catch (error: any) {
    // Prefetch must never disturb current playback. Engine Doctor retains the reason.
    resolverCacheStats.lastError = error?.message || String(error)
    return null
  }
}

/**
 * Android-only interactive fallback. Opens the source in an in-app WebView,
 * watches clear media requests created by the user's browser session, and returns
 * the selected stream plus the headers Media3 needs to replay it. No DRM/decryption.
 */
export async function captureUniversalUrl(url: string, options: { auto?: boolean } = {}): Promise<SourceResolution> {
  if (!isWebPageUrl(url)) throw new Error('Media Catcher opens http(s) web pages. RTSP/direct streams do not need it.')
  if (!isNative()) throw new Error('Media Catcher is available in the Android APK.')
  const captured = await SourceResolver.capture({ url, auto: !!options.auto })
  return { ...captured, refreshMode: 'capture' as const }
}

export function resolutionToTrack(r: SourceResolution): Track {
  let fallbackTitle = ''
  try {
    const url = new URL(r.sourceUrl)
    fallbackTitle = decodeURIComponent(url.pathname.split('/').filter(Boolean).pop() || '')
      .replace(/\.[a-z0-9]{2,5}$/i, '')
      .replace(/[-_]+/g, ' ')
      .trim() || url.hostname.replace(/^www\./, '')
  } catch {}
  const rawTitle = (r.title || '').trim()
  return {
    videoId: r.id,
    title: !isGenericTrackTitle(rawTitle, r.id) ? rawTitle : (fallbackTitle || (r.provider === 'youtube' ? `YouTube video ${r.id}` : 'Media item')),
    channel: (r.artist || '').trim() || (() => { try { return new URL(r.sourceUrl).hostname.replace(/^www\./, '') } catch { return 'Unknown source' } })(),
    thumbnail: r.thumbnail || '',
    provider: r.provider,
    sourceUrl: r.sourceUrl,
    playbackUrl: r.playbackUrl,
    downloadUrl: r.downloadUrl,
    providerUri: r.providerUri,
    mediaKind: r.mediaKind,
    mimeType: r.mimeType,
    requestHeaders: r.requestHeaders,
    sessionBound: r.sessionBound,
    refreshMode: r.refreshMode,
    downloadEngine: r.downloadEngine,
    capturedAt: r.sessionBound ? Date.now() : undefined,
    durationMs: r.durationMs,
    audioPreferred: r.audioPreferred,
    resolverEngine: r.resolverEngine,
    resolverTrail: r.resolverTrail,
    resolverDelivery: r.resolverDelivery,
    resolverRecovery: r.resolverRecovery,
    resolvedAt: r.resolvedAt,
  }
}

export async function openExternalUrl(url: string) {
  if (!isHttpUrl(url)) throw new Error('Invalid URL.')
  if (isNative()) return SourceResolver.openExternal({ url })
  if (url.toLowerCase().startsWith('rtsp:')) throw new Error('RTSP links need a native media app.')
  window.open(url, '_blank', 'noopener,noreferrer')
}

export function providerLabel(track: Track) {
  switch (track.provider) {
    case 'peertube': return 'PeerTube'
    case 'audius': return 'Audius'
    case 'direct': return 'Direct'
    case 'soundcloud': return 'SoundCloud'
    case 'spotify': return 'Spotify'
    case 'local': return 'Device'
    case 'youtube': return 'YouTube'
    default: return track.playbackUrl ? 'Direct' : 'Web'
  }
}
