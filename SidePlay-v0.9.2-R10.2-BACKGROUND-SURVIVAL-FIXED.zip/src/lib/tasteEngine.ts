import type { SidePlayState, TasteEventKind, Track } from '../types'
import { canonicalTrackKey, musicIdentity } from './musicIdentity'
import { isGenericTrackChannel, isGenericTrackTitle } from './trackIdentity'

const EVENT_WEIGHT: Record<TasteEventKind, number> = {
  play: 0.35,
  complete: 2.5,
  skip: -3.2,
  dislike: -6.5,
  like: 5.2,
  unlike: -2.0,
  queue: 2.0,
  playlist: 2.8,
}

const DAY = 86_400_000
const GLOBAL_HALF_LIFE = 45 * DAY
const SESSION_HALF_LIFE = 95 * 60 * 1000

function decay(ageMs: number, halfLifeMs: number) {
  if (ageMs <= 0) return 1
  return Math.pow(0.5, ageMs / halfLifeMs)
}

function add(map: Map<string, number>, key: string, value: number) {
  if (!key || !Number.isFinite(value)) return
  map.set(key, (map.get(key) || 0) + value)
}

export type TasteProfile = {
  trackScores: Map<string, number>
  canonicalScores: Map<string, number>
  artistScores: Map<string, number>
  sessionArtistScores: Map<string, number>
  sessionTrackScores: Map<string, number>
  stronglySkipped: Set<string>
  knownArtists: Set<string>
  /** Recent artist exposure is used as an anti-loop/fatigue signal in Radio. */
  recentArtistExposure: Map<string, number>
  /** 0..1: how much evidence the engine has before it should strongly personalize. */
  confidence: number
}

/**
 * R9 Taste Engine. It is deliberately local and explainable: no account upload,
 * no opaque model. Long-term taste decays over weeks; session taste decays over
 * hours so one late-night rabbit hole can steer Autoplay without becoming your
 * permanent identity.
 */
export function buildTasteProfile(state: SidePlayState, now = Date.now()): TasteProfile {
  const trackScores = new Map<string, number>()
  const canonicalScores = new Map<string, number>()
  const artistScores = new Map<string, number>()
  const sessionArtistScores = new Map<string, number>()
  const sessionTrackScores = new Map<string, number>()
  const stronglySkipped = new Set<string>()
  const knownArtists = new Set<string>()
  const recentArtistExposure = new Map<string, number>()

  const catalog = new Map<string, Track>()
  for (const track of [...state.history, ...state.favorites, ...state.playlists.flatMap((p) => p.tracks), ...state.queue]) {
    if (track?.videoId) catalog.set(track.videoId, track)
  }

  const scoreIdentity = (
    videoId: string,
    artistKey: string,
    canonical: string,
    score: number,
    sessionScore = 0,
    artistScale = 0.38,
    canonicalScale = 0.72,
  ) => {
    if (!videoId) return
    add(trackScores, videoId, score)
    if (canonical) add(canonicalScores, canonical, score * canonicalScale)
    if (artistKey) {
      // Track-level actions should not automatically become equally strong
      // artist-level opinions. One early skip must not teach SidePlay that the
      // listener suddenly hates the entire artist.
      add(artistScores, artistKey, score * artistScale)
      knownArtists.add(artistKey)
      if (sessionScore) add(sessionArtistScores, artistKey, sessionScore * artistScale)
    }
    if (sessionScore) add(sessionTrackScores, videoId, sessionScore)
  }

  const scoreTrack = (
    track: Track | undefined,
    score: number,
    sessionScore = 0,
    artistScale = 0.38,
    canonicalScale = 0.72,
  ) => {
    if (!track?.videoId) return
    const id = musicIdentity(track)
    const identityIsUsable = !isGenericTrackTitle(track.title, track.videoId) && !isGenericTrackChannel(track.channel)
    scoreIdentity(
      track.videoId,
      identityIsUsable ? id.artistKey : '',
      identityIsUsable ? canonicalTrackKey(track) : '',
      score,
      sessionScore,
      artistScale,
      canonicalScale,
    )
  }

  // Legacy state remains useful after the schema migration, but is intentionally
  // lower-confidence than explicit R9 events.
  state.history.slice(0, 140).forEach((track, index) => {
    const age = Math.max(0, now - (track.playedAt || now))
    const long = Math.max(0.05, decay(age, GLOBAL_HALF_LIFE)) * Math.max(0.1, 1.05 - index * 0.006)
    const session = decay(age, SESSION_HALF_LIFE) * 0.85
    scoreTrack(track, long * 0.7, session, 0.24, 0.55)
  })
  state.favorites.forEach((track) => scoreTrack(track, 4.8, 0, 0.72, 0.85))
  state.playlists.flatMap((p) => p.tracks).forEach((track) => scoreTrack(track, 1.9, 0, 0.5, 0.8))

  for (const [videoId, count] of Object.entries(state.playCounts || {})) {
    scoreTrack(catalog.get(videoId), Math.log2(1 + Math.max(0, count)) * 0.42, 0, 0.25, 0.65)
  }
  for (const [videoId, count] of Object.entries(state.completionCounts || {})) {
    scoreTrack(catalog.get(videoId), Math.min(5, Math.max(0, count)) * 0.75, 0, 0.36, 0.75)
  }
  for (const [videoId, count] of Object.entries(state.skipCounts || {})) {
    scoreTrack(catalog.get(videoId), -Math.min(5, Math.max(0, count)) * 0.82, 0, 0.12, 0.58)
    if (count >= 2) stronglySkipped.add(videoId)
  }

  for (const event of state.tasteEvents || []) {
    const catalogTrack = catalog.get(event.videoId)
    const snapshotTrack = !catalogTrack && event.title && event.channel ? {
      videoId: event.videoId,
      title: event.title,
      channel: event.channel,
      thumbnail: '',
    } as Track : undefined
    const track = catalogTrack || snapshotTrack
    const eventArtistKey = event.artistKey || (track ? musicIdentity(track).artistKey : '')
    const eventCanonicalKey = event.canonicalKey || (track ? canonicalTrackKey(track) : '')
    const age = Math.max(0, now - event.at)
    let base = EVENT_WEIGHT[event.kind]
    if (event.kind === 'skip' && typeof event.progress === 'number') {
      const p = Math.max(0, Math.min(1, event.progress))
      // Bounce in the opening seconds is a strong track-level "no". A skip after
      // most of the song is nearly neutral and should never condemn the artist.
      const factor = p < 0.08 ? 1.30 : p < 0.30 ? 1.0 : p < 0.60 ? 0.55 : p < 0.82 ? 0.22 : 0.07
      base *= factor
    }
    if (event.kind === 'complete' && typeof event.progress === 'number') {
      const p = Math.max(0, Math.min(1, event.progress))
      base *= p >= 0.92 ? 1.12 : p >= 0.75 ? 0.82 : 0.55
    }

    const artistScaleByKind: Record<TasteEventKind, number> = {
      play: 0.16,
      complete: 0.42,
      skip: 0.10,
      dislike: 0.20,
      like: 0.78,
      unlike: 0.34,
      queue: 0.34,
      playlist: 0.58,
    }
    const canonicalScaleByKind: Record<TasteEventKind, number> = {
      play: 0.50,
      complete: 0.82,
      skip: 0.70,
      dislike: 0.90,
      like: 0.95,
      unlike: 0.78,
      queue: 0.76,
      playlist: 0.88,
    }

    const long = base * decay(age, GLOBAL_HALF_LIFE)
    const session = base * decay(age, SESSION_HALF_LIFE)
    scoreIdentity(
      event.videoId,
      eventArtistKey,
      eventCanonicalKey,
      long,
      session,
      artistScaleByKind[event.kind],
      canonicalScaleByKind[event.kind],
    )

    if (
      eventArtistKey
      && age < 3 * 60 * 60 * 1000
      && (event.kind === 'play' || event.kind === 'complete')
    ) add(recentArtistExposure, eventArtistKey, decay(age, SESSION_HALF_LIFE))

    if ((event.kind === 'dislike' || (event.kind === 'skip' && (event.progress ?? 0) < 0.30)) && age < 14 * DAY) stronglySkipped.add(event.videoId)
  }

  const meaningfulEvents = (state.tasteEvents || []).filter((event) =>
    ['complete', 'skip', 'dislike', 'like', 'queue', 'playlist'].includes(event.kind)
  ).length
  const confidence = Math.max(0, Math.min(1, 1 - Math.exp(-meaningfulEvents / 16)))

  return {
    trackScores,
    canonicalScores,
    artistScores,
    sessionArtistScores,
    sessionTrackScores,
    stronglySkipped,
    knownArtists,
    recentArtistExposure,
    confidence,
  }
}

export function tasteScoreForTrack(track: Track, profile: TasteProfile) {
  const id = musicIdentity(track)
  const confidence = 0.32 + profile.confidence * 0.68
  const learned = (profile.trackScores.get(track.videoId) || 0)
    + (profile.canonicalScores.get(canonicalTrackKey(track)) || 0) * 0.6
    + (profile.artistScores.get(id.artistKey) || 0) * 0.35
    + (profile.sessionArtistScores.get(id.artistKey) || 0) * 0.72
  return learned * confidence
}

export function sessionAffinity(track: Track, profile: TasteProfile) {
  const id = musicIdentity(track)
  return (profile.sessionTrackScores.get(track.videoId) || 0) + (profile.sessionArtistScores.get(id.artistKey) || 0)
}

export type TasteDiagnostics = {
  events: number
  scoredTracks: number
  scoredArtists: number
  sessionArtists: number
  stronglySkipped: number
  confidence: number
  recentArtistExposure: Array<{ key: string; score: number }>
  topArtists: Array<{ key: string; score: number }>
  latestEventAt: number
}

/** Human-readable/debuggable view of the local taste model. This deliberately
 * exposes the model's own evidence so recommendation bugs are inspectable. */
export function getTasteDiagnostics(state: SidePlayState, now = Date.now()): TasteDiagnostics {
  const profile = buildTasteProfile(state, now)
  const topArtists = [...profile.artistScores.entries()]
    .filter(([, score]) => Number.isFinite(score))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([key, score]) => ({ key, score: Math.round(score * 100) / 100 }))
  return {
    events: state.tasteEvents?.length || 0,
    scoredTracks: profile.trackScores.size,
    scoredArtists: profile.artistScores.size,
    sessionArtists: profile.sessionArtistScores.size,
    stronglySkipped: profile.stronglySkipped.size,
    confidence: Math.round(profile.confidence * 100),
    recentArtistExposure: [...profile.recentArtistExposure.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([key, score]) => ({ key, score: Math.round(score * 100) / 100 })),
    topArtists,
    latestEventAt: state.tasteEvents?.[0]?.at || 0,
  }
}
