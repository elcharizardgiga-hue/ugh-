import { registerPlugin, type PluginListenerHandle } from '@capacitor/core'
import type { OfflineCopy, Track } from '../types'
import { isNative } from './nativeAudio'
import { downloadWithYtDlp, onYtDlpProgress } from './ytDlp'

interface OfflineMediaPlugin {
  importAudio(options: { videoId: string; title: string }): Promise<{
    localUri: string
    filename: string
    mimeType?: string
    bytes?: number
    mediaKind?: 'audio' | 'video'
  }>
  importMedia(options: { videoId: string; title: string }): Promise<{
    localUri: string
    filename: string
    mimeType?: string
    bytes?: number
    mediaKind?: 'audio' | 'video'
  }>
  importUri(options: { uri: string; videoId: string; title: string }): Promise<{
    localUri: string
    filename: string
    mimeType?: string
    bytes?: number
    mediaKind?: 'audio' | 'video'
  }>
  promoteRolling(options: {
    localUri: string
    videoId: string
    title: string
    mimeType?: string
  }): Promise<{
    localUri: string
    filename: string
    mimeType?: string
    bytes?: number
    provider?: string
    mediaKind?: 'audio' | 'video'
  }>
  download(options: {
    videoId: string
    title: string
    url: string
    filename?: string
    provider?: string
    mimeType?: string
    requestHeaders?: Record<string, string>
  }): Promise<{
    localUri: string
    filename: string
    mimeType?: string
    bytes?: number
    provider?: string
    sourceUrl?: string
    mediaKind?: 'audio' | 'video'
  }>
  remove(options: { localUri: string }): Promise<void>
  addListener(eventName: 'downloadProgress', listener: (event: { videoId: string; bytes: number; totalBytes: number; progress: number }) => void): Promise<PluginListenerHandle>
}

const OfflineMedia = registerPlugin<OfflineMediaPlugin>('OfflineMedia')
const PC_BRIDGE = 'http://127.0.0.1:4783'

function pickBrowserMedia(): Promise<File> {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = 'audio/*,video/*,.mp3,.mp2,.mpga,.m4a,.m4b,.aac,.adts,.ac3,.eac3,.ec3,.ac4,.amr,.3ga,.oga,.ogg,.opus,.flac,.wav,.webm,.mp4,.m4v,.mov,.3gp,.mkv,.mka,.flv,.f4v,.mpg,.mpeg,.mpegts,.ts,.mts,.m2ts'
    input.style.display = 'none'
    document.body.appendChild(input)
    let settled = false
    const finish = (file?: File) => {
      if (settled) return
      settled = true
      window.removeEventListener('focus', onFocus)
      input.remove()
      if (!file) return reject(new Error('Import cancelled.'))
      if (!file.size) return reject(new Error('The selected media file is empty.'))
      const ext = file.name.toLowerCase().split('.').pop() || ''
      const allowed = new Set(['mp3','mp2','mpga','m4a','m4b','aac','adts','ac3','eac3','ec3','ac4','amr','3ga','oga','ogg','opus','flac','wav','webm','mp4','m4v','mov','3gp','mkv','mka','flv','f4v','mpg','mpeg','mpegts','ts','mts','m2ts'])
      if (file.type && !file.type.startsWith('audio/') && !file.type.startsWith('video/') && !allowed.has(ext)) return reject(new Error('Please choose a supported audio or video file.'))
      resolve(file)
    }
    const onFocus = () => window.setTimeout(() => { if (!settled && !input.files?.length) finish() }, 250)
    input.onchange = () => finish(input.files?.[0])
    input.oncancel = () => finish()
    window.addEventListener('focus', onFocus)
    input.click()
  })
}

function copyFromResult(track: Track, result: { localUri: string; filename: string; mimeType?: string; bytes?: number; provider?: string; sourceUrl?: string; mediaKind?: 'audio'|'video' }): OfflineCopy {
  return {
    videoId: track.videoId,
    localUri: result.localUri,
    filename: result.filename,
    mimeType: result.mimeType,
    bytes: result.bytes,
    addedAt: Date.now(),
    platform: isNative() ? 'android' : 'pc',
    title: track.title,
    channel: track.channel,
    thumbnail: track.thumbnail,
    provider: track.provider,
    sourceUrl: track.sourceUrl,
    mediaKind: result.mediaKind || track.mediaKind,
  }
}

export async function importOfflineCopy(track: Track): Promise<OfflineCopy> {
  if (isNative()) {
    const result = await OfflineMedia.importMedia({ videoId: track.videoId, title: track.title })
    return copyFromResult(track, result)
  }

  const file = await pickBrowserMedia()
  const key = `${track.videoId}-${Date.now()}`
  const response = await fetch(`${PC_BRIDGE}/api/offline/import?key=${encodeURIComponent(key)}`, {
    method: 'POST',
    headers: {
      'content-type': file.type || 'application/octet-stream',
      'x-sideplay-filename': encodeURIComponent(file.name),
    },
    body: file,
  })
  const body = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(body?.error || `Offline import failed (${response.status}). Start SidePlay with START_SIDEPLAY.bat so the PC bridge is running.`)
  return {
    videoId: track.videoId,
    localUri: body.localUri,
    filename: body.filename || file.name,
    mimeType: body.mimeType || file.type,
    bytes: body.bytes || file.size,
    addedAt: Date.now(),
    platform: 'pc',
    title: track.title,
    channel: track.channel,
    thumbnail: track.thumbnail,
    provider: track.provider,
    sourceUrl: track.sourceUrl,
    mediaKind: file.type.startsWith('video/') ? 'video' : track.mediaKind || 'audio',
  }
}


export async function importSharedOfflineCopy(track: Track, uri: string): Promise<OfflineCopy> {
  if (!isNative()) throw new Error('Shared Android media import is only available in the APK.')
  const result = await OfflineMedia.importUri({ uri, videoId: track.videoId, title: track.title })
  return copyFromResult(track, result)
}

/** Save a provider-authorized progressive media URL directly into SidePlay's private offline vault. */
/** Promote SidePlay's hidden rolling cache into an explicit user Download.
 * This is a local app-private copy, so a cached 3 MB song should complete in
 * milliseconds instead of re-resolving/re-downloading it from the provider. */
export async function promoteRollingOfflineCopy(track: Track, cached: OfflineCopy): Promise<OfflineCopy> {
  if (!isNative()) throw new Error('Rolling cache promotion is Android-only.')
  if (!cached?.localUri) throw new Error('No rolling cache file is available to promote.')
  const result = await OfflineMedia.promoteRolling({
    localUri: cached.localUri,
    videoId: track.videoId,
    title: track.title,
    mimeType: cached.mimeType || track.mimeType,
  })
  return copyFromResult(track, result)
}

export async function downloadOfflineCopy(track: Track): Promise<OfflineCopy> {
  if (!isNative()) {
    throw new Error('One-tap Offline Vault downloads are available in the Android APK. On PC, import a local media file after downloading it.')
  }
  // R10 DOWNLOAD ACCELERATOR: if playback already resolved to a clear progressive
  // CDN object, save that exact object directly. Spinning up Python/yt-dlp for a
  // 3 MB song is dramatically slower than an ordinary HTTP copy and is unnecessary.
  const progressive = (track.downloadUrl || track.playbackUrl || '').trim()
  const segmented = /\.(m3u8|mpd)(?:$|[?#])/i.test(progressive) || /mpegurl|dash\+xml/i.test(track.mimeType || '')
  if (progressive && /^https?:\/\//i.test(progressive) && !segmented) {
    const result = await OfflineMedia.download({
      videoId: track.videoId,
      title: track.title,
      url: progressive,
      provider: track.provider || 'direct',
      mimeType: track.mimeType,
      requestHeaders: track.requestHeaders,
    })
    return copyFromResult(track, result)
  }
  if (track.downloadEngine === 'ytdlp') return downloadWithYtDlp(track)
  if (!track.downloadUrl) throw new Error('This source does not expose a downloadable media file to SidePlay.')
  const result = await OfflineMedia.download({
    videoId: track.videoId,
    title: track.title,
    url: track.downloadUrl,
    provider: track.provider || 'direct',
    mimeType: track.mimeType,
    requestHeaders: track.requestHeaders,
  })
  return copyFromResult(track, result)
}

export async function onOfflineDownloadProgress(listener: (event: { videoId: string; bytes: number; totalBytes: number; progress: number }) => void) {
  if (!isNative()) return { remove: async () => {} } as PluginListenerHandle
  const direct = await OfflineMedia.addListener('downloadProgress', listener)
  const ytdlp = await onYtDlpProgress((event) => listener({ videoId: event.videoId, bytes: 0, totalBytes: 0, progress: event.progress }))
  return {
    remove: async () => {
      await Promise.allSettled([direct.remove(), ytdlp.remove()])
    },
  } as PluginListenerHandle
}

export async function removeOfflineCopy(copy: OfflineCopy) {
  if (copy.platform === 'android' && isNative()) {
    await OfflineMedia.remove({ localUri: copy.localUri })
    return
  }
  if (copy.platform === 'pc' && !isNative()) {
    const response = await fetch(`${PC_BRIDGE}/api/offline?uri=${encodeURIComponent(copy.localUri)}`, { method: 'DELETE' })
    if (!response.ok && response.status !== 404) {
      const body = await response.json().catch(() => ({}))
      throw new Error(body?.error || 'Could not delete offline file.')
    }
  }
}

export function formatBytes(bytes?: number) {
  if (!bytes || bytes <= 0) return 'Local copy'
  const units = ['B', 'KB', 'MB', 'GB']
  let n = bytes
  let i = 0
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++ }
  return `${n >= 100 || i === 0 ? Math.round(n) : n.toFixed(1)} ${units[i]}`
}
