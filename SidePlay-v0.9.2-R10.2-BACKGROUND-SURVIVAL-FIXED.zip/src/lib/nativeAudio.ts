import { Capacitor, registerPlugin, type PluginListenerHandle } from '@capacitor/core'

export type NativeMedia = {
  url: string
  title: string
  artist?: string
  artwork?: string
  mimeType?: string
  requestHeaders?: Record<string, string>
  sourceUrl?: string
  refreshMode?: 'extractor' | 'capture' | 'youtube-native'
  resumable?: boolean
  audioPreferred?: boolean
  positionMs?: number
}

export type NativePlaybackStatus = {
  active: boolean
  playing: boolean
  positionMs: number
  durationMs: number
  playbackState?: number
}

interface BackgroundAudioPlugin {
  play(options: NativeMedia): Promise<void>
  pause(): Promise<void>
  resume(): Promise<void>
  stop(): Promise<void>
  seek(options: { positionMs: number }): Promise<NativePlaybackStatus>
  getStatus(): Promise<NativePlaybackStatus>
  getBackgroundHealth(): Promise<{ unrestricted: boolean; androidVersion: number }>
  getNativeDiagnostics(): Promise<{ stage: string; message?: string; timestamp?: number; serviceAlive: boolean; heartbeatAt?: number; heartbeatAgeMs?: number; recovery?: string; recoveryMessage?: string; recoveryAt?: number; recoveryAttempts?: number; playing?: boolean; playbackState?: number; positionMs?: number; durationMs?: number; lastEventAt?: number; lastState?: string; playbackIsolation?: string; recentExits?: Array<{ process?: string; reason?: number; reasonName?: string; status?: number; timestamp?: number; description?: string }> }>
  openBackgroundSettings(): Promise<void>
  openBluetoothSettings(): Promise<void>
  addListener(eventName: 'playbackState', listener: (event: { state: 'playing' | 'paused' | 'ready' | 'buffering' | 'ended' | 'error'; positionMs?: number; durationMs?: number; message?: string }) => void): Promise<PluginListenerHandle>
}

interface SharedTextPlugin {
  getInitialShare(): Promise<{ text?: string; uri?: string; name?: string; mimeType?: string }>
}

interface WebPlaybackPlugin {
  start(options: { title?: string; artist?: string }): Promise<{ active: boolean }>
  stop(): Promise<void>
  getStatus(): Promise<{ active: boolean; pipSupported?: boolean; inPip?: boolean }>
  setPipEnabled(options: { enabled: boolean }): Promise<{ enabled: boolean }>
}

export const BackgroundAudio = registerPlugin<BackgroundAudioPlugin>('BackgroundAudio')
export const SharedText = registerPlugin<SharedTextPlugin>('SharedText')
export const WebPlayback = registerPlugin<WebPlaybackPlugin>('WebPlayback')

export const isNative = () => Capacitor.isNativePlatform()

export type SpotifySessionStatus = {
  accessGranted?: boolean
  spotifyInstalled?: boolean
  sessionAvailable: boolean
  packageName?: string
  playing?: boolean
  state?: number
  positionMs?: number
  durationMs?: number
  actions?: number
  supportsPlayFromSearch?: boolean
  supportsPlayFromUri?: boolean
  supportsSeek?: boolean
  title?: string
  artist?: string
  album?: string
  mediaId?: string
  accepted?: boolean
  query?: string
}

interface SpotifySessionPlugin {
  hasAccess(): Promise<{ granted: boolean; spotifyInstalled: boolean }>
  openAccessSettings(): Promise<void>
  openSpotify(): Promise<void>
  getStatus(): Promise<SpotifySessionStatus>
  prepareFromSearch(options: { query: string; title?: string; artist?: string }): Promise<SpotifySessionStatus>
  playFromSearch(options: { query: string; title?: string; artist?: string }): Promise<SpotifySessionStatus>
  playFromSearchIntent(options: { query: string; title?: string; artist?: string; structured?: boolean }): Promise<{ accepted: boolean; route?: string }>
  warmSpotifySearch(options: { query: string }): Promise<{ accepted: boolean; route?: string }>
  playFromUri(options: { uri: string }): Promise<SpotifySessionStatus>
  play(): Promise<SpotifySessionStatus>
  pause(): Promise<SpotifySessionStatus>
  next(): Promise<SpotifySessionStatus>
  previous(): Promise<SpotifySessionStatus>
  seek(options: { positionMs: number }): Promise<SpotifySessionStatus>
}

export const SpotifySession = registerPlugin<SpotifySessionPlugin>('SpotifySession')

export type ProviderName = 'youtube' | 'youtubeweb' | 'youtubemusic' | 'spotify' | 'soundcloud'

export type ProviderSessionStatus = {
  provider?: ProviderName | string
  accessGranted?: boolean
  installed?: boolean
  sessionAvailable: boolean
  packageName?: string
  playing?: boolean
  state?: number
  positionMs?: number
  durationMs?: number
  actions?: number
  supportsSeek?: boolean
  supportsNext?: boolean
  supportsPrevious?: boolean
  title?: string
  artist?: string
  album?: string
  mediaId?: string
  browserPackage?: string
  browserLabel?: string
  systemDefaultBrowserPackage?: string
  sessionSource?: string
  notificationFallback?: boolean
  notificationMediaPackage?: string
  notificationMediaTitle?: string
  notificationMediaText?: string
  notificationMediaAgeMs?: number
}

export type BrowserChoice = { packageName: string; label: string; systemDefault?: boolean; selected?: boolean }

interface ProviderSessionPlugin {
  hasAccess(): Promise<{ granted: boolean; youtubeInstalled: boolean; youtubeMusicInstalled: boolean; spotifyInstalled: boolean; soundcloudInstalled: boolean; browserAvailable: boolean; browserPackage?: string; browserLabel?: string; systemDefaultBrowserPackage?: string; systemDefaultBrowserLabel?: string; browserOverridePackage?: string }>
  listBrowsers(): Promise<{ browsers: BrowserChoice[]; selectedPackage?: string; systemDefaultPackage?: string; overridePackage?: string }>
  setBrowserPreference(options: { packageName: string }): Promise<{ browserPackage?: string; browserLabel?: string; overridePackage?: string }>
  openAccessSettings(): Promise<void>
  openExact(options: { provider: ProviderName; url?: string; videoId?: string; title?: string; autoReturn?: boolean }): Promise<{ accepted: boolean; route?: string; packageName?: string; browserLabel?: string; accessGranted?: boolean; autoReturnArmed?: boolean }>
  getStatus(options: { provider: ProviderName; expectedTitle?: string; videoId?: string }): Promise<ProviderSessionStatus>
  play(options: { provider: ProviderName }): Promise<ProviderSessionStatus>
  pause(options: { provider: ProviderName }): Promise<ProviderSessionStatus>
  next(options: { provider: ProviderName }): Promise<ProviderSessionStatus>
  previous(options: { provider: ProviderName }): Promise<ProviderSessionStatus>
  seek(options: { provider: ProviderName; positionMs: number }): Promise<ProviderSessionStatus>
}

export const ProviderSession = registerPlugin<ProviderSessionPlugin>('ProviderSession')
