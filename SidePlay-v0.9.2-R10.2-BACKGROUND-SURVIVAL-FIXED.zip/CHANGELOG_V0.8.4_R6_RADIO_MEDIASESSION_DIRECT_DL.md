# SidePlay 0.8.4-r6 — Radio + MediaSession lifecycle + direct NewPipe download

## Media controls / playback process
- Fixes the R5 lifecycle bug where SidePlay's private PLAY/PAUSE/SEEK intents were passed through `MediaSessionService.onStartCommand()` before SidePlay handled them.
- Private SidePlay commands are now handled first; only real Media3/platform intents are delegated to the Media3 superclass.
- A foreground Play tap uses ordinary `startService()`. Media3 owns foreground promotion once the player has a `MediaItem`, avoiding the manual `startForegroundService()` deadline/crash loop.
- Keeps the process shield: UI in the main process, Media3 in `:playback`, yt-dlp/Python/QuickJS in `:extractor`.
- Adds native diagnostic breadcrumbs for `media-session-published` and `media-item-published`.

## Autoplay Radio
- Autoplay no longer depends on the user starting from a playlist.
- When fewer than three items remain in Up Next, SidePlay builds a lightweight recommendation radio from the current track and appends up to eight candidates.
- Radio uses the existing keyless/native YouTube search path and never wakes yt-dlp just for recommendations.
- The first two radio items are prefetched through the lightweight resolver ladder.
- If a track ends before radio discovery finished, the end-of-track path waits for/builds radio and continues instead of stopping.

## Offline download
- NewPipe and InnerTube SAFE now mark progressive playable media as a direct offline candidate.
- For a resolved YouTube `googlevideo.com` progressive object, Offline Vault can save the same clear media object Media3 already plays, with the same ordinary replay headers.
- YouTube watch pages are still rejected as files; adaptive DASH/HLS continues to use the yt-dlp/FFmpeg path.
- This gives music/audio downloads a path that can bypass current yt-dlp GVS PO-token 403 enforcement when NewPipe already has a working progressive stream.

## Identity
- versionName: `0.8.4-r6`
- versionCode: `813`

## Late R6 hardening from on-device diagnostics

- Engine Doctor showed `newpipe 8/0` but three real `:playback` process crashes, so the resolver is no longer treated as the primary suspect.
- The manually-created `MediaSession` is now explicitly registered with `MediaSessionService` via `addSession(mediaSession)`. This is critical because SidePlay starts playback from its own service command instead of first binding a `MediaController`; without registration, System UI may never discover the session/notification.
- SidePlay private PLAY/PAUSE/SEEK commands are handled before Media3's `super.onStartCommand`, while true platform/Media3 intents are delegated to the superclass.
- A foreground Activity tap now uses ordinary `startService`; Media3 owns promotion of the registered playback session to a media foreground service.
- Zero-Wait now briefly caches signed URLs from the native NewPipe/InnerTube YouTube resolvers. Browser-captured session URLs remain excluded. This fixes Engine Doctor showing prefetch attempts but zero cache entries.
