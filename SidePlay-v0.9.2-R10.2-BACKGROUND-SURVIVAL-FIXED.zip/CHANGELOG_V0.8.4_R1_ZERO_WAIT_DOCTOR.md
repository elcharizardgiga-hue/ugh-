# SidePlay v0.8.4-r1 — Zero Wait + Engine Doctor

## Build reliability
- Fixed the release-packaging bug which omitted `native/android/*.java` from the previous ZIP.
- Added a pre-build sanitizer which removes legacy `javax.annotation.Nonnull` imports/annotations from `SidePlayNewPipeDownloader.java` if an older file survived an over-the-top extraction.
- Added a second sanitizer inside `patch-android.mjs` for the generated Android source tree.
- Added source and generated-source checks which fail early if legacy `javax.annotation` somehow remains.
- Android identity is now `versionCode 808`, `versionName 0.8.4-r1`.

## Zero Wait
- Added a 7-minute in-memory resolution cache for successful non-session-bound media URLs.
- Added in-flight resolver deduplication so repeated taps/prefetches share one resolution job.
- Prefetches up to the next two queue items.
- Queue prefetch is lightweight only: NewPipe + InnerTube SAFE. It never wakes Python/QuickJS/yt-dlp.
- Real Play can still escalate to isolated yt-dlp when the lightweight ladder fails.

## Engine Doctor
- Added native resolver counters for NewPipe, InnerTube SAFE and yt-dlp.
- Shows yt-dlp failure streak/cooldown and confirms `android-process:extractor` isolation.
- Shows Zero-Wait cache entries, hits, prefetches and in-flight work.
- Shows the last resolver engine/trail/error without exposing media URLs, cookies or tokens.
- Added Copy diagnostics and Reset cache + counters controls.

## Resolver Fortress retained
- `NewPipe -> InnerTube SAFE -> isolated yt-dlp` playback ladder.
- yt-dlp Android extraction remains isolated in `:extractor` over Binder IPC.
- Media3 signed-URL refresh and position restore remain enabled.
- Video resolution still tries progressive A/V -> DASH -> HLS -> audio last.
