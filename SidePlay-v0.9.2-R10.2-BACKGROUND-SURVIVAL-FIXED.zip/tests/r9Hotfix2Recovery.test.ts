import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'

const playback = readFileSync(new URL('../native/android/PlaybackService.java', import.meta.url), 'utf8')
const background = readFileSync(new URL('../native/android/BackgroundAudioPlugin.java', import.meta.url), 'utf8')
const youtube = readFileSync(new URL('../native/android/NativeYouTubePlugin.java', import.meta.url), 'utf8')

test('playback process resurrection is guarded by a recent playing checkpoint', () => {
  assert.match(playback, /RECOVERY_MAX_AGE_MS/)
  assert.match(playback, /attemptStartupRecovery\(\)/)
  assert.match(playback, /state\.wantPlay/)
  assert.match(playback, /START_STICKY/)
  assert.match(playback, /skipped-paused/)
  assert.match(playback, /skipped-stale/)
})

test('provider resurrection re-resolves durable extractor sources and cannot overwrite a newer play request', () => {
  assert.match(playback, /resolveFreshExtractor\(state\.sourceUrl, state\.audioPreferred\)/)
  assert.match(playback, /final int generation = \+\+retryGeneration/)
  assert.match(playback, /generation != retryGeneration/)
  assert.match(playback, /restored-refreshed/)
})

test('native doctor exposes heartbeat, recovery state and readable Android exit reasons', () => {
  assert.match(background, /heartbeatAgeMs/)
  assert.match(background, /recoveryAttempts/)
  assert.match(background, /reasonName/)
  assert.match(background, /LOW_MEMORY/)
  assert.match(background, /PACKAGE_UPDATED/)
})

test('InnerTube SAFE has a circuit breaker after repeated failures', () => {
  assert.match(youtube, /innerTubeFailureStreak/)
  assert.match(youtube, /innerTubeCooldownUntilMs/)
  assert.match(youtube, /30_000L \* \(1L <</)
  assert.match(youtube, /innerTubeCooldownMs/)
})
