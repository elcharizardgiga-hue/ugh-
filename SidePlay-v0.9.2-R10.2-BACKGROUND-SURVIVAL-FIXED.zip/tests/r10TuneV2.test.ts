import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {
  DEFAULT_RADIO_TUNING,
  presetRadioTuning,
  radioSourceBase,
  radioTuneBias,
  radioTuningKey,
} from '../src/lib/radioTuning.ts'

const read = (file: string) => fs.readFileSync(path.resolve(file), 'utf8')

test('Tune presets change the actual discovery and variety controls, not only mode labels', () => {
  const stay = presetRadioTuning('stay')
  const surprise = presetRadioTuning('surprise')
  assert.ok(stay.discovery < DEFAULT_RADIO_TUNING.discovery)
  assert.ok(stay.variety < DEFAULT_RADIO_TUNING.variety)
  assert.ok(surprise.discovery > DEFAULT_RADIO_TUNING.discovery)
  assert.ok(surprise.variety > DEFAULT_RADIO_TUNING.variety)
  assert.notEqual(radioTuningKey(stay), radioTuningKey(surprise))
})

test('high Discovery makes search/new-artist candidates materially stronger than related familiar candidates', () => {
  const adventurous = presetRadioTuning('surprise')
  const familiar = presetRadioTuning('stay')

  const adventureUnknown = radioSourceBase(adventurous, false)
    + radioTuneBias(adventurous, { sameArtist: false, knownArtist: false, related: false })
  const adventureSame = radioSourceBase(adventurous, true)
    + radioTuneBias(adventurous, { sameArtist: true, knownArtist: true, related: true })
  assert.ok(adventureUnknown > adventureSame)

  const familiarUnknown = radioSourceBase(familiar, false)
    + radioTuneBias(familiar, { sameArtist: false, knownArtist: false, related: false })
  const familiarSame = radioSourceBase(familiar, true)
    + radioTuneBias(familiar, { sameArtist: true, knownArtist: true, related: true })
  assert.ok(familiarSame > familiarUnknown)
})

test('Tune applies live to autoplay without deleting manual Up Next choices', () => {
  const store = read('src/lib/store.tsx')
  const app = read('src/App.tsx')

  assert.match(store, /replaceAutoplayQueue: \(tracks: Track\[\]\) => void/)
  assert.match(store, /const manual = upcoming\.filter\(\(item\) => item\.queueOrigin !== 'autoplay'\)/)
  assert.match(store, /const tunedAutoplay = repairTrackList\(tracks\)/)
  assert.match(app, /sp\.replaceAutoplayQueue\(autoplay\)/)
  assert.match(app, /Apply to Up Next/)
  assert.match(app, /Manual queued songs stay in place/)
})

test('Tune radio builds are generation guarded so stale tunes cannot repaint newer ones', () => {
  const app = read('src/App.tsx')
  assert.match(app, /radioBuildRequestRef/)
  assert.match(app, /radioTuneApplyRef/)
  assert.match(app, /radioBuildRequestRef\.current === requestId/)
  assert.match(app, /radioTuneApplyRef\.current !== applyId/)
})
