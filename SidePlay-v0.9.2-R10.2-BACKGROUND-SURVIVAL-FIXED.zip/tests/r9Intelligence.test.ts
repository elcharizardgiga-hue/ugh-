import test from 'node:test'
import assert from 'node:assert/strict'
import type { Track } from '../src/types.ts'
import { canonicalTrackKey, rankAndDedupeMusicSearch } from '../src/lib/musicIdentity.ts'

const song = (videoId: string, title: string, channel = 'Artist - Topic'): Track => ({ videoId, title, channel, thumbnail: '' })

const baseState = (): SidePlayState => ({
  schemaVersion: 3, favorites: [], playlists: [], history: [], queue: [], currentIndex: -1,
  repeat: 'off', shuffle: false, youtubeApiKey: '', playCounts: {}, skipCounts: {}, completionCounts: {}, tasteEvents: [], offline: {}, preferOffline: true,
})

test('canonical identity collapses official/lyric duplicate uploads but preserves live variants', () => {
  const official = song('aaaaaaaaaaa', 'Artist - My Song (Official Audio)')
  const lyric = song('bbbbbbbbbbb', 'Artist - My Song (Lyrics)', 'Lyrics Hub')
  const live = song('ccccccccccc', 'Artist - My Song (Live)')
  assert.equal(canonicalTrackKey(official), canonicalTrackKey(lyric))
  assert.notEqual(canonicalTrackKey(official), canonicalTrackKey(live))
})

test('search ranking keeps one canonical upload and prefers trusted official/topic result', () => {
  const ranked = rankAndDedupeMusicSearch('artist my song', [
    song('bbbbbbbbbbb', 'Artist - My Song (Lyrics)', 'Random Lyrics'),
    song('aaaaaaaaaaa', 'Artist - My Song (Official Audio)', 'Artist - Topic'),
    song('ccccccccccc', 'Artist - My Song (Live)', 'Artist'),
  ])
  assert.equal(ranked[0].videoId, 'aaaaaaaaaaa')
  assert.equal(ranked.filter((x) => canonicalTrackKey(x) === canonicalTrackKey(ranked[0])).length, 1)
  assert.ok(ranked.some((x) => x.videoId === 'ccccccccccc'))
})


test('search ranking penalizes unrequested noisy variants', () => {
  const ranked = rankAndDedupeMusicSearch('artist my song', [
    song('aaaaaaaaaaa', 'Artist - My Song (Official Audio)', 'Artist - Topic'),
    song('ddddddddddd', 'Artist - My Song (Slowed + Reverb)', 'Slowed Central'),
    song('eeeeeeeeeee', 'Artist - My Song (Karaoke)', 'Karaoke Hub'),
  ])
  assert.equal(ranked[0].videoId, 'aaaaaaaaaaa')
})
