import test from 'node:test'
import assert from 'node:assert/strict'
import { cleanMusicTitle, isNearDuplicateSong, isNoisyVariant, musicIdentity, normalizeMusicText } from '../src/lib/musicIdentity.ts'

test('cleans common music-video decoration without deleting the song', () => {
  assert.equal(cleanMusicTitle('Doechii - Anxiety (Official Video)'), 'Doechii - Anxiety')
  assert.equal(normalizeMusicText('Beyoncé & JAY-Z'), 'beyonce and jay z')
})

test('extracts artist/song identity from Topic uploads', () => {
  const id = musicIdentity({ title: 'Kendrick Lamar - luther', channel: 'Kendrick Lamar - Topic' })
  assert.equal(id.artistKey, 'kendrick lamar')
  assert.equal(id.songKey, 'luther')
})

test('blocks same-song reuploads from Radio', () => {
  const seed = { videoId: 'aaaaaaaaaaa', title: 'Doechii - Anxiety (Official Video)', channel: 'Doechii' }
  const reupload = { videoId: 'bbbbbbbbbbb', title: 'Doechii - Anxiety [Lyrics]', channel: 'Lyrics Hub' }
  assert.equal(isNearDuplicateSong(seed, reupload), true)
})

test('penalizes slowed/cover variants unless the seed itself asks for that flavor', () => {
  const clean = { title: 'Song Name', channel: 'Artist' }
  const slowed = { title: 'Song Name (Slowed + Reverb)', channel: 'Uploader' }
  assert.equal(isNoisyVariant(clean, slowed), true)
  assert.equal(isNoisyVariant({ title: 'Song Name slowed reverb', channel: 'Artist' }, slowed), false)
})
