import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'

const read = (p: string) => fs.readFileSync(path.resolve(p), 'utf8')

test('lyrics cache is identity keyed and old poisoned cache is not reused', () => {
  const lyrics = read('src/lib/lyrics.ts')
  assert.match(lyrics, /sideplay\.lyrics\.cache\.v3/)
  assert.match(lyrics, /lyricsIdentityKey/)
  assert.match(lyrics, /cached\.identityKey === identityKey/)
  assert.doesNotMatch(lyrics, /localStorage\.getItem\(LEGACY_KEY\)/)
})

test('Now Playing generation guards lyrics and sync follows bounding rect coordinates', () => {
  const app = read('src/App.tsx')
  assert.match(app, /lyricsRequestRef/)
  assert.match(app, /lyricsTrackKeyRef/)
  assert.match(app, /result\.identityKey!==lyricsIdentityKey\(lyricTrack\)/)
  assert.match(app, /getBoundingClientRect\(\)/)
  assert.match(app, /lyricsManualHoldUntilRef/)
  assert.match(app, /lyricsSyncOffsetMs/)
})

test('lyrics and Tune surfaces are intentionally large on phones', () => {
  const css = read('src/styles.css')
  assert.match(css, /\.large-now-panel\{[^}]*min-height:min\(58dvh,640px\)/)
  assert.match(css, /\.synced-lyrics button\{font-size:20px/)
  assert.match(css, /\.lyrics-scroll\{min-height:38dvh/)
  assert.match(css, /\.tune-panel \.tune-slider b\{font-size:15px/)
})

test('queue view uses real queue indices for move/remove actions', () => {
  const app = read('src/App.tsx')
  assert.match(app, /sp\.moveQueue\(i,previousIndex\)/)
  assert.match(app, /sp\.moveQueue\(i,nextIndex\)/)
  assert.match(app, /sp\.removeQueue\(i\)/)
  assert.match(app, /queue-summary/)
})

test('youtube watch pathname is treated as placeholder metadata', () => {
  const identity = read('src/lib/trackIdentity.ts')
  assert.match(identity, /title === 'watch'/)
})

test('Taste separates artist weight from track weight and has fatigue/confidence', () => {
  const taste = read('src/lib/tasteEngine.ts')
  const recs = read('src/lib/recommendations.ts')
  assert.match(taste, /artistScale/)
  assert.match(taste, /recentArtistExposure/)
  assert.match(taste, /confidence/)
  assert.match(taste, /p < 0\.08 \? 1\.30/)
  assert.match(recs, /feedback/)
  assert.match(recs, /fatigueStrength/)
})

test('native LRCLIB fallback ranks candidates instead of returning first hit', () => {
  const native = read('native/android/NativeYouTubePlugin.java')
  assert.match(native, /lyricSimilarity/)
  assert.match(native, /no confident lyrics record/)
  assert.match(native, /titleScore < 0\.48/)
})
