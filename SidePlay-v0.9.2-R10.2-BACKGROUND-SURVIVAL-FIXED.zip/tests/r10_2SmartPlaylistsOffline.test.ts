import assert from 'node:assert/strict'
import fs from 'node:fs'
import test from 'node:test'

const app = fs.readFileSync('src/App.tsx', 'utf8')
const rolling = fs.readFileSync('src/lib/rollingCache.ts', 'utf8')
const nativeRolling = fs.readFileSync('native/android/RollingCachePlugin.java', 'utf8')
const smart = fs.readFileSync('src/lib/smartPlaylists.ts', 'utf8')

test('Discovery Mix is a persistent automatic smart playlist', () => {
  assert.match(smart, /sideplay\.smart\.discovery\.v1/)
  assert.match(smart, /title: 'Discovery Mix'/)
  assert.match(app, /refreshSmartDiscovery/)
  assert.match(app, /saveSmartDiscoveryMix\(next\)/)
  assert.match(app, /discovery: Math\.max\(82/)
  assert.match(app, /SMART PLAYLISTS/)
  assert.match(app, /smartDiscoveryNeedsRefresh/)
  assert.match(app, /if \(smartDiscoveryNeedsRefresh\(discoveryMix, latest\.at\)\) void refreshSmartDiscovery\(\)/)
})

test('automatic offline cache exposes a playable catalog separate from Downloads', () => {
  assert.match(rolling, /catalog\(\): Promise<\{ entriesJson: string \}>/)
  assert.match(rolling, /listRollingCopies/)
  assert.match(nativeRolling, /public void catalog\(PluginCall call\)/)
  assert.match(app, /title="Smart Cache"/)
  assert.match(app, /These are real local media bytes/)
})

test('next 20 rolling cache can escalate to isolated heavy resolver when lightweight resolution cannot cache bytes', () => {
  assert.match(app, /allowHeavyFallback: true/)
  assert.match(app, /R10\.2 OFFLINE RUNWAY GUARANTEE/)
  assert.match(app, /item\.allowHeavyFallback/)
})

test('offline badges count both explicit downloads and automatic rolling cache', () => {
  assert.match(app, /offlineReadyCount/)
  assert.match(app, /Cached offline/)
  assert.match(app, /smart cached/)
})
