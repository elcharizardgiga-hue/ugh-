# SidePlay v0.8.3 — RESOLVER FORTRESS

## Playback resolver
- Fixed the R5 regression where a video request could fall back to audio before trying DASH/HLS.
- YouTube resolution is now a three-stage ladder: NewPipeExtractor -> lightweight InnerTube SAFE PLAY -> serialized yt-dlp.
- InnerTube no longer returns video-only adaptive URLs as if they were complete video playback. It prefers muxed A/V, then DASH/HLS, then audio as a last resort.
- yt-dlp is back as a true last-resort playback resolver with a short circuit breaker so repeated failures do not repeatedly boot Python/QuickJS.
- yt-dlp work is globally serialized across search, playback resolution and downloads to avoid concurrent memory spikes.
- A failed final yt-dlp attempt may perform one guarded nightly extractor refresh and retry.
- yt-dlp network retries are still bounded and fragment concurrency is pinned to 1 for Android stability.

## Self-healing native playback
- Media3 now re-resolves durable extractor-backed sources after repeated playback failures instead of only retrying an expired CDN URL.
- YouTube refresh tries NewPipe first and yt-dlp only if needed, then seeks back to the prior playback position.
- Network restoration refreshes durable signed streams before resuming when appropriate.

## Branding
- New SidePlay app mark using the product rose/coral palette and an S-shaped media ribbon.
- Android patcher now installs SidePlay launcher/adaptive icon resources instead of relying on the generic Capacitor icon.

## Safety / scope
- No DRM decryption or authentication bypass was added.
- Browser Media Catcher remains explicit/manual.
- Existing offline vault safety validation remains unchanged.
