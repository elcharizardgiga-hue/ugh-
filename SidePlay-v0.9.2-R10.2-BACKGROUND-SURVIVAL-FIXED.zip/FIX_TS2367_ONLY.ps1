$ErrorActionPreference = 'Stop'
$path = Join-Path $PSScriptRoot 'src\App.tsx'
if (-not (Test-Path $path)) { throw "src\App.tsx not found next to this script." }
$text = Get-Content -Raw -LiteralPath $path
$old1 = "if (scope === 'audius') jobs.push(searchAudius(q, scope === 'all' ? 6 : 18)"
$new1 = "if (scope === 'audius') jobs.push(searchAudius(q, 18)"
$old2 = "if (scope === 'peertube') jobs.push(searchPeerTube(q, scope === 'all' ? 5 : 18)"
$new2 = "if (scope === 'peertube') jobs.push(searchPeerTube(q, 18)"
if (-not $text.Contains($old1) -and -not $text.Contains($new1)) { throw 'Audius target not found; source differs from expected v0.8.2.' }
if (-not $text.Contains($old2) -and -not $text.Contains($new2)) { throw 'PeerTube target not found; source differs from expected v0.8.2.' }
$text = $text.Replace($old1, $new1).Replace($old2, $new2)
Set-Content -LiteralPath $path -Value $text -Encoding UTF8
Write-Host '[OK] TS2367 provider-scope fix applied.' -ForegroundColor Green
Write-Host 'Run BUILD_SIDEPLAY_APK.bat again.'
