# SidePlay 0.9.2-r10.2 — Smart Playlists + Real Offline Runway

## Automatic smart playlists
- Discovery Mix is now a persistent, automatically refreshed smart playlist.
- The last good Discovery Mix survives app restarts and no-network launches.
- Library now has a Made for You section, so Daily Mix / Discovery / Rediscover are actual playable collections instead of only transient Home cards.
- Discovery refresh failures keep the last good playlist instead of clearing it.

## Smart Cache / offline playback
- Rolling cache now exposes a catalog of the actual local media bytes SidePlay has fetched.
- Offline screen separates permanent Downloads from automatic Smart Cache.
- Smart Cache tracks can be tapped and played through the same local-first playback path with no network.
- Queue rows show which upcoming tracks are already cached offline.
- Offline badge counts both permanent downloads and smart-cached queue tracks without pretending Smart Cache entries are permanent Downloads.

## Fetch reliability
- Current + next 20 use the lightweight resolver first.
- If a future YouTube track still has no cacheable progressive media URL, SidePlay may escalate sequentially to the isolated extractor process.
- Previous/backfill tracks do not trigger heavy extraction; they are expected to have been cached while they were ahead in the queue.
- Cache filling remains sequential to avoid hammering phone storage, battery, and playback.

Android release:
- versionCode 820
- versionName 0.9.2-r10.2
