# SidePlay 0.9.0-r10 — Stabilization

R10 is the architecture pass that turns the accumulated R8/R9 features into one coherent playback system.

## Core integrity
- Canonical metadata repair/merge boundary keeps placeholder resolver metadata from overwriting good song identity.
- Explicit playback state machine tracks resolving, preparing, buffering, playing, paused, recovery, ended and failure phases.
- Queue v2 canonical-dedupes musical duplicates and preserves manual Up Next intent ahead of autoplay.
- Persistent Taste identity snapshots, decaying global/session weights and visible Taste diagnostics.
- Resolver health routing/circuit breakers for NewPipe, InnerTube and yt-dlp.
- HF2 process resurrection and HF3 cohesion/search/lyrics fixes retained.

## Rolling playback cache
- App-managed persistent rolling cache targets previous 20 + current + following 20 songs.
- Cache is separate from explicit Downloads and can evict itself automatically.
- Playback checks rolling local media before touching the network resolver.
- Cache ceiling defaults to 768 MB and uses app-private storage.
- Next-track cache maintenance is sequential to avoid saturating the phone/network.

## Download Accelerator
- Explicit Download first promotes an already-cached rolling copy locally.
- Lightweight resolver path is attempted before any heavy extractor fallback.
- yt-dlp download mode uses concurrent fragments and chunked HTTP transfer where supported.
- Audio-only direct downloads avoid unnecessary FFmpeg initialization.

## Tune V2
- Presets set mode + Discovery + Variety as coherent profiles.
- Discovery now changes candidate sourcing and can overcome watch-next/same-artist dominance.
- Variety changes same-artist pull as well as artist caps.
- Apply Tune replaces only generated autoplay; manually queued songs stay put.
- Preset taps apply immediately; slider edits stage until Apply to Up Next.
- Generation guards prevent a slow old tune request from overwriting a newer one.

## UX hardening
- Search/autocomplete generations are guarded and suggestions dismiss correctly after submit.
- Now Playing and modal surfaces remain scrollable/reachable on small screens.
- Lyrics support LRCLIB synced/plain results plus native YouTube fallback, retry and tap-to-seek.
- Diagnostics include rolling-cache, playback-machine, resolver and Taste state.

## Release
- Source version: 0.9.0-r10
- Android versionCode: 818
- Android versionName: 0.9.0-r10
- GitHub release builder targets ARM64 only.
