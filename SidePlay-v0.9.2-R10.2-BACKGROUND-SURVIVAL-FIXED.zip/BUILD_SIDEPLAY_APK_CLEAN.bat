@echo off
echo Removing generated Android shell for a clean current-release build...
if exist "%~dp0android" rmdir /s /q "%~dp0android"
call "%~dp0BUILD_SIDEPLAY_R10_2.bat"
