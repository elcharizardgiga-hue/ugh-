import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { URL } from 'node:url'

const HOST = process.env.SIDEPLAY_PC_HOST || '127.0.0.1'
const PORT = Number(process.env.SIDEPLAY_PC_PORT || 4783)
const OFFLINE_DIR = process.env.SIDEPLAY_OFFLINE_DIR || path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'SidePlay', 'offline')
fs.mkdirSync(OFFLINE_DIR, { recursive: true })
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36'
const defaultInstances = ['https://inv.nadeko.net', 'https://invidious.nerdvpn.de']
const invidiousInstances = (process.env.SIDEPLAY_INVIDIOUS_INSTANCES || defaultInstances.join(','))
  .split(',').map(x => x.trim().replace(/\/$/, '')).filter(Boolean)

function json(res, status, body) {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    'access-control-allow-origin': '*',
    'access-control-allow-methods': 'GET,POST,DELETE,OPTIONS',
    'access-control-allow-headers': 'content-type,x-sideplay-filename',
    'cache-control': 'no-store',
  })
  res.end(payload)
}

async function fetchText(url, accept = 'text/html,application/json;q=0.9,*/*;q=0.8') {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 15000)
  try {
    const response = await fetch(url, {
      redirect: 'follow',
      headers: {
        'user-agent': UA,
        'accept-language': 'en-US,en;q=0.9',
        accept,
      },
      signal: controller.signal,
    })
    const text = await response.text()
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    return text
  } finally {
    clearTimeout(timer)
  }
}

async function postJson(url, body) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 15000)
  try {
    const response = await fetch(url, {
      method: 'POST',
      redirect: 'follow',
      headers: {
        'user-agent': UA,
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'origin': 'https://www.youtube.com',
        'referer': 'https://www.youtube.com/',
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    })
    const text = await response.text()
    if (!response.ok) throw new Error(`HTTP ${response.status}: ${text.slice(0, 180)}`)
    try { return JSON.parse(text) }
    catch { throw new Error(`YouTube returned non-JSON search data: ${text.slice(0, 120)}`) }
  } finally {
    clearTimeout(timer)
  }
}

function extractClientVersion(html) {
  const patterns = [
    /\"INNERTUBE_CONTEXT_CLIENT_VERSION\"\s*:\s*\"([^\"]+)\"/,
    /\"INNERTUBE_CLIENT_VERSION\"\s*:\s*\"([^\"]+)\"/,
    /\"clientVersion\"\s*:\s*\"(2\.[0-9.]+)\"/,
  ]
  for (const pattern of patterns) {
    const match = html.match(pattern)
    if (match?.[1]) return match[1]
  }
  return '2.20260909.00.00'
}

async function searchYouTubeInnertube(query, limit) {
  // Bootstrap the current WEB client version from YouTube itself. This is much
  // less brittle than scraping ytInitialData and the search endpoint currently
  // accepts signed-out WEB requests without a developer API key.
  let clientVersion = '2.20260909.00.00'
  try {
    const homepage = await fetchText('https://www.youtube.com/?hl=en&gl=US')
    clientVersion = extractClientVersion(homepage)
  } catch {}

  const response = await postJson('https://www.youtube.com/youtubei/v1/search?prettyPrint=false', {
    context: {
      client: {
        clientName: 'WEB',
        clientVersion,
        hl: 'en',
        gl: 'US',
        platform: 'DESKTOP',
      },
    },
    query,
  })

  const tracks = []
  collectVideos(response, tracks, new Set(), limit)
  if (!tracks.length) throw new Error('InnerTube returned no video results')
  return tracks
}

function extractInitialData(html) {
  // Fallback only. YouTube can mention the text "ytInitialData =" inside other
  // scripts, so never jump to the next random "{". Require an actual assignment
  // whose first non-whitespace character is a JSON object and validate candidates.
  const markers = [
    'var ytInitialData',
    'window["ytInitialData"]',
    "window['ytInitialData']",
    'ytInitialData',
  ]
  let searchFrom = 0

  while (searchFrom < html.length) {
    let best = null
    for (const marker of markers) {
      const at = html.indexOf(marker, searchFrom)
      if (at >= 0 && (!best || at < best.at)) best = { at, marker }
    }
    if (!best) break
    searchFrom = best.at + best.marker.length

    let i = searchFrom
    while (i < html.length && /\s/.test(html[i])) i++
    if (html[i] !== '=') continue
    i++
    while (i < html.length && /\s/.test(html[i])) i++
    if (html[i] !== '{') continue

    const start = i
    let depth = 0
    let inString = false
    let escaped = false
    for (; i < html.length; i++) {
      const c = html[i]
      if (inString) {
        if (escaped) escaped = false
        else if (c === '\\') escaped = true
        else if (c === '"') inString = false
        continue
      }
      if (c === '"') inString = true
      else if (c === '{') depth++
      else if (c === '}') {
        depth--
        if (depth === 0) {
          const candidate = html.slice(start, i + 1)
          try {
            const parsed = JSON.parse(candidate)
            if (parsed && typeof parsed === 'object' && (parsed.contents || parsed.responseContext)) return candidate
          } catch {}
          break
        }
      }
    }
  }
  throw new Error('YouTube response did not contain valid ytInitialData')
}

function textFrom(obj, fallback = '') {
  if (!obj || typeof obj !== 'object') return fallback
  if (typeof obj.simpleText === 'string' && obj.simpleText) return obj.simpleText
  if (Array.isArray(obj.runs)) {
    const text = obj.runs.map(run => run?.text || '').join('')
    if (text) return text
  }
  return fallback
}

function thumbFrom(obj, id) {
  const thumbs = obj?.thumbnails
  if (Array.isArray(thumbs) && thumbs.length) {
    const best = thumbs[thumbs.length - 1]
    if (best?.url) return best.url.startsWith('//') ? `https:${best.url}` : best.url
  }
  return `https://i.ytimg.com/vi/${id}/hqdefault.jpg`
}

function collectVideos(node, out, seen, limit) {
  if (!node || out.length >= limit) return
  if (Array.isArray(node)) {
    for (const item of node) {
      collectVideos(item, out, seen, limit)
      if (out.length >= limit) return
    }
    return
  }
  if (typeof node !== 'object') return

  const r = node.videoRenderer
  if (r?.videoId && !seen.has(r.videoId)) {
    seen.add(r.videoId)
    out.push({
      videoId: r.videoId,
      title: textFrom(r.title, 'Untitled'),
      channel: textFrom(r.ownerText, textFrom(r.shortBylineText, 'Unknown channel')),
      thumbnail: thumbFrom(r.thumbnail, r.videoId),
    })
    if (out.length >= limit) return
  }

  for (const value of Object.values(node)) {
    collectVideos(value, out, seen, limit)
    if (out.length >= limit) return
  }
}

async function searchYouTubeHtml(query, limit) {
  const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&hl=en&gl=US`
  const html = await fetchText(url)
  const initial = JSON.parse(extractInitialData(html))
  const tracks = []
  collectVideos(initial, tracks, new Set(), limit)
  if (!tracks.length) throw new Error('No video results found in YouTube response')
  return tracks
}

function normalizeInvidiousVideo(item) {
  const thumbs = Array.isArray(item.videoThumbnails) ? item.videoThumbnails : []
  const best = thumbs.find(t => t.quality === 'medium') || thumbs.find(t => t.quality === 'high') || thumbs[0]
  return {
    videoId: item.videoId,
    title: item.title || 'Untitled',
    channel: item.author || 'Unknown channel',
    thumbnail: best?.url || `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`,
    publishedAt: item.published ? new Date(Number(item.published) * 1000).toISOString() : undefined,
  }
}

async function searchInvidious(query, limit) {
  const failures = []
  for (const instance of invidiousInstances) {
    try {
      const url = `${instance}/api/v1/search?q=${encodeURIComponent(query)}&type=video&page=1&sort=relevance`
      const data = JSON.parse(await fetchText(url, 'application/json'))
      const tracks = (Array.isArray(data) ? data : [])
        .filter(item => item?.type === 'video' && item.videoId)
        .slice(0, limit)
        .map(normalizeInvidiousVideo)
      if (tracks.length) return { tracks, source: `invidious:${new URL(instance).host}` }
      failures.push(`${instance}: no video results`)
    } catch (error) {
      failures.push(`${instance}: ${error?.message || String(error)}`)
    }
  }
  throw new Error(`Invidious fallback failed (${failures.join('; ')})`)
}

async function search(query, limit) {
  const failures = []
  try {
    const tracks = await searchYouTubeInnertube(query, limit)
    return { tracks, source: 'youtube-innertube' }
  } catch (error) {
    failures.push(`InnerTube: ${error?.message || error}`)
  }
  try {
    const tracks = await searchYouTubeHtml(query, limit)
    return { tracks, source: 'youtube-html' }
  } catch (error) {
    failures.push(`HTML: ${error?.message || error}`)
  }
  try {
    return await searchInvidious(query, limit)
  } catch (error) {
    failures.push(error?.message || String(error))
  }
  throw new Error(`Keyless search failed (${failures.join(' | ')})`)
}

async function getVideo(videoId) {
  const watch = `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`
  const endpoint = `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(watch)}`
  try {
    const meta = JSON.parse(await fetchText(endpoint, 'application/json'))
    return {
      videoId,
      title: meta.title || `YouTube video ${videoId}`,
      channel: meta.author_name || 'YouTube',
      thumbnail: meta.thumbnail_url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    }
  } catch {
    return {
      videoId,
      title: `YouTube video ${videoId}`,
      channel: 'YouTube',
      thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    }
  }
}

function safeFileName(value) {
  return String(value || 'audio').replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').slice(0, 180)
}


const blockedDownloadExts = new Set(['.apk','.apks','.xapk','.aab','.dex','.exe','.dll','.com','.scr','.msi','.msp','.msix','.appx','.bat','.cmd','.ps1','.psm1','.vbs','.vbe','.js','.jse','.wsf','.wsh','.hta','.reg','.lnk','.sh','.bash','.zsh','.jar','.class','.war','.ear','.zip','.rar','.7z','.tar','.gz','.bz2','.xz','.cab','.iso','.img','.dmg','.pkg','.deb','.rpm'])
function normalizeMime(value) { return String(value || '').split(';', 1)[0].trim().toLowerCase() }
function mediaMime(type) { const t = normalizeMime(type); return t.startsWith('audio/') || t.startsWith('video/') || t === 'application/ogg' }
function genericBinaryMime(type) { const t = normalizeMime(type); return !t || t === 'application/octet-stream' || t === 'binary/octet-stream' || t === 'application/binary' }
function dangerousMime(type) { const t = normalizeMime(type); return ['android.package','java-archive','x-java','x-msdownload','x-msdos-program','x-executable','x-sh','shellscript','powershell','x-bat','x-rar','zip','7z','x-tar','gzip','x-iso9660'].some(x => t.includes(x)) }
function rejectDangerousName(value) { const ext = path.extname(String(value || '').split(/[?#]/, 1)[0]).toLowerCase(); if (blockedDownloadExts.has(ext)) throw new Error(`Blocked unsafe download type ${ext}. SidePlay only saves verified media.`) }
function looksDangerousPrefix(buf) {
  if (!buf?.length) return false
  if (buf.length >= 2 && buf[0] === 0x4d && buf[1] === 0x5a) return true
  if (buf.length >= 4 && buf[0] === 0x7f && buf.subarray(1,4).toString('ascii') === 'ELF') return true
  if (buf.length >= 4 && buf.subarray(0,4).toString('ascii') === 'dex\n') return true
  if (buf.length >= 4 && buf[0] === 0x50 && buf[1] === 0x4b && [0x03,0x05,0x07].includes(buf[2])) return true
  if (buf.length >= 6 && buf.subarray(0,4).toString('ascii') === 'Rar!' && buf[4] === 0x1a && buf[5] === 0x07) return true
  if (buf.length >= 6 && Buffer.from([0x37,0x7a,0xbc,0xaf,0x27,0x1c]).equals(buf.subarray(0,6))) return true
  const lead = buf.subarray(0,256).toString('latin1').replace(/\0/g,'').trim().toLowerCase()
  return lead.startsWith('#!') || lead.startsWith('@echo off') || lead.startsWith('powershell') || lead.startsWith('windows registry editor')
}
function looksDocumentPrefix(buf) { const lead = buf.subarray(0,512).toString('latin1').replace(/\0/g,'').trim().toLowerCase(); return lead.startsWith('<!doctype html') || lead.startsWith('<html') || lead.startsWith('<head') || lead.startsWith('<body') || lead.startsWith('<?xml') || lead.startsWith('{') || lead.startsWith('[') }
function looksMediaPrefix(buf) {
  if (!buf?.length) return false
  if (buf.length >= 3 && buf.subarray(0,3).toString('ascii') === 'ID3') return true
  if (buf.length >= 4 && ['fLaC','OggS'].includes(buf.subarray(0,4).toString('ascii'))) return true
  if (buf.length >= 12 && buf.subarray(0,4).toString('ascii') === 'RIFF' && buf.subarray(8,12).toString('ascii') === 'WAVE') return true
  if (buf.length >= 8 && buf.subarray(4,8).toString('ascii') === 'ftyp') return true
  if (buf.length >= 4 && Buffer.from([0x1a,0x45,0xdf,0xa3]).equals(buf.subarray(0,4))) return true
  if (buf.length >= 3 && buf.subarray(0,3).toString('ascii') === 'FLV') return true
  if (buf.length >= 5 && buf.subarray(0,5).toString('ascii') === '#!AMR') return true
  if (buf.length >= 2 && buf[0] === 0x0b && buf[1] === 0x77) return true
  if (buf.length >= 2 && buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0) return true
  if (buf.length >= 4 && buf[0] === 0x00 && buf[1] === 0x00 && buf[2] === 0x01 && [0xba,0xb3].includes(buf[3])) return true
  if (buf.length >= 188 && buf[0] === 0x47 && (buf.length < 377 || buf[188] === 0x47)) return true
  return false
}
function validateMediaMetadata({ type, names = [] }) { const mime = normalizeMime(type); if (dangerousMime(mime)) throw new Error(`Blocked potentially executable/package content type: ${mime}.`); if (mime && !mediaMime(mime) && !genericBinaryMime(mime)) throw new Error(`Server returned ${mime} instead of an audio/video file.`); for (const name of names) rejectDangerousName(name) }
function validateMediaPrefix(buf, type) { if (!buf?.length) throw new Error('Media file was empty.'); if (looksDangerousPrefix(buf)) throw new Error('Blocked a file whose contents look executable, packaged, scripted, or archived rather than media.'); if (looksDocumentPrefix(buf)) throw new Error('The URL/file returned a document payload rather than playable media.'); if (!mediaMime(type) && !looksMediaPrefix(buf)) throw new Error('SidePlay could not verify this generic binary response as audio/video media, so it was not saved.') }

function offlinePathFromUri(raw) {
  try {
    const u = new URL(raw)
    if (u.hostname !== HOST || Number(u.port || 80) !== PORT || !u.pathname.startsWith('/offline/')) return null
    const name = path.basename(decodeURIComponent(u.pathname.slice('/offline/'.length)))
    const target = path.resolve(OFFLINE_DIR, name)
    const root = path.resolve(OFFLINE_DIR) + path.sep
    return target.startsWith(root) ? target : null
  } catch { return null }
}

async function streamBodyToFile(req, finalPath, maxBytes = 4 * 1024 * 1024 * 1024, mimeType = '', nameHint = '') {
  const declared = Number(req.headers['content-length'] || 0)
  if (declared > maxBytes) throw new Error('File is larger than SidePlay\'s 4 GiB offline safety limit.')
  validateMediaMetadata({ type: mimeType || req.headers['content-type'], names: [nameHint] })
  const tempPath = `${finalPath}.partial-${process.pid}-${Date.now()}`
  let total = 0, checked = false, held = [], heldBytes = 0, output = null
  try {
    for await (const chunk of req) {
      total += chunk.length
      if (total > maxBytes) throw new Error('File exceeded SidePlay\'s 4 GiB offline safety limit.')
      if (!checked) {
        held.push(chunk); heldBytes += chunk.length
        if (heldBytes < 8192) continue
        validateMediaPrefix(Buffer.concat(held).subarray(0,8192), mimeType || req.headers['content-type'])
        output = fs.createWriteStream(tempPath, { flags: 'wx' })
        for (const part of held) if (!output.write(part)) await new Promise((resolve,reject)=>{ output.once('drain',resolve); output.once('error',reject) })
        held = []; checked = true
      } else if (!output.write(chunk)) await new Promise((resolve,reject)=>{ output.once('drain',resolve); output.once('error',reject) })
    }
    if (!total) throw new Error('The selected media file was empty.')
    if (!checked) {
      validateMediaPrefix(Buffer.concat(held).subarray(0,8192), mimeType || req.headers['content-type'])
      output = fs.createWriteStream(tempPath, { flags: 'wx' })
      for (const part of held) if (!output.write(part)) await new Promise((resolve,reject)=>{ output.once('drain',resolve); output.once('error',reject) })
    }
    await new Promise((resolve,reject)=>output.end(err=>err?reject(err):resolve()))
    fs.renameSync(tempPath, finalPath)
    return total
  } catch (error) {
    try { output?.destroy() } catch {}
    try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath) } catch {}
    throw error
  }
}

function serveOffline(req, res, file) {
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return json(res, 404, { error: 'Offline file not found' })
  const stat = fs.statSync(file)
  const ext = path.extname(file).toLowerCase()
  const mime = ({'.mp3':'audio/mpeg','.m4a':'audio/mp4','.aac':'audio/aac','.ogg':'audio/ogg','.opus':'audio/ogg','.flac':'audio/flac','.wav':'audio/wav','.webm':'audio/webm'})[ext] || 'application/octet-stream'
  const range = req.headers.range
  if (range) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(range)
    if (match) {
      const start = match[1] ? Number(match[1]) : 0
      const end = match[2] ? Math.min(Number(match[2]), stat.size - 1) : stat.size - 1
      if (Number.isFinite(start) && Number.isFinite(end) && start <= end && start < stat.size) {
        res.writeHead(206, {
          'content-type': mime,
          'content-length': end - start + 1,
          'content-range': `bytes ${start}-${end}/${stat.size}`,
          'accept-ranges': 'bytes',
          'cache-control': 'private, max-age=3600',
          'access-control-allow-origin': '*',
        })
        fs.createReadStream(file, { start, end }).pipe(res)
        return
      }
    }
    res.writeHead(416, { 'content-range': `bytes */${stat.size}` }); res.end(); return
  }
  res.writeHead(200, {
    'content-type': mime,
    'content-length': stat.size,
    'accept-ranges': 'bytes',
    'cache-control': 'private, max-age=3600',
    'access-control-allow-origin': '*',
  })
  fs.createReadStream(file).pipe(res)
}


async function readJson(req, maxBytes = 64 * 1024) {
  const chunks = []
  let total = 0
  for await (const chunk of req) {
    total += chunk.length
    if (total > maxBytes) throw new Error('Request body is too large.')
    chunks.push(chunk)
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}') }
  catch { throw new Error('Invalid JSON request.') }
}

function isBlockedDownloadHost(hostname) {
  const host = hostname.toLowerCase()
  return host === 'youtube.com' || host.endsWith('.youtube.com') || host === 'youtu.be' || host.endsWith('.googlevideo.com') || host.endsWith('spotify.com') || host.endsWith('scdn.co') || host === 'soundcloud.com' || host.endsWith('.soundcloud.com') || host.endsWith('sndcdn.com')
}

function filenameFromResponse(url, headers, requested) {
  if (requested) return safeFileName(requested)
  const disposition = headers.get('content-disposition') || ''
  const utf = disposition.match(/filename\*=UTF-8''([^;]+)/i)
  if (utf?.[1]) {
    try { return safeFileName(decodeURIComponent(utf[1].replace(/^"|"$/g, ''))) } catch {}
  }
  const plain = disposition.match(/filename="?([^";]+)"?/i)
  if (plain?.[1]) return safeFileName(plain[1])
  try {
    const name = path.basename(new URL(url).pathname)
    if (name && name !== '/') return safeFileName(decodeURIComponent(name))
  } catch {}
  return `SidePlay-${Date.now()}.media`
}

async function downloadDirectFile(rawUrl, requestedName) {
  let parsed
  try { parsed = new URL(rawUrl) } catch { throw new Error('Enter a valid direct media URL.') }
  if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('Only http(s) direct media URLs are supported.')
  if (isBlockedDownloadHost(parsed.hostname)) throw new Error('Provider-owned media downloads are not supported by SidePlay for this host.')
  rejectDangerousName(requestedName); rejectDangerousName(parsed.pathname)
  const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), 5 * 60 * 1000)
  try {
    const response = await fetch(parsed, { redirect:'follow', headers:{'user-agent':UA,accept:'audio/*,video/*,application/octet-stream;q=0.7,*/*;q=0.1'}, signal:controller.signal })
    if (!response.ok) throw new Error(`Remote server returned HTTP ${response.status}.`)
    const finalUrl = new URL(response.url || rawUrl)
    if (!['http:','https:'].includes(finalUrl.protocol)) throw new Error('Remote server redirected to an unsupported scheme.')
    const type = normalizeMime(response.headers.get('content-type') || '')
    const responseName = filenameFromResponse(finalUrl.toString(), response.headers, '')
    validateMediaMetadata({ type, names:[requestedName,responseName,finalUrl.pathname] })
    const maxBytes = 4 * 1024 * 1024 * 1024; const length = Number(response.headers.get('content-length') || 0)
    if (length > maxBytes) throw new Error('Direct download is larger than SidePlay\'s 4 GiB safety limit.')
    if (!response.body) throw new Error('Remote server returned no file body.')
    const iterator = response.body[Symbol.asyncIterator](); const held=[]; let heldBytes=0, ended=false
    while (heldBytes < 8192) { const next=await iterator.next(); if(next.done){ended=true;break}; const chunk=Buffer.from(next.value); held.push(chunk); heldBytes+=chunk.length }
    validateMediaPrefix(Buffer.concat(held).subarray(0,8192), type)
    const downloads=path.join(os.homedir(),'Downloads','SidePlay'); fs.mkdirSync(downloads,{recursive:true})
    let name=filenameFromResponse(finalUrl.toString(),response.headers,requestedName)
    if(!path.extname(name)){ const ext=type.startsWith('audio/mpeg')?'.mp3':type.startsWith('audio/mp4')?'.m4a':type.startsWith('audio/ogg')?'.ogg':type.startsWith('video/mp4')?'.mp4':type.startsWith('video/webm')?'.webm':'.media'; name+=ext }
    rejectDangerousName(name)
    let finalPath=path.join(downloads,name); if(fs.existsSync(finalPath)){const ext=path.extname(name),base=path.basename(name,ext);finalPath=path.join(downloads,`${base}-${Date.now()}${ext}`)}
    const temp=`${finalPath}.partial`, out=fs.createWriteStream(temp,{flags:'wx'}); let total=0
    try {
      for(const chunk of held){total+=chunk.length;if(total>maxBytes)throw new Error('Direct download exceeded SidePlay\'s 4 GiB safety limit.');if(!out.write(chunk))await new Promise((resolve,reject)=>{out.once('drain',resolve);out.once('error',reject)})}
      if(!ended)while(true){const next=await iterator.next();if(next.done)break;const chunk=Buffer.from(next.value);total+=chunk.length;if(total>maxBytes)throw new Error('Direct download exceeded SidePlay\'s 4 GiB safety limit.');if(!out.write(chunk))await new Promise((resolve,reject)=>{out.once('drain',resolve);out.once('error',reject)})}
      await new Promise((resolve,reject)=>out.end(err=>err?reject(err):resolve())); if(!total)throw new Error('Remote server returned an empty file.'); fs.renameSync(temp,finalPath)
      return {id:`pc-${Date.now()}`,destination:finalPath,bytes:total,verifiedMedia:true}
    } catch(error){try{out.destroy()}catch{};try{if(fs.existsSync(temp))fs.unlinkSync(temp)}catch{};throw error}
  } finally { clearTimeout(timer) }
}


async function suggestYouTube(query, limit = 10, hl = 'en', gl = 'US') {
  const endpoint = new URL('https://suggestqueries.google.com/complete/search')
  endpoint.searchParams.set('client', 'firefox')
  endpoint.searchParams.set('ds', 'yt')
  endpoint.searchParams.set('q', query)
  endpoint.searchParams.set('hl', /^[A-Za-z]{2,8}$/.test(hl) ? hl : 'en')
  endpoint.searchParams.set('gl', /^[A-Za-z]{2}$/.test(gl) ? gl.toUpperCase() : 'US')
  const response = await fetch(endpoint, { headers: { 'user-agent': UA, accept: 'application/json,text/plain,*/*' } })
  if (!response.ok) throw new Error(`Suggestion endpoint returned HTTP ${response.status}`)
  const data = await response.json()
  const raw = Array.isArray(data?.[1]) ? data[1] : []
  const seen = new Set()
  return raw.map(x => String(x || '').trim()).filter(x => x && !seen.has(x.toLowerCase()) && seen.add(x.toLowerCase())).slice(0, limit)
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return json(res, 204, {})

  try {
    const url = new URL(req.url || '/', `http://${HOST}:${PORT}`)

    if (req.method === 'GET' && url.pathname === '/health') {
      return json(res, 200, { ok: true, service: 'sideplay-pc-bridge', version: '0.3.0', offlineDir: OFFLINE_DIR })
    }
    if (req.method === 'GET' && url.pathname === '/api/suggest') {
      const query = (url.searchParams.get('q') || '').trim()
      const limit = Math.max(1, Math.min(Number(url.searchParams.get('limit') || 10) || 10, 15))
      const hl = (url.searchParams.get('hl') || 'en').trim()
      const gl = (url.searchParams.get('gl') || 'US').trim()
      if (!query) return json(res, 200, { suggestions: [] })
      return json(res, 200, { suggestions: await suggestYouTube(query, limit, hl, gl), source: 'youtube-suggest' })
    }
    if (req.method === 'GET' && url.pathname === '/api/search') {
      const query = (url.searchParams.get('q') || '').trim()
      const limit = Math.max(1, Math.min(Number(url.searchParams.get('limit') || 25) || 25, 50))
      if (!query) return json(res, 400, { error: 'q is required' })
      const result = await search(query, limit)
      return json(res, 200, result)
    }
    if (req.method === 'GET' && url.pathname === '/api/video') {
      const videoId = (url.searchParams.get('id') || '').trim()
      if (!/^[A-Za-z0-9_-]{11}$/.test(videoId)) return json(res, 400, { error: 'valid 11-character video id is required' })
      return json(res, 200, { track: await getVideo(videoId) })
    }
    if (req.method === 'POST' && url.pathname === '/api/offline/import') {
      const key = safeFileName(url.searchParams.get('key') || `track-${Date.now()}`)
      let original = 'audio'
      try { original = decodeURIComponent(req.headers['x-sideplay-filename'] || 'audio') } catch {}
      const ext = path.extname(safeFileName(original)).slice(0, 12)
      const name = `${key}${ext || '.audio'}`
      const file = path.join(OFFLINE_DIR, name)
      const bytes = await streamBodyToFile(req, file, 4 * 1024 * 1024 * 1024, req.headers['content-type'] || '', original)
      return json(res, 200, {
        localUri: `http://${HOST}:${PORT}/offline/${encodeURIComponent(name)}`,
        filename: safeFileName(original),
        mimeType: req.headers['content-type'] || 'application/octet-stream',
        bytes,
      })
    }
    if (req.method === 'DELETE' && url.pathname === '/api/offline') {
      const file = offlinePathFromUri(url.searchParams.get('uri') || '')
      if (!file) return json(res, 400, { error: 'Invalid SidePlay offline URI' })
      if (!fs.existsSync(file)) return json(res, 404, { error: 'Offline file not found' })
      fs.unlinkSync(file)
      return json(res, 200, { ok: true })
    }
    if (req.method === 'GET' && url.pathname.startsWith('/offline/')) {
      const name = path.basename(decodeURIComponent(url.pathname.slice('/offline/'.length)))
      const file = path.resolve(OFFLINE_DIR, name)
      const root = path.resolve(OFFLINE_DIR) + path.sep
      if (!file.startsWith(root)) return json(res, 400, { error: 'Invalid offline path' })
      return serveOffline(req, res, file)
    }
    if (req.method === 'POST' && url.pathname === '/api/direct-download') {
      const body = await readJson(req)
      const rawUrl = String(body?.url || '').trim()
      if (!rawUrl) return json(res, 400, { error: 'url is required' })
      const result = await downloadDirectFile(rawUrl, body?.filename ? String(body.filename) : '')
      return json(res, 200, result)
    }
    return json(res, 404, { error: 'Not found' })
  } catch (error) {
    return json(res, 502, { error: error?.message || String(error) })
  }
})

server.listen(PORT, HOST, () => {
  console.log(`[SidePlay PC bridge] http://${HOST}:${PORT}`)
  console.log(`[SidePlay offline vault] ${OFFLINE_DIR}`)
})

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => process.exit(0)))
}
