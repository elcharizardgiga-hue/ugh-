import fs from 'node:fs'
import { spawnSync } from 'node:child_process'

const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx'

function run(args) {
  console.log(`> ${npx} ${args.join(' ')}`)
  const r = spawnSync(npx, args, { stdio: 'inherit', shell: false })
  if (r.error) throw r.error
  if (r.status !== 0) process.exit(r.status ?? 1)
}

// SidePlay releases intentionally do not ship generated android/ output.
// Always recreate the Capacitor shell from the installed @capacitor/android
// version so a partial/stale directory can never trick CI into running sync
// before the platform has actually been added.
if (fs.existsSync('android')) {
  console.log('Removing stale/generated android/ shell...')
  fs.rmSync('android', { recursive: true, force: true })
}

console.log('Creating Capacitor Android platform...')
run(['cap', 'add', 'android'])

if (!fs.existsSync('android/gradlew')) {
  throw new Error('Capacitor reported success but android/gradlew was not created.')
}

console.log('Synchronizing web/native Capacitor state...')
run(['cap', 'sync', 'android'])

console.log('Applying SidePlay native Android engine...')
const patch = spawnSync(process.execPath, ['scripts/patch-android.mjs'], { stdio: 'inherit' })
if (patch.error) throw patch.error
if (patch.status !== 0) process.exit(patch.status ?? 1)

fs.writeFileSync('android/.sideplay-capacitor-major', '8\n')
console.log('SidePlay Android platform is ready.')
