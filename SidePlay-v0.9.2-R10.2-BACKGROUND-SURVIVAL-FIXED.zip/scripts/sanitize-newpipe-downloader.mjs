import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const candidates = [
  path.join(root, 'native', 'android', 'SidePlayNewPipeDownloader.java'),
  path.join(root, 'android', 'app', 'src', 'main', 'java', 'app', 'sideplay', 'mobile', 'SidePlayNewPipeDownloader.java'),
]

let touched = 0
for (const file of candidates) {
  if (!fs.existsSync(file)) continue
  const before = fs.readFileSync(file, 'utf8')
  const after = before
    .replace(/^import\s+javax\.annotation\.Nonnull;\s*$/gm, '')
    .replace(/@Nonnull\s+/g, '')
  if (after !== before) {
    fs.writeFileSync(file, after)
    touched++
    console.log(`Sanitized legacy javax.annotation usage: ${path.relative(root, file)}`)
  }
}

const canonical = candidates[0]
if (!fs.existsSync(canonical)) throw new Error('Missing native/android/SidePlayNewPipeDownloader.java')
const finalText = fs.readFileSync(canonical, 'utf8')
if (/javax\.annotation|@Nonnull/.test(finalText)) throw new Error('Could not remove legacy javax.annotation/Nonnull usage from the NewPipe downloader.')
console.log(touched ? `Sanitizer repaired ${touched} file(s).` : 'NewPipe downloader already javac-clean.')
