# SidePlay 0.8.4-r9 Hotfix3 — Cohesion Repair

This release pauses feature expansion and repairs the shared identity/state paths that Search, Queue, History, Taste and Now Playing all depend on.

## Metadata integrity

- Resolver placeholders such as `Untitled media`, generic YouTube labels and unknown channels no longer overwrite known catalog metadata.
- Metadata merges are quality-aware across playback resolution, queue/history persistence and offline metadata.
- Legacy placeholder tracks are repaired and Taste snapshots are healed when better metadata arrives.
- Generic artist/title buckets are excluded from Taste scoring and recommendation seeds.

## Search

- Search suggestions now actually disappear after a search is committed.
- Added generation guards so an older/slower search cannot overwrite a newer query.
- Added generation guards to remote autocomplete responses as well.

## Taste Engine

- Taste feedback is now recorded when the user abandons a track by choosing another track from any surface, not only the Next button.
- Play and queue signals can trigger recommendation refreshes so session taste becomes visible sooner.
- Old Taste events can recover identity from their own snapshots when catalog entries have rotated out.
- Placeholder identities are never frozen into new Taste events.

## Now Playing UX

- Fixed a later CSS rule that accidentally overrode the mobile scrollable player with `overflow:hidden`.
- Now Playing uses vertical touch scrolling and contained overscroll.

## Lyrics

- Added metadata-aware LRCLIB lookup for plain and synchronized lyrics.
- Added LRC parsing and synced line highlighting.
- Tapping a synced lyric seeks playback to that timestamp.
- Synced lyrics auto-follow the current playback position.
- Android gets a native LRCLIB fallback if WebView/browser lookup is blocked or unavailable.
- YouTube Music remains the video-id fallback.
- Added explicit loading, unavailable and Retry states; lyrics never block playback.

## Preserved hardening

- R8 queue integrity / playback atomicity.
- R9 intelligent search / Smart Radio / autocomplete.
- R9 Hotfix2 Playback Resurrection and low-memory recovery.
- NewPipe -> InnerTube SAFE -> isolated yt-dlp resolver ladder.

## Validation

- 17/17 source regression tests passing.
- 24 TS/TSX files parsed with TypeScript 5.8.3 with zero syntax diagnostics.
- Native Java source reaches dependency resolution under javac with no syntax-level error reported before missing Android/Capacitor classes.
