# SidePlay v0.8.4-r5 — Media Controls + Autoplay + Download 403 Recovery

## Background / lock-screen controls
- Explicit `DefaultMediaNotificationProvider` with a SidePlay playback channel and monochrome notification icon.
- MediaSession receives a `sessionActivity` PendingIntent so tapping the system media card returns to SidePlay.
- Playback startup uses `startForegroundService()` on Android O+; Media3 immediately owns the foreground media notification inside the isolated `:playback` process.
- Existing process shield remains: UI, Media3 `:playback`, and yt-dlp playback extraction `:extractor` are separate failure domains.

## Autoplay / queue
- Fixed a React state race in `store.next()` / `store.previous()`. The old code assigned the chosen track inside a deferred `setState` updater and returned immediately, so end-of-track autoplay could receive `null` even with a valid next item.
- Navigation now selects the target synchronously and then commits the index update.
- Existing Zero-Wait prefetch of the next two queue items remains enabled.

## Offline downloader
- Download UI starts at `0%` and ignores yt-dlp indeterminate negative progress instead of regressing to a permanent ellipsis.
- On YouTube HTTP 403, SidePlay updates yt-dlp once and retries public-media client paths in this order: `web_safari` (HLS-first), `android_vr`, `web_embedded`, `tv`.
- `web_safari` explicitly prefers HLS before direct GVS formats, matching yt-dlp's current PO-token guidance.
- Temporary files are cleared between client attempts so a failed partial download cannot poison the next attempt.
- If every path is blocked, the error explicitly identifies current YouTube PO-token/GVS enforcement instead of returning a vague provider failure.
- No DRM/decryption bypass is added.

## Build identity
- `versionName 0.8.4-r5`
- `versionCode 812`
