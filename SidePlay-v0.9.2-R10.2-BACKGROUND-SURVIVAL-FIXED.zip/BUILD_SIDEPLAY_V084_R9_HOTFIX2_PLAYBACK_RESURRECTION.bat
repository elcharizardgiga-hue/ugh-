@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "ROOT=%~dp0"
cd /d "%ROOT%"
title SidePlay v0.8.4-r9 HOTFIX2 - PLAYBACK RESURRECTION + PROCESS RECOVERY

set "SIDEPLAY_TOOLS=%LOCALAPPDATA%\SidePlay\tools"
if "%LOCALAPPDATA%"=="" set "SIDEPLAY_TOOLS=%USERPROFILE%\AppData\Local\SidePlay\tools"
set "LOG=%ROOT%sideplay-build.log"
set "ERRMSG=Unknown build error."
set "NEED_NPM=1"
if exist "SidePlay-debug.apk" del /q "SidePlay-debug.apk" >nul 2>&1
if exist "SidePlay-INSTALL.apk" del /q "SidePlay-INSTALL.apk" >nul 2>&1

where node >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Node.js 22+ was not found in PATH."
  goto :fail_early
)
where npm >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=npm was not found in PATH."
  goto :fail_early
)

for /f "delims=" %%V in ('node -p "require('./package.json').version"') do set "APPVER=%%V"
if "%APPVER%"=="" set "APPVER=unknown"
>"%LOG%" echo SidePlay Android Build v%APPVER% - %DATE% %TIME%

echo SidePlay Android Builder v%APPVER% - builder r9 HOTFIX2 PLAYBACK RESURRECTION + INTELLIGENCE + UX
echo Fast repeat builds + dependency-aware cache
echo Root: %ROOT%
echo Log: %LOG%
echo.

for /f "delims=" %%V in ('node -p "process.versions.node"') do set "NODEVER=%%V"
echo Node %NODEVER%
echo [%TIME%] builder revision r9 HOTFIX2 PLAYBACK RESURRECTION + TASTE ENGINE + SMART RADIO + ZERO WAIT + ENGINE DOCTOR root=%ROOT%>>"%LOG%"
echo [%TIME%] Node %NODEVER%>>"%LOG%"

node -e "const p=require('./package.json'); if(p.version!=='0.8.4-r9'||p.devDependencies?.typescript!=='5.8.3') process.exit(1)" >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=Release package metadata is stale: expected SidePlay 0.8.4-r9 with TypeScript 5.8.3."
  goto :fail
)

echo Checking native Android sources...
call node scripts\sanitize-newpipe-downloader.mjs >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=Could not sanitize legacy NewPipe downloader annotations."
  goto :fail
)
for %%F in (PlaybackService.java BackgroundAudioPlugin.java SharedTextPlugin.java NativeYouTubePlugin.java SidePlayNewPipeDownloader.java NewPipeYouTubeResolver.java YtDlpExtractorService.java YtDlpIsolatedClient.java DirectDownloadPlugin.java OfflineMediaPlugin.java WebPlaybackKeepAliveService.java WebPlaybackPlugin.java SpotifySessionListenerService.java SpotifySessionPlugin.java ProviderSessionPlugin.java SourceResolverPlugin.java YtDlpPlugin.java MediaCaptureActivity.java MediaSafety.java) do (
  if not exist "native\android\%%F" (
    set "ERRMSG=Release is incomplete: native\android\%%F is missing."
    goto :fail
  )
)
echo [ OK ] Native background playback sources present.
findstr /C:"getContext().startService(intent)" "%ROOT%native\android\BackgroundAudioPlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Media-control source check failed: foreground-tap startService lifecycle fix is missing."
  goto :fail
)
findstr /C:"startForegroundService(intent)" "%ROOT%native\android\BackgroundAudioPlugin.java" >nul 2>&1
if not errorlevel 1 (
  set "ERRMSG=Media-control source check failed: legacy forced foreground-service launch is still present."
  goto :fail
)
findstr /C:"DefaultMediaNotificationProvider" "%ROOT%native\android\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Media-control source check failed: explicit Media3 notification provider is missing."
  goto :fail
)
findstr /C:"sidePlayCommand" "%ROOT%native\android\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=MediaSession lifecycle fix is missing: private SidePlay commands would still hit Media3 super.onStartCommand."
  goto :fail
)
findstr /C:"addSession(mediaSession)" "%ROOT%native\android\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=MediaSession registration fix is missing: Android System UI will not discover the playback session."
  goto :fail
)
findstr /C:"discoverRadio" "%ROOT%src\App.tsx" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Radio autoplay source is missing."
  goto :fail
)
if not exist "%ROOT%src\lib\trackIdentity.ts" (
  set "ERRMSG=Legacy queue sanitizer source is missing."
  goto :fail
)
findstr /C:"repairTrackIdentity" "%ROOT%src\App.tsx" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Legacy YouTube autoplay sanitizer is missing from App.tsx."
  goto :fail
)
findstr /C:"provider: 'youtube'" "%ROOT%src\lib\recommendations.ts" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Recommendation normalization source is missing."
  goto :fail
)
findstr /C:"buildTasteProfile" "%ROOT%src\lib\tasteEngine.ts" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=R9 Taste Engine source is missing."
  goto :fail
)
findstr /C:"rankAndDedupeMusicSearch" "%ROOT%src\lib\musicIdentity.ts" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=R9 canonical search ranking source is missing."
  goto :fail
)
findstr /C:"NativeYouTube.lyrics" "%ROOT%src\lib\lyrics.ts" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=R9 lyrics bridge source is missing."
  goto :fail
)
findstr /C:"public void suggest(PluginCall call)" "%ROOT%native\android\NativeYouTubePlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=R9 native autocomplete method is missing."
  goto :fail
)
findstr /C:"public void lyrics(PluginCall call)" "%ROOT%native\android\NativeYouTubePlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=R9 native lyrics method is missing."
  goto :fail
)
findstr /C:"downloadUrl" "%ROOT%native\android\NewPipeYouTubeResolver.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=NewPipe direct-download fallback source is missing."
  goto :fail
)
findstr /C:"android_vr" "%ROOT%native\android\YtDlpPlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Downloader recovery source check failed: YouTube 403 client fallback ladder is missing."
  goto :fail
)
findstr /C:"protocol^=m3u8" "%ROOT%native\android\YtDlpPlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Downloader recovery source check failed: web_safari HLS-first fallback is missing."
  goto :fail
)
findstr /C:"SidePlay/0.8.4-r9 Android" "%ROOT%native\android\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Crash-safe PlaybackService source is missing or stale."
  goto :fail
)
findstr /C:"ACTION_SEEK" "%ROOT%native\android\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Process-shield PlaybackService source is missing ACTION_SEEK."
  goto :fail
)
findstr /C:"android-process:playback" "%ROOT%native\android\BackgroundAudioPlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Process-shield BackgroundAudioPlugin source is stale."
  goto :fail
)
findstr /C:"attemptStartupRecovery()" "%ROOT%native\android\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Playback Resurrection source is missing."
  goto :fail
)
findstr /C:"return hasRecentPlayingSnapshot() ? START_STICKY : START_NOT_STICKY;" "%ROOT%native\android\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Playback Resurrection sticky restart guard is missing."
  goto :fail
)
findstr /C:"restored-refreshed" "%ROOT%native\android\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Fresh provider-stream resurrection path is missing."
  goto :fail
)
findstr /C:"heartbeatAgeMs" "%ROOT%native\android\BackgroundAudioPlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Playback heartbeat diagnostics are missing."
  goto :fail
)
findstr /C:"reasonName" "%ROOT%native\android\BackgroundAudioPlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Readable Android process-exit diagnostics are missing."
  goto :fail
)
findstr /C:"innerTubeCooldownUntilMs" "%ROOT%native\android\NativeYouTubePlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=InnerTube circuit breaker is missing."
  goto :fail
)
findstr /C:", t);" "%ROOT%native\android\BackgroundAudioPlugin.java" | findstr /C:"call.reject" >nul 2>&1
if not errorlevel 1 (
  set "ERRMSG=Capacitor 8 compile guard failed: BackgroundAudioPlugin still passes Throwable directly to PluginCall.reject."
  goto :fail
)
findstr /C:"asException(Throwable t)" "%ROOT%native\android\BackgroundAudioPlugin.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Capacitor 8 compile guard failed: Throwable-to-Exception bridge is missing."
  goto :fail
)
findstr /C:"javax.annotation" native\android\SidePlayNewPipeDownloader.java >nul
if not errorlevel 1 (
  set "ERRMSG=Release source is stale: native\android\SidePlayNewPipeDownloader.java still imports javax.annotation. Re-extract this v0.8.4-r9 ZIP into a clean folder."
  goto :fail
)
echo [ OK ] Native downloader source is javac-clean.
echo [%TIME%] native source preflight OK>>"%LOG%"

rem ---------------------------------------------------------------------------
rem [1/7] Dependency cache validation.
rem Old SidePlay builds only checked for Capacitor, so a new dependency such as
rem jszip could be missing while the builder incorrectly printed "npm cache ready".
rem We hash only dependency declarations (not the app version) and also check the
rem important runtime/build packages. Version-only updates therefore stay fast.
rem ---------------------------------------------------------------------------
for /f "delims=" %%H in ('node -e "const p=require('./package.json'),c=require('crypto'); console.log(c.createHash('sha256').update(JSON.stringify([p.dependencies,p.devDependencies])).digest('hex'))"') do set "PKGHASH=%%H"
set "HASHFILE=node_modules\.sideplay-package.sha256"
set "CACHEDHASH="
if exist "%HASHFILE%" set /p CACHEDHASH=<"%HASHFILE%"

if /I "%PKGHASH%"=="%CACHEDHASH%" set "NEED_NPM=0"
if not exist node_modules\@capacitor\cli\package.json set "NEED_NPM=1"
if not exist node_modules\@capacitor\app\package.json set "NEED_NPM=1"
if not exist node_modules\react\package.json set "NEED_NPM=1"
if not exist node_modules\vite\package.json set "NEED_NPM=1"
if not exist node_modules\jszip\package.json set "NEED_NPM=1"

if "%NEED_NPM%"=="1" (
  echo [1/7] Syncing npm dependencies - package changed or cache incomplete...
  echo [%TIME%] [1/7] npm install --prefer-offline>>"%LOG%"
  call npm install --prefer-offline --no-audit --no-fund >>"%LOG%" 2>&1
  if errorlevel 1 (
    set "ERRMSG=npm dependency sync failed."
    goto :fail
  )
  if not exist node_modules mkdir node_modules >nul 2>&1
  >"%HASHFILE%" echo %PKGHASH%
) else (
  echo [1/7] npm dependencies unchanged - skip install.
  echo [%TIME%] [1/7] npm skipped; package hash matched>>"%LOG%"
)

echo [2/7] Running R9 Hotfix2 core regression tests...
echo [%TIME%] [2/7] core tests>>"%LOG%"
call npm run test:core >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=Core regression tests failed."
  goto :fail
)

echo [2/7] Building web app...
echo [%TIME%] [2/7] web build>>"%LOG%"
call npm run build >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=Web build failed."
  goto :fail
)

rem Regenerate the generated Android shell when it predates this marker or
rem was made by a different Capacitor major. This prevents a stale android/
rem folder from surviving source upgrades indefinitely.
for /f "delims=" %%V in ('node -p "require('@capacitor/android/package.json').version.split('.')[0]"') do set "CAPMAJOR=%%V"
set "ANDROID_RECREATE=0"
if exist android\gradlew.bat (
  set "OLD_CAPMAJOR="
  if exist android\.sideplay-capacitor-major set /p OLD_CAPMAJOR=<android\.sideplay-capacitor-major
  if not exist android\.sideplay-capacitor-major set "ANDROID_RECREATE=1"
  if defined OLD_CAPMAJOR if not "!OLD_CAPMAJOR!"=="!CAPMAJOR!" set "ANDROID_RECREATE=1"
)
if "!ANDROID_RECREATE!"=="1" (
  echo [3/7] Regenerating stale Android shell for Capacitor !CAPMAJOR!...
  echo [%TIME%] [3/7] removing stale android shell>>"%LOG%"
  rmdir /s /q android
)

if not exist android\gradlew.bat (
  echo [3/7] Creating Android project - first run only...
  echo [%TIME%] [3/7] cap add android>>"%LOG%"
  call npx cap add android >>"%LOG%" 2>&1
  if errorlevel 1 (
    set "ERRMSG=Capacitor could not create android/."
    goto :fail
  )
  set "NEED_SYNC=1"
) else (
  echo [3/7] Android project already exists.
  echo [%TIME%] [3/7] android exists>>"%LOG%"
  set "NEED_SYNC=0"
)

echo [4/7] Synchronizing Capacitor Android state...
echo [%TIME%] [4/7] cap sync android>>"%LOG%"
call npx cap sync android >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=Capacitor Android sync failed."
  goto :fail
)
>android\.sideplay-capacitor-major echo !CAPMAJOR!

echo [5/7] Patching native SidePlay bridge...
echo [%TIME%] [5/7] patch native>>"%LOG%"
call node scripts\patch-android.mjs >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=Native Android patch failed."
  goto :fail
)
findstr /C:":playback" "%ROOT%android\app\src\main\AndroidManifest.xml" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Process shield was not applied: PlaybackService is not in :playback."
  goto :fail
)
findstr /C:"addSession(mediaSession)" "%ROOT%android\app\src\main\java\app\sideplay\mobile\PlaybackService.java" >nul 2>&1
if errorlevel 1 (
  set "ERRMSG=Patched PlaybackService is missing MediaSessionService registration."
  goto :fail
)

if not exist "android\app\src\main\java\app\sideplay\mobile\YtDlpExtractorService.java" (
  set "ERRMSG=Isolated yt-dlp service was not copied into Android."
  goto :fail
)
if not exist "android\app\src\main\java\app\sideplay\mobile\YtDlpIsolatedClient.java" (
  set "ERRMSG=Isolated yt-dlp IPC client was not copied into Android."
  goto :fail
)
findstr /C:":extractor" android\app\src\main\AndroidManifest.xml >nul
if errorlevel 1 (
  set "ERRMSG=Isolated yt-dlp :extractor process is missing from AndroidManifest.xml."
  goto :fail
)
findstr /C:"javax.annotation" android\app\src\main\java\app\sideplay\mobile\SidePlayNewPipeDownloader.java >nul
if not errorlevel 1 (
  set "ERRMSG=Legacy javax.annotation import is still present and will fail javac."
  goto :fail
)

echo [6/7] Checking cached JDK + Android SDK...
echo [%TIME%] [6/7] toolchain check>>"%LOG%"
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\setup-android-tools.ps1 >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=Android toolchain setup failed."
  goto :fail
)
if not exist "%SIDEPLAY_TOOLS%\sideplay-env.bat" (
  set "ERRMSG=Toolchain environment file was not created."
  goto :fail
)
call "%SIDEPLAY_TOOLS%\sideplay-env.bat"

if not exist "%JAVA_HOME%\bin\java.exe" (
  set "ERRMSG=Cached Java executable is missing."
  goto :fail
)
if not exist "%ANDROID_HOME%\platforms\android-36\android.jar" (
  set "ERRMSG=Android SDK 36 is missing."
  goto :fail
)

echo [7/7] Clean Gradle package build + APK validation...
set "GRADLEW=%ROOT%android\gradlew.bat"
if not exist "%GRADLEW%" (
  set "ERRMSG=Gradle wrapper is missing: %GRADLEW%"
  goto :fail
)
echo [%TIME%] [7/7] gradle wrapper=%GRADLEW%>>"%LOG%"
echo [%TIME%] [7/7] gradle clean assembleDebug>>"%LOG%"
call "%GRADLEW%" -p "%ROOT%android" --daemon --build-cache --console=plain :app:clean :app:assembleDebug >>"%LOG%" 2>&1
set "GRADLE_RC=%ERRORLEVEL%"
if not "%GRADLE_RC%"=="0" (
  set "ERRMSG=Gradle compilation failed with exit code %GRADLE_RC%."
  goto :fail
)

set "APK=%ROOT%android\app\build\outputs\apk\debug\app-debug.apk"
if not exist "%APK%" (
  set "ERRMSG=Gradle finished but app-debug.apk was not found."
  goto :fail
)
copy /Y "%APK%" "%ROOT%SidePlay-INSTALL.apk" >nul
if errorlevel 1 (
  set "ERRMSG=Could not copy final APK."
  goto :fail
)

set "BT=%ANDROID_HOME%\build-tools\36.0.0"
set "APKSIGNER=%BT%\apksigner.bat"
set "AAPT=%BT%\aapt.exe"
set "ZIPALIGN=%BT%\zipalign.exe"
if not exist "%APKSIGNER%" (
  set "ERRMSG=apksigner is missing from Android build-tools 36.0.0."
  goto :fail
)
if not exist "%AAPT%" (
  set "ERRMSG=aapt is missing from Android build-tools 36.0.0."
  goto :fail
)
if not exist "%ZIPALIGN%" (
  set "ERRMSG=zipalign is missing from Android build-tools 36.0.0."
  goto :fail
)

echo [%TIME%] validating final APK signature>>"%LOG%"
call "%APKSIGNER%" verify --verbose --print-certs "%ROOT%SidePlay-INSTALL.apk" >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=APK signature verification failed. Refusing to hand off an invalid package."
  goto :fail
)

echo [%TIME%] validating APK ZIP alignment>>"%LOG%"
"%ZIPALIGN%" -c -v 4 "%ROOT%SidePlay-INSTALL.apk" >>"%LOG%" 2>&1
if errorlevel 1 (
  set "ERRMSG=APK zip alignment validation failed."
  goto :fail
)

echo [%TIME%] parsing APK manifest/package metadata>>"%LOG%"
"%AAPT%" dump badging "%ROOT%SidePlay-INSTALL.apk" > "%ROOT%sideplay-apk-badging.txt" 2>>"%LOG%"
if errorlevel 1 (
  set "ERRMSG=Android aapt could not parse the final APK package."
  goto :fail
)
findstr /C:"package: name='app.sideplay.mobile'" "%ROOT%sideplay-apk-badging.txt" >nul
if errorlevel 1 (
  set "ERRMSG=Final APK package id is not app.sideplay.mobile."
  goto :fail
)
findstr /C:"versionCode='816'" "%ROOT%sideplay-apk-badging.txt" >nul
if errorlevel 1 (
  set "ERRMSG=Final APK is not versionCode 816."
  goto :fail
)
findstr /C:"versionName='0.8.4-r9'" "%ROOT%sideplay-apk-badging.txt" >nul
if errorlevel 1 (
  set "ERRMSG=Final APK is not versionName 0.8.4-r9."
  goto :fail
)
"%AAPT%" dump xmltree "%ROOT%SidePlay-INSTALL.apk" AndroidManifest.xml > "%ROOT%sideplay-apk-manifest.txt" 2>>"%LOG%"
if errorlevel 1 (
  set "ERRMSG=Could not inspect the packaged AndroidManifest.xml."
  goto :fail
)
findstr /C:"YtDlpExtractorService" "%ROOT%sideplay-apk-manifest.txt" >nul
if errorlevel 1 (
  set "ERRMSG=Final APK does not contain YtDlpExtractorService."
  goto :fail
)
findstr /C:":extractor" "%ROOT%sideplay-apk-manifest.txt" >nul
if errorlevel 1 (
  set "ERRMSG=Final APK manifest does not contain the isolated :extractor process."
  goto :fail
)

for %%A in ("%ROOT%SidePlay-INSTALL.apk") do set "APKSIZE=%%~zA"
for /f "tokens=*" %%H in ('certutil -hashfile "%ROOT%SidePlay-INSTALL.apk" SHA256 ^| findstr /R /V "hash CertUtil"') do if not "%%H"=="" set "APKSHAFULL=%%H"
echo [%TIME%] SUCCESS SidePlay-INSTALL.apk !APKSIZE! bytes>>"%LOG%"
echo.
echo ========================================
echo   PACKAGE VERIFIED BY ANDROID TOOLS
echo   %ROOT%SidePlay-INSTALL.apk
echo ========================================
echo.
echo Signature: PASS
echo ZIP alignment: PASS
echo aapt package parse: PASS
echo Package: app.sideplay.mobile
echo APK metadata: sideplay-apk-badging.txt
echo Full details: sideplay-build.log
echo.
echo If the phone still refuses it, run VERIFY_SIDEPLAY_APK.bat first.
echo For the exact device PackageManager error, enable USB debugging and run INSTALL_SIDEPLAY_USB.bat.
echo.
pause
exit /b 0

:fail_early
echo SidePlay Android Builder
echo.
echo BUILD FAILED: %ERRMSG%
echo.
pause
exit /b 1

:fail
echo.
echo BUILD FAILED: %ERRMSG%
echo [%TIME%] BUILD FAILED: %ERRMSG%>>"%LOG%"
echo.
echo Last 60 log lines:
powershell -NoProfile -Command "if (Test-Path -LiteralPath '%LOG%') { Get-Content -LiteralPath '%LOG%' -Tail 60 }"
echo.
echo Full diagnostic log:
echo %LOG%
echo.
pause
exit /b 1
