package app.sideplay.mobile;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "NativeYouTube")
public class NativeYouTubePlugin extends Plugin {
    private static final ExecutorService PLAY_RESOLVER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "SidePlayNewPipeResolver");
        t.setDaemon(true);
        return t;
    });
    private static final String UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36";
    // yt-dlp is the expensive last line of defense, not the first thing every tap boots.
    // A short circuit breaker prevents repeated Python/QuickJS startup storms when a
    // provider change temporarily breaks the extractor on a particular device.
    private static volatile long ytdlpCooldownUntilMs = 0L;
    private static volatile int ytdlpFailureStreak = 0;
    private static volatile long newPipeCooldownUntilMs = 0L;
    private static volatile int newPipeFailureStreak = 0;
    private static volatile long innerTubeCooldownUntilMs = 0L;
    private static volatile int innerTubeFailureStreak = 0;

    // Lightweight in-memory engine telemetry for SidePlay Engine Doctor.
    // This intentionally contains no URLs/cookies/tokens; only counters + labels.
    private static volatile int newPipeSuccesses = 0;
    private static volatile int newPipeFailures = 0;
    private static volatile int innerTubeSuccesses = 0;
    private static volatile int innerTubeFailures = 0;
    private static volatile int ytdlpSuccesses = 0;
    private static volatile int ytdlpFailures = 0;
    private static volatile String lastResolverEngine = "none";
    private static volatile String lastResolverTrail = "";
    private static volatile String lastResolverError = "";
    private static volatile long lastResolvedAtMs = 0L;

    @PluginMethod
    public void search(PluginCall call) {
        final String query = call.getString("query", "").trim();
        final Integer requested = call.getInt("limit", 25);
        final int limit = Math.max(1, Math.min(requested == null ? 25 : requested, 50));
        if (query.isEmpty()) {
            call.reject("Search query is empty.");
            return;
        }

        new Thread(() -> {
            StringBuilder failures = new StringBuilder();
            try {
                JSArray tracks = searchInnertube(query, limit);
                JSObject result = new JSObject();
                result.put("tracks", tracks);
                result.put("source", "youtube-innertube");
                call.resolve(result);
                return;
            } catch (Exception e) {
                failures.append("InnerTube: ").append(message(e));
            }

            try {
                String url = "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, StandardCharsets.UTF_8.toString()) + "&hl=en&gl=US";
                String html = get(url);
                JSONObject initial = new JSONObject(extractInitialData(html));
                JSArray tracks = new JSArray();
                collectVideoRenderers(initial, tracks, new HashSet<>(), limit);
                if (tracks.length() == 0) throw new Exception("HTML parser returned no videos");
                JSObject result = new JSObject();
                result.put("tracks", tracks);
                result.put("source", "youtube-html");
                call.resolve(result);
            } catch (Exception e) {
                failures.append(" | HTML: ").append(message(e));
                call.reject("Keyless YouTube search failed: " + failures);
            }
        }).start();
    }

    @PluginMethod
    public void related(PluginCall call) {
        final String videoId = call.getString("videoId", "").trim();
        final Integer requested = call.getInt("limit", 30);
        final int limit = Math.max(1, Math.min(requested == null ? 30 : requested, 50));
        if (!videoId.matches("[A-Za-z0-9_-]{11}")) {
            call.reject("A valid videoId is required.");
            return;
        }

        new Thread(() -> {
            try {
                JSArray tracks = relatedInnertube(videoId, limit);
                JSObject result = new JSObject();
                result.put("tracks", tracks);
                result.put("source", "youtube-watch-next");
                call.resolve(result);
            } catch (Exception e) {
                call.reject("YouTube related feed failed: " + message(e));
            }
        }, "SidePlayRelated").start();
    }

    @PluginMethod
    public void suggest(PluginCall call) {
        final String query = call.getString("query", "").trim();
        final Integer requested = call.getInt("limit", 10);
        final int limit = Math.max(1, Math.min(requested == null ? 10 : requested, 15));
        final String hl = call.getString("hl", "en").replaceAll("[^A-Za-z-]", "");
        final String gl = call.getString("gl", "US").replaceAll("[^A-Za-z]", "");
        if (query.isEmpty()) {
            JSObject result = new JSObject();
            result.put("suggestions", new JSArray());
            result.put("source", "youtube-suggest");
            call.resolve(result);
            return;
        }
        new Thread(() -> {
            try {
                String endpoint = "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q="
                    + URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
                    + "&hl=" + URLEncoder.encode(hl.isEmpty() ? "en" : hl, StandardCharsets.UTF_8.toString())
                    + "&gl=" + URLEncoder.encode(gl.isEmpty() ? "US" : gl, StandardCharsets.UTF_8.toString());
                JSONArray root = new JSONArray(get(endpoint));
                JSONArray raw = root.optJSONArray(1);
                JSArray suggestions = new JSArray();
                Set<String> seen = new HashSet<>();
                if (raw != null) {
                    for (int i = 0; i < raw.length() && suggestions.length() < limit; i++) {
                        String value = raw.optString(i, "").trim();
                        String key = value.toLowerCase();
                        if (!value.isEmpty() && seen.add(key)) suggestions.put(value);
                    }
                }
                JSObject result = new JSObject();
                result.put("suggestions", suggestions);
                result.put("source", "youtube-suggest");
                call.resolve(result);
            } catch (Exception e) {
                call.reject("YouTube suggestions failed: " + message(e));
            }
        }, "SidePlaySuggest").start();
    }

    @PluginMethod
    public void lyrics(PluginCall call) {
        final String videoId = call.getString("videoId", "").trim();
        final String title = call.getString("title", "").trim();
        final String artist = call.getString("artist", "").trim();
        final Integer durationValue = call.getInt("durationMs", 0);
        final int durationMs = durationValue == null ? 0 : Math.max(0, durationValue);
        if (!videoId.matches("[A-Za-z0-9_-]{11}")) {
            call.reject("A valid videoId is required.");
            return;
        }
        new Thread(() -> {
            String youtubeFailure = "";
            try {
                String lyricText = lyricsInnertube(videoId);
                if (lyricText.trim().isEmpty()) throw new Exception("No lyrics were exposed for this track");
                JSObject result = new JSObject();
                result.put("videoId", videoId);
                result.put("text", lyricText);
                result.put("source", "YouTube Music");
                result.put("synced", false);
                result.put("fetchedAt", System.currentTimeMillis());
                call.resolve(result);
                return;
            } catch (Exception e) {
                youtubeFailure = message(e);
            }

            // HF3 fallback: use metadata-aware LRCLIB over native HTTP so lyrics
            // still work if WebView CORS or YouTube Music's private tab changes.
            if (!title.isEmpty() && !artist.isEmpty()) {
                try {
                    JSONObject row = lyricsLrclib(title, artist, durationMs);
                    String plain = row.optString("plainLyrics", "").trim();
                    String synced = row.optString("syncedLyrics", "").trim();
                    if (plain.isEmpty() && synced.isEmpty()) throw new Exception("matched record had no lyric text");
                    JSObject result = new JSObject();
                    result.put("videoId", videoId);
                    result.put("text", plain.isEmpty() ? stripLrcTimestamps(synced) : plain);
                    result.put("source", "LRCLIB");
                    result.put("synced", !synced.isEmpty());
                    if (!synced.isEmpty()) result.put("syncedText", synced);
                    result.put("fetchedAt", System.currentTimeMillis());
                    call.resolve(result);
                    return;
                } catch (Exception lrclibFailure) {
                    call.reject("Lyrics unavailable. YouTube Music: " + youtubeFailure + " | LRCLIB: " + message(lrclibFailure));
                    return;
                }
            }

            call.reject("Lyrics unavailable: " + youtubeFailure);
        }, "SidePlayLyrics").start();
    }

    @PluginMethod
    public void getVideo(PluginCall call) {
        final String videoId = call.getString("videoId", "").trim();
        if (videoId.isEmpty()) {
            call.reject("videoId is required.");
            return;
        }
        new Thread(() -> {
            try {
                String watch = "https://www.youtube.com/watch?v=" + URLEncoder.encode(videoId, StandardCharsets.UTF_8.toString());
                String endpoint = "https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(watch, StandardCharsets.UTF_8.toString());
                JSONObject meta = new JSONObject(get(endpoint));
                JSObject track = new JSObject();
                track.put("videoId", videoId);
                track.put("title", meta.optString("title", "YouTube video " + videoId));
                track.put("channel", meta.optString("author_name", "YouTube"));
                track.put("thumbnail", meta.optString("thumbnail_url", "https://i.ytimg.com/vi/" + videoId + "/hqdefault.jpg"));
                JSObject result = new JSObject();
                result.put("track", track);
                call.resolve(result);
            } catch (Exception e) {
                call.reject("Could not load video metadata: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
            }
        }).start();
    }


    /**
     * R4 SAFE PLAY resolver. This deliberately avoids the embedded Python/QuickJS
     * yt-dlp runtime. It asks YouTube's own lightweight InnerTube player endpoint
     * for already-signed clear media URLs and only returns formats that contain a
     * direct `url` field. Cipher-only formats are not deciphered here.
     */
    @PluginMethod
    public void resolve(PluginCall call) {
        final String rawUrl = call.getString("url", "").trim();
        String rawId = call.getString("videoId", "").trim();
        final boolean audioOnly = Boolean.TRUE.equals(call.getBoolean("audioOnly", false));
        final boolean allowHeavyFallback = !Boolean.FALSE.equals(call.getBoolean("allowHeavyFallback", true));
        if (rawId.isEmpty()) rawId = youtubeIdFrom(rawUrl);
        if (rawId.isEmpty()) {
            call.reject("A valid YouTube video URL or videoId is required.");
            return;
        }
        final String videoId = rawId;
        final String source = rawUrl.isEmpty() ? "https://www.youtube.com/watch?v=" + videoId : rawUrl;

        PLAY_RESOLVER.execute(() -> {
            String newPipeFailure = "";
            String safeFailureText = "";
            long newPipeNow = System.currentTimeMillis();
            if (newPipeNow < newPipeCooldownUntilMs) {
                long seconds = Math.max(1L, (newPipeCooldownUntilMs - newPipeNow + 999L) / 1000L);
                newPipeFailure = "cooldown " + seconds + "s after repeated failures";
                lastResolverError = "NewPipe: " + newPipeFailure;
            } else {
                try {
                    JSObject primary = NewPipeYouTubeResolver.resolve(source, videoId, audioOnly);
                    primary.put("resolverTrail", "newpipe");
                    newPipeSuccesses++;
                    newPipeFailureStreak = 0;
                    newPipeCooldownUntilMs = 0L;
                    lastResolverEngine = "newpipe";
                    lastResolverTrail = "newpipe";
                    lastResolverError = "";
                    lastResolvedAtMs = System.currentTimeMillis();
                    call.resolve(primary);
                    return;
                } catch (Exception e) {
                    newPipeFailures++;
                    newPipeFailureStreak = Math.min(8, newPipeFailureStreak + 1);
                    if (newPipeFailureStreak >= 3) {
                        long cooldown = Math.min(120_000L, 15_000L * (1L << Math.min(3, newPipeFailureStreak - 3)));
                        newPipeCooldownUntilMs = System.currentTimeMillis() + cooldown;
                    }
                    newPipeFailure = message(e);
                    lastResolverError = "NewPipe: " + newPipeFailure;
                }
            }

            // Keep the zero-Python InnerTube path second, but stop hammering it when
            // a provider/client change makes it repeatedly return no usable direct URL.
            long innerNow = System.currentTimeMillis();
            if (innerNow < innerTubeCooldownUntilMs) {
                long seconds = Math.max(1L, (innerTubeCooldownUntilMs - innerNow + 999L) / 1000L);
                safeFailureText = "cooldown " + seconds + "s after repeated failures";
                lastResolverError = "NewPipe: " + newPipeFailure + " | InnerTube SAFE: " + safeFailureText;
            } else {
                try {
                    JSObject fallback = resolvePlayer(videoId, source, audioOnly);
                    fallback.put("resolverEngine", "innertube-safe");
                    fallback.put("resolverTrail", "newpipe -> innertube-safe");
                    fallback.put("resolvedAt", System.currentTimeMillis());
                    fallback.put("note", "Resolved by SAFE PLAY after NewPipe failed: " + newPipeFailure);
                    innerTubeSuccesses++;
                    innerTubeFailureStreak = 0;
                    innerTubeCooldownUntilMs = 0L;
                    lastResolverEngine = "innertube-safe";
                    lastResolverTrail = "newpipe -> innertube-safe";
                    lastResolverError = "";
                    lastResolvedAtMs = System.currentTimeMillis();
                    call.resolve(fallback);
                    return;
                } catch (Exception safeFailure) {
                    innerTubeFailures++;
                    innerTubeFailureStreak = Math.min(8, innerTubeFailureStreak + 1);
                    if (innerTubeFailureStreak >= 3) {
                        long cooldown = Math.min(300_000L, 30_000L * (1L << Math.min(4, innerTubeFailureStreak - 3)));
                        innerTubeCooldownUntilMs = System.currentTimeMillis() + cooldown;
                    }
                    safeFailureText = message(safeFailure);
                    lastResolverError = "NewPipe: " + newPipeFailure + " | InnerTube: " + safeFailureText;
                }
            }

            // Prefetch is intentionally lightweight: never wake Python/QuickJS/yt-dlp
            // just because an item happens to be next in the queue. A real Play tap may
            // still escalate to the isolated extractor if both cheap resolvers fail.
            if (!allowHeavyFallback) {
                call.reject("Lightweight resolver prefetch stopped before yt-dlp. NewPipe: " + newPipeFailure
                    + " | Safe fallback: " + safeFailureText);
                return;
            }

            // Final fallback: yt-dlp. R5 kept this completely out of normal Play after an
            // OEM crash. R6/0.8.3 brings it back only after both lightweight resolvers fail,
            // serialized inside YtDlpPlugin and protected by a short failure cooldown.
            long now = System.currentTimeMillis();
            if (now < ytdlpCooldownUntilMs) {
                long seconds = Math.max(1L, (ytdlpCooldownUntilMs - now + 999L) / 1000L);
                call.reject("YouTube resolver failed. NewPipe: " + newPipeFailure
                    + " | Safe fallback: " + safeFailureText
                    + " | yt-dlp cooling down for " + seconds + "s after a recent failure.");
                return;
            }
            try {
                String heavyJson = YtDlpIsolatedClient.resolveBlocking(getContext(), source, audioOnly, 24_000L);
                JSONObject heavyRaw = new JSONObject(heavyJson);
                JSObject heavy = new JSObject();
                java.util.Iterator<String> heavyKeys = heavyRaw.keys();
                while (heavyKeys.hasNext()) {
                    String key = heavyKeys.next();
                    heavy.put(key, heavyRaw.get(key));
                }
                heavy.put("extractorIsolation", "android-process:extractor");
                ytdlpFailureStreak = 0;
                ytdlpCooldownUntilMs = 0L;
                ytdlpSuccesses++;
                lastResolverEngine = "yt-dlp";
                lastResolverTrail = "newpipe -> innertube-safe -> yt-dlp";
                lastResolverError = "";
                lastResolvedAtMs = System.currentTimeMillis();
                heavy.put("resolverEngine", "yt-dlp");
                heavy.put("resolverTrail", "newpipe -> innertube-safe -> yt-dlp");
                heavy.put("resolvedAt", System.currentTimeMillis());
                heavy.put("note", "Resolved by yt-dlp after NewPipe and SAFE PLAY failed. NewPipe: "
                    + newPipeFailure + " | Safe fallback: " + safeFailureText);
                call.resolve(heavy);
            } catch (Throwable heavyFailure) {
                ytdlpFailures++;
                ytdlpFailureStreak = Math.min(6, ytdlpFailureStreak + 1);
                long cooldown = Math.min(120_000L, 15_000L * (1L << Math.max(0, ytdlpFailureStreak - 1)));
                ytdlpCooldownUntilMs = System.currentTimeMillis() + cooldown;
                lastResolverError = "NewPipe: " + newPipeFailure + " | InnerTube: " + safeFailureText + " | yt-dlp: " + message(heavyFailure);
                call.reject("YouTube resolver failed. NewPipe: " + newPipeFailure
                    + " | Safe fallback: " + safeFailureText
                    + " | yt-dlp: " + message(heavyFailure));
            }
        });
    }

    @PluginMethod
    public void getResolverHealth(PluginCall call) {
        JSObject out = new JSObject();
        long now = System.currentTimeMillis();
        out.put("newPipeSuccesses", newPipeSuccesses);
        out.put("newPipeFailures", newPipeFailures);
        out.put("newPipeFailureStreak", newPipeFailureStreak);
        out.put("newPipeCooldownMs", Math.max(0L, newPipeCooldownUntilMs - now));
        out.put("innerTubeSuccesses", innerTubeSuccesses);
        out.put("innerTubeFailures", innerTubeFailures);
        out.put("innerTubeFailureStreak", innerTubeFailureStreak);
        out.put("innerTubeCooldownMs", Math.max(0L, innerTubeCooldownUntilMs - now));
        out.put("ytdlpSuccesses", ytdlpSuccesses);
        out.put("ytdlpFailures", ytdlpFailures);
        out.put("ytdlpFailureStreak", ytdlpFailureStreak);
        out.put("ytdlpCooldownMs", Math.max(0L, ytdlpCooldownUntilMs - now));
        out.put("lastResolverEngine", lastResolverEngine);
        out.put("lastResolverTrail", lastResolverTrail);
        out.put("lastResolverError", lastResolverError);
        out.put("lastResolvedAt", lastResolvedAtMs);
        out.put("extractorIsolation", "android-process:extractor");
        out.put("newPipeVersion", "0.26.5");
        out.put("ytDlpAndroidVersion", "0.18.1");
        call.resolve(out);
    }

    @PluginMethod
    public void resetResolverHealth(PluginCall call) {
        newPipeSuccesses = 0;
        newPipeFailures = 0;
        newPipeFailureStreak = 0;
        newPipeCooldownUntilMs = 0L;
        innerTubeSuccesses = 0;
        innerTubeFailures = 0;
        innerTubeFailureStreak = 0;
        innerTubeCooldownUntilMs = 0L;
        ytdlpSuccesses = 0;
        ytdlpFailures = 0;
        ytdlpFailureStreak = 0;
        ytdlpCooldownUntilMs = 0L;
        lastResolverEngine = "none";
        lastResolverTrail = "";
        lastResolverError = "";
        lastResolvedAtMs = 0L;
        call.resolve(new JSObject());
    }

    public static JSObject resolveSafeForPlayback(String videoId, String source, boolean audioOnly) throws Exception {
        long now = System.currentTimeMillis();
        if (now < innerTubeCooldownUntilMs) {
            long seconds = Math.max(1L, (innerTubeCooldownUntilMs - now + 999L) / 1000L);
            throw new Exception("InnerTube SAFE cooling down for " + seconds + "s after repeated failures.");
        }
        try {
            JSObject out = resolvePlayer(videoId, source, audioOnly);
            innerTubeFailureStreak = 0;
            innerTubeCooldownUntilMs = 0L;
            return out;
        } catch (Exception failure) {
            innerTubeFailureStreak = Math.min(8, innerTubeFailureStreak + 1);
            if (innerTubeFailureStreak >= 3) {
                long cooldown = Math.min(300_000L, 30_000L * (1L << Math.min(4, innerTubeFailureStreak - 3)));
                innerTubeCooldownUntilMs = System.currentTimeMillis() + cooldown;
            }
            throw failure;
        }
    }

    private static JSObject resolvePlayer(String videoId, String source, boolean audioOnly) throws Exception {
        String apiKey = "";
        String webVersion = "2.20260909.00.00";
        try {
            String homepage = get("https://www.youtube.com/?hl=en&gl=US");
            apiKey = findJsonStringValue(homepage, "INNERTUBE_API_KEY");
            String detected = extractClientVersion(homepage);
            if (!detected.isEmpty()) webVersion = detected;
        } catch (Exception ignored) {}
        if (apiKey.isEmpty()) apiKey = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";

        String[][] clients = new String[][] {
            {"ANDROID", "21.36.45", "3", "com.google.android.youtube/21.36.45 (Linux; U; Android 14; en_US) gzip"},
            {"WEB", webVersion, "1", UA}
        };
        StringBuilder failures = new StringBuilder();
        for (String[] client : clients) {
            try {
                JSONObject player = playerRequest(videoId, apiKey, client[0], client[1], client[2], client[3]);
                String status = player.optJSONObject("playabilityStatus") == null ? "" : player.optJSONObject("playabilityStatus").optString("status", "");
                if (!"OK".equals(status)) {
                    String reason = player.optJSONObject("playabilityStatus") == null ? "unavailable" : player.optJSONObject("playabilityStatus").optString("reason", status);
                    throw new Exception(reason.isEmpty() ? "Video is not playable for client " + client[0] : reason);
                }
                JSONObject streaming = player.optJSONObject("streamingData");
                if (streaming == null) throw new Exception("Player returned no streamingData.");

                JSONObject chosen = chooseDirectFormat(streaming, audioOnly);
                String playback = chosen == null ? "" : chosen.optString("url", "");
                String mime = chosen == null ? "" : mimeBase(chosen.optString("mimeType", ""));
                String mediaKind = mime.startsWith("video/") ? "video" : "audio";
                boolean progressiveDownload = !playback.isEmpty();

                if (playback.isEmpty() && !audioOnly) {
                    String dash = streaming.optString("dashManifestUrl", "");
                    if (!dash.isEmpty()) {
                        playback = dash;
                        mime = "application/dash+xml";
                        mediaKind = "video";
                        progressiveDownload = false;
                    }
                }
                if (playback.isEmpty() && !audioOnly) {
                    String hls = streaming.optString("hlsManifestUrl", "");
                    if (!hls.isEmpty()) {
                        playback = hls;
                        mime = "application/x-mpegURL";
                        mediaKind = "video";
                        progressiveDownload = false;
                    }
                }
                if (playback.isEmpty() && !audioOnly) {
                    JSONObject audioFallback = chooseDirectFormat(streaming, true);
                    if (audioFallback != null) {
                        playback = audioFallback.optString("url", "");
                        mime = mimeBase(audioFallback.optString("mimeType", ""));
                        mediaKind = "audio";
                        progressiveDownload = !playback.isEmpty();
                    }
                }
                if (playback.isEmpty()) throw new Exception("Only cipher-protected formats were returned; no direct stream URL/manifest was available.");

                JSONObject details = player.optJSONObject("videoDetails");
                JSObject out = new JSObject();
                out.put("id", videoId);
                out.put("title", details == null ? "YouTube video " + videoId : details.optString("title", "YouTube video " + videoId));
                out.put("artist", details == null ? "YouTube" : details.optString("author", "YouTube"));
                String thumb = bestVideoThumbnail(details, videoId);
                if (!thumb.isEmpty()) out.put("thumbnail", thumb);
                out.put("provider", "youtube");
                out.put("sourceUrl", source);
                out.put("playbackUrl", playback);
                if (!mime.isEmpty()) out.put("mimeType", mime);
                out.put("mediaKind", audioOnly ? "audio" : mediaKind);
                out.put("audioPreferred", audioOnly);
                if (details != null) {
                    try {
                        long seconds = Long.parseLong(details.optString("lengthSeconds", "0"));
                        if (seconds > 0) out.put("durationMs", seconds * 1000L);
                    } catch (Exception ignored) {}
                }
                JSObject headers = new JSObject();
                headers.put("User-Agent", client[3]);
                headers.put("Referer", "https://www.youtube.com/");
                out.put("requestHeaders", headers);
                out.put("playable", true);
                out.put("downloadable", true);
                if (progressiveDownload) {
                    out.put("downloadUrl", playback);
                    out.put("downloadEngine", "direct");
                } else {
                    out.put("downloadEngine", "ytdlp");
                }
                out.put("sessionBound", true);
                out.put("refreshMode", "youtube-native");
                out.put("note", "Resolved through SidePlay SAFE PLAY without starting Python/QuickJS/yt-dlp.");
                return out;
            } catch (Exception e) {
                if (failures.length() > 0) failures.append(" | ");
                failures.append(client[0]).append(": ").append(message(e));
            }
        }
        throw new Exception(failures.length() == 0 ? "No safe client returned a direct stream." : failures.toString());
    }

    private static JSONObject playerRequest(String videoId, String apiKey, String clientName, String clientVersion, String clientId, String userAgent) throws Exception {
        JSONObject client = new JSONObject();
        client.put("clientName", clientName);
        client.put("clientVersion", clientVersion);
        client.put("hl", "en");
        client.put("gl", "US");
        if ("ANDROID".equals(clientName)) {
            client.put("androidSdkVersion", 35);
            client.put("osName", "Android");
            client.put("osVersion", "14");
        } else {
            client.put("platform", "DESKTOP");
        }
        JSONObject context = new JSONObject();
        context.put("client", client);
        JSONObject body = new JSONObject();
        body.put("context", context);
        body.put("videoId", videoId);
        body.put("contentCheckOk", true);
        body.put("racyCheckOk", true);
        String endpoint = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false" + (apiKey.isEmpty() ? "" : "&key=" + URLEncoder.encode(apiKey, StandardCharsets.UTF_8.toString()));
        return new JSONObject(postPlayerJson(endpoint, body.toString(), clientId, clientVersion, userAgent));
    }

    private static JSONObject chooseDirectFormat(JSONObject streaming, boolean audioOnly) {
        JSONObject best = null;
        long bestScore = Long.MIN_VALUE;
        JSONArray[] groups = new JSONArray[] { streaming.optJSONArray("formats"), streaming.optJSONArray("adaptiveFormats") };
        for (JSONArray group : groups) {
            if (group == null) continue;
            for (int i = 0; i < group.length(); i++) {
                JSONObject f = group.optJSONObject(i);
                if (f == null || f.optString("url", "").isEmpty()) continue;
                String mime = f.optString("mimeType", "").toLowerCase();
                boolean audio = mime.startsWith("audio/");
                boolean video = mime.startsWith("video/");
                if (audioOnly && !audio) continue;
                if (!audioOnly && !video) continue;
                if (!audioOnly && !(f.has("audioQuality") || f.optInt("audioChannels", 0) > 0)) continue;
                long bitrate = f.optLong("bitrate", 0L);
                long height = f.optLong("height", 0L);
                long score = audioOnly ? bitrate : height * 100000000L + bitrate;
                // Prefer progressive A/V formats when available. Adaptive video-only
                // formats normally have no audioQuality/audioChannels metadata.
                if (!audioOnly && (f.has("audioQuality") || f.optInt("audioChannels", 0) > 0)) score += 1000000000000L;
                if (best == null || score > bestScore) {
                    best = f;
                    bestScore = score;
                }
            }
        }
        return best;
    }

    private static String bestVideoThumbnail(JSONObject details, String videoId) {
        if (details != null) {
            JSONObject thumbnail = details.optJSONObject("thumbnail");
            JSONArray thumbs = thumbnail == null ? null : thumbnail.optJSONArray("thumbnails");
            if (thumbs != null) {
                for (int i = thumbs.length() - 1; i >= 0; i--) {
                    JSONObject t = thumbs.optJSONObject(i);
                    if (t != null && !t.optString("url", "").isEmpty()) return t.optString("url", "");
                }
            }
        }
        return "https://i.ytimg.com/vi/" + videoId + "/hqdefault.jpg";
    }

    private static String mimeBase(String raw) {
        if (raw == null) return "";
        int semicolon = raw.indexOf(';');
        return (semicolon >= 0 ? raw.substring(0, semicolon) : raw).trim();
    }

    private static String youtubeIdFrom(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        if (value.matches("[A-Za-z0-9_-]{11}")) return value;
        try {
            URI uri = URI.create(value);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
            String path = uri.getPath() == null ? "" : uri.getPath();
            if (host.equals("youtu.be") || host.endsWith(".youtu.be")) {
                String[] parts = path.split("/");
                for (String part : parts) if (part.matches("[A-Za-z0-9_-]{11}")) return part;
            }
            if (host.contains("youtube.com")) {
                String query = uri.getRawQuery();
                if (query != null) {
                    for (String pair : query.split("&")) {
                        int eq = pair.indexOf('=');
                        if (eq > 0 && pair.substring(0, eq).equals("v")) {
                            String id = java.net.URLDecoder.decode(pair.substring(eq + 1), StandardCharsets.UTF_8.toString());
                            if (id.matches("[A-Za-z0-9_-]{11}")) return id;
                        }
                    }
                }
                for (String part : path.split("/")) if (part.matches("[A-Za-z0-9_-]{11}")) return part;
            }
        } catch (Exception ignored) {}
        return "";
    }

    private static String postPlayerJson(String urlString, String body, String clientId, String clientVersion, String userAgent) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("User-Agent", userAgent);
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Origin", "https://www.youtube.com");
        conn.setRequestProperty("Referer", "https://www.youtube.com/");
        conn.setRequestProperty("X-YouTube-Client-Name", clientId);
        conn.setRequestProperty("X-YouTube-Client-Version", clientVersion);
        byte[] payload = body.getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(payload.length);
        try (OutputStream os = conn.getOutputStream()) { os.write(payload); }
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder responseBody = new StringBuilder();
        if (stream != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) responseBody.append(line).append('\n');
            }
        }
        conn.disconnect();
        if (code < 200 || code >= 400) throw new Exception("HTTP " + code + ": " + responseBody.substring(0, Math.min(220, responseBody.length())));
        return responseBody.toString();
    }

    private static String message(Throwable e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    private JSArray searchInnertube(String query, int limit) throws Exception {
        String clientVersion = "2.20260909.00.00";
        try {
            clientVersion = extractClientVersion(get("https://www.youtube.com/?hl=en&gl=US"));
        } catch (Exception ignored) {}

        JSONObject client = new JSONObject();
        client.put("clientName", "WEB");
        client.put("clientVersion", clientVersion);
        client.put("hl", "en");
        client.put("gl", "US");
        client.put("platform", "DESKTOP");

        JSONObject context = new JSONObject();
        context.put("client", client);
        JSONObject body = new JSONObject();
        body.put("context", context);
        body.put("query", query);

        JSONObject response = new JSONObject(postJson("https://www.youtube.com/youtubei/v1/search?prettyPrint=false", body.toString()));
        JSArray tracks = new JSArray();
        collectVideoRenderers(response, tracks, new HashSet<>(), limit);
        if (tracks.length() == 0) throw new Exception("InnerTube returned no video results");
        return tracks;
    }

    private JSArray relatedInnertube(String videoId, int limit) throws Exception {
        String clientVersion = "2.20260909.00.00";
        try {
            clientVersion = extractClientVersion(get("https://www.youtube.com/?hl=en&gl=US"));
        } catch (Exception ignored) {}

        JSONObject client = new JSONObject();
        client.put("clientName", "WEB");
        client.put("clientVersion", clientVersion);
        client.put("hl", "en");
        client.put("gl", "US");
        client.put("platform", "DESKTOP");

        JSONObject context = new JSONObject();
        context.put("client", client);
        JSONObject body = new JSONObject();
        body.put("context", context);
        body.put("videoId", videoId);
        body.put("contentCheckOk", true);
        body.put("racyCheckOk", true);

        JSONObject response = new JSONObject(postJson("https://www.youtube.com/youtubei/v1/next?prettyPrint=false", body.toString()));
        JSArray tracks = new JSArray();
        collectRelatedRenderers(response, tracks, new HashSet<>(), limit, videoId);
        if (tracks.length() == 0) throw new Exception("Watch-next returned no related videos");
        return tracks;
    }

    private JSONObject lyricsLrclib(String title, String artist, int durationMs) throws Exception {
        String base = "https://lrclib.net/api/get?track_name="
            + URLEncoder.encode(title, StandardCharsets.UTF_8.toString())
            + "&artist_name=" + URLEncoder.encode(artist, StandardCharsets.UTF_8.toString());
        if (durationMs > 10_000) base += "&duration=" + Math.round(durationMs / 1000.0);
        try {
            JSONObject exact = new JSONObject(get(base));
            if (!exact.optBoolean("instrumental", false)
                && (!exact.optString("plainLyrics", "").trim().isEmpty() || !exact.optString("syncedLyrics", "").trim().isEmpty())) return exact;
        } catch (Exception ignored) {}

        String query = artist + " " + title;
        String searchUrl = "https://lrclib.net/api/search?track_name="
            + URLEncoder.encode(title, StandardCharsets.UTF_8.toString())
            + "&artist_name=" + URLEncoder.encode(artist, StandardCharsets.UTF_8.toString())
            + "&q=" + URLEncoder.encode(query, StandardCharsets.UTF_8.toString());
        JSONArray rows = new JSONArray(get(searchUrl));
        JSONObject best = null;
        double bestScore = 0.0;
        double targetDuration = durationMs > 10_000 ? durationMs / 1000.0 : 0.0;

        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null || row.optBoolean("instrumental", false)) continue;

            String plain = row.optString("plainLyrics", "").trim();
            String synced = row.optString("syncedLyrics", "").trim();
            if (plain.isEmpty() && synced.isEmpty()) continue;

            double titleScore = lyricSimilarity(title, row.optString("trackName", ""));
            double artistScore = lyricSimilarity(artist, row.optString("artistName", ""));

            // Native fallback used to accept the first search hit. That made an
            // unrelated result sticky enough to look like a hardcoded lyrics path.
            if (titleScore < 0.48 || artistScore < 0.34) continue;

            double score = titleScore * 8.0 + artistScore * 7.0;
            double rowDuration = row.optDouble("duration", 0.0);
            if (targetDuration > 0.0 && rowDuration > 0.0) {
                score -= Math.min(5.0, Math.abs(targetDuration - rowDuration) / 8.0);
            }
            if (!synced.isEmpty()) score += 0.8;

            if (best == null || score > bestScore) {
                best = row;
                bestScore = score;
            }
        }

        if (best != null && bestScore >= 6.2) return best;
        throw new Exception("no confident lyrics record");
    }

    private String normalizeLyricsIdentity(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "")
            .toLowerCase(Locale.ROOT)
            .replaceAll("[^a-z0-9]+", " ")
            .trim();
        return normalized.replaceAll("\\s+", " ");
    }

    private double lyricSimilarity(String leftValue, String rightValue) {
        String left = normalizeLyricsIdentity(leftValue);
        String right = normalizeLyricsIdentity(rightValue);
        if (left.isEmpty() || right.isEmpty()) return 0.0;

        Set<String> leftTokens = new HashSet<>();
        Set<String> rightTokens = new HashSet<>();
        for (String token : left.split(" ")) if (!token.isEmpty()) leftTokens.add(token);
        for (String token : right.split(" ")) if (!token.isEmpty()) rightTokens.add(token);
        if (leftTokens.isEmpty() || rightTokens.isEmpty()) return 0.0;

        int common = 0;
        for (String token : leftTokens) if (rightTokens.contains(token)) common++;
        return common / (double) Math.max(leftTokens.size(), rightTokens.size());
    }

    private String stripLrcTimestamps(String lrc) {
        StringBuilder out = new StringBuilder();
        for (String line : lrc.split("\\r?\\n")) {
            String clean = line.replaceFirst("^\\[\\d{1,3}:\\d{2}(?:\\.\\d{1,3})?\\]\\s*", "");
            if (!clean.trim().isEmpty()) {
                if (out.length() > 0) out.append('\n');
                out.append(clean);
            }
        }
        return out.toString();
    }

    private String lyricsInnertube(String videoId) throws Exception {
        JSONObject client = new JSONObject();
        client.put("clientName", "WEB_REMIX");
        client.put("clientVersion", "1.20260909.01.00");
        client.put("hl", "en");
        client.put("gl", "US");
        client.put("platform", "DESKTOP");

        JSONObject context = new JSONObject();
        context.put("client", client);
        JSONObject nextBody = new JSONObject();
        nextBody.put("context", context);
        nextBody.put("videoId", videoId);
        nextBody.put("contentCheckOk", true);
        nextBody.put("racyCheckOk", true);

        JSONObject next = new JSONObject(postJsonMusic("https://music.youtube.com/youtubei/v1/next?prettyPrint=false", nextBody.toString()));
        String browseId = findLyricsBrowseId(next);
        if (browseId.isEmpty()) throw new Exception("This YouTube Music item has no lyrics tab");

        JSONObject browseBody = new JSONObject();
        browseBody.put("context", context);
        browseBody.put("browseId", browseId);
        JSONObject browse = new JSONObject(postJsonMusic("https://music.youtube.com/youtubei/v1/browse?prettyPrint=false", browseBody.toString()));
        String lyrics = findLyricsText(browse);
        if (lyrics.isEmpty()) throw new Exception("Lyrics tab returned no text");
        return lyrics;
    }

    private String findLyricsBrowseId(Object node) {
        if (node == null) return "";
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            JSONObject tab = obj.optJSONObject("tabRenderer");
            if (tab != null) {
                String title = tab.optString("title", "");
                if (title.isEmpty()) title = text(tab.optJSONObject("title"), "");
                if ("lyrics".equalsIgnoreCase(title.trim())) {
                    JSONObject endpoint = tab.optJSONObject("endpoint");
                    JSONObject browse = endpoint == null ? null : endpoint.optJSONObject("browseEndpoint");
                    String browseId = browse == null ? "" : browse.optString("browseId", "");
                    if (!browseId.isEmpty()) return browseId;
                }
            }
            JSONArray names = obj.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    String found = findLyricsBrowseId(obj.opt(names.optString(i)));
                    if (!found.isEmpty()) return found;
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) {
                String found = findLyricsBrowseId(arr.opt(i));
                if (!found.isEmpty()) return found;
            }
        }
        return "";
    }

    private String findLyricsText(Object node) {
        if (node == null) return "";
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            JSONObject shelf = obj.optJSONObject("musicDescriptionShelfRenderer");
            if (shelf != null) {
                String value = text(shelf.optJSONObject("description"), "").trim();
                if (!value.isEmpty()) return value;
            }
            JSONArray names = obj.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    String found = findLyricsText(obj.opt(names.optString(i)));
                    if (!found.isEmpty()) return found;
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) {
                String found = findLyricsText(arr.opt(i));
                if (!found.isEmpty()) return found;
            }
        }
        return "";
    }

    private static String extractClientVersion(String html) {
        String value = findJsonStringValue(html, "INNERTUBE_CONTEXT_CLIENT_VERSION");
        if (!value.isEmpty()) return value;
        value = findJsonStringValue(html, "INNERTUBE_CLIENT_VERSION");
        if (!value.isEmpty()) return value;
        value = findJsonStringValue(html, "clientVersion");
        if (value.startsWith("2.")) return value;
        return "2.20260909.00.00";
    }

    private static String findJsonStringValue(String text, String key) {
        String marker = "\"" + key + "\"";
        int at = text.indexOf(marker);
        while (at >= 0) {
            int colon = text.indexOf(':', at + marker.length());
            if (colon < 0) break;
            int quote = colon + 1;
            while (quote < text.length() && Character.isWhitespace(text.charAt(quote))) quote++;
            if (quote < text.length() && text.charAt(quote) == '"') {
                int end = quote + 1;
                boolean escaped = false;
                for (; end < text.length(); end++) {
                    char c = text.charAt(end);
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') return text.substring(quote + 1, end);
                }
            }
            at = text.indexOf(marker, at + marker.length());
        }
        return "";
    }

    private String postJson(String urlString, String body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("User-Agent", UA);
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Origin", "https://www.youtube.com");
        conn.setRequestProperty("Referer", "https://www.youtube.com/");
        byte[] payload = body.getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(payload.length);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(payload);
        }
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder responseBody = new StringBuilder();
        if (stream != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) responseBody.append(line).append('\n');
            }
        }
        conn.disconnect();
        if (code < 200 || code >= 400) throw new Exception("HTTP " + code + ": " + responseBody.substring(0, Math.min(180, responseBody.length())));
        return responseBody.toString();
    }

    private String postJsonMusic(String urlString, String body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("User-Agent", UA);
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Origin", "https://music.youtube.com");
        conn.setRequestProperty("Referer", "https://music.youtube.com/");
        byte[] payload = body.getBytes(StandardCharsets.UTF_8);
        conn.setFixedLengthStreamingMode(payload.length);
        try (OutputStream os = conn.getOutputStream()) { os.write(payload); }
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder responseBody = new StringBuilder();
        if (stream != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) responseBody.append(line).append('\n');
            }
        }
        conn.disconnect();
        if (code < 200 || code >= 400) throw new Exception("HTTP " + code + ": " + responseBody.substring(0, Math.min(180, responseBody.length())));
        return responseBody.toString();
    }

    private static String get(String urlString) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(15000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", UA);
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        conn.setRequestProperty("Accept", "text/html,application/json;q=0.9,*/*;q=0.8");
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder body = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) body.append(line).append('\n');
        } finally {
            conn.disconnect();
        }
        if (code < 200 || code >= 400) throw new Exception("HTTP " + code);
        return body.toString();
    }

    private String extractInitialData(String html) throws Exception {
        String[] markers = new String[] {
            "var ytInitialData",
            "window[\"ytInitialData\"]",
            "window['ytInitialData']",
            "ytInitialData"
        };
        int searchFrom = 0;

        while (searchFrom < html.length()) {
            int bestAt = -1;
            String bestMarker = null;
            for (String marker : markers) {
                int at = html.indexOf(marker, searchFrom);
                if (at >= 0 && (bestAt < 0 || at < bestAt)) {
                    bestAt = at;
                    bestMarker = marker;
                }
            }
            if (bestAt < 0 || bestMarker == null) break;
            searchFrom = bestAt + bestMarker.length();

            int i = searchFrom;
            while (i < html.length() && Character.isWhitespace(html.charAt(i))) i++;
            if (i >= html.length() || html.charAt(i) != '=') continue;
            i++;
            while (i < html.length() && Character.isWhitespace(html.charAt(i))) i++;
            if (i >= html.length() || html.charAt(i) != '{') continue;

            int start = i;
            int depth = 0;
            boolean inString = false;
            boolean escaped = false;
            for (; i < html.length(); i++) {
                char c = html.charAt(i);
                if (inString) {
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') inString = false;
                    continue;
                }
                if (c == '"') inString = true;
                else if (c == '{') depth++;
                else if (c == '}') {
                    depth--;
                    if (depth == 0) {
                        String candidate = html.substring(start, i + 1);
                        try {
                            JSONObject parsed = new JSONObject(candidate);
                            if (parsed.has("contents") || parsed.has("responseContext")) return candidate;
                        } catch (Exception ignored) {}
                        break;
                    }
                }
            }
        }
        throw new Exception("YouTube response did not contain valid ytInitialData");
    }

    private void collectRelatedRenderers(Object node, JSArray out, Set<String> seen, int limit, String seedId) throws Exception {
        if (out.length() >= limit || node == null) return;
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            String[] rendererNames = new String[] { "compactVideoRenderer", "videoRenderer", "playlistPanelVideoRenderer" };
            for (String name : rendererNames) {
                JSONObject renderer = obj.optJSONObject(name);
                if (renderer != null) addRelatedVideo(renderer, out, seen, seedId);
                if (out.length() >= limit) return;
            }
            JSONArray names = obj.names();
            if (names == null) return;
            for (int i = 0; i < names.length() && out.length() < limit; i++) {
                collectRelatedRenderers(obj.opt(names.optString(i)), out, seen, limit, seedId);
            }
        } else if (node instanceof JSONArray) {
            JSONArray array = (JSONArray) node;
            for (int i = 0; i < array.length() && out.length() < limit; i++) {
                collectRelatedRenderers(array.opt(i), out, seen, limit, seedId);
            }
        }
    }

    private void addRelatedVideo(JSONObject r, JSArray out, Set<String> seen, String seedId) {
        String id = r.optString("videoId", "");
        if (id.isEmpty() || id.equals(seedId) || seen.contains(id)) return;
        seen.add(id);

        String title = text(r.optJSONObject("title"), "").trim();
        if (title.isEmpty()) return;
        JSObject track = new JSObject();
        track.put("videoId", id);
        track.put("title", title);
        String channel = text(r.optJSONObject("ownerText"), "");
        if (channel.isEmpty()) channel = text(r.optJSONObject("shortBylineText"), "");
        if (channel.isEmpty()) channel = text(r.optJSONObject("longBylineText"), "Unknown channel");
        track.put("channel", channel);
        track.put("thumbnail", thumbnail(r.optJSONObject("thumbnail"), id));
        track.put("provider", "youtube");
        track.put("sourceUrl", "https://www.youtube.com/watch?v=" + id);
        track.put("mediaKind", "audio");
        track.put("audioPreferred", true);
        out.put(track);
    }

    private void collectVideoRenderers(Object node, JSArray out, Set<String> seen, int limit) throws Exception {
        if (out.length() >= limit || node == null) return;
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            JSONObject renderer = obj.optJSONObject("videoRenderer");
            if (renderer != null) addVideo(renderer, out, seen);
            if (out.length() >= limit) return;
            JSONArray names = obj.names();
            if (names == null) return;
            for (int i = 0; i < names.length() && out.length() < limit; i++) {
                collectVideoRenderers(obj.opt(names.optString(i)), out, seen, limit);
            }
        } else if (node instanceof JSONArray) {
            JSONArray array = (JSONArray) node;
            for (int i = 0; i < array.length() && out.length() < limit; i++) {
                collectVideoRenderers(array.opt(i), out, seen, limit);
            }
        }
    }

    private void addVideo(JSONObject r, JSArray out, Set<String> seen) {
        String id = r.optString("videoId", "");
        if (id.isEmpty() || seen.contains(id)) return;
        seen.add(id);

        String title = text(r.optJSONObject("title"), "").trim();
        if (title.isEmpty()) return;
        JSObject track = new JSObject();
        track.put("videoId", id);
        track.put("title", title);
        String channel = text(r.optJSONObject("ownerText"), "");
        if (channel.isEmpty()) channel = text(r.optJSONObject("shortBylineText"), "Unknown channel");
        track.put("channel", channel);
        track.put("thumbnail", thumbnail(r.optJSONObject("thumbnail"), id));
        out.put(track);
    }

    private String text(JSONObject obj, String fallback) {
        if (obj == null) return fallback;
        String simple = obj.optString("simpleText", "");
        if (!simple.isEmpty()) return simple;
        JSONArray runs = obj.optJSONArray("runs");
        if (runs != null && runs.length() > 0) {
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < runs.length(); i++) s.append(runs.optJSONObject(i) == null ? "" : runs.optJSONObject(i).optString("text", ""));
            if (s.length() > 0) return s.toString();
        }
        return fallback;
    }

    private String thumbnail(JSONObject obj, String id) {
        if (obj != null) {
            JSONArray thumbs = obj.optJSONArray("thumbnails");
            if (thumbs != null && thumbs.length() > 0) {
                JSONObject best = thumbs.optJSONObject(thumbs.length() - 1);
                if (best != null) {
                    String url = best.optString("url", "");
                    if (!url.isEmpty()) return url.startsWith("//") ? "https:" + url : url;
                }
            }
        }
        return "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg";
    }
}
