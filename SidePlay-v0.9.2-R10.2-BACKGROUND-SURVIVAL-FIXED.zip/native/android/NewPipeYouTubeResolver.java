package app.sideplay.mobile;

import com.getcapacitor.JSObject;

import org.schabi.newpipe.extractor.MediaFormat;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.StreamExtractor;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.util.Collections;
import java.util.List;

/**
 * R6 YouTube playback/download resolver backed by NewPipeExtractor.
 *
 * This is deliberately used only for native playback resolution. yt-dlp remains available for
 * explicit download/provider tooling, but a normal Play tap never initializes its Python stack.
 */
final class NewPipeYouTubeResolver {
    private static final Object INIT_LOCK = new Object();
    private static volatile boolean initialized = false;

    private NewPipeYouTubeResolver() {}

    static JSObject resolve(String sourceUrl, String videoId, boolean audioOnly) throws Exception {
        ensureInitialized();
        final String canonical = "https://www.youtube.com/watch?v=" + videoId;
        final StreamExtractor extractor = ServiceList.YouTube.getStreamExtractor(canonical);
        extractor.fetchPage();

        String playback = "";
        String mime = "";
        String mediaKind = "audio";
        String delivery = "newpipe-audio";
        int bitrate = 0;

        if (!audioOnly) {
            VideoStream video = chooseVideo(safeVideos(extractor));
            if (video != null) {
                playback = video.getContent();
                MediaFormat format = video.getFormat();
                mime = format == null ? "" : format.getMimeType();
                mediaKind = "video";
                bitrate = video.getBitrate();
                delivery = "newpipe-progressive-video";
            }
        }

        // Video requests must exhaust real video delivery before falling back to audio.
        // R5 used to choose audio immediately after progressive A/V, which meant many
        // perfectly playable DASH/HLS videos were silently downgraded to audio-only.
        if (playback.isEmpty() && !audioOnly) {
            String dash = safeDash(extractor);
            if (!dash.isEmpty()) {
                playback = dash;
                mime = "application/dash+xml";
                mediaKind = "video";
                delivery = "newpipe-dash-adaptive";
            }
        }

        if (playback.isEmpty() && !audioOnly) {
            String hls = safeHls(extractor);
            if (!hls.isEmpty()) {
                playback = hls;
                mime = "application/x-mpegURL";
                mediaKind = "video";
                delivery = "newpipe-hls-adaptive";
            }
        }

        if (playback.isEmpty()) {
            AudioStream audio = chooseAudio(safeAudio(extractor));
            if (audio != null) {
                playback = audio.getContent();
                MediaFormat format = audio.getFormat();
                mime = format == null ? "" : format.getMimeType();
                mediaKind = "audio";
                bitrate = Math.max(audio.getAverageBitrate(), audio.getBitrate());
                delivery = "newpipe-audio-last-resort";
            }
        }

        // Audio-only requests may still be recoverable through DASH when NewPipe did
        // not expose an individual clear audio URL (for example some live streams).
        if (playback.isEmpty() && audioOnly) {
            String dash = safeDash(extractor);
            if (!dash.isEmpty()) {
                playback = dash;
                mime = "application/dash+xml";
                mediaKind = "audio";
                delivery = "newpipe-dash-audio-fallback";
            }
        }

        if (playback.isEmpty() || !(playback.startsWith("https://") || playback.startsWith("http://"))) {
            throw new Exception("NewPipeExtractor returned no Media3-playable URL for this video.");
        }

        JSObject out = new JSObject();
        out.put("id", videoId);
        out.put("provider", "youtube");
        out.put("sourceUrl", sourceUrl == null || sourceUrl.isEmpty() ? canonical : sourceUrl);
        out.put("playbackUrl", playback);
        if (!mime.isEmpty()) out.put("mimeType", mime);
        out.put("mediaKind", audioOnly ? "audio" : mediaKind);
        out.put("audioPreferred", audioOnly);
        out.put("playable", true);
        out.put("downloadable", true);
        // If NewPipe gave us a progressive CDN object that Media3 can already play,
        // reuse that exact clear URL for Offline Vault before involving yt-dlp/PO-token
        // delivery. DASH/HLS still need the adaptive yt-dlp/FFmpeg path.
        boolean directDownload = delivery.startsWith("newpipe-progressive-") || delivery.startsWith("newpipe-audio");
        if (directDownload) {
            out.put("downloadUrl", playback);
            out.put("downloadEngine", "direct");
        } else {
            out.put("downloadEngine", "ytdlp");
        }
        out.put("sessionBound", true);
        out.put("refreshMode", "youtube-native");
        if (bitrate > 0) out.put("bitrate", bitrate);
        out.put("resolverEngine", "newpipe");
        out.put("resolverDelivery", delivery);
        out.put("resolvedAt", System.currentTimeMillis());
        out.put("note", "Resolved by NewPipeExtractor 0.26.5 (" + delivery + ") without starting yt-dlp/Python.");

        JSObject headers = new JSObject();
        headers.put("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/152.0.0.0 Mobile Safari/537.36");
        headers.put("Referer", "https://www.youtube.com/");
        out.put("requestHeaders", headers);
        return out;
    }

    private static void ensureInitialized() {
        if (initialized && NewPipe.getDownloader() != null) return;
        synchronized (INIT_LOCK) {
            if (!initialized || NewPipe.getDownloader() == null) {
                NewPipe.init(new SidePlayNewPipeDownloader());
                initialized = true;
            }
        }
    }

    private static List<AudioStream> safeAudio(StreamExtractor extractor) {
        try {
            List<AudioStream> streams = extractor.getAudioStreams();
            return streams == null ? Collections.emptyList() : streams;
        } catch (Exception ignored) {
            return Collections.emptyList();
        }
    }

    private static List<VideoStream> safeVideos(StreamExtractor extractor) {
        try {
            List<VideoStream> streams = extractor.getVideoStreams();
            return streams == null ? Collections.emptyList() : streams;
        } catch (Exception ignored) {
            return Collections.emptyList();
        }
    }

    private static String safeHls(StreamExtractor extractor) {
        try {
            String value = extractor.getHlsUrl();
            return value == null ? "" : value;
        } catch (Exception ignored) {
            return "";
        }
    }

    private static String safeDash(StreamExtractor extractor) {
        try {
            String value = extractor.getDashMpdUrl();
            return value == null ? "" : value;
        } catch (Exception ignored) {
            return "";
        }
    }

    private static AudioStream chooseAudio(List<AudioStream> streams) {
        AudioStream best = null;
        long score = Long.MIN_VALUE;
        for (AudioStream stream : streams) {
            if (stream == null || !stream.isUrl()) continue;
            String url = stream.getContent();
            if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) continue;
            long candidate = Math.max(stream.getAverageBitrate(), stream.getBitrate());
            MediaFormat format = stream.getFormat();
            if (format == MediaFormat.M4A) candidate += 10_000; // Media3-friendly tie breaker.
            if (best == null || candidate > score) {
                best = stream;
                score = candidate;
            }
        }
        return best;
    }

    private static VideoStream chooseVideo(List<VideoStream> streams) {
        VideoStream best = null;
        long score = Long.MIN_VALUE;
        for (VideoStream stream : streams) {
            if (stream == null || !stream.isUrl() || stream.isVideoOnly()) continue;
            String url = stream.getContent();
            if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) continue;
            long candidate = (long) Math.max(0, stream.getHeight()) * 1_000_000L + Math.max(0, stream.getBitrate());
            MediaFormat format = stream.getFormat();
            if (format == MediaFormat.MPEG_4) candidate += 100_000; // Prefer MP4 when quality ties.
            if (best == null || candidate > score) {
                best = stream;
                score = candidate;
            }
        }
        return best;
    }
}
