package app.sideplay.mobile;

import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;


/**
 * Small blocking downloader adapter for NewPipeExtractor.
 *
 * SidePlay intentionally keeps this independent from yt-dlp/Python/QuickJS so a normal
 * Play tap cannot boot the heavy extractor stack that was killing the Android process.
 */
final class SidePlayNewPipeDownloader extends Downloader {
    private static final String DEFAULT_UA =
            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36";
    private static final int CONNECT_TIMEOUT_MS = 12_000;
    private static final int READ_TIMEOUT_MS = 22_000;
    private static final int MAX_BODY_BYTES = 12 * 1024 * 1024;

    @Override
    public Response execute(Request request) throws IOException, ReCaptchaException {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(request.url()).openConnection();
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestMethod(request.httpMethod());
            conn.setUseCaches(false);

            boolean hasUa = false;
            boolean hasAcceptEncoding = false;
            for (Map.Entry<String, List<String>> entry : request.headers().entrySet()) {
                String name = entry.getKey();
                if (name == null) continue;
                if ("User-Agent".equalsIgnoreCase(name)) hasUa = true;
                if ("Accept-Encoding".equalsIgnoreCase(name)) {
                    // Force a codec the small adapter can always decode.
                    hasAcceptEncoding = true;
                    continue;
                }
                List<String> values = entry.getValue();
                if (values == null) continue;
                for (String value : values) {
                    if (value != null) conn.addRequestProperty(name, value);
                }
            }
            if (!hasUa) conn.setRequestProperty("User-Agent", DEFAULT_UA);
            if (!hasAcceptEncoding) conn.setRequestProperty("Accept-Encoding", "gzip");
            else conn.setRequestProperty("Accept-Encoding", "gzip");

            byte[] payload = request.dataToSend();
            if (payload != null && payload.length > 0 && !"GET".equalsIgnoreCase(request.httpMethod())
                    && !"HEAD".equalsIgnoreCase(request.httpMethod())) {
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(payload.length);
                try (OutputStream output = conn.getOutputStream()) {
                    output.write(payload);
                }
            }

            int code = conn.getResponseCode();
            String message = conn.getResponseMessage();
            Map<String, List<String>> headers = copyHeaders(conn.getHeaderFields());
            String body = "";
            if (!"HEAD".equalsIgnoreCase(request.httpMethod())) {
                InputStream raw = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
                if (raw != null) {
                    String encoding = conn.getContentEncoding();
                    InputStream decoded = raw;
                    if (encoding != null) {
                        String lower = encoding.toLowerCase(Locale.ROOT);
                        if (lower.contains("gzip")) decoded = new GZIPInputStream(raw);
                        else if (lower.contains("deflate")) decoded = new InflaterInputStream(raw);
                    }
                    body = readUtf8(decoded, MAX_BODY_BYTES);
                }
            }
            String latest = conn.getURL() == null ? request.url() : conn.getURL().toString();
            return new Response(code, message == null ? "" : message, headers, body, latest);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static Map<String, List<String>> copyHeaders(Map<String, List<String>> input) {
        Map<String, List<String>> out = new LinkedHashMap<>();
        if (input == null) return out;
        for (Map.Entry<String, List<String>> entry : input.entrySet()) {
            if (entry.getKey() == null || entry.getValue() == null) continue;
            out.put(entry.getKey(), new ArrayList<>(entry.getValue()));
        }
        return out;
    }

    private static String readUtf8(InputStream input, int limit) throws IOException {
        try (BufferedInputStream in = new BufferedInputStream(input);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16 * 1024];
            int total = 0;
            int read;
            while ((read = in.read(buffer)) != -1) {
                total += read;
                if (total > limit) throw new IOException("Extractor response exceeded SidePlay safety limit.");
                out.write(buffer, 0, read);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
}
