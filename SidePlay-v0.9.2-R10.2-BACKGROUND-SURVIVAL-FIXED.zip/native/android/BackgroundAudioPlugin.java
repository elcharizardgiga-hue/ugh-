package app.sideplay.mobile;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "BackgroundAudio")
public class BackgroundAudioPlugin extends Plugin {
    private BroadcastReceiver receiver;
    private volatile boolean lastActive = false;
    private volatile boolean lastPlaying = false;
    private volatile long lastPositionMs = 0L;
    private volatile long lastDurationMs = 0L;
    private volatile int lastPlaybackState = 1;
    private volatile long lastEventAtMs = 0L;
    private volatile String lastState = "inactive";

    @Override
    public void load() {
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String state = intent.getStringExtra("state");
                long positionMs = intent.getLongExtra("positionMs", 0L);
                long durationMs = intent.getLongExtra("durationMs", 0L);
                int playbackState = intent.getIntExtra("playbackState", lastPlaybackState);
                lastState = state == null ? "unknown" : state;
                lastPositionMs = Math.max(0L, positionMs);
                lastDurationMs = Math.max(0L, durationMs);
                lastPlaybackState = playbackState;
                lastEventAtMs = System.currentTimeMillis();
                lastPlaying = "playing".equals(state);
                lastActive = !("stopped".equals(state) || "service-destroyed".equals(state));

                JSObject out = new JSObject();
                out.put("state", state);
                out.put("positionMs", lastPositionMs);
                out.put("durationMs", lastDurationMs);
                out.put("playbackState", lastPlaybackState);
                String message = intent.getStringExtra("message");
                if (message != null) out.put("message", message);
                notifyListeners("playbackState", out, false);
            }
        };
        IntentFilter filter = new IntentFilter(PlaybackService.ACTION_EVENT);
        if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(receiver, filter);
    }

    @Override
    protected void handleOnDestroy() {
        if (receiver != null) {
            try { getContext().unregisterReceiver(receiver); } catch (Exception ignored) {}
            receiver = null;
        }
        super.handleOnDestroy();
    }

    @PluginMethod
    public void play(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isBlank()) {
            call.reject("A direct media URL is required.");
            return;
        }
        Intent intent = new Intent(getContext(), PlaybackService.class);
        intent.setAction(PlaybackService.ACTION_PLAY);
        intent.putExtra("url", url);
        intent.putExtra("title", call.getString("title", "SidePlay"));
        intent.putExtra("artist", call.getString("artist", ""));
        intent.putExtra("artwork", call.getString("artwork", ""));
        intent.putExtra("mimeType", call.getString("mimeType", ""));
        intent.putExtra("sourceUrl", call.getString("sourceUrl", ""));
        intent.putExtra("refreshMode", call.getString("refreshMode", ""));
        intent.putExtra("resumable", call.getBoolean("resumable", true));
        intent.putExtra("audioPreferred", call.getBoolean("audioPreferred", false));
        JSObject requestHeaders = call.getObject("requestHeaders");
        if (requestHeaders != null && requestHeaders.length() > 0) intent.putExtra("requestHeadersJson", requestHeaders.toString());
        Double requestedPosition = call.getDouble("positionMs", 0.0);
        long positionMs = requestedPosition == null ? 0L : Math.max(0L, requestedPosition.longValue());
        intent.putExtra("positionMs", positionMs);
        try {
            // R6: this call originates from a foreground Activity tap. Start the
            // MediaSessionService normally and let Media3 promote itself to a media
            // foreground service when the Player receives a MediaItem/starts playback.
            // This avoids the startForegroundService deadline crash loop seen on-device.
            getContext().startService(intent);
            call.resolve(new JSObject());
        } catch (Throwable t) {
            call.reject("Could not start SidePlay native playback service: " + safe(t), asException(t));
        }
    }

    @PluginMethod public void pause(PluginCall call) { send(PlaybackService.ACTION_PAUSE); call.resolve(); }
    @PluginMethod public void resume(PluginCall call) { send(PlaybackService.ACTION_RESUME); call.resolve(); }
    @PluginMethod public void stop(PluginCall call) { send(PlaybackService.ACTION_STOP); call.resolve(); }

    @PluginMethod
    public void seek(PluginCall call) {
        Double requestedPosition = call.getDouble("positionMs", 0.0);
        long positionMs = requestedPosition == null ? 0L : Math.max(0L, requestedPosition.longValue());
        Intent intent = new Intent(getContext(), PlaybackService.class);
        intent.setAction(PlaybackService.ACTION_SEEK);
        intent.putExtra("positionMs", positionMs);
        try {
            getContext().startService(intent);
            lastPositionMs = positionMs;
            call.resolve(cachedSnapshot());
        } catch (Throwable t) {
            call.reject("Could not seek native playback: " + safe(t), asException(t));
        }
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        call.resolve(cachedSnapshot());
    }

    @PluginMethod
    public void getBackgroundHealth(PluginCall call) {
        PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        boolean unrestricted = Build.VERSION.SDK_INT < 23 || (pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName()));
        JSObject out = new JSObject();
        out.put("unrestricted", unrestricted);
        out.put("androidVersion", Build.VERSION.SDK_INT);
        call.resolve(out);
    }

    @PluginMethod
    public void openBluetoothSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception first) {
            try {
                Intent intent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
                call.resolve();
            } catch (Exception second) {
                call.reject("Could not open Android Bluetooth settings.", second);
            }
        }
    }

    @PluginMethod
    public void openBackgroundSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception first) {
            try {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getContext().getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
                call.resolve();
            } catch (Exception second) {
                call.reject("Could not open Android background settings.", second);
            }
        }
    }

    @PluginMethod
    public void getNativeDiagnostics(PluginCall call) {
        JSObject out = new JSObject();
        android.content.SharedPreferences prefs = getContext().getSharedPreferences("sideplay-native-playback-diagnostics", Context.MODE_PRIVATE);
        out.put("stage", prefs.getString("stage", "never-started"));
        out.put("message", prefs.getString("message", ""));
        out.put("timestamp", prefs.getLong("timestamp", 0L));
        long heartbeatAt = prefs.getLong("heartbeatAt", 0L);
        long livenessAt = Math.max(heartbeatAt, lastEventAtMs);
        long heartbeatAgeMs = livenessAt <= 0L ? Long.MAX_VALUE : Math.max(0L, System.currentTimeMillis() - livenessAt);
        boolean heartbeatAlive = heartbeatAgeMs <= 15_000L;
        out.put("serviceAlive", lastActive && heartbeatAlive);
        out.put("heartbeatAt", heartbeatAt);
        out.put("heartbeatAgeMs", heartbeatAgeMs == Long.MAX_VALUE ? -1L : heartbeatAgeMs);
        out.put("recovery", prefs.getString("recovery", "none"));
        out.put("recoveryMessage", prefs.getString("recoveryMessage", ""));
        out.put("recoveryAt", prefs.getLong("recoveryAt", 0L));
        out.put("recoveryAttempts", prefs.getInt("recoveryAttempts", 0));
        out.put("playing", lastPlaying && heartbeatAlive);
        out.put("playbackState", lastPlaybackState);
        out.put("positionMs", lastPositionMs);
        out.put("durationMs", lastDurationMs);
        out.put("lastEventAt", lastEventAtMs);
        out.put("lastState", lastState);
        out.put("playbackIsolation", "android-process:playback");

        if (Build.VERSION.SDK_INT >= 30) {
            try {
                ActivityManager am = (ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) {
                    java.util.List<ApplicationExitInfo> exits = am.getHistoricalProcessExitReasons(getContext().getPackageName(), 0, 8);
                    JSArray arr = new JSArray();
                    for (ApplicationExitInfo info : exits) {
                        JSObject item = new JSObject();
                        item.put("process", info.getProcessName());
                        item.put("reason", info.getReason());
                        item.put("reasonName", exitReasonName(info.getReason()));
                        item.put("status", info.getStatus());
                        item.put("timestamp", info.getTimestamp());
                        String description = info.getDescription();
                        if (description != null && !description.isBlank()) item.put("description", description);
                        arr.put(item);
                    }
                    out.put("recentExits", arr);
                }
            } catch (Throwable ignored) {}
        }
        call.resolve(out);
    }

    private static String exitReasonName(int reason) {
        switch (reason) {
            case 0: return "UNKNOWN";
            case 1: return "EXIT_SELF";
            case 2: return "SIGNALED";
            case 3: return "LOW_MEMORY";
            case 4: return "CRASH";
            case 5: return "CRASH_NATIVE";
            case 6: return "ANR";
            case 7: return "INITIALIZATION_FAILURE";
            case 8: return "PERMISSION_CHANGE";
            case 9: return "EXCESSIVE_RESOURCE_USAGE";
            case 10: return "USER_REQUESTED";
            case 11: return "USER_STOPPED";
            case 12: return "DEPENDENCY_DIED";
            case 13: return "OTHER";
            case 14: return "FREEZER";
            case 15: return "PACKAGE_STATE_CHANGE";
            case 16: return "PACKAGE_UPDATED";
            default: return "REASON_" + reason;
        }
    }

    private static String safe(Throwable t) {
        if (t == null) return "unknown error";
        String message = t.getMessage();
        return message == null || message.isBlank() ? t.getClass().getSimpleName() : t.getClass().getSimpleName() + ": " + message;
    }

    // Capacitor 8 PluginCall.reject accepts Exception, not arbitrary Throwable.
    // Keep the broader Throwable guard around Android service handoff, but bridge
    // Errors into an Exception before returning them across the Capacitor API.
    private static Exception asException(Throwable t) {
        if (t instanceof Exception) return (Exception) t;
        return new Exception(safe(t), t);
    }

    private JSObject cachedSnapshot() {
        JSObject out = new JSObject();
        out.put("active", lastActive);
        out.put("playing", lastPlaying);
        out.put("positionMs", lastPositionMs);
        out.put("durationMs", lastDurationMs);
        out.put("playbackState", lastPlaybackState);
        return out;
    }

    private void send(String action) {
        Intent intent = new Intent(getContext(), PlaybackService.class);
        intent.setAction(action);
        try { getContext().startService(intent); } catch (Throwable ignored) {}
    }
}
