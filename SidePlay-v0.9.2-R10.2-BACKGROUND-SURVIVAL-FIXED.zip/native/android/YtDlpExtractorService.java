package app.sideplay.mobile;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.RemoteException;

import com.getcapacitor.JSObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * yt-dlp playback extractor hosted in a dedicated Android process.
 *
 * IMPORTANT: AndroidManifest declares this service with android:process=":extractor".
 * Python/QuickJS/yt-dlp are therefore initialized outside SidePlay's UI/Media3
 * process. If the extractor process crashes, Android disconnects the Binder and
 * SidePlay remains alive; the client can then fall back to NewPipe/SAFE PLAY.
 */
public final class YtDlpExtractorService extends Service {
    public static final int MSG_RESOLVE = 1001;
    public static final int MSG_RESULT = 1002;
    public static final int MSG_ERROR = 1003;
    public static final int MSG_CANCEL_AND_RESET = 1004;

    public static final String KEY_URL = "url";
    public static final String KEY_AUDIO_ONLY = "audioOnly";
    public static final String KEY_JSON = "json";
    public static final String KEY_ERROR = "error";

    private final AtomicBoolean busy = new AtomicBoolean(false);
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "SidePlayYtDlpIsolated");
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
    });

    private Messenger messenger;

    @Override
    public void onCreate() {
        super.onCreate();
        messenger = new Messenger(new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == MSG_CANCEL_AND_RESET) {
                    // Deliberately kill ONLY the :extractor process. This is the
                    // hard timeout/circuit breaker for a wedged Python/QuickJS run.
                    Process.killProcess(Process.myPid());
                    return;
                }
                if (msg.what != MSG_RESOLVE) {
                    super.handleMessage(msg);
                    return;
                }
                handleResolve(msg);
            }
        });
    }

    @Override
    public IBinder onBind(Intent intent) {
        return messenger == null ? null : messenger.getBinder();
    }

    @Override
    public void onDestroy() {
        try { executor.shutdownNow(); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    private void handleResolve(Message msg) {
        final Messenger reply = msg.replyTo;
        final Bundle data = msg.getData();
        final String source = data == null ? "" : data.getString(KEY_URL, "").trim();
        final boolean audioOnly = data != null && data.getBoolean(KEY_AUDIO_ONLY, false);

        if (reply == null) return;
        if (source.isEmpty() || !(source.startsWith("https://") || source.startsWith("http://"))) {
            sendError(reply, "A public http(s) media URL is required.");
            return;
        }
        if (!busy.compareAndSet(false, true)) {
            sendError(reply, "The isolated extractor is already resolving another item.");
            return;
        }

        executor.execute(() -> {
            try {
                JSObject result = YtDlpPlugin.resolveForPlayback(getApplicationContext(), source, audioOnly);
                Bundle out = new Bundle();
                out.putString(KEY_JSON, result.toString());
                send(reply, MSG_RESULT, out);
            } catch (Throwable error) {
                sendError(reply, safe(error));
            } finally {
                busy.set(false);
            }
        });
    }

    private static void sendError(Messenger reply, String error) {
        Bundle out = new Bundle();
        out.putString(KEY_ERROR, error == null || error.isBlank() ? "yt-dlp extraction failed." : error);
        send(reply, MSG_ERROR, out);
    }

    private static void send(Messenger reply, int what, Bundle data) {
        try {
            Message message = Message.obtain(null, what);
            message.setData(data == null ? new Bundle() : data);
            reply.send(message);
        } catch (RemoteException ignored) {
            // Main process went away; there is nobody left to receive the result.
        }
    }

    private static String safe(Throwable error) {
        if (error == null) return "yt-dlp extraction failed.";
        String message = error.getMessage();
        if (message == null || message.isBlank()) message = error.getClass().getSimpleName();
        return message;
    }
}
