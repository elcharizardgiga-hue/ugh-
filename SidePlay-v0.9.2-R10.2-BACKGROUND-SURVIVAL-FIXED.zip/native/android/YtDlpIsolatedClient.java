package app.sideplay.mobile;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/** Main-process IPC client for the dedicated :extractor yt-dlp process. */
final class YtDlpIsolatedClient {
    interface Callback {
        void onSuccess(String json);
        void onError(String message);
    }

    private YtDlpIsolatedClient() {}

    static void resolve(Context context, String source, boolean audioOnly, long timeoutMs, Callback callback) {
        new Request(context.getApplicationContext(), source, audioOnly, Math.max(5_000L, timeoutMs), callback).start();
    }

    /**
     * Background-thread bridge used by Media3 recovery and NativeYouTube's resolver ladder.
     * The actual yt-dlp/Python work still happens ONLY in the :extractor process.
     */
    static String resolveBlocking(Context context, String source, boolean audioOnly, long timeoutMs) throws Exception {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            throw new IllegalStateException("resolveBlocking must never run on Android's main thread.");
        }
        final long bounded = Math.max(5_000L, timeoutMs);
        final CountDownLatch latch = new CountDownLatch(1);
        final AtomicReference<String> result = new AtomicReference<>(null);
        final AtomicReference<String> error = new AtomicReference<>(null);
        resolve(context, source, audioOnly, bounded, new Callback() {
            @Override public void onSuccess(String json) { result.set(json); latch.countDown(); }
            @Override public void onError(String message) { error.set(message); latch.countDown(); }
        });
        if (!latch.await(bounded + 2_500L, TimeUnit.MILLISECONDS)) {
            throw new Exception("Timed out waiting for isolated yt-dlp IPC response.");
        }
        String failure = error.get();
        if (failure != null && !failure.isBlank()) throw new Exception(failure);
        String json = result.get();
        if (json == null || json.isBlank()) throw new Exception("The isolated extractor returned no JSON.");
        return json;
    }

    private static final class Request implements ServiceConnection {
        private final Context app;
        private final String source;
        private final boolean audioOnly;
        private final long timeoutMs;
        private final Callback callback;
        private final Handler main = new Handler(Looper.getMainLooper());
        private final AtomicBoolean finished = new AtomicBoolean(false);
        private Messenger remote;
        private boolean bound;

        private final Messenger reply = new Messenger(new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                Bundle data = msg.getData();
                if (msg.what == YtDlpExtractorService.MSG_RESULT) {
                    String json = data == null ? "" : data.getString(YtDlpExtractorService.KEY_JSON, "");
                    if (json == null || json.isBlank()) finishError("The isolated extractor returned an empty result.");
                    else finishSuccess(json);
                    return;
                }
                if (msg.what == YtDlpExtractorService.MSG_ERROR) {
                    String error = data == null ? "yt-dlp extraction failed." : data.getString(YtDlpExtractorService.KEY_ERROR, "yt-dlp extraction failed.");
                    finishError(error);
                    return;
                }
                super.handleMessage(msg);
            }
        });

        private final Runnable timeout;

        Request(Context app, String source, boolean audioOnly, long timeoutMs, Callback callback) {
            this.app = app;
            this.source = source;
            this.audioOnly = audioOnly;
            this.timeoutMs = timeoutMs;
            this.callback = callback;
            // Build the timeout only after all final fields are assigned. Besides
            // satisfying Java definite-assignment rules, this guarantees the
            // callback observed by the timeout belongs to this request instance.
            this.timeout = () -> {
                if (!finished.compareAndSet(false, true)) return;
                // If Python/QuickJS is wedged, ask the CHILD process to kill itself.
                // The SidePlay UI + Media3 process remains untouched.
                sendReset();
                cleanup();
                this.callback.onError("yt-dlp timed out in the isolated extractor process. SidePlay stayed alive; try another result or retry.");
            };
        }

        void start() {
            Intent intent = new Intent(app, YtDlpExtractorService.class);
            try {
                bound = app.bindService(intent, this, Context.BIND_AUTO_CREATE);
            } catch (Throwable error) {
                finishError("Could not bind the isolated extractor: " + safe(error));
                return;
            }
            if (!bound) {
                finishError("Android refused to bind the isolated extractor process.");
                return;
            }
            main.postDelayed(timeout, timeoutMs);
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            if (finished.get()) return;
            remote = new Messenger(service);
            Bundle data = new Bundle();
            data.putString(YtDlpExtractorService.KEY_URL, source);
            data.putBoolean(YtDlpExtractorService.KEY_AUDIO_ONLY, audioOnly);
            Message request = Message.obtain(null, YtDlpExtractorService.MSG_RESOLVE);
            request.setData(data);
            request.replyTo = reply;
            try {
                remote.send(request);
            } catch (RemoteException error) {
                finishError("Could not talk to the isolated extractor: " + safe(error));
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            // Called when the remote process crashes/is killed unexpectedly.
            finishError("The yt-dlp extractor process stopped unexpectedly. SidePlay itself is still running.");
        }

        @Override
        public void onBindingDied(ComponentName name) {
            finishError("The yt-dlp extractor binding died. SidePlay itself is still running.");
        }

        @Override
        public void onNullBinding(ComponentName name) {
            finishError("The yt-dlp extractor returned a null Binder.");
        }

        private void finishSuccess(String json) {
            if (!finished.compareAndSet(false, true)) return;
            main.removeCallbacks(timeout);
            cleanup();
            callback.onSuccess(json);
        }

        private void finishError(String message) {
            if (!finished.compareAndSet(false, true)) return;
            main.removeCallbacks(timeout);
            cleanup();
            callback.onError(message == null || message.isBlank() ? "yt-dlp extraction failed." : message);
        }

        private void sendReset() {
            Messenger target = remote;
            if (target == null) return;
            try {
                target.send(Message.obtain(null, YtDlpExtractorService.MSG_CANCEL_AND_RESET));
            } catch (Throwable ignored) {}
        }

        private void cleanup() {
            if (!bound) return;
            bound = false;
            try { app.unbindService(this); } catch (Throwable ignored) {}
            remote = null;
        }

        private static String safe(Throwable error) {
            if (error == null) return "unknown error";
            String message = error.getMessage();
            return message == null || message.isBlank() ? error.getClass().getSimpleName() : message;
        }
    }
}
