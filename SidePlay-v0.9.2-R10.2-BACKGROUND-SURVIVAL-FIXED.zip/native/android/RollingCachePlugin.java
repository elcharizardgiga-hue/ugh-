package app.sideplay.mobile;

import android.net.Uri;
import android.webkit.MimeTypeMap;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Persistent rolling playback cache.
 *
 * This is deliberately separate from SidePlay's explicit Offline Vault. Entries are
 * app-managed playback cache objects: invisible to Downloads, safe to evict, and kept
 * only while they remain in the rolling previous/current/next window.
 */
@CapacitorPlugin(name = "RollingCache")
public class RollingCachePlugin extends Plugin {
    private static final String PREFS = "sideplay-rolling-cache-v1";
    private static final String KEY_PREFIX = "entry:";
    private static final long DEFAULT_MAX_BYTES = 768L * 1024L * 1024L;
    private static final ConcurrentHashMap<String, Object> LOCKS = new ConcurrentHashMap<>();

    @PluginMethod
    public void lookup(PluginCall call) {
        String videoId = call.getString("videoId", "");
        if (videoId.isBlank()) { call.reject("videoId is required."); return; }
        try {
            JSObject result = lookupEntry(videoId, true);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Rolling cache lookup failed: " + safe(e));
        }
    }

    @PluginMethod
    public void cache(PluginCall call) {
        String videoId = call.getString("videoId", "");
        String raw = call.getString("url", "");
        String title = call.getString("title", "SidePlay media");
        String channel = call.getString("channel", "");
        String thumbnail = call.getString("thumbnail", "");
        String provider = call.getString("provider", "");
        String sourceUrl = call.getString("sourceUrl", "");
        String mediaKind = call.getString("mediaKind", "");
        String mimeHint = call.getString("mimeType", "");
        JSObject requestHeaders = call.getObject("requestHeaders");
        if (videoId.isBlank()) { call.reject("videoId is required."); return; }
        if (!(raw.startsWith("https://") || raw.startsWith("http://"))) {
            call.reject("Rolling cache requires a direct http(s) media URL.");
            return;
        }
        if (isSegmented(raw, mimeHint)) {
            call.reject("Rolling cache currently stores progressive media only.");
            return;
        }

        new Thread(() -> {
            Object lock = LOCKS.computeIfAbsent(videoId, ignored -> new Object());
            synchronized (lock) {
                try {
                    JSObject existing = lookupEntry(videoId, true);
                    if (existing.optBoolean("hit", false)) {
                        call.resolve(existing);
                        return;
                    }
                    call.resolve(download(videoId, title, channel, thumbnail, provider, sourceUrl, mediaKind, raw, mimeHint, requestHeaders));
                } catch (Exception e) {
                    call.reject("Rolling cache fill failed: " + safe(e));
                } finally {
                    LOCKS.remove(videoId, lock);
                }
            }
        }, "SidePlayRollingCache").start();
    }

    @PluginMethod
    public void catalog(PluginCall call) {
        try {
            JSONArray rows = new JSONArray();
            List<JSONObject> entries = new ArrayList<>();
            for (Map.Entry<String, ?> item : prefs().getAll().entrySet()) {
                if (!item.getKey().startsWith(KEY_PREFIX) || !(item.getValue() instanceof String)) continue;
                try {
                    JSONObject meta = new JSONObject((String) item.getValue());
                    String id = meta.optString("videoId", item.getKey().substring(KEY_PREFIX.length()));
                    File file = new File(cacheDir(), meta.optString("filename", ""));
                    if (!file.isFile() || file.length() <= 0) continue;

                    JSONObject row = new JSONObject(meta.toString());
                    row.put("hit", true);
                    row.put("videoId", id);
                    row.put("localUri", Uri.fromFile(file).toString());
                    row.put("filename", file.getName());
                    row.put("bytes", file.length());
                    row.put("rolling", true);
                    entries.add(row);
                } catch (Exception ignored) {}
            }

            entries.sort((a, b) -> Long.compare(
                b.optLong("lastAccessAt", b.optLong("cachedAt", 0L)),
                a.optLong("lastAccessAt", a.optLong("cachedAt", 0L))
            ));
            for (JSONObject row : entries) rows.put(row);

            JSObject out = new JSObject();
            out.put("entriesJson", rows.toString());
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Rolling cache catalog failed: " + safe(e));
        }
    }

    @PluginMethod
    public void prune(PluginCall call) {
        String keepIdsJson = call.getString("keepIdsJson", "[]");
        Long requested = call.getLong("maxBytes");
        long maxBytes = requested == null ? DEFAULT_MAX_BYTES : Math.max(64L * 1024L * 1024L, requested);
        try {
            Set<String> keep = new HashSet<>();
            JSONArray arr = new JSONArray(keepIdsJson == null ? "[]" : keepIdsJson);
            for (int i = 0; i < arr.length(); i++) {
                String id = arr.optString(i, "").trim();
                if (!id.isEmpty()) keep.add(id);
            }

            Map<String, ?> all = prefs().getAll();
            for (String key : new ArrayList<>(all.keySet())) {
                if (!key.startsWith(KEY_PREFIX)) continue;
                String id = key.substring(KEY_PREFIX.length());
                if (!keep.contains(id)) removeEntry(id);
            }

            List<Entry> entries = readEntries();
            long total = 0L;
            for (Entry e : entries) total += e.bytes;
            if (total > maxBytes) {
                entries.sort(Comparator.comparingLong(e -> e.lastAccessAt));
                for (Entry e : entries) {
                    if (total <= maxBytes) break;
                    removeEntry(e.videoId);
                    total -= e.bytes;
                }
            }
            call.resolve(statsObject());
        } catch (Exception e) {
            call.reject("Rolling cache prune failed: " + safe(e));
        }
    }

    @PluginMethod
    public void remove(PluginCall call) {
        String videoId = call.getString("videoId", "");
        if (videoId.isBlank()) { call.reject("videoId is required."); return; }
        removeEntry(videoId);
        call.resolve();
    }

    @PluginMethod
    public void clear(PluginCall call) {
        for (Entry entry : readEntries()) removeEntry(entry.videoId);
        prefs().edit().clear().apply();
        call.resolve(statsObject());
    }

    @PluginMethod
    public void stats(PluginCall call) {
        call.resolve(statsObject());
    }

    private JSObject download(
        String videoId,
        String title,
        String channel,
        String thumbnail,
        String provider,
        String sourceUrl,
        String mediaKind,
        String raw,
        String mimeHint,
        JSObject requestHeaders
    ) throws Exception {
        HttpURLConnection connection = openConnection(raw, requestHeaders);
        int code = connection.getResponseCode();
        if (code < 200 || code >= 300) {
            connection.disconnect();
            throw new Exception("HTTP " + code);
        }
        String finalUrl = connection.getURL().toString();
        String mime = stripParams(firstNonBlank(connection.getContentType(), mimeHint));
        if (isSegmented(finalUrl, mime)) {
            connection.disconnect();
            throw new Exception("Segmented HLS/DASH media is not stored by rolling cache.");
        }
        MediaSafety.validateMetadata(finalUrl, connection.getHeaderField("Content-Disposition"), mime, null);
        long total = connection.getContentLengthLong();
        if (total > MediaSafety.MAX_OFFLINE_BYTES) {
            connection.disconnect();
            throw new Exception("Media exceeds SidePlay's safety limit.");
        }

        File dir = cacheDir();
        long available = dir.getUsableSpace();
        if (total > 0 && total + MediaSafety.STORAGE_RESERVE_BYTES > available) {
            connection.disconnect();
            throw new Exception("Not enough free storage for rolling cache.");
        }

        String ext = extensionFrom(finalUrl);
        if (ext.isBlank()) ext = extensionForMime(mime);
        if (ext.isBlank()) ext = "media";
        String safeId = safeFile(videoId);
        File part = new File(dir, safeId + "." + ext + ".part");
        File out = new File(dir, safeId + "." + ext);

        long bytes = 0L;
        try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream(), 1024 * 1024);
             BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(part), 1024 * 1024)) {
            input.mark(64 * 1024);
            byte[] prefix = new byte[8192];
            int prefixRead = input.read(prefix);
            if (prefixRead <= 0) throw new Exception("Downloaded cache object was empty.");
            MediaSafety.validatePrefix(prefix, prefixRead, mime, out.getName());
            input.reset();

            byte[] buffer = new byte[1024 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                bytes += read;
                if (bytes > MediaSafety.MAX_OFFLINE_BYTES) throw new Exception("Rolling cache object exceeded SidePlay's safety limit.");
                output.write(buffer, 0, read);
            }
            output.flush();
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            part.delete();
            throw e;
        } finally {
            connection.disconnect();
        }

        if (bytes <= 0) {
            //noinspection ResultOfMethodCallIgnored
            part.delete();
            throw new Exception("Downloaded cache object was empty.");
        }

        removePhysicalFor(videoId);
        if (!part.renameTo(out)) {
            try (FileInputStream in = new FileInputStream(part);
                 BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(out), 1024 * 1024)) {
                byte[] buffer = new byte[1024 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) output.write(buffer, 0, read);
                output.flush();
            }
            //noinspection ResultOfMethodCallIgnored
            part.delete();
        }

        long now = System.currentTimeMillis();
        JSONObject meta = new JSONObject();
        meta.put("videoId", videoId);
        meta.put("filename", out.getName());
        meta.put("mimeType", mime);
        meta.put("bytes", out.length());
        meta.put("title", title == null ? "" : title);
        meta.put("channel", channel == null ? "" : channel);
        meta.put("thumbnail", thumbnail == null ? "" : thumbnail);
        meta.put("provider", provider == null ? "" : provider);
        meta.put("sourceUrl", sourceUrl == null ? "" : sourceUrl);
        meta.put("mediaKind", mediaKind == null ? "" : mediaKind);
        meta.put("cachedAt", now);
        meta.put("lastAccessAt", now);
        prefs().edit().putString(KEY_PREFIX + videoId, meta.toString()).apply();
        return toJs(meta, out, true);
    }

    private JSObject lookupEntry(String videoId, boolean touch) throws Exception {
        String raw = prefs().getString(KEY_PREFIX + videoId, "");
        if (raw == null || raw.isBlank()) return miss(videoId);
        JSONObject meta = new JSONObject(raw);
        File file = new File(cacheDir(), meta.optString("filename", ""));
        if (!file.isFile() || file.length() <= 0) {
            removeEntry(videoId);
            return miss(videoId);
        }
        if (touch) {
            meta.put("lastAccessAt", System.currentTimeMillis());
            prefs().edit().putString(KEY_PREFIX + videoId, meta.toString()).apply();
        }
        return toJs(meta, file, true);
    }

    private JSObject miss(String videoId) {
        JSObject out = new JSObject();
        out.put("videoId", videoId);
        out.put("hit", false);
        return out;
    }

    private JSObject toJs(JSONObject meta, File file, boolean hit) {
        JSObject out = new JSObject();
        out.put("hit", hit);
        out.put("videoId", meta.optString("videoId", ""));
        out.put("localUri", Uri.fromFile(file).toString());
        out.put("filename", file.getName());
        out.put("mimeType", meta.optString("mimeType", ""));
        out.put("bytes", file.length());
        out.put("title", meta.optString("title", ""));
        out.put("channel", meta.optString("channel", ""));
        out.put("thumbnail", meta.optString("thumbnail", ""));
        out.put("provider", meta.optString("provider", ""));
        out.put("sourceUrl", meta.optString("sourceUrl", ""));
        out.put("mediaKind", meta.optString("mediaKind", ""));
        out.put("cachedAt", meta.optLong("cachedAt", 0L));
        out.put("lastAccessAt", meta.optLong("lastAccessAt", 0L));
        out.put("rolling", true);
        return out;
    }

    private JSObject statsObject() {
        List<Entry> entries = readEntries();
        long bytes = 0L;
        for (Entry e : entries) bytes += e.bytes;
        JSObject out = new JSObject();
        out.put("entries", entries.size());
        out.put("bytes", bytes);
        out.put("maxBytesDefault", DEFAULT_MAX_BYTES);
        out.put("directory", cacheDir().getAbsolutePath());
        out.put("inFlight", LOCKS.size());
        return out;
    }

    private List<Entry> readEntries() {
        List<Entry> entries = new ArrayList<>();
        for (Map.Entry<String, ?> item : prefs().getAll().entrySet()) {
            if (!item.getKey().startsWith(KEY_PREFIX) || !(item.getValue() instanceof String)) continue;
            try {
                JSONObject meta = new JSONObject((String) item.getValue());
                String id = meta.optString("videoId", item.getKey().substring(KEY_PREFIX.length()));
                File file = new File(cacheDir(), meta.optString("filename", ""));
                if (!file.isFile() || file.length() <= 0) continue;
                entries.add(new Entry(id, file.length(), meta.optLong("lastAccessAt", meta.optLong("cachedAt", 0L))));
            } catch (Exception ignored) {}
        }
        return entries;
    }

    private void removeEntry(String videoId) {
        removePhysicalFor(videoId);
        prefs().edit().remove(KEY_PREFIX + videoId).apply();
    }

    private void removePhysicalFor(String videoId) {
        String raw = prefs().getString(KEY_PREFIX + videoId, "");
        if (raw != null && !raw.isBlank()) {
            try {
                JSONObject meta = new JSONObject(raw);
                File file = new File(cacheDir(), meta.optString("filename", ""));
                //noinspection ResultOfMethodCallIgnored
                file.delete();
            } catch (Exception ignored) {}
        }
        String prefix = safeFile(videoId) + ".";
        File[] files = cacheDir().listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.getName().startsWith(prefix)) {
                    //noinspection ResultOfMethodCallIgnored
                    file.delete();
                }
            }
        }
    }

    private HttpURLConnection openConnection(String raw, JSObject headers) throws Exception {
        URL original = new URL(raw);
        URL current = original;
        for (int redirect = 0; redirect <= 6; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(30000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Connection", "keep-alive");
            applyHeaders(connection, headers, sameHost(original, current));
            if (!hasHeader(headers, "User-Agent")) connection.setRequestProperty("User-Agent", "SidePlay/0.9.2-r10.2 Android");
            if (!hasHeader(headers, "Accept")) connection.setRequestProperty("Accept", "audio/*,video/*,application/octet-stream;q=0.9,*/*;q=0.1");
            int code = connection.getResponseCode();
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String location = connection.getHeaderField("Location");
                if (location == null || location.isBlank()) return connection;
                URL next = new URL(current, location);
                connection.disconnect();
                if (!("http".equalsIgnoreCase(next.getProtocol()) || "https".equalsIgnoreCase(next.getProtocol()))) {
                    throw new Exception("Unsupported redirect scheme.");
                }
                current = next;
                continue;
            }
            return connection;
        }
        throw new Exception("Too many redirects.");
    }

    private static void applyHeaders(HttpURLConnection connection, JSObject headers, boolean includeSensitive) {
        if (headers == null) return;
        Iterator<String> keys = headers.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            String value = headers.optString(key, "");
            if (key == null || key.isBlank() || value.isBlank()) continue;
            String lower = key.toLowerCase(Locale.ROOT);
            if (lower.equals("host") || lower.equals("content-length") || lower.equals("connection") || lower.equals("accept-encoding") || lower.equals("range") || lower.startsWith("sec-")) continue;
            if (!includeSensitive && (lower.equals("cookie") || lower.equals("authorization") || lower.equals("proxy-authorization") || lower.equals("x-csrf-token") || lower.equals("x-xsrf-token"))) continue;
            try { connection.setRequestProperty(key, value); } catch (Exception ignored) {}
        }
    }

    private static boolean hasHeader(JSObject headers, String wanted) {
        if (headers == null) return false;
        Iterator<String> keys = headers.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (key != null && key.equalsIgnoreCase(wanted) && !headers.optString(key, "").isBlank()) return true;
        }
        return false;
    }

    private static boolean sameHost(URL a, URL b) {
        return a != null && b != null && String.valueOf(a.getHost()).equalsIgnoreCase(String.valueOf(b.getHost()));
    }

    private static boolean isSegmented(String url, String mime) {
        String lower = (url == null ? "" : url).toLowerCase(Locale.ROOT);
        String m = (mime == null ? "" : mime).toLowerCase(Locale.ROOT);
        return lower.contains(".m3u8") || lower.contains(".mpd") || m.contains("mpegurl") || m.contains("dash+xml");
    }

    private File cacheDir() {
        File dir = new File(getContext().getFilesDir(), "rolling-cache");
        if (!dir.exists()) //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
        return dir;
    }

    private android.content.SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, 0);
    }

    private static String stripParams(String mime) {
        if (mime == null) return "";
        int semicolon = mime.indexOf(';');
        return (semicolon >= 0 ? mime.substring(0, semicolon) : mime).trim();
    }

    private static String firstNonBlank(String... values) {
        for (String value : values) if (value != null && !value.isBlank()) return value;
        return "";
    }

    private static String extensionFrom(String raw) {
        try {
            String path = URI.create(raw).getPath();
            if (path == null) return "";
            int dot = path.lastIndexOf('.');
            if (dot < 0 || dot >= path.length() - 1) return "";
            String ext = path.substring(dot + 1).toLowerCase(Locale.ROOT);
            return ext.matches("[a-z0-9]{1,6}") ? ext : "";
        } catch (Exception ignored) { return ""; }
    }

    private static String extensionForMime(String mime) {
        String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(stripParams(mime));
        if (ext != null && !ext.isBlank()) return ext;
        String m = stripParams(mime).toLowerCase(Locale.ROOT);
        if (m.equals("audio/mp4")) return "m4a";
        if (m.equals("audio/ogg")) return "ogg";
        if (m.equals("audio/webm")) return "webm";
        return "";
    }

    private static String safeFile(String value) {
        String safe = (value == null ? "track" : value).replaceAll("[^A-Za-z0-9._-]", "_");
        if (safe.length() > 80) safe = safe.substring(0, 80);
        return safe.isBlank() ? "track" : safe;
    }

    private static String safe(Throwable t) {
        if (t == null) return "unknown error";
        String m = t.getMessage();
        return m == null || m.isBlank() ? t.getClass().getSimpleName() : m;
    }

    private static final class Entry {
        final String videoId;
        final long bytes;
        final long lastAccessAt;
        Entry(String videoId, long bytes, long lastAccessAt) {
            this.videoId = videoId;
            this.bytes = bytes;
            this.lastAccessAt = lastAccessAt;
        }
    }
}
