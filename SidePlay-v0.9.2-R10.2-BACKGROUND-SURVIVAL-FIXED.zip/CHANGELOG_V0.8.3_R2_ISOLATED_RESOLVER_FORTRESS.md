# SidePlay v0.8.3-r2 — Isolated Resolver Fortress

## Resolver
- Merged v0.8.2 R6 yt-dlp process isolation with v0.8.3 Resolver Fortress.
- YouTube playback ladder is NewPipe -> InnerTube SAFE -> yt-dlp in `:extractor`.
- Media3 refresh follows NewPipe -> InnerTube SAFE -> isolated yt-dlp and resumes around the previous position.
- NewPipe keeps video manifests ahead of audio fallback.

## Stability
- Removed `javax.annotation.Nonnull` from `SidePlayNewPipeDownloader`, fixing Android javac builds without adding a one-annotation dependency.
- Added blocking IPC bridge only for background resolver threads; it refuses main-thread use.
- Isolated yt-dlp service hard-kills only its own process on timeout.
- `resolveForPlayback()` has a runtime process guard and refuses to initialize yt-dlp outside `:extractor`.
- Existing yt-dlp serialization, bounded retries, single-fragment policy, and guarded nightly update+retry remain.

## Packaging
- Android `versionCode 807`.
- Android `versionName 0.8.3-r2`.
- Build scripts verify the isolated service, manifest process, and absence of legacy `javax.annotation`.
