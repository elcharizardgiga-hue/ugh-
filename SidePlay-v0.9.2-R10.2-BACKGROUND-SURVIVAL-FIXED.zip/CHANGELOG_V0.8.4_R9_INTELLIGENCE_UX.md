# SidePlay 0.8.4-r9 — Intelligence + UX

R9 keeps R8's playback atomicity, queue integrity and watch-next-first Radio, then adds a local Taste Engine and the first user-facing intelligence layer around Search, Radio and Now Playing.

## Taste Engine v1

- Persists explicit listening signals in state schema v3: play, completion, early skip, like/unlike, manual queue and playlist adds.
- Uses weighted signals instead of treating every play as equal.
- Long-term taste decays over ~45 days; session taste decays over ~2.5 hours.
- Early skips count more negatively than late skips.
- Repeat/completion/library actions are stronger positive signals than passive plays.
- Keeps a bounded event history (max 1,200 events) so local state does not grow forever.
- R8/v2 and legacy/v1 libraries migrate forward automatically.

## Tune Radio

Now Playing adds a Tune panel with:

- Stay here
- Go deeper
- Surprise me
- Energy
- Chill
- Balanced
- Discovery slider: familiar ↔ new artists
- Variety slider: coherent ↔ more artist diversity

Radio combines YouTube watch-next candidates, local/session taste, canonical song identity, skips, recent listening and diversity limits. Search expansion remains a fallback when the native related feed is unavailable or thin.

## Search + autocomplete

- Search suggestions combine recent searches/listening with YouTube query suggestions.
- Suggestions are debounced and keyboard friendly (Up/Down, Enter/Tab, Escape).
- Suggestion locale follows the browser/device language-region instead of forcing US-English.
- Search results are reranked for query intent.
- Official/Topic/VEVO-style results get a small trust boost.
- Unrequested karaoke/cover/slowed/reverb/noise variants are penalized.
- Canonical dedupe collapses duplicate uploads of the same song while preserving meaningful variants such as live/remix/acoustic.

## Lyrics

- Now Playing has an on-demand Lyrics panel.
- Android requests lyrics from YouTube Music metadata only when the user opens the panel.
- Results are cached locally with a TTL and bounded cache size.
- Lyrics are best-effort and never block playback, queue transitions or Radio.
- R9 exposes plain lyrics when available; synchronized word/line timing is not claimed in this release.

## UX + queue continuity

- R8 manual-queue priority and Your Queue / Autoplay separation remain intact.
- “Less like this” is available from track actions and feeds the Taste Engine.
- Recommendation reasons remain visible.
- Zero-Wait prefetch stays isolated from full Play resolution.
- Tune/lyrics panels are contained inside Now Playing instead of pushing the listener into Settings or an external browser.

## Build / release identity

- Source package: `0.8.4-r9`
- Android package: `app.sideplay.mobile`
- Android versionName: `0.8.4-r9`
- Android versionCode: `816`
- TypeScript is pinned to real npm release `5.8.3` (keeps the R8 Hotfix 1 dependency correction).
- Core regression tests: 7 tests covering music identity, noisy variants, canonical search dedupe and ranking.

Build with `BUILD_SIDEPLAY_APK_CLEAN.bat` for the first run or `BUILD_SIDEPLAY_V084_R9_INTELLIGENCE_UX.bat` directly.
