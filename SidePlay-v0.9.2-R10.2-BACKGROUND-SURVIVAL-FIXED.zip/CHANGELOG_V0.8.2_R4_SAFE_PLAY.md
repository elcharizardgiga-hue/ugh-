# SidePlay v0.8.2 R4 SAFE PLAY

- Normal Play no longer invokes yt-dlp / embedded Python / QuickJS.
- YouTube playback now uses the lightweight NativeYouTube InnerTube resolver for direct clear stream URLs.
- Media3 retry/resume/network-recovery paths no longer auto-start yt-dlp.
- yt-dlp remains available only for explicit provider downloads/manual workflows.
- One-time migration clears only old extractor resume snapshot, not app cache/history/playlists/downloads.
