# SidePlay R10 plan

## Phase 1 — identity and state
- Canonical Track metadata boundary
- Persistent metadata self-healing
- Explicit playback state machine
- Queue v2 with manual/autoplay separation
- Search generation guards
- Taste event identity snapshots and decay

## Phase 2 — reliability and offline continuity
- Resolver health/circuit breakers
- Playback resurrection
- Persistent rolling cache: previous 20 + current + next 20
- Local-first playback from rolling cache
- Automatic storage pruning
- Download Accelerator and rolling-cache promotion

## Phase 3 — recommendation control
- Tune V2 presets with real tuning values
- Discovery affects candidate sourcing
- Variety affects same-artist pull and artist caps
- Tune applies directly to generated Up Next while preserving manual queue
- Stale tune requests cannot overwrite newer settings
- Taste diagnostics visible to the user

## Phase 4 — UX cohesion
- Search suggestion lifecycle cleanup
- Scroll-safe Now Playing/modals
- Synced/plain lyrics with fallback, retry and tap-to-seek
- MediaSession/background diagnostics
- ARM64 reproducible release workflow

## Phase 5 — after the stabilization build proves solid on-device
- Native next-item prebuffer / true gapless capability probe
- Optional crossfade
- SideMix natural-language mix composer
- Smart Library auto-collections
- SidePlay Memory/listening-session summaries
- Expanded device torture tests and long-run soak tests

R10 intentionally puts the nervous system first. The Phase 5 features are kept behind the stabilization milestone so they do not destabilize queue/playback again before the core is proven on-device.
