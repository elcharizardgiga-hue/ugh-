# SidePlay v0.8.4-r1 — GitHub APK build

Upload the contents of this source folder to the repository root and run `.github/workflows/build-apk.yml`.

The workflow verifies:
- source version `0.8.4`
- `native/android` resolver + isolated-extractor sources are present
- no legacy `javax.annotation` remains in the NewPipe downloader
- Zero-Wait/Engine-Doctor source markers are present
- package `app.sideplay.mobile`
- versionName `0.8.4-r1`
- versionCode `808`
- ARM64 packaging, APK signature and zip alignment

For upgrade-in-place installs, keep using the same Android signing key as the previous installed build.
