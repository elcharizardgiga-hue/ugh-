# SidePlay v0.9.2-r10.2 — Background Survival Hotfix

- PlaybackService no longer delegates active task removal to OEM-sensitive MediaSessionService cleanup.
- Active native playback remains alive when the SidePlay UI is backgrounded/removed.
- Reasserts playback/checkpoint heartbeat when the task disappears.
- Explicit Pause/Stop still disable resurrection normally.
- Builder now verifies the background-survival contract.
