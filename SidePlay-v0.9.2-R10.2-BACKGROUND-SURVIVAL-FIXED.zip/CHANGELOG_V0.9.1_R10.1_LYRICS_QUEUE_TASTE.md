# SidePlay 0.9.1-r10.1 — Lyrics, Queue & Taste Integrity

## Lyrics
- v3 cache is keyed by video id + healed artist/song identity, not video id alone.
- Previous v1/v2 lyrics caches are intentionally not reused.
- Every lyrics request is generation guarded so a slow old song can never repaint a new track.
- Native LRCLIB fallback now ranks title/artist/duration matches instead of taking the first search result.
- Synced lyrics auto-follow now uses DOM bounding rectangles instead of offsetTop coordinate assumptions.
- Manual lyric scrolling pauses Follow for six seconds; a Follow button resumes it.
- Global +/- 0.5 second sync offset with persistent correction.
- Tap-to-seek accounts for the sync offset.

## UI
- Lyrics and Tune are now large listening surfaces, not tiny cards.
- Larger lyric typography, active-line emphasis and more vertical viewport.
- Larger Tune presets, sliders, descriptions and actions.

## Queue
- Fixed Queue View move/remove index bug: section-local positions no longer mutate the wrong global queue item.
- Added Now Playing identity and manual/autoplay/total counts.
- Manual items remain ahead of generated autoplay.

## Metadata
- YouTube `/watch` pathname is considered placeholder metadata and triggers real metadata hydration.

## Taste Engine
- Track opinions and artist opinions now have separate weights.
- Early bounces are strongly negative for the track; late skips are nearly neutral.
- Single-track skips no longer punish the whole artist at equal strength.
- Personalization confidence ramps up with meaningful evidence instead of overfitting immediately.
- Recent-artist fatigue counterbalances the session-affinity feedback loop unless Tune explicitly requests Stay/Deeper.
