# SidePlay 0.8.4-r9 Hotfix 2 — Playback Resurrection

This hotfix hardens the native Android playback process after real-world Engine Doctor telemetry showed `:playback` and `:extractor` being reclaimed by Android under low-memory pressure.

## Playback Resurrection
- Native Media3 playback now returns `START_STICKY` only while a recent persisted checkpoint says playback should still be active.
- Android sticky recreation (`null` Intent) restores the current track and position automatically.
- Paused, stopped, missing, and stale checkpoints never auto-play.
- Provider/extractor streams are re-resolved from the durable source URL before restoration instead of blindly trusting an expired signed URL.
- Recovery is generation-safe: a fresh user Play command invalidates any older in-flight resurrection so recovery can never overwrite the newly selected track.
- Network recovery can resurrect a player that came back with zero MediaItems.

## Engine Doctor
- Adds a native heartbeat so stale broadcasts no longer make a dead `:playback` process look alive.
- Reports recovery state (`attempting`, `refreshing-source`, `restored-refreshed`, `restored-direct`, `waiting-network`, etc.) plus attempt count.
- Android process-exit reasons now include readable names such as `LOW_MEMORY` and `PACKAGE_UPDATED`.

## Resolver circuit breaker
- InnerTube SAFE now tracks consecutive resolver failures.
- After 3 consecutive failures it cools down exponentially (30s → 60s → 120s → ... capped at 5 minutes) instead of being hammered on every track.
- A successful InnerTube resolution resets the breaker immediately.
- NewPipe and isolated yt-dlp remain available in the existing ladder.

## Validation
- 11/11 core regression tests passing.
- Java source smoke parsing reaches dependency resolution with no syntax-pattern errors in `PlaybackService`, `BackgroundAudioPlugin`, or `NativeYouTubePlugin`.
- TypeScript release remains pinned to 5.8.3.

Release identity intentionally remains `0.8.4-r9 / versionCode 816`; this is a source hotfix to the R9/R10 development base rather than the final R10 feature release.
