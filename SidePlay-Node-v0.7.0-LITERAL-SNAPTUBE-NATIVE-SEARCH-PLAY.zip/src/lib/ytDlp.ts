import { registerPlugin, type PluginListenerHandle } from '@capacitor/core'
import type { OfflineCopy, Track } from '../types'
import type { SourceResolution } from './universalSource'

interface YtDlpPlugin {
  search(options: { query: string; engine?: 'youtube' | 'youtube-music' | 'soundcloud'; limit?: number }): Promise<{ tracks: Track[]; engine: string; count: number }>
  resolve(options: { url: string }): Promise<SourceResolution>
  download(options: { url: string; videoId: string; title: string; mediaKind?: 'audio' | 'video' }): Promise<{
    localUri: string
    filename: string
    mimeType?: string
    bytes?: number
    provider?: string
    sourceUrl?: string
    mediaKind?: 'audio' | 'video'
  }>
  addListener(eventName: 'downloadProgress', listener: (event: { videoId: string; progress: number; line?: string }) => void): Promise<PluginListenerHandle>
}

const YtDlp = registerPlugin<YtDlpPlugin>('YtDlp')

export async function searchWithYtDlp(query: string, engine: 'youtube' | 'youtube-music' | 'soundcloud' = 'youtube', limit = 20) {
  const result = await YtDlp.search({ query, engine, limit })
  return Array.isArray(result.tracks) ? result.tracks : []
}

export async function resolveWithYtDlp(url: string) {
  return YtDlp.resolve({ url })
}

export async function downloadWithYtDlp(track: Track): Promise<OfflineCopy> {
  if (!track.sourceUrl) throw new Error('This item has no durable source URL for provider download.')
  const result = await YtDlp.download({
    url: track.sourceUrl,
    videoId: track.videoId,
    title: track.title,
    mediaKind: track.mediaKind,
  })
  return {
    videoId: track.videoId,
    localUri: result.localUri,
    filename: result.filename,
    mimeType: result.mimeType,
    bytes: result.bytes,
    addedAt: Date.now(),
    platform: 'android',
    title: track.title,
    channel: track.channel,
    thumbnail: track.thumbnail,
    provider: track.provider,
    sourceUrl: track.sourceUrl,
    mediaKind: result.mediaKind || track.mediaKind,
  }
}

export function onYtDlpProgress(listener: (event: { videoId: string; progress: number }) => void) {
  return YtDlp.addListener('downloadProgress', listener)
}
