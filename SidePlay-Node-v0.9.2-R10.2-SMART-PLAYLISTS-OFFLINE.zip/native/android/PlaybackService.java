package app.sideplay.mobile;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.ResolvingDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.session.DefaultMediaNotificationProvider;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;

import org.json.JSONObject;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.net.URI;
import java.net.URLDecoder;

public class PlaybackService extends MediaSessionService {
    public static final String ACTION_PLAY = "app.sideplay.mobile.PLAY";
    public static final String ACTION_PAUSE = "app.sideplay.mobile.PAUSE";
    public static final String ACTION_RESUME = "app.sideplay.mobile.RESUME";
    public static final String ACTION_STOP = "app.sideplay.mobile.STOP";
    public static final String ACTION_SEEK = "app.sideplay.mobile.SEEK";
    public static final String ACTION_EVENT = "app.sideplay.mobile.PLAYBACK_EVENT";

    private static final String PREFS = "sideplay-playback-resume-v1";
    private static final String K_URL = "url";
    private static final String K_TITLE = "title";
    private static final String K_ARTIST = "artist";
    private static final String K_ARTWORK = "artwork";
    private static final String K_MIME = "mime";
    private static final String K_HEADERS = "headers";
    private static final String K_SOURCE_URL = "sourceUrl";
    private static final String K_REFRESH_MODE = "refreshMode";
    private static final String K_POSITION = "position";
    private static final String K_RESUMABLE = "resumable";
    private static final String K_WANT_PLAY = "wantPlay";
    private static final String K_AUDIO_PREFERRED = "audioPreferred";
    private static final String K_UPDATED = "updated";
    private static final long RECOVERY_MAX_AGE_MS = 6L * 60L * 60L * 1000L;
    private static final long RECOVERY_HEARTBEAT_MS = 5000L;

    private static volatile PlaybackService instance;

    private ExoPlayer player;
    private SharedPreferences diagnosticsPrefs;
    private volatile boolean startupHealthy = false;
    private volatile String startupFailure = "";
    private MediaSession mediaSession;
    private SharedPreferences resumePrefs;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    private final Handler retryHandler = new Handler(Looper.getMainLooper());
    private final Handler checkpointHandler = new Handler(Looper.getMainLooper());
    private int retryCount = 0;
    private int retryGeneration = 0;
    private volatile boolean wantPlay = false;
    private volatile boolean pendingNetworkRecovery = false;
    private volatile boolean currentResumable = false;
    private volatile Uri currentOriginalUri;
    private volatile Map<String, String> currentHeaders = Collections.emptyMap();
    private volatile String currentSourceUrl = "";
    private volatile String currentRefreshMode = "";
    private volatile boolean currentAudioPreferred = false;
    private volatile boolean extractorRefreshInFlight = false;
    private volatile int extractorRefreshCount = 0;
    private volatile boolean startupRecoveryAttempted = false;

    private final Runnable checkpointRunnable = new Runnable() {
        @Override public void run() {
            touchHeartbeat();
            try { persistCurrent(); } catch (Exception ignored) {}
            if (player != null && player.getMediaItemCount() > 0) {
                try { broadcast(player.isPlaying() ? "playing" : "paused", null); } catch (Throwable ignored) {}
                checkpointHandler.postDelayed(this, RECOVERY_HEARTBEAT_MS);
            }
        }
    };

    public static @Nullable PlaybackService getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        // Make the system media controller deterministic. MediaSessionService has a
        // default provider, but explicitly owning the channel/icon prevents OEMs from
        // treating SidePlay like a generic background service with no visible controls.
        try {
            DefaultMediaNotificationProvider provider = new DefaultMediaNotificationProvider.Builder(this)
                .setNotificationId(9405)
                .setChannelId("sideplay_playback")
                .setChannelName(R.string.sideplay_playback_channel_name)
                .build();
            provider.setSmallIcon(R.drawable.ic_sideplay_notification);
            setMediaNotificationProvider(provider);
        } catch (Throwable ignored) {
            // Media3's built-in provider remains available if an OEM/resource quirk
            // prevents the custom provider from being installed.
        }

        diagnosticsPrefs = getSharedPreferences("sideplay-native-playback-diagnostics", Context.MODE_PRIVATE);
        markStage("service-onCreate", "MediaSessionService created");
        resumePrefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        // One-time R4 migration: discard only the old native resume snapshot when it
        // points at the crash-prone embedded extractor path. This is NOT an app/cache
        // wipe: favorites, playlists, history, downloads and WebView data are untouched.
        SharedPreferences migrations = getSharedPreferences("sideplay-migrations", Context.MODE_PRIVATE);
        if (!migrations.getBoolean("r4-safe-play", false)) {
            if ("extractor".equals(resumePrefs.getString(K_REFRESH_MODE, ""))) {
                resumePrefs.edit().clear().apply();
            }
            migrations.edit().putBoolean("r4-safe-play", true).apply();
        }

        markStage("datasource-init", "Preparing Media3 data source");
        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
            .setUserAgent("SidePlay/0.8.4-r9 Android")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(12000)
            .setReadTimeoutMs(30000);
        DefaultDataSource.Factory baseDataSourceFactory = new DefaultDataSource.Factory(this, httpFactory);
        DataSource.Factory resolvingDataSourceFactory = new ResolvingDataSource.Factory(
            baseDataSourceFactory,
            dataSpec -> dataSpec.withRequestHeaders(headersForUri(currentHeaders, currentOriginalUri, dataSpec.uri))
        );
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(this)
            .setDataSourceFactory(resolvingDataSourceFactory);

        // Media3 1.8.1 compatibility: the split streaming/local buffer builder
        // methods were added after the version SidePlay currently pins. A
        // single music-first profile keeps the same robust streaming behavior
        // while compiling against 1.8.1. Local files are unaffected in
        // practice because reads are on-device.
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
            .setBufferDurationsMs(15000, 60000, 1200, 2800)
            .setBackBuffer(15000, true)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build();

        markStage("player-build", "Building ExoPlayer");
        try {
            player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(mediaSourceFactory)
                .setLoadControl(loadControl)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build();
        } catch (Throwable t) {
            failStartup("player-build-failed", t);
            return;
        }

        // R2 CRASH-SAFE: audio offload is intentionally disabled. It is optional,
        // OEM/codec dependent, and not worth risking the core playback path.
        // Gapless/crossfade can return later behind a capability probe.
        markStage("player-built", "ExoPlayer ready; audio offload disabled for stability");

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build();
        player.setAudioAttributes(audioAttributes, true);
        player.setHandleAudioBecomingNoisy(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                broadcast(isPlaying ? "playing" : "paused", null);
                persistCurrent();
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
                markStage("player-state-" + playbackState, "isPlaying=" + player.isPlaying());
                if (playbackState == Player.STATE_ENDED) {
                    wantPlay = false;
                    pendingNetworkRecovery = false;
                    broadcast("ended", null);
                    persistCurrent();
                } else if (playbackState == Player.STATE_BUFFERING) {
                    broadcast("buffering", null);
                } else if (playbackState == Player.STATE_READY) {
                    retryCount = 0;
                    extractorRefreshCount = 0;
                    pendingNetworkRecovery = false;
                    broadcast(player.isPlaying() ? "playing" : "ready", null);
                    persistCurrent();
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                markStage("player-error", error == null ? "unknown" : safe(error));
                if (player != null && player.getMediaItemCount() > 0 && retryCount < 3) {
                    final int generation = retryGeneration;
                    final int attempt = ++retryCount;
                    broadcast("buffering", "Connection interrupted. Retrying " + attempt + "/3…");
                    retryHandler.postDelayed(() -> {
                        if (generation != retryGeneration || player == null || player.getMediaItemCount() == 0) return;
                        try {
                            player.prepare();
                            if (wantPlay) player.play();
                        } catch (Exception retryError) {
                            broadcast("error", retryError.getMessage() == null ? "Native playback retry failed." : retryError.getMessage());
                        }
                    }, attempt == 1 ? 900L : attempt == 2 ? 2600L : 6500L);
                    return;
                }
                // A signed provider URL can expire while the durable source page is still
                // perfectly valid. Refresh once or twice through the resolver ladder and seek
                // back to the same position before surfacing a terminal error.
                if (wantPlay && isExtractorRefreshMode(currentRefreshMode)
                    && isSafeDurableSource(currentSourceUrl) && extractorRefreshCount < 2) {
                    refreshExtractorCurrent("Stream expired or stopped responding. Refreshing source…");
                    return;
                }
                pendingNetworkRecovery = wantPlay && player != null && player.getMediaItemCount() > 0;
                broadcast("error", error == null ? "Native playback failed. Waiting for network recovery." : error.getMessage());
            }
        });

        MediaSession.Callback sessionCallback = new MediaSession.Callback() {
            @Override
            @UnstableApi
            public ListenableFuture<MediaSession.MediaItemsWithStartPosition> onPlaybackResumption(
                MediaSession session,
                MediaSession.ControllerInfo controller
            ) {
                ResumeState state = readResumeState();
                if (state == null) {
                    return Futures.immediateFailedFuture(new IllegalStateException("No resumable SidePlay item is available."));
                }
                // Media3 1.8.1 exposes the two-argument resumption callback.
                // This service is a MediaSessionService (not MediaLibraryService),
                // so this callback represents an actual playback-resume request.
                wantPlay = true;
                // R4 SAFE PLAY: resume the last verified URL directly. Do not boot
                // yt-dlp from a MediaSession/lock-screen resumption callback.
                applyResumeNetworkState(state);
                MediaItem item = buildMediaItem(state.url, state.title, state.artist, state.artwork, state.mimeType);
                return Futures.immediateFuture(
                    new MediaSession.MediaItemsWithStartPosition(
                        Collections.singletonList(item),
                        0,
                        Math.max(0L, state.positionMs)
                    )
                );
            }
        };

        markStage("session-build", "Building MediaSession");
        try {
            Intent launchIntent = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent sessionActivity = PendingIntent.getActivity(
                this,
                9405,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            mediaSession = new MediaSession.Builder(this, player)
                .setCallback(sessionCallback)
                .setSessionActivity(sessionActivity)
                .build();
            // R6: this service is started by SidePlay's own foreground Activity, not by
            // a MediaController bind. onGetSession() therefore may not run before the
            // first PLAY command. Explicitly register the session with the service so
            // Media3 owns its notification/foreground lifecycle immediately.
            addSession(mediaSession);
            markStage("media-session-published", "MediaSession added to MediaSessionService and discoverable by System UI");
        } catch (Throwable t) {
            failStartup("session-build-failed", t);
            return;
        }

        registerNetworkRecovery();
        checkpointHandler.postDelayed(checkpointRunnable, RECOVERY_HEARTBEAT_MS);
        startupHealthy = true;
        startupFailure = "";
        touchHeartbeat();
        markStage("ready", "Native playback service ready in :playback process");
        broadcast("ready", null);
        // R10 PLAYBACK RESURRECTION is intentionally triggered only by a null
        // START_STICKY restart Intent below. Doing it here would briefly restore an old
        // song even when this fresh service creation was caused by a brand-new Play tap.
    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        // R6 MEDIASESSION LIFECYCLE: SidePlay's private PLAY/PAUSE/SEEK intents are
        // app-internal service commands, not Media3 media-button/session intents. Feeding
        // them through MediaSessionService.onStartCommand first can make Media3 treat the
        // unknown action as an invalid session start on some OEM builds. Handle our own
        // commands first; only delegate intents which actually belong to Media3/platform.
        if (intent == null) {
            // START_STICKY recreation arrives with a null Intent. This is the only
            // automatic resurrection entry point, so a normal fresh Play tap can never
            // flash an older persisted song before its own ACTION_PLAY is processed.
            attemptStartupRecovery();
            return hasRecentPlayingSnapshot() ? START_STICKY : START_NOT_STICKY;
        }
        String action = intent.getAction();
        boolean sidePlayCommand = ACTION_PLAY.equals(action) || ACTION_PAUSE.equals(action) ||
            ACTION_RESUME.equals(action) || ACTION_STOP.equals(action) || ACTION_SEEK.equals(action);

        if (!sidePlayCommand) {
            try {
                return super.onStartCommand(intent, flags, startId);
            } catch (Throwable t) {
                markStage("media3-super-start-failed", safe(t));
                broadcast("error", "Media3 service command failed: " + safe(t));
                return START_NOT_STICKY;
            }
        }

        if (!startupHealthy || player == null || mediaSession == null) {
            String reason = startupFailure.isBlank() ? "Native player did not initialize." : startupFailure;
            markStage("play-rejected-unhealthy", reason);
            broadcast("error", reason);
            stopSelf();
            return START_NOT_STICKY;
        }

        // R10 intentionally allows guarded sticky resurrection. The persisted snapshot
        // must be recent and marked wantPlay=true; Pause/Stop clear that intent.

        if (ACTION_PLAY.equals(action)) {
            markStage("play-command", "Playback intent received");
            retryGeneration++;
            retryCount = 0;
            pendingNetworkRecovery = false;
            String url = intent.getStringExtra("url");
            String title = intent.getStringExtra("title");
            String artist = intent.getStringExtra("artist");
            String artwork = intent.getStringExtra("artwork");
            String mimeType = intent.getStringExtra("mimeType");
            String headersJson = intent.getStringExtra("requestHeadersJson");
            String sourceUrl = intent.getStringExtra("sourceUrl");
            String refreshMode = intent.getStringExtra("refreshMode");
            boolean requestedResumable = intent.getBooleanExtra("resumable", true);
            boolean audioPreferred = intent.getBooleanExtra("audioPreferred", false);
            long positionMs = Math.max(0L, intent.getLongExtra("positionMs", 0L));

            if (url != null && !url.isBlank()) {
                try {
                    currentOriginalUri = Uri.parse(url);
                    currentHeaders = parseHeaders(headersJson);
                    currentSourceUrl = sourceUrl == null ? "" : sourceUrl.trim();
                    currentRefreshMode = refreshMode == null ? "" : refreshMode.trim();
                    currentAudioPreferred = audioPreferred;
                    extractorRefreshCount = 0;
                    extractorRefreshInFlight = false;
                    boolean durableExtractor = "extractor".equals(currentRefreshMode) && isSafeDurableSource(currentSourceUrl);
                    currentResumable = requestedResumable && !containsSensitiveHeaders(currentHeaders) && (!"extractor".equals(currentRefreshMode) || durableExtractor);
                    wantPlay = true;
                    MediaItem item = buildMediaItem(url, title, artist, artwork, mimeType);
                    markStage("media-item", "Media item built: " + safeMime(mimeType));
                    player.setMediaItem(item);
                    markStage("media-item-published", "Media item entered MediaSession playlist");
                    if (positionMs > 0L) player.seekTo(positionMs);
                    persistSnapshot(url, title, artist, artwork, mimeType, currentHeaders, currentSourceUrl, currentRefreshMode, positionMs, currentResumable, true);
                    markStage("prepare", "Preparing Media3 source");
                    player.prepare();
                    markStage("play-requested", "Calling ExoPlayer.play()");
                    player.play();
                    checkpointHandler.removeCallbacks(checkpointRunnable);
                    checkpointHandler.postDelayed(checkpointRunnable, RECOVERY_HEARTBEAT_MS);
                } catch (Throwable e) {
                    markStage("play-command-failed", safe(e));
                    broadcast("error", e.getMessage() == null ? "Could not prepare native media." : e.getMessage());
                }
            }
            return START_STICKY;
        }

        if (ACTION_PAUSE.equals(action)) {
            retryGeneration++;
            wantPlay = false;
            player.pause();
            persistCurrent();
            markRecovery("paused", "Playback intent is paused; automatic resurrection is disabled.");
            return START_NOT_STICKY;
        }

        if (ACTION_RESUME.equals(action)) {
            wantPlay = true;
            if (player.getMediaItemCount() > 0) {
                player.play();
            } else {
                ResumeState state = readResumeState();
                if (state != null) restoreIntoPlayerSmart(state, true);
            }
            persistCurrent();
            return START_STICKY;
        }

        if (ACTION_SEEK.equals(action)) {
            long target = Math.max(0L, intent.getLongExtra("positionMs", 0L));
            seekTo(target);
            broadcast(player.isPlaying() ? "playing" : "paused", null);
            return START_NOT_STICKY;
        }

        if (ACTION_STOP.equals(action)) {
            retryGeneration++;
            wantPlay = false;
            pendingNetworkRecovery = false;
            player.stop();
            player.clearMediaItems();
            clearResumeState();
            markRecovery("stopped", "Playback was explicitly stopped; no resurrection snapshot remains.");
            stopSelf();
            return START_NOT_STICKY;
        }

        return START_NOT_STICKY;
    }

    private void attemptStartupRecovery() {
        if (startupRecoveryAttempted || !startupHealthy || player == null) return;
        startupRecoveryAttempted = true;
        ResumeState state = readResumeState();
        if (state == null) {
            markRecovery("none", "No resumable playback checkpoint is available.");
            return;
        }
        long ageMs = Math.max(0L, System.currentTimeMillis() - state.updatedAt);
        if (!state.wantPlay) {
            markRecovery("skipped-paused", "Checkpoint exists but playback was not active.");
            return;
        }
        if (state.updatedAt <= 0L || ageMs > RECOVERY_MAX_AGE_MS) {
            markRecovery("skipped-stale", "Checkpoint is too old for automatic resurrection.");
            return;
        }
        recoverSnapshot(state, "process-resurrection");
    }

    private boolean hasRecentPlayingSnapshot() {
        ResumeState state = readResumeState();
        if (state == null || !state.wantPlay || state.updatedAt <= 0L) return false;
        return System.currentTimeMillis() - state.updatedAt <= RECOVERY_MAX_AGE_MS;
    }

    private void recoverSnapshot(ResumeState state, String cause) {
        if (state == null || player == null || !state.wantPlay) return;
        final int generation = ++retryGeneration;
        final long ageMs = Math.max(0L, System.currentTimeMillis() - state.updatedAt);
        wantPlay = true;
        pendingNetworkRecovery = false;
        bumpRecoveryAttempt();
        markRecovery("attempting", cause + " · age=" + ageMs + "ms · position=" + state.positionMs + "ms");

        if (isExtractorRefreshMode(state.refreshMode) && isSafeDurableSource(state.sourceUrl)) {
            applyResumeNetworkState(state);
            currentResumable = true;
            extractorRefreshInFlight = true;
            markRecovery("refreshing-source", "Refreshing provider stream from durable source before restore.");
            new Thread(() -> {
                try {
                    FreshExtractor fresh = resolveFreshExtractor(state.sourceUrl, state.audioPreferred);
                    retryHandler.post(() -> {
                        if (generation != retryGeneration || player == null || !wantPlay) {
                            extractorRefreshInFlight = false;
                            return;
                        }
                        try {
                            applyFreshExtractorState(fresh, state);
                            MediaItem item = buildMediaItem(fresh.url, state.title, state.artist, state.artwork, fresh.mimeType);
                            player.setMediaItem(item);
                            if (state.positionMs > 0L) player.seekTo(state.positionMs);
                            persistSnapshot(
                                fresh.url, state.title, state.artist, state.artwork, fresh.mimeType, fresh.headers,
                                state.sourceUrl, "extractor", state.positionMs, true, true
                            );
                            player.prepare();
                            player.play();
                            markRecovery("restored-refreshed", "Recovered current track after process restart with a fresh provider stream.");
                            broadcast("buffering", "Playback process recovered. Restoring your track…");
                            checkpointHandler.removeCallbacks(checkpointRunnable);
                            checkpointHandler.postDelayed(checkpointRunnable, RECOVERY_HEARTBEAT_MS);
                        } catch (Throwable restoreError) {
                            pendingNetworkRecovery = true;
                            startupRecoveryAttempted = false;
                            markRecovery("waiting-network", "Fresh stream resolved but Media3 restore failed: " + safe(restoreError));
                            broadcast("error", "Playback recovery is waiting for network/media readiness.");
                        } finally {
                            extractorRefreshInFlight = false;
                        }
                    });
                } catch (Throwable resolveError) {
                    retryHandler.post(() -> {
                        if (generation != retryGeneration) return;
                        extractorRefreshInFlight = false;
                        pendingNetworkRecovery = true;
                        startupRecoveryAttempted = false;
                        markRecovery("waiting-network", "Could not refresh provider stream yet: " + safe(resolveError));
                        broadcast("buffering", "Playback process recovered. Waiting to refresh the stream…");
                    });
                }
            }, "SidePlayPlaybackResurrection").start();
            return;
        }

        try {
            restoreIntoPlayer(state, true);
            markRecovery("restored-direct", "Recovered current track directly from the persisted checkpoint.");
            broadcast("buffering", "Playback process recovered. Restoring your track…");
            checkpointHandler.removeCallbacks(checkpointRunnable);
            checkpointHandler.postDelayed(checkpointRunnable, RECOVERY_HEARTBEAT_MS);
        } catch (Throwable restoreError) {
            pendingNetworkRecovery = true;
            startupRecoveryAttempted = false;
            markRecovery("waiting-network", "Direct restore failed: " + safe(restoreError));
            broadcast("error", "Playback process recovered, but the saved stream is not ready yet.");
        }
    }

    private MediaItem buildMediaItem(String url, String title, String artist, String artwork, String mimeType) {
        MediaMetadata.Builder meta = new MediaMetadata.Builder()
            .setTitle(title == null || title.isBlank() ? "SidePlay" : title)
            .setArtist(artist == null ? "" : artist);
        if (artwork != null && !artwork.isBlank()) {
            try { meta.setArtworkUri(Uri.parse(artwork)); } catch (Exception ignored) {}
        }

        MediaItem.Builder itemBuilder = new MediaItem.Builder()
            .setUri(Uri.parse(url))
            .setMediaMetadata(meta.build());
        if (mimeType != null && !mimeType.isBlank()) itemBuilder.setMimeType(mimeType);
        return itemBuilder.build();
    }

    private void restoreIntoPlayerSmart(ResumeState state, boolean play) {
        // R4 SAFE PLAY: restoration is intentionally lightweight. If an ephemeral
        // provider URL has expired, the UI will resolve a fresh URL on the next tap.
        restoreIntoPlayer(state, play);
    }

    private void refreshExtractorCurrent(String message) {
        if (extractorRefreshInFlight || !isExtractorRefreshMode(currentRefreshMode) || !isSafeDurableSource(currentSourceUrl)) return;
        extractorRefreshInFlight = true;
        extractorRefreshCount++;
        final long position = getPositionMs();
        final MediaItem current = player == null ? null : player.getCurrentMediaItem();
        final String title = current == null || current.mediaMetadata.title == null ? "SidePlay" : current.mediaMetadata.title.toString();
        final String artist = current == null || current.mediaMetadata.artist == null ? "" : current.mediaMetadata.artist.toString();
        final String artwork = current == null || current.mediaMetadata.artworkUri == null ? "" : current.mediaMetadata.artworkUri.toString();
        final String source = currentSourceUrl;
        broadcast("buffering", message);

        new Thread(() -> {
            try {
                FreshExtractor fresh = resolveFreshExtractor(source, currentAudioPreferred);
                retryHandler.post(() -> {
                    try {
                        currentOriginalUri = Uri.parse(fresh.url);
                        currentHeaders = fresh.headers;
                        retryCount = 0;
                        pendingNetworkRecovery = false;
                        MediaItem item = buildMediaItem(fresh.url, title, artist, artwork, fresh.mimeType);
                        player.setMediaItem(item);
                        if (position > 0L) player.seekTo(position);
                        persistSnapshot(fresh.url, title, artist, artwork, fresh.mimeType, fresh.headers,
                            source, "extractor", position, currentResumable, wantPlay);
                        player.prepare();
                        if (wantPlay) player.play();
                    } catch (Exception e) {
                        pendingNetworkRecovery = wantPlay;
                        broadcast("error", "Provider stream refresh failed: " + safe(e));
                    } finally {
                        extractorRefreshInFlight = false;
                    }
                });
            } catch (Throwable e) {
                retryHandler.post(() -> {
                    extractorRefreshInFlight = false;
                    pendingNetworkRecovery = wantPlay;
                    broadcast("error", "Provider stream refresh failed: " + safe(e));
                });
            }
        }, "SidePlayRefreshExtractor").start();
    }

    private FreshExtractor resolveFreshExtractor(String sourceUrl, boolean audioOnly) throws Exception {
        JSONObject resolved = null;
        String youtubeId = youtubeIdFrom(sourceUrl);
        Exception newPipeFailure = null;
        Exception innerTubeFailure = null;

        if (!youtubeId.isBlank()) {
            try {
                resolved = NewPipeYouTubeResolver.resolve(sourceUrl, youtubeId, audioOnly);
            } catch (Exception e) {
                newPipeFailure = e;
            }
            if (resolved == null) {
                try {
                    resolved = new JSONObject(NativeYouTubePlugin.resolveSafeForPlayback(youtubeId, sourceUrl, audioOnly).toString());
                } catch (Exception e) {
                    innerTubeFailure = e;
                }
            }
        }

        if (resolved == null) {
            try {
                String json = YtDlpIsolatedClient.resolveBlocking(getApplicationContext(), sourceUrl, audioOnly, 24_000L);
                resolved = new JSONObject(json);
            } catch (Exception ytdlpFailure) {
                StringBuilder failures = new StringBuilder();
                if (newPipeFailure != null) failures.append("NewPipe: ").append(safe(newPipeFailure));
                if (innerTubeFailure != null) {
                    if (failures.length() > 0) failures.append(" | ");
                    failures.append("InnerTube SAFE: ").append(safe(innerTubeFailure));
                }
                if (failures.length() > 0) failures.append(" | ");
                failures.append("isolated yt-dlp: ").append(safe(ytdlpFailure));
                throw new Exception(failures.toString(), ytdlpFailure);
            }
        }

        String url = resolved.optString("playbackUrl", "");
        if (url.isBlank()) throw new Exception("Resolver ladder returned no playable URL.");
        String mime = resolved.optString("mimeType", "");
        JSONObject rawHeaders = resolved.optJSONObject("requestHeaders");
        Map<String, String> headers = rawHeaders == null ? Collections.emptyMap() : parseHeaders(rawHeaders.toString());
        return new FreshExtractor(url, mime, headers);
    }

    private static boolean isExtractorRefreshMode(String mode) {
        return "extractor".equals(mode) || "youtube-native".equals(mode);
    }

    private static String youtubeIdFrom(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        if (value.matches("[A-Za-z0-9_-]{11}")) return value;
        try {
            URI uri = URI.create(value);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            String path = uri.getPath() == null ? "" : uri.getPath();
            if (host.equals("youtu.be") || host.endsWith(".youtu.be")) {
                String id = path.replaceFirst("^/", "").split("/", 2)[0];
                return id.matches("[A-Za-z0-9_-]{11}") ? id : "";
            }
            if (host.contains("youtube.com")) {
                if (path.startsWith("/shorts/") || path.startsWith("/embed/") || path.startsWith("/live/")) {
                    String[] parts = path.split("/");
                    if (parts.length > 2 && parts[2].matches("[A-Za-z0-9_-]{11}")) return parts[2];
                }
                String query = uri.getRawQuery();
                if (query != null) {
                    for (String part : query.split("&")) {
                        int eq = part.indexOf('=');
                        if (eq <= 0 || !"v".equals(part.substring(0, eq))) continue;
                        String id = URLDecoder.decode(part.substring(eq + 1), java.nio.charset.StandardCharsets.UTF_8);
                        if (id.matches("[A-Za-z0-9_-]{11}")) return id;
                    }
                }
            }
        } catch (Exception ignored) {}
        return "";
    }

    private void applyFreshExtractorState(FreshExtractor fresh, ResumeState state) {
        currentOriginalUri = Uri.parse(fresh.url);
        currentHeaders = fresh.headers;
        currentSourceUrl = state.sourceUrl == null ? "" : state.sourceUrl;
        currentRefreshMode = "extractor";
        currentAudioPreferred = state.audioPreferred;
        currentResumable = true;
    }

    private static final class FreshExtractor {
        final String url;
        final String mimeType;
        final Map<String, String> headers;
        FreshExtractor(String url, String mimeType, Map<String, String> headers) {
            this.url = url;
            this.mimeType = mimeType == null ? "" : mimeType;
            this.headers = headers == null ? Collections.emptyMap() : headers;
        }
    }

    private void restoreIntoPlayer(ResumeState state, boolean play) {
        applyResumeNetworkState(state);
        currentResumable = true;
        wantPlay = play;
        MediaItem item = buildMediaItem(state.url, state.title, state.artist, state.artwork, state.mimeType);
        player.setMediaItem(item);
        if (state.positionMs > 0L) player.seekTo(state.positionMs);
        player.prepare();
        if (play) player.play();
    }

    private void applyResumeNetworkState(ResumeState state) {
        currentOriginalUri = Uri.parse(state.url);
        currentHeaders = parseHeaders(state.headersJson);
        currentSourceUrl = state.sourceUrl == null ? "" : state.sourceUrl;
        currentRefreshMode = state.refreshMode == null ? "" : state.refreshMode;
        currentAudioPreferred = state.audioPreferred;
        currentResumable = true;
    }

    private void registerNetworkRecovery() {
        try {
            connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager == null) return;
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    retryHandler.post(() -> {
                        if (!pendingNetworkRecovery || !wantPlay || player == null) return;
                        try {
                            retryCount = 0;
                            pendingNetworkRecovery = false;
                            if (player.getMediaItemCount() == 0) {
                                ResumeState state = readResumeState();
                                if (state != null && state.wantPlay) {
                                    startupRecoveryAttempted = true;
                                    recoverSnapshot(state, "network-restored");
                                }
                                return;
                            }
                            retryGeneration++;
                            if (isExtractorRefreshMode(currentRefreshMode) && isSafeDurableSource(currentSourceUrl)) {
                                extractorRefreshCount = 0;
                                refreshExtractorCurrent("Network restored. Refreshing source…");
                            } else {
                                player.prepare();
                                player.play();
                                broadcast("buffering", "Network restored. Reconnecting…");
                            }
                        } catch (Exception e) {
                            pendingNetworkRecovery = true;
                        }
                    });
                }
            };
            connectivityManager.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception ignored) {}
    }

    private void persistCurrent() {
        if (resumePrefs == null || player == null || player.getMediaItemCount() == 0 || !currentResumable) return;
        MediaItem item = player.getCurrentMediaItem();
        if (item == null || item.localConfiguration == null || item.localConfiguration.uri == null) return;
        MediaMetadata meta = item.mediaMetadata;
        String artwork = meta.artworkUri == null ? "" : meta.artworkUri.toString();
        String mime = item.localConfiguration.mimeType == null ? "" : item.localConfiguration.mimeType;
        persistSnapshot(
            item.localConfiguration.uri.toString(),
            meta.title == null ? "SidePlay" : meta.title.toString(),
            meta.artist == null ? "" : meta.artist.toString(),
            artwork,
            mime,
            currentHeaders,
            currentSourceUrl,
            currentRefreshMode,
            getPositionMs(),
            true,
            wantPlay
        );
    }

    private void persistSnapshot(
        String url,
        String title,
        String artist,
        String artwork,
        String mimeType,
        Map<String, String> headers,
        String sourceUrl,
        String refreshMode,
        long positionMs,
        boolean resumable,
        boolean shouldPlay
    ) {
        if (resumePrefs == null || !resumable || url == null || url.isBlank()) {
            if (!resumable) clearResumeState();
            return;
        }
        Map<String, String> safeHeaders = stripSensitiveHeaders(headers);
        resumePrefs.edit()
            .putString(K_URL, url)
            .putString(K_TITLE, title == null ? "SidePlay" : title)
            .putString(K_ARTIST, artist == null ? "" : artist)
            .putString(K_ARTWORK, artwork == null ? "" : artwork)
            .putString(K_MIME, mimeType == null ? "" : mimeType)
            .putString(K_HEADERS, toJson(safeHeaders))
            .putString(K_SOURCE_URL, sourceUrl == null ? "" : sourceUrl)
            .putString(K_REFRESH_MODE, refreshMode == null ? "" : refreshMode)
            .putLong(K_POSITION, Math.max(0L, positionMs))
            .putBoolean(K_RESUMABLE, true)
            .putBoolean(K_WANT_PLAY, shouldPlay)
            .putBoolean(K_AUDIO_PREFERRED, currentAudioPreferred)
            .putLong(K_UPDATED, System.currentTimeMillis())
            .apply();
    }

    private @Nullable ResumeState readResumeState() {
        if (resumePrefs == null || !resumePrefs.getBoolean(K_RESUMABLE, false)) return null;
        String url = resumePrefs.getString(K_URL, "");
        if (url == null || url.isBlank()) return null;
        ResumeState out = new ResumeState();
        out.url = url;
        out.title = resumePrefs.getString(K_TITLE, "SidePlay");
        out.artist = resumePrefs.getString(K_ARTIST, "");
        out.artwork = resumePrefs.getString(K_ARTWORK, "");
        out.mimeType = resumePrefs.getString(K_MIME, "");
        out.headersJson = resumePrefs.getString(K_HEADERS, "{}");
        out.sourceUrl = resumePrefs.getString(K_SOURCE_URL, "");
        out.refreshMode = resumePrefs.getString(K_REFRESH_MODE, "");
        out.positionMs = Math.max(0L, resumePrefs.getLong(K_POSITION, 0L));
        out.wantPlay = resumePrefs.getBoolean(K_WANT_PLAY, false);
        out.audioPreferred = resumePrefs.getBoolean(K_AUDIO_PREFERRED, out.mimeType != null && out.mimeType.startsWith("audio/"));
        out.updatedAt = resumePrefs.getLong(K_UPDATED, 0L);
        return out;
    }

    private void clearResumeState() {
        if (resumePrefs != null) resumePrefs.edit().clear().apply();
    }

    private static class ResumeState {
        String url;
        String title;
        String artist;
        String artwork;
        String mimeType;
        String headersJson;
        String sourceUrl;
        String refreshMode;
        long positionMs;
        boolean wantPlay;
        boolean audioPreferred;
        long updatedAt;
    }

    private static boolean isSafeDurableSource(@Nullable String raw) {
        if (raw == null || raw.isBlank()) return false;
        try {
            URI uri = URI.create(raw);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            if (!(scheme.equals("http") || scheme.equals("https")) || uri.getHost() == null || uri.getHost().isBlank()) return false;
            if (uri.getUserInfo() != null && !uri.getUserInfo().isBlank()) return false;
            String query = uri.getRawQuery();
            if (query == null || query.isBlank()) return true;
            for (String part : query.split("&")) {
                String rawKey = part.contains("=") ? part.substring(0, part.indexOf('=')) : part;
                String key;
                try { key = URLDecoder.decode(rawKey, "UTF-8").toLowerCase(Locale.ROOT); }
                catch (Exception ignored) { key = rawKey.toLowerCase(Locale.ROOT); }
                // Common public navigation parameters are safe to persist. Anything
                // resembling an auth/signed-CDN credential remains ephemeral.
                if (key.equals("v") || key.equals("list") || key.equals("index") || key.equals("t") || key.equals("start") || key.equals("si")) continue;
                if (key.contains("token") || key.contains("auth") || key.contains("signature") || key.equals("sig") ||
                    key.contains("credential") || key.contains("session") || key.contains("jwt") || key.contains("policy") ||
                    key.equals("key") || key.contains("expires")) return false;
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static Map<String, String> parseHeaders(@Nullable String raw) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (raw == null || raw.isBlank()) return out;
        try {
            JSONObject json = new JSONObject(raw);
            Iterator<String> keys = json.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                String value = json.optString(key, "");
                if (key == null || key.isBlank() || value.isBlank()) continue;
                String lower = key.toLowerCase(Locale.ROOT);
                if (lower.equals("host") || lower.equals("content-length") || lower.equals("connection") || lower.equals("accept-encoding") || lower.equals("range") || lower.startsWith("sec-")) continue;
                out.put(key, value);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static boolean containsSensitiveHeaders(Map<String, String> headers) {
        for (String key : headers.keySet()) if (isSensitiveHeader(key)) return true;
        return false;
    }

    private static Map<String, String> stripSensitiveHeaders(Map<String, String> headers) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (headers == null) return out;
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            if (entry.getKey() == null || entry.getValue() == null || entry.getValue().isBlank()) continue;
            if (isSensitiveHeader(entry.getKey())) continue;
            out.put(entry.getKey(), entry.getValue());
        }
        return out;
    }

    private static String toJson(Map<String, String> headers) {
        JSONObject json = new JSONObject();
        if (headers != null) {
            for (Map.Entry<String, String> e : headers.entrySet()) {
                try { json.put(e.getKey(), e.getValue()); } catch (Exception ignored) {}
            }
        }
        return json.toString();
    }

    private static Map<String, String> headersForUri(Map<String, String> captured, Uri original, Uri target) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (captured == null) return out;
        String originalHost = original == null || original.getHost() == null ? "" : original.getHost();
        String targetHost = target == null || target.getHost() == null ? "" : target.getHost();
        boolean sameHost = !originalHost.isBlank() && originalHost.equalsIgnoreCase(targetHost);
        for (Map.Entry<String, String> entry : captured.entrySet()) {
            String key = entry.getKey();
            if (key == null || entry.getValue() == null || entry.getValue().isBlank()) continue;
            if (!sameHost && isSensitiveHeader(key)) continue;
            out.put(key, entry.getValue());
        }
        return out;
    }

    private static boolean isSensitiveHeader(String key) {
        String lower = key == null ? "" : key.toLowerCase(Locale.ROOT);
        return lower.equals("cookie") || lower.equals("authorization") || lower.equals("proxy-authorization") ||
            lower.equals("x-csrf-token") || lower.equals("x-xsrf-token");
    }

    @Override
    public void onTaskRemoved(@Nullable Intent rootIntent) {
        // Let MediaSessionService apply its documented default: keep the service when
        // playback is ongoing, stop it otherwise. We only checkpoint first.
        try { persistCurrent(); } catch (Throwable ignored) {}
        super.onTaskRemoved(rootIntent);
    }

    public void seekTo(long positionMs) {
        if (player == null) return;
        long duration = normalizedDuration();
        long target = Math.max(0L, positionMs);
        if (duration > 0L) target = Math.min(target, duration);
        player.seekTo(target);
        persistCurrent();
    }

    public long getPositionMs() {
        return player == null ? 0L : Math.max(0L, player.getCurrentPosition());
    }

    public long getDurationMs() {
        return normalizedDuration();
    }

    public boolean isPlayingNow() {
        return player != null && player.isPlaying();
    }

    public int getPlaybackStateValue() {
        return player == null ? Player.STATE_IDLE : player.getPlaybackState();
    }

    private long normalizedDuration() {
        if (player == null) return 0L;
        long duration = player.getDuration();
        return duration == C.TIME_UNSET || duration < 0L ? 0L : duration;
    }

    private void broadcast(String state, @Nullable String message) {
        Intent event = new Intent(ACTION_EVENT);
        event.setPackage(getPackageName());
        event.putExtra("state", state);
        event.putExtra("positionMs", getPositionMs());
        event.putExtra("durationMs", getDurationMs());
        event.putExtra("playbackState", getPlaybackStateValue());
        if (message != null && !message.isBlank()) event.putExtra("message", message);
        sendBroadcast(event);
    }

    private void touchHeartbeat() {
        try {
            if (diagnosticsPrefs == null) diagnosticsPrefs = getSharedPreferences("sideplay-native-playback-diagnostics", Context.MODE_PRIVATE);
            diagnosticsPrefs.edit().putLong("heartbeatAt", System.currentTimeMillis()).apply();
        } catch (Throwable ignored) {}
    }

    private void bumpRecoveryAttempt() {
        try {
            if (diagnosticsPrefs == null) diagnosticsPrefs = getSharedPreferences("sideplay-native-playback-diagnostics", Context.MODE_PRIVATE);
            int attempts = diagnosticsPrefs.getInt("recoveryAttempts", 0);
            diagnosticsPrefs.edit().putInt("recoveryAttempts", Math.min(9999, attempts + 1)).apply();
        } catch (Throwable ignored) {}
    }

    private void markRecovery(String state, String message) {
        try {
            if (diagnosticsPrefs == null) diagnosticsPrefs = getSharedPreferences("sideplay-native-playback-diagnostics", Context.MODE_PRIVATE);
            diagnosticsPrefs.edit()
                .putString("recovery", state == null ? "" : state)
                .putString("recoveryMessage", message == null ? "" : message)
                .putLong("recoveryAt", System.currentTimeMillis())
                .commit();
        } catch (Throwable ignored) {}
    }

    private void markStage(String stage, String message) {
        try {
            if (diagnosticsPrefs == null) diagnosticsPrefs = getSharedPreferences("sideplay-native-playback-diagnostics", Context.MODE_PRIVATE);
            diagnosticsPrefs.edit()
                .putString("stage", stage == null ? "" : stage)
                .putString("message", message == null ? "" : message)
                .putLong("timestamp", System.currentTimeMillis())
                .putLong("heartbeatAt", System.currentTimeMillis())
                .commit();
        } catch (Throwable ignored) {}
    }

    private void failStartup(String stage, Throwable t) {
        startupHealthy = false;
        startupFailure = "Native playback startup failed at " + stage + ": " + safe(t);
        markStage(stage, startupFailure);
        try { broadcast("error", startupFailure); } catch (Throwable ignored) {}
        try { if (mediaSession != null) mediaSession.release(); } catch (Throwable ignored) {}
        mediaSession = null;
        try { if (player != null) player.release(); } catch (Throwable ignored) {}
        player = null;
    }

    private static String safeMime(String value) {
        return value == null || value.isBlank() ? "auto" : value;
    }

    @Nullable
    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    @Override
    public void onDestroy() {
        markStage("service-destroy", startupFailure.isBlank() ? "Service destroyed" : startupFailure);
        try { broadcast("service-destroyed", startupFailure.isBlank() ? null : startupFailure); } catch (Throwable ignored) {}
        persistCurrent();
        try { if (diagnosticsPrefs != null) diagnosticsPrefs.edit().putLong("heartbeatAt", 0L).apply(); } catch (Throwable ignored) {}
        instance = null;
        retryGeneration++;
        retryHandler.removeCallbacksAndMessages(null);
        checkpointHandler.removeCallbacksAndMessages(null);
        try {
            if (connectivityManager != null && networkCallback != null) connectivityManager.unregisterNetworkCallback(networkCallback);
        } catch (Exception ignored) {}
        if (mediaSession != null) mediaSession.release();
        if (player != null) player.release();
        super.onDestroy();
    }

    private static String safe(Throwable t) {
        if (t == null) return "unknown error";
        String message = t.getMessage();
        return message == null || message.isBlank() ? t.getClass().getSimpleName() : message;
    }
}
