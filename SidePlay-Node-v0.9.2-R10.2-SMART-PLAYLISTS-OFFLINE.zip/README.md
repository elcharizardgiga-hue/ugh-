# SidePlay 0.8.4-r9

R9 is the **Intelligence + UX** release. It keeps R8's boringly reliable playback/queue core, then makes SidePlay learn from listening behavior, understand duplicate song uploads, offer tunable Radio, autocomplete Search and show on-demand lyrics when YouTube Music exposes them.

Android identity: `app.sideplay.mobile` · `versionName 0.8.4-r9` · `versionCode 816`.

## Headline features

- **Taste Engine v1:** weighted plays, completions, skips, likes, queue adds and playlist adds with long-term + session decay.
- **Session-aware Radio:** tonight's rabbit hole can steer Autoplay without permanently rewriting long-term taste.
- **Tune Radio:** Stay here, Go deeper, Surprise me, Energy, Chill, Balanced, plus Discovery and Variety controls.
- **Canonical track identity:** duplicate lyric/official/reupload results collapse while meaningful live/remix/acoustic variants stay separate.
- **Smarter search:** intent ranking, noisy-variant penalties and official/Topic preference.
- **Autocomplete:** local history + real YouTube query suggestions, keyboard navigation and device/browser locale awareness.
- **Lyrics:** on-demand, locally cached YouTube Music lyrics when available; lyrics failures never affect playback.
- **Explainable recommendations:** SidePlay keeps showing why a candidate belongs in the current rotation.
- **Queue clarity:** user choices remain ahead of Autoplay and are visually separated from SidePlay recommendations.

## Recommendation architecture

1. Current video/song seeds YouTube's native watch-next graph on Android.
2. Search expands the pool only when the native related feed is unavailable or thin.
3. Canonical identity removes duplicate uploads and unwanted noisy variants.
4. The local Taste Engine scores long-term affinity and the current listening session separately.
5. Tune Radio adjusts exploration, coherence and artist diversity.
6. Recent queue/history and strong skips are filtered or penalized before Autoplay is committed.

Taste data stays local in SidePlay state; the R9 engine is deliberately explainable rather than an opaque remote profile.

## Lyrics behavior

Lyrics are fetched only when the Lyrics panel is opened. R9 uses YouTube Music metadata on Android and caches successful text locally. Availability varies by track. R9 does **not** claim synchronized timestamps yet.

## Playback architecture

- Main process: Capacitor/React UI.
- `:playback`: Media3 ExoPlayer + MediaSessionService.
- `:extractor`: isolated yt-dlp/Python/QuickJS fallback.
- Resolver ladder: NewPipe → InnerTube SAFE → isolated yt-dlp for real Play.
- Lightweight Zero-Wait prefetch remains isolated from full Play work.
- R8 playback atomicity and live-queue preservation remain in force.

## Build

First clean build:

`BUILD_SIDEPLAY_APK_CLEAN.bat`

Repeat build:

`BUILD_SIDEPLAY_APK.bat`

Dedicated R9 builder:

`BUILD_SIDEPLAY_V084_R9_INTELLIGENCE_UX.bat`

Dependencies use exact versions. TypeScript is pinned to `5.8.3`.

## Release notes

See `CHANGELOG_V0.8.4_R9_INTELLIGENCE_UX.md`.

## 0.8.4-r9 Hotfix3 — Cohesion Repair

Hotfix3 focuses on fixing shared identity/state bugs instead of adding more surface area. It prevents placeholder resolver metadata from contaminating Queue, History and Taste; fixes sticky autocomplete and stale search races; teaches Taste from manual track changes; restores mobile Now Playing scrolling; and upgrades Lyrics with synced LRCLIB lookup plus YouTube Music fallback and retry states. Playback Resurrection from Hotfix2 remains included.
