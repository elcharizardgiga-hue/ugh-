@echo off
echo Removing generated Android shell for a genuinely clean v0.8.4-r9 Hotfix3 build...
if exist "%~dp0android" rmdir /s /q "%~dp0android"
call "%~dp0BUILD_SIDEPLAY_V084_R9_HOTFIX3_COHESION_REPAIR.bat"
