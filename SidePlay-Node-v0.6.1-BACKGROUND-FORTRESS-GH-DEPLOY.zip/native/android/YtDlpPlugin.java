package app.sideplay.mobile;

import android.net.Uri;
import android.webkit.MimeTypeMap;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.yausername.ffmpeg.FFmpeg;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import kotlin.Unit;
import kotlin.jvm.functions.Function3;

/**
 * Broad public-media extraction/download layer backed by yt-dlp.
 *
 * This deliberately does not enable DRM/decryption bypasses. yt-dlp is asked for
 * clear playable/downloadable formats only. SidePlay's MediaSafety gate still
 * validates completed files before they are admitted to the persistent vault.
 */
@CapacitorPlugin(name = "YtDlp")
public class YtDlpPlugin extends Plugin {
    private static final Object INIT_LOCK = new Object();
    private static volatile boolean initialized = false;

    @PluginMethod
    public void resolve(PluginCall call) {
        String raw = call.getString("url");
        if (raw == null || raw.isBlank() || !(raw.startsWith("https://") || raw.startsWith("http://"))) {
            call.reject("A public http(s) media page URL is required.");
            return;
        }
        final String source = raw.trim();
        new Thread(() -> {
            try {
                ensureInitialized();
                JSObject out = resolveInternal(source);
                call.resolve(out);
            } catch (Throwable e) {
                call.reject("Provider extractor could not resolve this page: " + safe(e));
            }
        }, "SidePlayYtDlpResolve").start();
    }

    @PluginMethod
    public void download(PluginCall call) {
        String raw = call.getString("url");
        String videoId = call.getString("videoId");
        String title = call.getString("title");
        String mediaKind = call.getString("mediaKind");
        if (raw == null || raw.isBlank() || !(raw.startsWith("https://") || raw.startsWith("http://"))) {
            call.reject("A public http(s) source URL is required.");
            return;
        }
        final String source = raw.trim();
        final String id = videoId == null || videoId.isBlank() ? stableId(source) : videoId;
        final String wantedTitle = title == null || title.isBlank() ? "SidePlay media" : title;
        final boolean audioOnly = "audio".equalsIgnoreCase(mediaKind);

        new Thread(() -> {
            File work = null;
            try {
                ensureInitialized();
                work = new File(getContext().getCacheDir(), "ytdlp-" + System.currentTimeMillis() + "-" + Math.abs(id.hashCode()));
                if (!work.mkdirs()) throw new Exception("Could not create temporary extractor storage.");
                File out = downloadInternal(source, id, work, audioOnly);
                JSObject result = admitDownloadedFile(out, id, wantedTitle, source);
                emitProgress(id, 100f, "Complete");
                call.resolve(result);
            } catch (Throwable e) {
                call.reject("Provider download failed: " + safe(e));
            } finally {
                if (work != null) deleteTree(work);
            }
        }, "SidePlayYtDlpDownload").start();
    }

    private void ensureInitialized() throws Exception {
        if (initialized) return;
        synchronized (INIT_LOCK) {
            if (initialized) return;
            YoutubeDL.getInstance().init(getContext());
            FFmpeg.getInstance().init(getContext());
            initialized = true;
            maybeUpdateExtractor();
        }
    }

    private void maybeUpdateExtractor() {
        try {
            long now = System.currentTimeMillis();
            long last = getContext().getSharedPreferences("sideplay-ytdlp", 0).getLong("lastUpdate", 0L);
            if (now - last < 24L * 60L * 60L * 1000L) return;
            Class<?> channelClass = Class.forName("com.yausername.youtubedl_android.YoutubeDL$UpdateChannel");
            @SuppressWarnings({"rawtypes", "unchecked"})
            Object nightly = Enum.valueOf((Class<? extends Enum>) channelClass.asSubclass(Enum.class), "NIGHTLY");
            Method target = null;
            for (Method m : YoutubeDL.class.getMethods()) {
                if (m.getName().equals("updateYoutubeDL") && m.getParameterCount() == 2) { target = m; break; }
            }
            if (target == null) return;
            target.invoke(YoutubeDL.getInstance(), getContext(), nightly);
            getContext().getSharedPreferences("sideplay-ytdlp", 0).edit().putLong("lastUpdate", now).apply();
        } catch (Throwable ignored) {
            // Keep the bundled extractor usable when offline or when update servers fail.
        }
    }

    private JSObject resolveInternal(String source) throws Exception {
        YoutubeDLRequest request = baseRequest(source);
        // Prefer a single URL containing both audio and video so Media3 can play it
        // immediately. If only adaptive/live media exists, yt-dlp may return HLS/DASH.
        request.addOption("-f", "best[acodec!=none][vcodec!=none]/bestaudio/best");
        Object info = YoutubeDL.getInstance().getInfo(request);
        String playback = str(info, "getUrl");
        if (playback.isBlank()) throw new Exception("Extractor returned metadata but no clear playable URL.");

        String title = firstNonBlank(str(info, "getTitle"), filenameFrom(playback), "Media");
        String artist = firstNonBlank(str(info, "getUploader"), str(info, "getChannel"), str(info, "getArtist"), host(source));
        String thumb = firstNonBlank(str(info, "getThumbnail"), str(info, "getThumbnailUrl"));
        long durationMs = durationMs(info);
        String provider = providerFor(source);
        String mime = inferMime(playback);
        String kind = inferKind(playback, mime, info);

        JSObject out = new JSObject();
        out.put("id", firstNonBlank(str(info, "getId"), stableId(source)));
        out.put("title", title);
        out.put("artist", artist);
        if (!thumb.isBlank()) out.put("thumbnail", thumb);
        out.put("provider", provider);
        out.put("sourceUrl", source);
        out.put("playbackUrl", playback);
        if (!mime.isBlank()) out.put("mimeType", mime);
        out.put("mediaKind", kind);
        if (durationMs > 0) out.put("durationMs", durationMs);
        JSObject headers = headers(info);
        if (headers.length() > 0) out.put("requestHeaders", headers);
        out.put("playable", true);
        out.put("downloadable", true);
        out.put("downloadEngine", "ytdlp");
        out.put("refreshMode", "extractor");
        out.put("sessionBound", true);
        out.put("note", "Resolved with SidePlay provider extractor. Clear media only; protected DRM streams are not bypassed.");
        return out;
    }

    private File downloadInternal(String source, String videoId, File work, boolean audioOnly) throws Exception {
        YoutubeDLRequest request = baseRequest(source);
        request.addOption("--no-mtime");
        request.addOption("--restrict-filenames");
        request.addOption("--max-filesize", "4096M");
        request.addOption("-o", new File(work, "%(title).120B-%(id)s.%(ext)s").getAbsolutePath());
        if (audioOnly) {
            request.addOption("-f", "bestaudio/best");
            request.addOption("-x");
            request.addOption("--audio-format", "m4a");
        } else {
            request.addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best");
            request.addOption("--merge-output-format", "mp4");
        }

        String processId = "sideplay-" + videoId + "-" + System.nanoTime();
        Function3<Float, Long, String, Unit> callback = new Function3<Float, Long, String, Unit>() {
            @Override public Unit invoke(Float progress, Long eta, String line) {
                emitProgress(videoId, progress == null ? -1f : progress, line == null ? "" : line);
                return Unit.INSTANCE;
            }
        };
        try {
            YoutubeDL.getInstance().execute(request, processId, callback);
        } catch (Throwable first) {
            if (audioOnly) throw first;
            // Some providers expose codecs that cannot be cleanly remuxed to MP4.
            // Retry once with Matroska, which is deliberately supported by SidePlay.
            deleteChildren(work);
            YoutubeDLRequest fallback = baseRequest(source);
            fallback.addOption("--no-mtime");
            fallback.addOption("--restrict-filenames");
            fallback.addOption("--max-filesize", "4096M");
            fallback.addOption("-o", new File(work, "%(title).120B-%(id)s.%(ext)s").getAbsolutePath());
            fallback.addOption("-f", "bestvideo+bestaudio/best");
            fallback.addOption("--merge-output-format", "mkv");
            YoutubeDL.getInstance().execute(fallback, processId + "-mkv", callback);
        }

        File chosen = null;
        File[] files = work.listFiles();
        if (files != null) {
            for (File f : files) {
                if (!f.isFile()) continue;
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (n.endsWith(".part") || n.endsWith(".ytdl") || n.endsWith(".json") || n.endsWith(".temp")) continue;
                if (chosen == null || f.length() > chosen.length()) chosen = f;
            }
        }
        if (chosen == null || !chosen.exists() || chosen.length() <= 0) throw new Exception("Extractor completed without a media file.");
        if (chosen.length() > MediaSafety.MAX_OFFLINE_BYTES) throw new Exception("Media exceeds SidePlay's 4 GiB offline safety limit.");
        return chosen;
    }

    private YoutubeDLRequest baseRequest(String source) {
        YoutubeDLRequest request = new YoutubeDLRequest(source);
        request.addOption("--no-playlist");
        request.addOption("--no-warnings");
        request.addOption("--force-ipv4");
        request.addOption("--socket-timeout", "25");
        request.addOption("--retries", "5");
        request.addOption("--fragment-retries", "5");
        request.addOption("--extractor-retries", "3");
        return request;
    }

    private JSObject admitDownloadedFile(File input, String videoId, String title, String source) throws Exception {
        String filename = sanitizeFilename(input.getName());
        String mime = mimeForName(filename);
        MediaSafety.validateMetadata(source, filename, mime, filename);
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(input))) {
            byte[] prefix = new byte[8192];
            int n = in.read(prefix);
            MediaSafety.validatePrefix(prefix, n, mime, filename);
        }

        File vault = new File(getContext().getFilesDir(), "offline");
        if (!vault.exists() && !vault.mkdirs()) throw new Exception("Could not create SidePlay offline storage.");
        if (vault.getUsableSpace() < input.length() + MediaSafety.STORAGE_RESERVE_BYTES) throw new Exception("Not enough free storage to save this media safely.");

        String ext = extensionWithDot(filename);
        File dest = new File(vault, sanitizeFilename(videoId) + "-" + System.currentTimeMillis() + ext);
        copyFile(input, dest);
        try {
            try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(dest))) {
                byte[] prefix = new byte[8192];
                int n = in.read(prefix);
                MediaSafety.validatePrefix(prefix, n, mime, filename);
            }
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            dest.delete();
            throw e;
        }

        JSObject out = new JSObject();
        out.put("localUri", Uri.fromFile(dest).toString());
        out.put("filename", filename.isBlank() ? sanitizeFilename(title) + ext : filename);
        out.put("mimeType", mime);
        out.put("bytes", dest.length());
        out.put("provider", providerFor(source));
        out.put("sourceUrl", source);
        out.put("mediaKind", mime.startsWith("video/") ? "video" : "audio");
        return out;
    }

    private void emitProgress(String videoId, float progress, String line) {
        JSObject event = new JSObject();
        event.put("videoId", videoId);
        event.put("progress", progress >= 0 ? Math.min(1d, progress / 100d) : -1d);
        event.put("line", line);
        notifyListeners("downloadProgress", event, true);
    }

    private static JSObject headers(Object info) {
        JSObject out = new JSObject();
        Object value = invoke(info, "getHttpHeaders", "getHttp_headers");
        if (value instanceof Map<?, ?>) {
            for (Map.Entry<?, ?> e : ((Map<?, ?>) value).entrySet()) {
                if (e.getKey() != null && e.getValue() != null) out.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
            }
        }
        return out;
    }

    private static long durationMs(Object info) {
        Object value = invoke(info, "getDuration");
        if (value instanceof Number) return Math.max(0L, Math.round(((Number) value).doubleValue() * 1000d));
        try { return Math.max(0L, Math.round(Double.parseDouble(String.valueOf(value)) * 1000d)); } catch (Exception ignored) { return 0L; }
    }

    private static String inferKind(String url, String mime, Object info) {
        String vcodec = str(info, "getVcodec", "getVideoCodec");
        if (!vcodec.isBlank() && !"none".equalsIgnoreCase(vcodec)) return "video";
        String lower = url.toLowerCase(Locale.ROOT);
        if (mime.startsWith("video/") || lower.contains(".mp4") || lower.contains(".webm") || lower.contains(".m3u8") || lower.contains(".mpd")) return "video";
        return "audio";
    }

    private static String inferMime(String url) {
        String lower = url.toLowerCase(Locale.ROOT);
        if (lower.contains(".m3u8")) return "application/x-mpegURL";
        if (lower.contains(".mpd")) return "application/dash+xml";
        return mimeForName(url);
    }

    private static String mimeForName(String name) {
        String clean = name == null ? "" : name.split("[?#]", 2)[0];
        String ext = extension(clean);
        String mime = ext.isBlank() ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.ROOT));
        if (mime != null) return mime;
        switch (ext.toLowerCase(Locale.ROOT)) {
            case "m4a": return "audio/mp4";
            case "opus": return "audio/ogg";
            case "mkv": return "video/x-matroska";
            case "webm": return "video/webm";
            case "ts": case "m2ts": case "mts": return "video/mp2t";
            default: return "application/octet-stream";
        }
    }

    private static String providerFor(String raw) {
        String h = host(raw).toLowerCase(Locale.ROOT);
        if (h.contains("youtube.com") || h.equals("youtu.be") || h.endsWith(".youtu.be")) return "youtube";
        if (h.contains("soundcloud.com")) return "soundcloud";
        if (h.contains("spotify.com")) return "spotify";
        if (h.contains("tiktok.com")) return "unknown";
        return "unknown";
    }

    private static Object invoke(Object target, String... names) {
        if (target == null) return null;
        for (String name : names) {
            try {
                Method m = target.getClass().getMethod(name);
                return m.invoke(target);
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private static String str(Object target, String... names) {
        Object value = invoke(target, names);
        return value == null ? "" : String.valueOf(value).trim();
    }

    private static String firstNonBlank(String... values) {
        for (String v : values) if (v != null && !v.isBlank() && !"null".equalsIgnoreCase(v)) return v;
        return "";
    }

    private static String host(String raw) {
        try { String h = URI.create(raw).getHost(); return h == null ? "" : h; } catch (Exception ignored) { return ""; }
    }

    private static String filenameFrom(String raw) {
        try {
            String p = URI.create(raw).getPath();
            if (p == null || p.isBlank()) return "";
            String n = p.substring(p.lastIndexOf('/') + 1);
            return n.isBlank() ? "" : n;
        } catch (Exception ignored) { return ""; }
    }

    private static String extension(String name) {
        if (name == null) return "";
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        int dot = name.lastIndexOf('.');
        return dot > slash && dot < name.length() - 1 ? name.substring(dot + 1) : "";
    }

    private static String extensionWithDot(String name) {
        String e = extension(name);
        return e.isBlank() ? "" : "." + e;
    }

    private static String sanitizeFilename(String raw) {
        String s = raw == null ? "media" : raw.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (s.isBlank()) s = "media";
        if (s.length() > 160) s = s.substring(0, 160);
        return s;
    }

    private static void copyFile(File from, File to) throws Exception {
        try (FileInputStream in = new FileInputStream(from); FileOutputStream out = new FileOutputStream(to)) {
            byte[] buffer = new byte[256 * 1024];
            int n;
            long total = 0;
            while ((n = in.read(buffer)) != -1) {
                total += n;
                if (total > MediaSafety.MAX_OFFLINE_BYTES) throw new Exception("Media exceeds SidePlay's 4 GiB offline safety limit.");
                out.write(buffer, 0, n);
            }
            out.flush();
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            to.delete();
            throw e;
        }
    }

    private static void deleteChildren(File dir) {
        if (dir == null || !dir.isDirectory()) return;
        File[] children = dir.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteTree(c);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private static String stableId(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder("ydl-");
            for (int i = 0; i < 8 && i < hash.length; i++) sb.append(String.format(Locale.ROOT, "%02x", hash[i]));
            return sb.toString();
        } catch (Exception e) { return "ydl-" + Integer.toUnsignedString(value.hashCode(), 36); }
    }

    private static String safe(Throwable e) {
        String m = e == null ? "unknown error" : e.getMessage();
        if (m == null || m.isBlank()) m = e == null ? "unknown error" : e.getClass().getSimpleName();
        m = m.replaceAll("(?i)(cookie|authorization|token|password)=?[^\\s,;]+", "$1=[redacted]");
        return m.length() > 700 ? m.substring(0, 700) : m;
    }
}
