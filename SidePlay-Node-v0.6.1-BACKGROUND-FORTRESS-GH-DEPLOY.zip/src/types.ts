export type MediaProvider = 'youtube' | 'peertube' | 'audius' | 'direct' | 'soundcloud' | 'spotify' | 'local' | 'unknown'
export type MediaKind = 'audio' | 'video'

export type Track = {
  /** Legacy name kept so old SidePlay libraries remain compatible. For non-YouTube
   * sources this is a stable SidePlay media id, not necessarily a YouTube id. */
  videoId: string
  title: string
  channel: string
  thumbnail: string
  publishedAt?: string

  /** v0.4 universal-source metadata. All fields are optional for backwards compatibility. */
  provider?: MediaProvider
  sourceUrl?: string
  /** Direct/authorized URL that SidePlay's native Media3 engine can play itself. */
  playbackUrl?: string
  /** Direct/authorized progressive file URL SidePlay may save into its private offline vault. */
  downloadUrl?: string
  mediaKind?: MediaKind
  mimeType?: string
  /** Request context captured from the source page when a CDN requires browser headers/cookies. */
  requestHeaders?: Record<string, string>
  /** True when playback URL came from a live browser session and should be re-captured after restart/session loss. */
  sessionBound?: boolean
  capturedAt?: number
  /** How an ephemeral playback URL should be refreshed when it expires. */
  refreshMode?: 'extractor' | 'capture'
  /** Offline engine used when the durable source is a provider page rather than a direct file. */
  downloadEngine?: 'direct' | 'ytdlp'
  durationMs?: number
  /** Exact provider URI when a provider supports an external/session handoff (for example spotify:track:...). */
  providerUri?: string
}

export type Playlist = {
  id: string
  name: string
  tracks: Track[]
  createdAt: number
  updatedAt: number
}

export type HistoryEntry = Track & {
  playedAt: number
}

export type RepeatMode = 'off' | 'all' | 'one'

export type OfflineCopy = {
  videoId: string
  localUri: string
  filename: string
  mimeType?: string
  bytes?: number
  addedAt: number
  platform: 'android' | 'pc'
  title?: string
  channel?: string
  thumbnail?: string
  provider?: MediaProvider
  sourceUrl?: string
  mediaKind?: MediaKind
}

export type SidePlayState = {
  favorites: Track[]
  playlists: Playlist[]
  history: HistoryEntry[]
  queue: Track[]
  currentIndex: number
  repeat: RepeatMode
  shuffle: boolean
  youtubeApiKey: string
  playCounts: Record<string, number>
  offline: Record<string, OfflineCopy>
  preferOffline: boolean
}
