package com.stickerforge.app

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.util.Base64
import com.aureusapps.android.webpandroid.encoder.WebPAnimEncoder
import com.aureusapps.android.webpandroid.encoder.WebPAnimEncoderOptions
import com.aureusapps.android.webpandroid.encoder.WebPConfig
import com.aureusapps.android.webpandroid.encoder.WebPMuxAnimParams
import com.aureusapps.android.webpandroid.encoder.WebPPreset
import java.io.File
import java.io.FileOutputStream

object AnimationEncoder {
    private data class Draft(val packId:String, val dir:File, val durations:MutableList<Int> = mutableListOf())
    private val drafts = mutableMapOf<String,Draft>()

    @JvmStatic @Synchronized fun begin(context: Context, packId:String): String {
        val pack=StickerStore.pack(context,packId) ?: return "Pack not found"
        if(!pack.animated) return "This is not an animated pack"
        val dir=File(context.cacheDir,"sf_anim/$packId")
        dir.deleteRecursively(); dir.mkdirs()
        drafts[packId]=Draft(packId,dir)
        return "OK"
    }

    @JvmStatic @Synchronized fun addFrame(context:Context, packId:String, dataUrl:String, durationMs:Int):String {
        val d=drafts[packId] ?: return "Start the animation first"
        if(d.durations.size>=120) return "Maximum 120 frames"
        val comma=dataUrl.indexOf(','); if(comma<0) return "Invalid frame"
        val bytes=Base64.decode(dataUrl.substring(comma+1),Base64.DEFAULT)
        val opts=BitmapFactory.Options().apply{inJustDecodeBounds=true}
        BitmapFactory.decodeByteArray(bytes,0,bytes.size,opts)
        if(opts.outWidth!=512 || opts.outHeight!=512) return "Every frame must be 512×512"
        val dur=durationMs.coerceIn(8,2000)
        if(d.durations.sum()+dur>10000) return "Animation would exceed 10 seconds"
        FileOutputStream(File(d.dir,"frame_${d.durations.size.toString().padStart(3,'0')}.png")).use{it.write(bytes)}
        d.durations.add(dur)
        return "OK"
    }

    @JvmStatic @Synchronized fun finish(context:Context, packId:String, quality:Int):String {
        val d=drafts[packId] ?: return "No animation draft"
        if(d.durations.size<2) return "Animated stickers need at least 2 frames"
        if(StickerStore.count(context,packId)>=30) return "Pack already has 30 stickers"
        val out=File(d.dir,"out.webp")
        var encoder:WebPAnimEncoder?=null
        try {
            encoder=WebPAnimEncoder(context,512,512,WebPAnimEncoderOptions(minimizeSize=true,allowMixed=true,animParams=WebPMuxAnimParams(backgroundColor=Color.TRANSPARENT,loopCount=0)))
            encoder.configure(WebPConfig(lossless=WebPConfig.COMPRESSION_LOSSY,quality=quality.coerceIn(20,95).toFloat(),method=6,alphaQuality=90,threadLevel=1),WebPPreset.WEBP_PRESET_PICTURE)
            var timestamp=0L
            d.durations.forEachIndexed { i, dur ->
                val f=File(d.dir,"frame_${i.toString().padStart(3,'0')}.png")
                val bmp=BitmapFactory.decodeFile(f.absolutePath) ?: throw IllegalStateException("Could not decode frame ${i+1}")
                encoder.addFrame(timestamp,bmp); bmp.recycle(); timestamp += dur
            }
            encoder.assemble(timestamp,Uri.fromFile(out))
            if(!out.exists()) return "Encoder did not create a WebP"
            if(out.length()>500*1024) return "Animated WebP is ${out.length()/1024} KB. Lower quality or use fewer frames."
            val msg=StickerStore.saveAnimatedBytes(context,packId,out.readBytes())
            d.dir.deleteRecursively(); drafts.remove(packId)
            return msg
        } catch(e:Exception){ return "Animation encode failed: ${e.message}" }
        finally { try{encoder?.release()}catch(_:Exception){} }
    }
}
