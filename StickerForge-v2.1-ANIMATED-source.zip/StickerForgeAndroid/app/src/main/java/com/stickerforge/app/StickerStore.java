package com.stickerforge.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.util.*;

public final class StickerStore {
    public static final String TRAY_ICON="tray.png";
    private static final String PREFS="stickerforge_v2", KEY_PACKS="packs";
    private StickerStore(){}

    public static final class Pack {
        public String id,name,publisher; public boolean animated;
        Pack(String i,String n,String p,boolean a){id=i;name=n;publisher=p;animated=a;}
    }
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    private static JSONArray raw(Context c){try{return new JSONArray(prefs(c).getString(KEY_PACKS,"[]"));}catch(Exception e){return new JSONArray();}}
    private static void saveRaw(Context c,JSONArray a){prefs(c).edit().putString(KEY_PACKS,a.toString()).apply(); notifyAll(c);}
    private static void notifyAll(Context c){c.getContentResolver().notifyChange(android.net.Uri.parse("content://"+BuildConfig.CONTENT_PROVIDER_AUTHORITY+"/metadata"),null);}
    private static String slug(String s){String x=s==null?"pack":s.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+","_").replaceAll("^_+|_+$",""); return x.isEmpty()?"pack":x;}

    public static synchronized Pack createPack(Context c,String name,String publisher,boolean animated)throws Exception{
        JSONArray a=raw(c); if(a.length()>=10) throw new IOException("WhatsApp apps can expose up to 10 packs");
        String id=slug(name)+"_"+Long.toString(System.currentTimeMillis(),36);
        JSONObject o=new JSONObject();o.put("id",id);o.put("name",name==null||name.trim().isEmpty()?"My Pack":name.trim());o.put("publisher",publisher==null||publisher.trim().isEmpty()?"StickerForge":publisher.trim());o.put("animated",animated);o.put("version",1);a.put(o);saveRaw(c,a);packDir(c,id).mkdirs();return new Pack(id,o.getString("name"),o.getString("publisher"),animated);
    }
    public static synchronized void updatePack(Context c,String id,String name,String publisher)throws Exception{JSONArray a=raw(c);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(id.equals(o.optString("id"))){o.put("name",name);o.put("publisher",publisher);o.put("version",o.optInt("version",1)+1);saveRaw(c,a);return;}}throw new IOException("Pack not found");}
    public static synchronized void deletePack(Context c,String id)throws Exception{JSONArray a=raw(c),b=new JSONArray();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(!id.equals(o.optString("id")))b.put(o);}saveRaw(c,b);deleteRecursive(packDir(c,id));}
    private static void deleteRecursive(File f){if(f.isDirectory()){File[] q=f.listFiles();if(q!=null)for(File x:q)deleteRecursive(x);}f.delete();}
    public static List<Pack> packs(Context c){List<Pack> out=new ArrayList<>();JSONArray a=raw(c);for(int i=0;i<a.length();i++)try{JSONObject o=a.getJSONObject(i);out.add(new Pack(o.getString("id"),o.getString("name"),o.optString("publisher","StickerForge"),o.optBoolean("animated",false)));}catch(Exception ignored){}return out;}
    public static Pack pack(Context c,String id){for(Pack p:packs(c))if(p.id.equals(id))return p;return null;}
    public static int version(Context c,String id){JSONArray a=raw(c);for(int i=0;i<a.length();i++)try{JSONObject o=a.getJSONObject(i);if(id.equals(o.getString("id")))return o.optInt("version",1);}catch(Exception ignored){}return 1;}
    private static void bump(Context c,String id){JSONArray a=raw(c);for(int i=0;i<a.length();i++)try{JSONObject o=a.getJSONObject(i);if(id.equals(o.getString("id"))){o.put("version",o.optInt("version",1)+1);saveRaw(c,a);return;}}catch(Exception ignored){}}
    public static File packDir(Context c,String id){File d=new File(c.getFilesDir(),"stickers/"+id);if(!d.exists())d.mkdirs();return d;}
    public static List<File> stickerFiles(Context c,String id){File[] f=packDir(c,id).listFiles((d,n)->n.endsWith(".webp"));List<File> o=new ArrayList<>();if(f!=null){Arrays.sort(f,Comparator.comparing(File::getName));o.addAll(Arrays.asList(f));}return o;}
    public static int count(Context c,String id){return stickerFiles(c,id).size();}
    public static synchronized String saveDataUrl(Context c,String id,String dataUrl)throws Exception{Pack p=pack(c,id);if(p==null)throw new IOException("Pack not found");if(p.animated)throw new IOException("Use animated import for animated packs");if(count(c,id)>=30)return "Pack already has 30 stickers";int comma=dataUrl.indexOf(',');if(comma<0)throw new IOException("Invalid data URL");byte[] bytes=Base64.decode(dataUrl.substring(comma+1),Base64.DEFAULT);validateStatic(bytes);String name=String.format(Locale.US,"sticker_%02d.webp",count(c,id)+1);try(FileOutputStream fos=new FileOutputStream(new File(packDir(c,id),name))){fos.write(bytes);}ensureTray(c,id,bytes);bump(c,id);return "Added • "+count(c,id)+"/30";}
    public static synchronized String saveAnimatedBytes(Context c,String id,byte[] bytes)throws Exception{Pack p=pack(c,id);if(p==null||!p.animated)throw new IOException("Choose an animated pack");if(count(c,id)>=30)return "Pack already has 30 stickers";if(bytes.length>500*1024)throw new IOException("Animated sticker exceeds 500 KB");if(!isWebP(bytes))throw new IOException("Animated sticker must be WebP");String name=String.format(Locale.US,"sticker_%02d.webp",count(c,id)+1);try(FileOutputStream fos=new FileOutputStream(new File(packDir(c,id),name))){fos.write(bytes);}ensureTray(c,id,bytes);bump(c,id);return "Animated sticker added • "+count(c,id)+"/30";}
    private static boolean isWebP(byte[] b){return b.length>=12&&b[0]=='R'&&b[1]=='I'&&b[2]=='F'&&b[3]=='F'&&b[8]=='W'&&b[9]=='E'&&b[10]=='B'&&b[11]=='P';}
    private static void validateStatic(byte[] b)throws IOException{if(b.length>100*1024)throw new IOException("Sticker is over 100 KB");if(!isWebP(b))throw new IOException("Not a real WebP");BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(b,0,b.length,o);if(o.outWidth!=512||o.outHeight!=512)throw new IOException("Sticker must be exactly 512×512");}
    private static void ensureTray(Context c,String id,byte[] b)throws IOException{File t=new File(packDir(c,id),TRAY_ICON);if(t.exists())return;Bitmap src=BitmapFactory.decodeByteArray(b,0,b.length);if(src==null){Bitmap blank=Bitmap.createBitmap(96,96,Bitmap.Config.ARGB_8888);try(FileOutputStream f=new FileOutputStream(t)){blank.compress(Bitmap.CompressFormat.PNG,100,f);}blank.recycle();return;}Bitmap icon=Bitmap.createScaledBitmap(src,96,96,true);try(FileOutputStream f=new FileOutputStream(t)){icon.compress(Bitmap.CompressFormat.PNG,100,f);}src.recycle();icon.recycle();}
}
