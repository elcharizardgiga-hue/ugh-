# StickerForge v2.1 — Animated Forge

Android WhatsApp sticker maker with static and animated packs.

## Animated editor
- Frame-by-frame 512×512 compositor
- Multiple image and text layers per frame
- Duplicate/delete/reorder frames
- Per-frame duration (8–2000 ms)
- Playback preview
- Real animated WebP encoding on Android through libwebp JNI (`com.aureusapps.android:webp-android:1.1.2`)
- Export guardrails: max 10 seconds and max 500 KB
- Existing animated WebP import remains available

WhatsApp pack rules are enforced at the pack level: 3–30 stickers, and static/animated stickers cannot be mixed in one pack.

Build with JDK 17 / Gradle 8.9. `assembleDebug` produces the APK.
