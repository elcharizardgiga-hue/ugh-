SIDEPLAY R10 BUILD V2 - PREINSTALLED ANDROID SDK

Upload:
- SidePlay-Node-v0.9.0-R10-STABILIZATION.zip to repository root
- SIDEPLAY_R10_BUILD.yml to .github/workflows/SIDEPLAY_R10_BUILD.yml

This V2 workflow deliberately DOES NOT use android-actions/setup-android.
GitHub's Ubuntu runner already contains the Android SDK.

Expected proof line:
SIDEPLAY 0.9.0 R10 STABILIZATION WORKFLOW V2 - PREINSTALLED SDK

The workflow only invokes sdkmanager if one of these is actually missing:
- platform-tools
- platforms;android-36
- build-tools;36.0.0

This avoids setup-android trying to upgrade command-line tools before the build.
