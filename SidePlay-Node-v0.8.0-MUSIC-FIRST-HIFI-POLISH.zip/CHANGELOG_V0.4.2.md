# SidePlay v0.4.2

## YouTube dual-route background bridge

- Added a dedicated **YouTube Web** handoff route that forces the exact watch URL into an installed/default browser instead of letting Android redirect it back to the YouTube app.
- Added **Auto / YT app / Web** route selection in Settings. Auto prefers the official YouTube app when installed and falls back to Web if the app route cannot be opened.
- SidePlay can mirror/control the browser MediaSession after Notification Access is granted, including play/pause/seek when the browser exposes those controls.
- Browser and app sessions are verified against the selected SidePlay track before SidePlay marks them connected. Unrelated browser audio is rejected instead of becoming a false-positive player.
- App-resume session detection now retries several times to avoid racing Android's delayed MediaSession publication.
- PiP remains disabled.
- Universal Media3 direct/local/PeerTube playback and real offline downloads remain unchanged.
