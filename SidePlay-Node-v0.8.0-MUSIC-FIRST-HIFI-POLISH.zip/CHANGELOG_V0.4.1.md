# SidePlay v0.4.1 — Universal Player + Provider Bridge

This build pushes the v0.4 universal-player architecture further instead of trying to force every service into one brittle WebView.

## YouTube Premium background bridge

- Added `ProviderSessionPlugin.java`.
- YouTube results on Android can now be handed off by exact video ID to the official YouTube app.
- The handoff is deterministic at the video-selection step: SidePlay opens the selected YouTube video, not a fuzzy song search.
- The YouTube app is launched from the SidePlay activity so pressing Android Back returns naturally to SidePlay.
- A native hint tells the user to tap Back once after playback starts.
- With YouTube Premium, provider-owned background/screen-off playback can continue in the official YouTube app.
- If Notification Access is enabled, SidePlay can mirror the active YouTube Android media session for play/pause/seek and progress after returning.
- PiP remains disabled in SidePlay.

## Universal URL resolver gets broader

- Added conservative public HTML5 media discovery for ordinary web pages.
- SidePlay can follow media that a public HTML document explicitly exposes through `og:audio`, `og:video`, `<audio>`, `<video>` or `<source>` tags.
- Relative media URLs are resolved against the page and probed before being accepted.
- Progressive public files become playable + downloadable.
- Public HLS/DASH discovered from HTML becomes natively playable online.
- The resolver still does not execute private page APIs, bypass authentication/DRM, or decrypt protected provider streams.

## Offline / download UX

- Direct and PeerTube progressive media still download as real bytes into SidePlay's app-private vault.
- Provider rows no longer show a fake/generic “Import file” action when the provider has not exposed a SidePlay-downloadable file.
- Now Playing exposes Download only when a real download/local action exists.
- Provider source actions remain separate from SidePlay-owned offline files.

## UX cleanup

- YouTube provider handoff gets an explicit player state: `YouTube Premium · background` or `YouTube · tap Back`.
- Spotify bridge moved under an advanced disclosure instead of occupying the main Settings flow.
- Added one compact Provider Background Bridge card.
- Removed the old PiP CSS block entirely.
- Tightened mini-player / bottom-nav spacing and small-screen action layout.

## Build

- Package version: `0.4.1`.
- GitHub workflow now validates `ProviderSessionPlugin.java` before compiling.
- Final artifact name: `SidePlay-v0.4.1-SIGNED-APK`.
- Final APK: `SidePlay-v0.4.1.apk`.
