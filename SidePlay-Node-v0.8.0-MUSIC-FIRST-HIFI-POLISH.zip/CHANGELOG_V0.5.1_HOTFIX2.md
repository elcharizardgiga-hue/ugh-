# SidePlay v0.5.1 HOTFIX2 — Android package validation

- Keeps HOTFIX1's `SourceResolverPlugin.base(...)` static-context compile fix.
- Stops treating a successful `assembleDebug` as proof that the handoff APK is installable.
- The local builder now validates the exact `SidePlay-INSTALL.apk` with Android SDK `apksigner`, `zipalign`, and `aapt dump badging` before reporting success.
- Adds `VERIFY_SIDEPLAY_APK.bat` for repeatable offline APK structural/signature checks.
- Adds `INSTALL_SIDEPLAY_USB.bat` to surface the phone's exact `PackageManager` install error through `adb install` without auto-uninstalling anything.
- `cap sync android` now runs on repeat builds rather than only copying web assets.
- Generated `android/` projects are stamped with the Capacitor major version. Missing/mismatched stamps trigger a one-time Android-shell regeneration to prevent stale generated Gradle/manifest state from surviving source upgrades.
- `BUILD_SIDEPLAY_APK_CLEAN.bat` now truly recreates the generated Android project.
