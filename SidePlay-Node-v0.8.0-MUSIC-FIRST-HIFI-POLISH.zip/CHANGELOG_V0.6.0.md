# SidePlay v0.6.0 — provider extraction engine

## Functional engine changes

- Added on-device yt-dlp provider extraction before the existing generic resolver.
- Added yt-dlp + FFmpeg adaptive/offline pipeline for provider pages, HLS/DASH-style sources and split audio/video when yt-dlp can obtain clear formats.
- Direct `.m3u8` / `.mpd` URLs now route offline saves through yt-dlp/FFmpeg instead of being play-only.
- Provider/search items can resolve on-demand when Save is requested; they no longer need to be played once before the extractor-backed downloader is available.
- Added MP4-first merge with MKV fallback for codec combinations that cannot be remuxed cleanly to MP4.
- Added short-lived extracted-stream refresh using the durable original provider URL.
- Added failure-tolerant daily yt-dlp NIGHTLY updater attempt so provider extractors do not freeze at the version bundled in the Android dependency.
- Preserved generic static resolver and SidePlay Media Catcher as escalating fallbacks when provider extraction fails.
- Preserved Media3 background/lock-screen/Bluetooth/Alexa output path for resolved streams.
- Provider downloads are admitted into the SidePlay vault only after MediaSafety validates filename/MIME, prefix bytes, file size and free-storage reserve.
- Existing direct progressive downloads retain cross-host sensitive-header stripping.
- Spotify remains provider/session handoff; SidePlay does not attempt to decrypt DRM media.

## Build changes

- Added `io.github.junkfood02.youtubedl-android:library:0.18.1`.
- Added `io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1`.
- Android manifest is patched with `android:extractNativeLibs="true"` as required by the native extractor/FFmpeg runtime.
- `YtDlpPlugin.java` is registered and included in builder native-source preflight checks.
