# SidePlay v0.4.5 — Now Playing layout repair

- Rebuilt the expanded Now Playing screen so it no longer crops 16:9 YouTube/PeerTube artwork into a giant square.
- Video-like sources now use a real 16:9 stage with `object-fit: contain`; audio sources keep square album art.
- Desktop Now Playing is now a responsive two-column player instead of a phone-sized vertical sheet stretched inside a desktop viewport.
- Mobile Now Playing uses viewport-aware media heights so title, seek bar and controls do not crash into each other.
- Short-height phones get an extra compact layout pass.
- Now Playing actions collapse to a predictable two-column grid instead of overflowing horizontally.
- Header / close / queue controls stay above content without covering the artwork.
- Preserves all v0.4.4 fixes: Android `RoleManager#getRoleHolders()` compile repair, multi-source search, native-first ordering, Audius/PeerTube support, Media3 playback, offline vault and PiP disabled.
