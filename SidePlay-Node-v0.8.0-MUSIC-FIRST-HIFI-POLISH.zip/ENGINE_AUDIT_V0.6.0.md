# SidePlay v0.6.0 engine audit

This release changes the functional media engine, not just UI.

Verified in this source package:
- yt-dlp Android provider extractor is registered ahead of the generic resolver for public web/provider pages.
- FFmpeg-backed provider downloads can assemble adaptive/separate audio+video formats when the extractor exposes clear media.
- Direct HLS/DASH manifests are playable through Media3 and route offline saves through the adaptive downloader.
- Short-lived extracted playback URLs are treated as refreshable; SidePlay can re-run extraction from the durable source URL.
- Existing static/public resolver and interactive browser Media Catcher remain fallback layers.
- Progressive downloads and completed yt-dlp downloads both pass SidePlay MediaSafety checks before entering the private vault.
- MediaSafety retains filename/MIME/signature/size/storage checks and does not admit executable/package/script/archive/document payloads as media.
- Android patcher registers YtDlpPlugin, injects yt-dlp/FFmpeg + Media3 dependencies, and enables native-lib extraction.
- Windows build pipeline still verifies the final APK with Android SDK package/signature/alignment tools before reporting success.

Local validation performed before packaging:
- Java syntax/compatibility smoke compile of YtDlpPlugin + MediaSafety against Android/Capacitor/yt-dlp API stubs: PASS.
- TypeScript/TSX transpile syntax pass across src/: PASS.
- Android patcher JavaScript syntax check: PASS.
- Synthetic generated-Android patch simulation (plugin registration/dependencies/manifest): PASS.

Not claimed:
- DRM/Widevine decryption, encrypted protected-stream bypass, paywall/authentication bypass, or guaranteed compatibility with every website forever.
- A full Gradle APK compile inside the ChatGPT sandbox; the included Windows/GitHub builders perform that against the real dependency graph.
