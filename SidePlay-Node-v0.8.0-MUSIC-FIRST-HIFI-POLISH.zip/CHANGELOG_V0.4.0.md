# SidePlay v0.4.0 — Universal Player + Real Offline Vault

## Playback architecture
- Direct audio/video URLs play through SidePlay's native Android Media3 `MediaSessionService`.
- Added Media3 HLS and DASH modules for online segmented streams.
- Public PeerTube watch links are resolved through the instance's public REST API to an exposed progressive file or HLS playlist.
- Media3 owns background, screen-off, lock-screen, Bluetooth and media-notification playback whenever SidePlay has a real playable media URL/file.
- Direct video uses the same native background session; the expanded player shows a muted synchronized foreground video surface while Media3 owns audio/session state.
- PiP stays disabled.

## Actual downloads / offline
- Added a real app-private SidePlay offline vault on Android.
- Progressive direct media and public PeerTube download files can be downloaded into the vault with progress reporting.
- Downloads use a `.part` file and only become visible after a successful complete write.
- Imported audio/video files are copied into the same vault.
- Android Share/Open media intents can be copied directly into the vault and played immediately.
- Offline entries persist in the SidePlay library and are played from the local file by Media3 with no network connection.
- Deleting an offline item deletes the actual vault file.
- HLS/DASH is online-playable but v0.4.0 does not fake an offline save for segmented playlists; it requires an exposed progressive file.

## Universal URL resolver
- Added native source resolver with provider capabilities instead of pretending every web page is a media file.
- Direct HTTP(S) media: native play; progressive files can download.
- PeerTube: public API resolution to real exposed playback/download URLs.
- Spotify: provider URI/session handoff remains optional; SidePlay does not download Spotify audio.
- SoundCloud: provider page metadata/open-source path unless an authorized stream integration is available; no hidden-stream scraping.
- YouTube: search/embed/provider path remains; no hidden-stream extraction or download bypass.

## UX cleanup
- Reduced bottom navigation to Home / Search / Library / Offline.
- Removed the Queue tab from permanent navigation; Queue is available from Now Playing.
- Replaced crowded 5-button track rows with Play + at most Download + one More menu.
- Moved Like, Play next, Queue, Playlist, Offline and Open source into one bottom action sheet.
- Simplified cards and Now Playing actions.
- Fixed mini-player/bottom-nav spacing on phones.
- Added clear provider and playback-engine badges.
- Settings advanced sections are collapsed by default.
- Search accepts normal text or pasted media/provider URLs.

## Android integration
- Requests Android 13+ media notification permission on first launch.
- Handles text links shared to SidePlay.
- Handles audio/video files shared/opened from Android and imports them into the vault.
- Allows explicit HTTP direct media for radio/local-server compatibility.
