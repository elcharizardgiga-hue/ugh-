# SidePlay v0.7.0 — Native Search → Native Play

## Functional changes

- Added on-device yt-dlp catalog search (`ytsearch` and `scsearch`) through the existing Android extractor runtime.
- YouTube search no longer depends on a YouTube Data API key on Android. If yt-dlp search fails, SidePlay falls back to its independent native InnerTube/HTML search path.
- Search results retain their durable provider/source URL, then resolve through yt-dlp when tapped and enter SidePlay Media3 rather than immediately handing off to another app.
- External YouTube background bridge now defaults OFF; it remains an explicit fallback users can enable.
- Enabled QuickJS + yt-dlp EJS support for current YouTube JS challenge solving; extractor failures trigger a throttled nightly yt-dlp refresh and one retry.
- Extractor-backed playback now sends its durable public source URL into the native playback service.
- If a provider CDN URL expires after retries, MediaSessionService re-runs yt-dlp natively and swaps in a fresh URL while preserving playback position.
- Media3 playback resumption after service recreation can re-extract a fresh provider stream instead of persisting an expired signed CDN URL.
- Network recovery re-extracts provider media when appropriate.
- Durable-source persistence rejects credential-like/tokenized source URLs and still strips sensitive request headers.
- Existing MediaSafety checks remain in front of permanent offline storage.

## Boundary

SidePlay resolves clear media that yt-dlp or the browser session can legitimately expose. It does not decrypt DRM, bypass paywalls, or persist authentication cookies/tokens.
