# Third-party notices — SidePlay v0.6.0

SidePlay v0.6.0 integrates **youtubedl-android / yt-dlp for Android** (`io.github.junkfood02.youtubedl-android:library:0.18.1` and `ffmpeg:0.18.1`) for broad public-media extraction and adaptive media download/merge support.

Project: https://github.com/yausername/youtubedl-android
License: GNU General Public License v3.0 (GPL-3.0)

A copy of GPL-3.0 is included as `LICENSE-GPL-3.0.txt`.

The extractor is only used for clear media that the device is permitted to access. SidePlay does not add DRM decryption or protected-stream bypass logic. Sites can change at any time; yt-dlp extraction therefore includes a failure-tolerant on-device updater and SidePlay retains its generic resolver/network-capture fallback.
