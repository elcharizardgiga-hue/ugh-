@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title SidePlay APK Verifier

set "SIDEPLAY_TOOLS=%LOCALAPPDATA%\SidePlay\tools"
if "%LOCALAPPDATA%"=="" set "SIDEPLAY_TOOLS=%USERPROFILE%\AppData\Local\SidePlay\tools"
if exist "%SIDEPLAY_TOOLS%\sideplay-env.bat" call "%SIDEPLAY_TOOLS%\sideplay-env.bat"

set "APK=SidePlay-INSTALL.apk"
if not exist "%APK%" set "APK=SidePlay-debug.apk"
if not exist "%APK%" (
  echo [FAIL] No SidePlay-INSTALL.apk or SidePlay-debug.apk found here.
  echo Run BUILD_SIDEPLAY_APK.bat first.
  goto :done
)

if "%ANDROID_HOME%"=="" (
  echo [FAIL] Android SDK environment is not loaded.
  echo Run BUILD_SIDEPLAY_APK.bat once so SidePlay can provision its SDK.
  goto :done
)
set "BT=%ANDROID_HOME%\build-tools\36.0.0"
set "APKSIGNER=%BT%\apksigner.bat"
set "AAPT=%BT%\aapt.exe"
set "ZIPALIGN=%BT%\zipalign.exe"

echo ========================================
echo        SidePlay APK Verifier
echo ========================================
echo APK: %CD%\%APK%
echo.

if not exist "%APKSIGNER%" (echo [FAIL] apksigner missing.& goto :done)
if not exist "%AAPT%" (echo [FAIL] aapt missing.& goto :done)
if not exist "%ZIPALIGN%" (echo [FAIL] zipalign missing.& goto :done)

call "%APKSIGNER%" verify --verbose --print-certs "%APK%"
if errorlevel 1 (echo.& echo [FAIL] APK signature is invalid.& goto :done)
echo [ OK ] APK signature verifies.
echo.

"%ZIPALIGN%" -c -v 4 "%APK%" >nul
if errorlevel 1 (echo [FAIL] APK ZIP alignment is invalid.& goto :done)
echo [ OK ] APK ZIP alignment verifies.

echo.
"%AAPT%" dump badging "%APK%" > sideplay-apk-badging.txt
if errorlevel 1 (echo [FAIL] aapt cannot parse this APK.& goto :done)
findstr /C:"package: name='app.sideplay.mobile'" sideplay-apk-badging.txt >nul
if errorlevel 1 (echo [FAIL] Package id is not app.sideplay.mobile.& goto :done)
echo [ OK ] Android can parse the package metadata.
for /f "delims=" %%L in ('findstr /B /C:"package:" /C:"sdkVersion:" /C:"targetSdkVersion:" sideplay-apk-badging.txt') do echo      %%L

echo.
for %%A in ("%APK%") do echo Size: %%~zA bytes
certutil -hashfile "%APK%" SHA256 | findstr /R /V "hash CertUtil"
echo.
echo [PASS] This APK is structurally parseable and correctly signed.
echo If the PHONE still rejects it, use INSTALL_SIDEPLAY_USB.bat to get the exact PackageManager error code.

:done
echo.
pause
