# SidePlay v0.6.1 — Background Fortress + GitHub Release Deploy

## Native background playback hardening

- Media3 `MediaSessionService` remains the owner of native playback.
- Stable/local native media now persists a safe resumption snapshot and supports Media3 playback resumption through `MediaButtonReceiver`.
- Active native playback can recover after Android recreates the sticky service.
- Swiping SidePlay out of Recents no longer stops a native session just because the item is paused/buffering.
- Added network-availability recovery after bounded ExoPlayer retries.
- Added `ACCESS_NETWORK_STATE` and Media3 media-button receiver manifest plumbing.
- ExoPlayer now uses one resolving data-source factory for request headers across normal playback and safe resumption.
- Cookies/Authorization/CSRF headers remain non-persistent. Browser/session-bound media is intentionally not marked OS-resumable.

## GitHub Actions / deploy

- `.github/workflows/build-apk.yml` accepts either expanded SidePlay source or a `SidePlay-Node-v*.zip` at repository root.
- Builds, signs, zipaligns, `apksigner` verifies, and `aapt2 dump badging` parses the final APK.
- Uploads a verified APK artifact on normal pushes/manual runs.
- A `v*` tag publishes a GitHub Release when persistent signing secrets are configured.
- CI falls back to a one-run test key when secrets are absent, but deliberately skips tagged Release publication so users do not accidentally ship update-incompatible APK signatures.
