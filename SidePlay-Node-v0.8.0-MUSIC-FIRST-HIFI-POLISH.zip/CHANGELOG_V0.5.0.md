# SidePlay v0.5.0 — PLAY-WHATEVER Media Catcher

- Adds an Android **Media Catcher** fallback for dynamic pages after static/direct resolution fails.
- Media Catcher uses an in-app WebView and observes both WebView requests and browser Performance API resources while the user starts the desired media.
- Candidate ranking understands direct audio/video, HLS, DASH, extensionless `video`/`audio` resources, manifest/playlist URLs, and recent XHR/fetch activity. Segment files and obvious non-media assets are intentionally de-prioritized/ignored.
- Before handing a candidate to SidePlay, the catcher probes the URL with the browser request context and MIME hints.
- Captured streams carry **Referer, User-Agent, Cookie and safe request headers** into Media3, avoiding the common “resolver found it but playback gets HTTP 403” failure.
- `PlaybackService` now creates a per-item Media3 data-source/media-source with the captured HTTP headers and explicit MIME type, so extensionless HLS/DASH/progressive URLs can be inferred correctly.
- Progressive captured downloads pass the same request headers into Offline Vault downloads.
- Captured cookies/auth headers are runtime-only, are stripped from persisted library/history/exports, and are not forwarded across hosts on playback/download redirects. Session-bound CDN URLs are also discarded on persistence so they are re-captured after restart.
- Unknown/SoundCloud-style web pages now offer/trigger Media Catcher on Android instead of immediately giving up and opening the source externally.
- Offline > Add from URL now exposes **Catch media** when static resolution cannot produce a playback URL.
- Adds a Settings → **Alexa / Echo output** helper that opens Android Bluetooth pairing; Echo speakers then receive SidePlay as a normal Media3/Bluetooth media source.
- Keeps existing direct media, PeerTube, Audius, YouTube provider bridge, Spotify lab bridge, background/screen-off playback, media notification and Bluetooth output behavior.
- Hard boundary remains: no DRM decryption, encrypted-manifest bypass, login/paywall bypass, or fake “downloadable” claims.

## Build note

The repository ZIP remains source-first. `npm install` + the Android build script/GitHub workflow generates the Android project, copies `MediaCaptureActivity.java`, registers the activity-result bridge, and adds the catcher activity to the manifest.
