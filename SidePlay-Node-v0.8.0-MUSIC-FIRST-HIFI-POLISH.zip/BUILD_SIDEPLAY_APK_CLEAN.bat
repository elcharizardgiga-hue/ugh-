@echo off
setlocal
cd /d "%~dp0"
title SidePlay - Full Clean Android Rebuild
echo.
echo This removes generated Android/build output and recreates the Android shell.
echo Source files, npm packages and the cached JDK/SDK are kept.
echo.
if exist android rmdir /s /q android
if exist dist rmdir /s /q dist
if exist SidePlay-debug.apk del /q SidePlay-debug.apk
if exist SidePlay-INSTALL.apk del /q SidePlay-INSTALL.apk
call BUILD_SIDEPLAY_APK.bat
