import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const android = path.join(root, 'android')
if (!fs.existsSync(android)) throw new Error('android/ does not exist. Run: npx cap add android')

const nativeFiles = [
  'PlaybackService.java',
  'BackgroundAudioPlugin.java',
  'SharedTextPlugin.java',
  'NativeYouTubePlugin.java',
  'DirectDownloadPlugin.java',
  'OfflineMediaPlugin.java',
  'SourceResolverPlugin.java',
  'YtDlpPlugin.java',
  'MediaCaptureActivity.java',
  'MediaSafety.java',
  'WebPlaybackKeepAliveService.java',
  'WebPlaybackPlugin.java',
  'SpotifySessionListenerService.java',
  'SpotifySessionPlugin.java',
  'ProviderSessionPlugin.java',
]
for (const file of nativeFiles) {
  const source = path.join(root, 'native', 'android', file)
  if (!fs.existsSync(source)) throw new Error(`Missing native Android source: native/android/${file}. Re-extract a complete SidePlay release.`)
}

const pkgDir = path.join(android, 'app', 'src', 'main', 'java', 'app', 'sideplay', 'mobile')
fs.mkdirSync(pkgDir, { recursive: true })
for (const file of nativeFiles) {
  fs.copyFileSync(path.join(root, 'native', 'android', file), path.join(pkgDir, file))
}

const mainActivity = path.join(pkgDir, 'MainActivity.java')
fs.writeFileSync(mainActivity, `package app.sideplay.mobile;\n\nimport android.Manifest;\nimport android.content.Intent;\nimport android.os.Build;\nimport android.os.Bundle;\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n  @Override\n  public void onCreate(Bundle savedInstanceState) {\n    registerPlugin(BackgroundAudioPlugin.class);\n    registerPlugin(SharedTextPlugin.class);\n    registerPlugin(NativeYouTubePlugin.class);\n    registerPlugin(DirectDownloadPlugin.class);\n    registerPlugin(OfflineMediaPlugin.class);\n    registerPlugin(SourceResolverPlugin.class);\n    registerPlugin(YtDlpPlugin.class);\n    registerPlugin(WebPlaybackPlugin.class);\n    registerPlugin(SpotifySessionPlugin.class);\n    registerPlugin(ProviderSessionPlugin.class);\n    super.onCreate(savedInstanceState);\n\n    // Android 13+: ask once for media notification permission. Background playback\n    // itself is owned by MediaSessionService; this permission makes the controls\n    // visible in the notification shade when the OS requires it.\n    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {\n      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9404);\n    }\n  }\n\n  // Kept for WebPlaybackPlugin compatibility. PiP is deliberately disabled.\n  public void setSidePlayPipEnabled(boolean enabled) {}\n  public void setWebPlaybackWanted(boolean wanted) {}\n\n  @Override\n  protected void onActivityResult(int requestCode, int resultCode, Intent data) {\n    if (SourceResolverPlugin.handleActivityResult(requestCode, resultCode, data)) return;\n    if (OfflineMediaPlugin.handleActivityResult(requestCode, resultCode, data)) return;\n    super.onActivityResult(requestCode, resultCode, data);\n  }\n\n  @Override\n  protected void onNewIntent(Intent intent) {\n    super.onNewIntent(intent);\n    setIntent(intent);\n  }\n}\n`)

const gradle = path.join(android, 'app', 'build.gradle')
let g = fs.readFileSync(gradle, 'utf8')
const mediaDeps = [
  'implementation "io.github.junkfood02.youtubedl-android:library:0.18.1"',
  'implementation "io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1"',
  'implementation "androidx.media3:media3-exoplayer:1.8.1"',
  'implementation "androidx.media3:media3-exoplayer-hls:1.8.1"',
  'implementation "androidx.media3:media3-exoplayer-dash:1.8.1"',
  'implementation "androidx.media3:media3-exoplayer-rtsp:1.8.1"',
  'implementation "androidx.media3:media3-session:1.8.1"',
]
for (const dep of mediaDeps) {
  if (!g.includes(dep)) g = g.replace(/dependencies\s*\{/, `dependencies {\n    ${dep}`)
}
fs.writeFileSync(gradle, g)

const manifest = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml')
let m = fs.readFileSync(manifest, 'utf8')
const perms = [
  '<uses-permission android:name="android.permission.INTERNET" />',
  '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
  '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />',
  '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '<uses-permission android:name="android.permission.WAKE_LOCK" />',
  '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
  '<uses-permission android:name="android.permission.REORDER_TASKS" />',
]
for (const p of perms) if (!m.includes(p)) m = m.replace(/<application/, `    ${p}\n    <application`)

// PiP is intentionally absent in the universal player architecture.
m = m.replace(/\s+android:supportsPictureInPicture="true"/g, '')
// Direct HTTP radio/media is common. SidePlay only treats explicit media URLs as playable.
if (!m.includes('android:usesCleartextTraffic=')) m = m.replace(/<application/, '<application android:usesCleartextTraffic="true"')
if (!m.includes('android:extractNativeLibs=')) m = m.replace(/<application/, '<application android:extractNativeLibs="true"')

if (!m.includes('PlaybackService')) {
  m = m.replace(/<\/application>/, `        <service\n            android:name=".PlaybackService"\n            android:stopWithTask="false"\n            android:foregroundServiceType="mediaPlayback"\n            android:exported="true">\n            <intent-filter>\n                <action android:name="androidx.media3.session.MediaSessionService" />\n            </intent-filter>\n        </service>\n    </application>`)
} else if (!/android:name="\.PlaybackService"[\s\S]*?android:stopWithTask=/.test(m)) {
  m = m.replace(/android:name="\.PlaybackService"/, 'android:name=".PlaybackService"\n            android:stopWithTask="false"')
}

if (!m.includes('androidx.media3.session.MediaButtonReceiver')) {
  m = m.replace(/<\/application>/, `        <receiver
            android:name="androidx.media3.session.MediaButtonReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
    </application>`)
}

if (!m.includes('MediaCaptureActivity')) {
  m = m.replace(/<\/application>/, `        <activity
            android:name=".MediaCaptureActivity"
            android:exported="false" />
    </application>`)
}

if (!m.includes('WebPlaybackKeepAliveService')) {
  m = m.replace(/<\/application>/, `        <service\n            android:name=".WebPlaybackKeepAliveService"\n            android:stopWithTask="true"\n            android:foregroundServiceType="mediaPlayback"\n            android:exported="false" />\n    </application>`)
}

// Provider and browser package visibility for Android 11+.
// The VIEW intent query lets us resolve the user's default browser without
// accidentally handing youtube.com straight back to the YouTube app.
const queries = `    <queries>
        <package android:name="com.spotify.music" />
        <package android:name="com.google.android.youtube" />
        <package android:name="com.google.android.apps.youtube.music" />
        <package android:name="com.soundcloud.android" />
        <package android:name="com.android.chrome" />
        <package android:name="com.google.android.apps.chrome" />
        <package android:name="com.sec.android.app.sbrowser" />
        <package android:name="com.brave.browser" />
        <package android:name="org.mozilla.firefox" />
        <package android:name="org.mozilla.fenix" />
        <package android:name="com.microsoft.emmx" />
        <package android:name="com.opera.browser" />
        <package android:name="com.vivaldi.browser" />
        <package android:name="com.kiwibrowser.browser" />
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <category android:name="android.intent.category.BROWSABLE" />
            <data android:scheme="https" />
        </intent>
    </queries>
`
m = m.replace(/\s*<queries>[\s\S]*?<\/queries>\s*/m, '\n')
m = m.replace(/<application/, `${queries}    <application`)
if (!m.includes('SpotifySessionListenerService')) {
  m = m.replace(/<\/application>/, `        <service\n            android:name=".SpotifySessionListenerService"\n            android:label="SidePlay provider media control"\n            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"\n            android:exported="true">\n            <intent-filter>\n                <action android:name="android.service.notification.NotificationListenerService" />\n            </intent-filter>\n        </service>\n    </application>`)
}
if (!m.includes('android.intent.action.SEND')) {
  m = m.replace(/(<activity[\s\S]*?<intent-filter>[\s\S]*?<\/intent-filter>)/, `$1\n            <intent-filter>\n                <action android:name="android.intent.action.SEND" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <data android:mimeType="text/plain" />\n            </intent-filter>`)
}
if (!m.includes('sideplay.media.share')) {
  m = m.replace(/<\/activity>/, `            <!-- sideplay.media.share -->
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="audio/*" />
                <data android:mimeType="video/*" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:scheme="content" />
                <data android:scheme="file" />
                <data android:mimeType="audio/*" />
                <data android:mimeType="video/*" />
            </intent-filter>
        </activity>`)
}
fs.writeFileSync(manifest, m)
console.log('Android project patched: yt-dlp provider extraction/download + FFmpeg merge, Media3 universal player (progressive/HLS/DASH/RTSP), PLAY-WHATEVER Media Catcher with browser-session header replay, offline vault downloads, public HTML/PeerTube/direct resolver, Share/Open media intents, YouTube app/Web handoff, and optional Spotify provider bridge. PiP is disabled.')
