# SidePlay v0.4.6 — browser session capture + engine/source repair

- Fixed the v0.4.3 Android compile failure inherited from `RoleManager#getRoleHolders()` by keeping the v0.4.4 `PackageManager.resolveActivity(..., MATCH_DEFAULT_ONLY)` default-browser resolution.
- Browser playback detection now has **two independent paths**:
  1. `MediaSessionManager.getActiveSessions(...)`, and
  2. the exact `MediaSession.Token` embedded in Android's media notification, captured by SidePlay's enabled NotificationListener.
- This directly addresses the case where YouTube Web is audibly playing in Brave/Samsung Internet while SidePlay remains stuck on `YOUTUBE WEB · CONNECTING`.
- Media-notification title/text are used as metadata fallback when the browser exposes blank/delayed `MediaMetadata`.
- If a browser exposes media notification actions but no usable controller token, SidePlay can still fall back to the notification's play/pause/previous/next actions instead of being completely dead.
- Dynamic browser matching no longer depends solely on a browser allow-list. The browser SidePlay launched, the last browser, fresh media-notification package, playback state and expected title are scored together.
- Preserves v0.4.4 multi-source search: **All / Audius / PeerTube / YouTube**, native-first ordering, PeerTube resolution, Audius Media3 playback/download support and partial-source failure handling.
- Preserves v0.4.5 Now Playing/mobile layout repair and compact row/action UX.
- PiP remains disabled.
