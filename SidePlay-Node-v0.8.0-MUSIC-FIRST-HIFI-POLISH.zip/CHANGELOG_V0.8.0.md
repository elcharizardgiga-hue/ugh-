# SidePlay v0.8.0 — Music-first / Hi-Fi Polish

## Playback quality
- Music searches now resolve through the provider's best available clear audio representation instead of preferring a convenient muxed video stream.
- Audio-only downloads preserve the provider's original audio representation instead of forcing a lossy M4A conversion.
- Provider refresh/resumption preserves the audio-only preference when signed stream URLs expire.
- Media3 now uses a music-focused buffer profile, network wake mode, audio offload when supported, and gapless-support-required offload preferences.
- SidePlay does **not** claim to create lossless audio from a lossy source. If a source exposes a lossless representation, keeping the original codec avoids an unnecessary quality loss.

## Listening experience
- Autoplay can continue from recommendations/favorites/history after Up Next runs out.
- Fixed queue transitions: an ended track now resolves/plays the next provider item instead of only moving the queue index, and Next/Previous no longer double-count plays/history.
- Audio-preferred intent is persisted independently from container MIME, so Opus-in-WebM and extensionless best-audio streams stay audio-first across signed-URL refresh, network recovery, and service recreation.
- Native search is music-first by default (YouTube Music + SoundCloud + Audius first, PeerTube discovery after the music catalog); the explicit YouTube/PeerTube tabs remain video-first.
- Search, playback refresh, downloads and background resumption keep the original provider page as the durable source while treating signed CDN playback URLs as disposable.

## Product/UI pass
- Reworked Home around listening: greeting, Resume, Shuffle, Jump back in, mixes, and recommendations.
- Search is centered on songs/artists/videos instead of resolver/provider terminology.
- Dark graphite/glass shell with square artwork, tighter grids, cleaner mini-player, and artwork-derived Now Playing backdrop.
- Now Playing gives artwork/title/artist/playback controls visual priority and moves provider/debug details out of the core flow.
- Settings now surfaces autoplay and the music-quality behavior in plain language.

## Safety / boundaries
- Existing MediaSafety validation remains in front of permanent offline storage.
- DRM/Widevine/paywall decryption is not bypassed.
- Session cookies/auth tokens remain ephemeral and are not persisted merely to improve resumption.
