# SidePlay v0.8.0 — Music-first Native Search → Native Play

> v0.8.0 product pass: music-first search, best-available original audio selection, no forced lossy audio transcode for offline music, Media3 music buffering/offload tuning, autoplay, and a content-first dark player UI. SidePlay preserves source quality; it does not invent lossless quality when a provider only exposes lossy media.

This build makes the Snaptube-style path the default on Android: search on-device (yt-dlp YouTube/SoundCloud with independent YouTube search fallback), resolve provider media locally, and hand the resulting clear stream to the persistent Media3 service for foreground/background playback. External YouTube handoff is opt-in instead of the default escape path. Extractor-backed sessions persist only the durable public source URL; if the temporary CDN URL expires or Android recreates the playback service, SidePlay re-runs the extractor instead of persisting browser credentials. DRM/decryption/paywall bypass remains intentionally unsupported.

# SidePlay v0.6.1 — Snaptube-style engine + Background Fortress

This release keeps the v0.6 yt-dlp/FFmpeg provider engine and hardens Android background playback itself. SidePlay-owned native media lives in a Media3 `MediaSessionService`, uses network wake mode, survives Activity/task removal while a media item exists, retries transient failures, reconnects when Android reports network availability again, and stores a **safe** resumption snapshot for stable/local media so Media3/Bluetooth controls can resume after service recreation.

Session-cookie/browser captures are intentionally different: SidePlay does **not** persist Cookie/Authorization/CSRF headers just to make them resume after process death. Those streams stay ephemeral and are re-resolved through the extractor/catcher when SidePlay is active. This preserves the privacy boundary introduced in v0.5.x.

GitHub deploy is now first-class: `.github/workflows/build-apk.yml` builds either expanded source or a source ZIP, verifies the final APK with `apksigner`, `zipalign` and `aapt2 dump badging`, uploads an Actions artifact on every build, and publishes a GitHub Release on `v*` tags when a persistent Android signing keystore is configured via repository secrets. See `GITHUB_DEPLOY.md`.

See `CHANGELOG_V0.6.1.md`, `ENGINE_AUDIT_V0.6.1.md`, and `THIRD_PARTY_NOTICES.md`.

---

# SidePlay v0.5.1 — ANYWHERE / WHATEVER

SidePlay now follows a split trust model: **be aggressive about playback; be strict about saving files.** Paste/share/open a clear media source and SidePlay tries direct Media3 playback first, public-page resolution next, then the browser-session Media Catcher when JavaScript/session context is required.

Playback coverage now includes progressive HTTP(S), HLS, DASH, **RTSP**, broad audio/video containers, extensionless CDN endpoints identified by MIME/signature, public HTML5/OpenGraph/Twitter media, PeerTube, public `.m3u`/`.pls` radio playlists, Android Share/Open-with media, local imports and browser-captured session streams. Short-lived browser captures are refreshed when stale or after a playback failure instead of being treated like permanent URLs.

Downloads are deliberately more conservative than playback. Offline Vault validates URL/name/MIME plus the first bytes of the actual response, rejects executable/package/script/archive/document payloads masquerading as media, blocks dangerous double extensions, enforces a 4 GiB ceiling/storage reserve, and avoids leaking session credentials across unrelated redirect hosts.

**Boundary:** SidePlay does not decrypt DRM, defeat encrypted manifests, bypass paywalls/authentication, or rip provider-owned protected media. “Whatever” here means clear playable media legitimately exposed to the device or the user's authorized browser session.

See `CHANGELOG_V0.5.1.md` for the full hardening list.

---

# SidePlay v0.5.0 — PLAY-WHATEVER Media Catcher

v0.5.0 adds a stronger Android fallback for web pages that do not expose their media in initial HTML. **Media Catcher** opens the page in an in-app SidePlay WebView, watches the clear media requests generated while the user starts playback, ranks likely progressive/HLS/DASH resources, validates them, and hands the selected URL to Media3 together with the request context it needs (MIME type, Referer, User-Agent, cookies and other safe captured headers).

That means SidePlay is no longer limited to obvious `.mp3`, `.mp4`, `.m3u8` or OpenGraph links. Extensionless CDN media and JavaScript-created players can work when the page ultimately requests a clear playable stream. SidePlay still does **not** decrypt DRM, defeat encrypted manifests, or bypass authentication/paywalls.

Captured progressive files can use the same header/session context for Offline Vault downloads. Captured HLS/DASH remains online playback only in this release.

For Echo speakers, Settings now includes **Alexa / Echo output**: it opens Android Bluetooth pairing so a paired Echo can act as SidePlay's normal Media3 audio output. Full “Alexa, play … on SidePlay” voice invocation would still require an Alexa Skill/cloud integration.


## v0.4.6 YouTube app + Web bridge

Android YouTube playback now has three selectable handoff modes: **Auto**, **YT app**, and **Web**. The Web route opens the exact YouTube watch URL in the detected browser and SidePlay can attach to that browser's Android media session when the browser exposes one. SidePlay verifies the external session title before showing it as connected.

# SidePlay v0.4.1 — Universal Player + Provider Bridge

SidePlay is now built around one rule: **if a source gives SidePlay a real playable media resource, SidePlay owns playback natively.** On Android that means Media3 + `MediaSessionService`, not a hidden browser player.

## What v0.4.1 can do

- Play direct audio/video URLs through the native Android player.
- Play HLS (`.m3u8`) and DASH (`.mpd`) streams online.
- Resolve public PeerTube watch links through the PeerTube instance API.
- Resolve standard public HTML5/OpenGraph audio/video exposed by ordinary web pages.
- Keep SidePlay-owned media playing after Home, app switching and screen-off.
- Expose Android media notification / lock-screen / Bluetooth controls.
- Download real progressive direct/PeerTube media files into SidePlay's private offline vault.
- Import audio or video files from the phone into the same vault.
- Receive links and media from Android **Share / Open with SidePlay**.
- Play downloaded/imported media with no network connection.
- Hand exact YouTube video IDs to the official YouTube Android app; with YouTube Premium, background/screen-off playback is provider-owned and SidePlay can mirror media controls after you return.
- Keep the optional Spotify handoff adapter as an advanced bridge rather than the core playback engine.

## Provider capability model

SidePlay does **not** label every web page “downloadable.” The source resolver reports what it actually has:

| Source | SidePlay native play | SidePlay offline save |
| --- | --- | --- |
| Direct progressive audio/video | Yes | Yes |
| PeerTube public progressive file | Yes | Yes |
| PeerTube HLS-only stream | Yes | Not yet |
| HLS / DASH direct stream | Yes | Not yet |
| Local/shared phone file | Yes | Already local / imported |
| YouTube page | Official-app handoff on Android; foreground embed fallback | Provider-managed offline only |
| Spotify | Optional provider handoff | No |
| SoundCloud page | Provider/open-source unless authorized stream is supplied | No hidden-stream scraping |

This keeps the universal player useful without pretending SidePlay has rights or technical access to media a provider has not exposed.

## UX changes

v0.4.1 keeps the v0.4 button cleanup and removes more fake provider actions. Track rows now have the track itself, an optional download button when a real download is available, and one **More** button. Like, Play next, Queue, Playlist, Offline/Import and Open source live in one action sheet. Mobile navigation is only **Home / Search / Library / Offline**; Queue opens from Now Playing. Mini-player spacing was adjusted so it no longer sits on top of bottom navigation.

## Offline downloads

The Android offline vault stores actual bytes in SidePlay's app-private files directory. Downloads are written to a temporary `.part` file and committed only after success. Download progress is reported into the UI. Imported audio/video uses the same vault. Deleting an offline item deletes the actual local file.

## Build Android

For phone-only development, upload the release ZIP to your GitHub repository root and use `.github/workflows/build-apk.yml`. The workflow builds, zipaligns, explicitly signs, verifies and uploads a `SidePlay-v0.4.1-SIGNED-APK` artifact.

For Windows development, the existing `BUILD_SIDEPLAY_APK.bat` / `START_SIDEPLAY.bat` paths remain in the project.

## Main files

- `src/App.tsx` — universal UX and playback orchestration
- `src/lib/universalSource.ts` — source capability model / resolver wrapper
- `src/lib/offlineMedia.ts` — vault import/download API
- `native/android/SourceResolverPlugin.java` — direct + PeerTube + public HTML5 resolver
- `native/android/OfflineMediaPlugin.java` — real download/import vault
- `native/android/PlaybackService.java` — Media3 background player
- `native/android/BackgroundAudioPlugin.java` — controller bridge
- `native/android/SharedTextPlugin.java` — Android Share/Open receiver
- `native/android/ProviderSessionPlugin.java` — official-provider launch + Android media-session mirror
- `scripts/patch-android.mjs` — generated Android project patcher

See `CHANGELOG_V0.4.1.md` and `UNIVERSAL_PLAYER.md` for details.


## v0.4.6 — browser handoff repair

- Browser route consults Android's Browser role first, so the real system default (for example Brave) wins over stale remembered choices.
- Settings can explicitly pin a browser or follow the system default.
- Browser MediaSessions are discovered dynamically and scored by selected-video metadata instead of relying only on a hard-coded package list.
- YouTube app and Web handoffs arm a short native auto-return watcher. When provider playback becomes active, SidePlay attempts to bring its own task back automatically and reconnect.
- Pending UI now says `CONNECTING` rather than instructing the user to tap Back.
- PiP remains disabled.

## HOTFIX2 package validation
The Windows builder now regenerates stale generated Android shells when necessary, runs `cap sync android`, performs a clean app package build, and only emits `SidePlay-INSTALL.apk` after Android SDK `apksigner`, `zipalign`, and `aapt dump badging` all accept the exact APK. `VERIFY_SIDEPLAY_APK.bat` repeats those checks, while `INSTALL_SIDEPLAY_USB.bat` uses `adb install` to expose the phone's exact PackageManager error without automatically uninstalling anything.
