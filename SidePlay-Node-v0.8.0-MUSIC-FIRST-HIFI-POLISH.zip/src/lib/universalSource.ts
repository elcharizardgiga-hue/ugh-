import { registerPlugin } from '@capacitor/core'
import type { MediaKind, MediaProvider, Track } from '../types'
import { isNative } from './nativeAudio'
import { resolveWithYtDlp } from './ytDlp'

export type SourceResolution = {
  id: string
  title: string
  artist?: string
  thumbnail?: string
  provider: MediaProvider
  sourceUrl: string
  playbackUrl?: string
  downloadUrl?: string
  providerUri?: string
  mediaKind?: MediaKind
  mimeType?: string
  requestHeaders?: Record<string, string>
  sessionBound?: boolean
  durationMs?: number
  playable: boolean
  downloadable: boolean
  downloadEngine?: 'direct' | 'ytdlp'
  refreshMode?: 'extractor' | 'capture'
  audioPreferred?: boolean
  note?: string
}

type SourceResolverPlugin = {
  resolve(options: { url: string }): Promise<SourceResolution>
  capture(options: { url: string }): Promise<SourceResolution>
  openExternal(options: { url: string }): Promise<void>
}

const SourceResolver = registerPlugin<SourceResolverPlugin>('SourceResolver')

const DIRECT_MEDIA = /\.(mp3|mp2|mpga|m4a|m4b|aac|adts|ac3|eac3|ec3|ac4|amr|3ga|oga|ogg|opus|flac|wav|mp4|m4v|mov|3gp|webm|mkv|mka|flv|f4v|mpg|mpeg|mpegts|m2ts|mts|ts|m3u8|mpd)(?:$|[?#])/i
const SEGMENTED_MEDIA = /\.(m3u8|mpd)(?:$|[?#])/i

function stableId(input: string) {
  let hash = 2166136261
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i)
    hash = Math.imul(hash, 16777619)
  }
  return `src-${(hash >>> 0).toString(36)}`
}

export function isHttpUrl(value: string) {
  try {
    const u = new URL(value)
    return u.protocol === 'http:' || u.protocol === 'https:' || u.protocol === 'rtsp:'
  } catch { return false }
}

export function isWebPageUrl(value: string) {
  try {
    const u = new URL(value)
    return u.protocol === 'http:' || u.protocol === 'https:'
  } catch { return false }
}

function inferKind(url: string, mimeType = ''): MediaKind {
  const m = mimeType.toLowerCase()
  if (m.startsWith('video/') || /\.(mp4|m4v|mov|3gp|webm|mkv|flv|f4v|mpg|mpeg|mpegts|m2ts|mts|ts)(?:$|[?#])/i.test(url) || url.toLowerCase().startsWith('rtsp:')) return 'video'
  return 'audio'
}

function browserResolve(url: string): SourceResolution {
  const u = new URL(url)
  const host = u.hostname.toLowerCase()
  if (u.protocol === 'rtsp:') {
    return { id: stableId(url), title: decodeURIComponent(u.pathname.split('/').pop() || 'RTSP stream'), artist: host || 'RTSP', provider: 'direct', sourceUrl: url, playbackUrl: url, mediaKind: 'video', playable: true, downloadable: false, note: 'RTSP live playback is supported in the Android app. Live RTSP streams are not saved by the offline downloader.' }
  }
  if (host === 'open.spotify.com' || host.endsWith('.spotify.com')) {
    const m = u.pathname.match(/\/track\/([A-Za-z0-9]+)/)
    return {
      id: stableId(url), title: 'Spotify track', artist: 'Spotify', provider: 'spotify', sourceUrl: url,
      providerUri: m ? `spotify:track:${m[1]}` : undefined, playable: false, downloadable: false,
      note: 'Spotify links use provider handoff; Spotify audio is not downloaded by SidePlay.',
    }
  }
  if (host === 'soundcloud.com' || host.endsWith('.soundcloud.com')) {
    return { id: stableId(url), title: 'SoundCloud', artist: host, provider: 'soundcloud', sourceUrl: url, playable: false, downloadable: false, note: 'This SoundCloud page needs an authorized SoundCloud stream URL/API integration.' }
  }
  if (DIRECT_MEDIA.test(url)) {
    const segmented = /\.(m3u8|mpd)(?:$|[?#])/i.test(url)
    return { id: stableId(url), title: decodeURIComponent(u.pathname.split('/').pop() || 'Direct media'), artist: host, provider: 'direct', sourceUrl: url, playbackUrl: url, downloadUrl: segmented ? undefined : url, mediaKind: inferKind(url), playable: true, downloadable: !segmented }
  }
  return { id: stableId(url), title: u.hostname, artist: 'Web link', provider: 'unknown', sourceUrl: url, playable: false, downloadable: false, note: 'This page is not a direct media resource. SidePlay did not extract protected/hidden media from it.' }
}

export async function resolveUniversalUrl(url: string, options: { audioOnly?: boolean } = {}): Promise<SourceResolution> {
  if (!isHttpUrl(url)) throw new Error('Paste a valid http(s) or rtsp URL.')
  if (isNative()) {
    // RTSP and obvious direct files are faster and more reliable through SidePlay's
    // native resolver. Spotify remains provider/session handoff because its media is DRM-protected.
    const lower = url.toLowerCase()
    const spotify = /https?:\/\/(?:[^/]+\.)?spotify\.com\//i.test(url)
    if (lower.startsWith('rtsp:') || spotify) return SourceResolver.resolve({ url })
    if (DIRECT_MEDIA.test(url)) {
      const direct = await SourceResolver.resolve({ url })
      // Direct adaptive manifests are perfectly valid playback sources. For offline
      // use, route them through yt-dlp/FFmpeg so their segments/tracks can be
      // assembled into one verified media file instead of pretending they are
      // ordinary progressive downloads.
      if (SEGMENTED_MEDIA.test(url)) {
        return { ...direct, downloadable: true, downloadEngine: 'ytdlp' as const }
      }
      return direct
    }
    try {
      const extracted = await resolveWithYtDlp(url, !!options.audioOnly)
      if (extracted?.playbackUrl) return extracted
    } catch {
      // Fall through to SidePlay's static/public resolver. The caller can still
      // escalate to the interactive network catcher if no playable URL emerges.
    }
    return SourceResolver.resolve({ url })
  }
  return browserResolve(url)
}

/**
 * Android-only interactive fallback. Opens the source in an in-app WebView,
 * watches clear media requests created by the user's browser session, and returns
 * the selected stream plus the headers Media3 needs to replay it. No DRM/decryption.
 */
export async function captureUniversalUrl(url: string): Promise<SourceResolution> {
  if (!isWebPageUrl(url)) throw new Error('Media Catcher opens http(s) web pages. RTSP/direct streams do not need it.')
  if (!isNative()) throw new Error('Media Catcher is available in the Android APK.')
  const captured = await SourceResolver.capture({ url })
  return { ...captured, refreshMode: 'capture' as const }
}

export function resolutionToTrack(r: SourceResolution): Track {
  return {
    videoId: r.id,
    title: r.title || 'Untitled media',
    channel: r.artist || new URL(r.sourceUrl).hostname,
    thumbnail: r.thumbnail || '',
    provider: r.provider,
    sourceUrl: r.sourceUrl,
    playbackUrl: r.playbackUrl,
    downloadUrl: r.downloadUrl,
    providerUri: r.providerUri,
    mediaKind: r.mediaKind,
    mimeType: r.mimeType,
    requestHeaders: r.requestHeaders,
    sessionBound: r.sessionBound,
    refreshMode: r.refreshMode,
    downloadEngine: r.downloadEngine,
    capturedAt: r.sessionBound ? Date.now() : undefined,
    durationMs: r.durationMs,
    audioPreferred: r.audioPreferred,
  }
}

export async function openExternalUrl(url: string) {
  if (!isHttpUrl(url)) throw new Error('Invalid URL.')
  if (isNative()) return SourceResolver.openExternal({ url })
  if (url.toLowerCase().startsWith('rtsp:')) throw new Error('RTSP links need a native media app.')
  window.open(url, '_blank', 'noopener,noreferrer')
}

export function providerLabel(track: Track) {
  switch (track.provider) {
    case 'peertube': return 'PeerTube'
    case 'audius': return 'Audius'
    case 'direct': return 'Direct'
    case 'soundcloud': return 'SoundCloud'
    case 'spotify': return 'Spotify'
    case 'local': return 'Device'
    case 'youtube': return 'YouTube'
    default: return track.playbackUrl ? 'Direct' : 'Web'
  }
}
