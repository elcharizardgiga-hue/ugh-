import type { Track } from '../types'

const PEERTUBE_BASE = 'https://peertube.cpy.re'
const AUDIUS_BASE = 'https://api.audius.co'
const AUDIUS_APP_NAME = 'SidePlay'

function text(value: unknown, fallback = '') {
  return typeof value === 'string' && value.trim() ? value.trim() : fallback
}

function absolute(base: string, value: unknown) {
  const raw = text(value)
  if (!raw) return ''
  try { return new URL(raw, base).toString() } catch { return '' }
}

export async function searchPeerTube(query: string, limit = 10): Promise<Track[]> {
  const url = new URL('/api/v1/search/videos', PEERTUBE_BASE)
  url.searchParams.set('search', query)
  url.searchParams.set('count', String(Math.max(1, Math.min(20, limit))))
  url.searchParams.set('sort', '-match')
  url.searchParams.set('searchTarget', 'search-index')
  url.searchParams.set('skipCount', 'true')

  let res = await fetch(url)
  if (!res.ok) {
    // Some public instances do not enable the global index; retry against the
    // instance's federated/local catalog instead of making the whole search fail.
    url.searchParams.delete('searchTarget')
    res = await fetch(url)
  }
  if (!res.ok) throw new Error(`PeerTube search failed (${res.status}).`)
  const body = await res.json()
  const rows = Array.isArray(body?.data) ? body.data : []

  return rows.map((item: any): Track => {
    const uuid = text(item.uuid || item.shortUUID || item.id, `pt-${Math.random().toString(36).slice(2)}`)
    const origin = text(item.url) || absolute(PEERTUBE_BASE, item?.channel?.url) || `${PEERTUBE_BASE}/w/${uuid}`
    let originBase = PEERTUBE_BASE
    try { originBase = new URL(origin).origin } catch {}
    const thumb = absolute(originBase, item.thumbnailPath || item.previewPath)
    const channel = text(item?.channel?.displayName || item?.channel?.name || item?.account?.displayName || item?.account?.name, 'PeerTube')
    return {
      videoId: `peertube-${uuid}`,
      title: text(item.name, 'PeerTube video'),
      channel,
      thumbnail: thumb,
      provider: 'peertube',
      sourceUrl: origin,
      mediaKind: 'video',
      durationMs: Number(item.duration) > 0 ? Number(item.duration) * 1000 : undefined,
      publishedAt: text(item.publishedAt || item.createdAt),
    }
  })
}

export async function searchAudius(query: string, limit = 10): Promise<Track[]> {
  const url = new URL('/v1/tracks/search', AUDIUS_BASE)
  url.searchParams.set('query', query)
  url.searchParams.set('limit', String(Math.max(1, Math.min(20, limit))))
  url.searchParams.set('app_name', AUDIUS_APP_NAME)

  const res = await fetch(url)
  if (!res.ok) throw new Error(`Audius search failed (${res.status}).`)
  const body = await res.json()
  const rows = Array.isArray(body?.data) ? body.data : []

  return rows
    .filter((item: any) => item?.access?.stream !== false && item?.is_streamable !== false && item?.isStreamable !== false)
    .map((item: any): Track => {
      const id = text(item.id, `au-${Math.random().toString(36).slice(2)}`)
      const artwork = item?.artwork || {}
      const thumbnail = text(artwork['480x480'] || artwork._480x480 || artwork['150x150'] || artwork._150x150)
      const stream = `${AUDIUS_BASE}/v1/tracks/${encodeURIComponent(id)}/stream?app_name=${encodeURIComponent(AUDIUS_APP_NAME)}`
      const explicitDownload = item?.access?.download
      const downloadable = explicitDownload === true || (explicitDownload !== false && Boolean(item.is_downloadable ?? item.isDownloadable ?? item.downloadable) && !item.download_conditions && !item.downloadConditions)
      const rawPermalink = text(item.permalink)
      const sourceUrl = rawPermalink ? (rawPermalink.startsWith('http') ? rawPermalink : `https://audius.co${rawPermalink.startsWith('/') ? '' : '/'}${rawPermalink}`) : `https://audius.co/tracks/${id}`
      return {
        videoId: `audius-${id}`,
        title: text(item.title, 'Audius track'),
        channel: text(item?.user?.name || item?.user?.handle, 'Audius'),
        thumbnail,
        provider: 'audius',
        sourceUrl,
        playbackUrl: stream,
        downloadUrl: downloadable ? `${AUDIUS_BASE}/v1/tracks/${encodeURIComponent(id)}/download?app_name=${encodeURIComponent(AUDIUS_APP_NAME)}` : undefined,
        mediaKind: 'audio',
        mimeType: 'audio/mpeg',
        durationMs: Number(item.duration) > 0 ? Number(item.duration) * 1000 : undefined,
        publishedAt: text(item.release_date || item.releaseDate),
      }
    })
}

export function interleaveSources(groups: Track[][]): Track[] {
  const result: Track[] = []
  const seen = new Set<string>()
  const max = Math.max(0, ...groups.map((g) => g.length))
  for (let i = 0; i < max; i++) {
    for (const group of groups) {
      const track = group[i]
      if (!track) continue
      const key = `${track.provider || 'unknown'}:${track.videoId}`
      if (seen.has(key)) continue
      seen.add(key)
      result.push(track)
    }
  }
  return result
}
