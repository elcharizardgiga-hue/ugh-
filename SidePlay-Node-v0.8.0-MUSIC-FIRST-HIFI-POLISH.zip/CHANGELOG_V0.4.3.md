# SidePlay v0.4.3 — Automatic YouTube bridge return

This release focuses on the three failures seen in v0.4.2: the wrong browser opening, SidePlay missing a browser media session that Android was already showing, and the manual “tap Back” handoff.

## Fixed

- Browser selection now consults Android `RoleManager.ROLE_BROWSER` before remembered browser history.
- The previous sticky browser preference key was retired so an old Samsung Internet selection cannot keep overriding a new system default.
- Added an explicit browser selector in SidePlay settings: follow System default or pin an installed browser such as Brave.
- Browser session discovery now dynamically recognizes installed browsers and scores active MediaSessions using package, playback state, selected title and media id.
- Status polling passes the selected YouTube title/video id into native session discovery, reducing false “NO SESSION” results.
- Exact YouTube links add `autoplay=1` for the Web route.
- YouTube app and Web handoffs arm a native 12-second watcher. When playback becomes active, SidePlay makes a best-effort `AppTask.moveToFront()` return and immediately reconnects through the existing app-state sync path.
- Notification-listener updates provide a second auto-return signal for media notifications. No notification text is stored.
- Pending player labels now say `CONNECTING` instead of `TAP BACK`.
- PiP remains disabled.

## Android limitation

Modern Android applies background-activity-launch policy. The auto-return uses SidePlay's own task and a user-initiated, short-lived handoff window, but the OS can still refuse to foreground the app on some builds. In that case playback/session mirroring still works when SidePlay is reopened manually; no protected stream extraction is used.
