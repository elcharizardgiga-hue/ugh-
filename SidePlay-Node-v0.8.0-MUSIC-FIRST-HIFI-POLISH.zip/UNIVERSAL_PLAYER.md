# SidePlay Universal Player

SidePlay v0.4.1 separates **discovery/provider links** from **playable media**.

A source adapter can return these capabilities:

- `playbackUrl`: SidePlay can play it itself.
- `downloadUrl`: SidePlay can save the real progressive file into its Android offline vault.
- `providerUri`: the provider app can be handed an exact provider identifier when supported.
- source-only: SidePlay can open the provider, but does not pretend it owns a stream it was not given.

## Native playback

On Android, `BackgroundAudioPlugin` sends SidePlay-owned media to `PlaybackService`, a Media3 `MediaSessionService`. That is the long-lived playback owner. The React UI is only a controller/view.

Supported SidePlay-owned inputs include normal progressive audio/video URLs, public HTML5/OpenGraph media, PeerTube, HLS, DASH and local vault files. HLS/DASH needs an online connection in this version. Progressive files can be saved for offline playback when the source exposes a downloadable URL.

## Offline vault

`OfflineMediaPlugin` stores actual bytes under SidePlay's app-private files directory. Downloads are written to a temporary `.part` file, then committed after completion. The library keeps the local file URI and metadata. Deleting the offline copy removes the vault file.

## Provider bridge

Protected providers stay provider-owned. On Android, YouTube results can be launched by exact video ID in the official YouTube app. For YouTube Premium users, the official app supplies background and screen-off playback. If the user grants Notification Access, SidePlay can mirror that Android media session for controls after returning with Back.

Spotify and SoundCloud remain optional provider bridges unless they expose an authorized/direct media resource. SidePlay does not convert those provider pages into hidden media URLs.

## Generic public web media

For ordinary websites, the resolver may follow media that the public HTML explicitly publishes through standard `og:audio`, `og:video`, `<audio>`, `<video>` or `<source>` fields. That broadens “paste almost anything” support without executing private APIs or bypassing DRM/authentication.
