# SidePlay v0.8.0 Engine Audit

## Verified in source
- Music-first yt-dlp search (`ytmsearch`) marks results audio-preferred.
- Audio-preferred provider resolution requests `bestaudio` and passes the result to native Media3.
- Signed provider URLs remain refreshable from the durable public source URL.
- Audio-preferred state is persisted separately from MIME/container, preventing Opus/WebM audio from accidentally re-resolving with the video profile after service recreation.
- Queue end/Next/Previous flows return the chosen item through the resolver/player path; play counts are recorded only once by `playNow`.
- Audio downloads no longer request an M4A transcode; they preserve the best source audio representation.
- Video downloads still support separate best-video + best-audio merge through FFmpeg.
- Media3 background service retains lock-screen/Bluetooth/media-session behavior.
- Media3 has separate streaming/local buffer targets, network wake mode, music audio attributes, noisy-route handling, and offload preferences requesting gapless support.
- Offline files still pass MediaSafety metadata + signature checks before entering the vault.
- TypeScript/TSX syntax transpile audit passes for the source tree.

## Deliberately not claimed
- No artificial "lossless upscaling". Output quality is bounded by the source representation.
- Crossfade is not advertised as implemented in v0.8.0.
- Loudness normalization is not advertised as implemented in v0.8.0.
- DRM-protected streams remain out of scope.

## Validation performed in this workspace
- Full TS/TSX/MTS source tree passed a TypeScript transpile syntax audit.
- Android patcher executed successfully against a generated Android shell and registered/copied the v0.8.0 native playback/extractor files.
- `YtDlpPlugin.java` + `PlaybackService.java` passed a Javac compile smoke test against Android/Media3/Capacitor API stubs updated for the v0.8.0 code path.
- GitHub Actions workflow YAML parses successfully and targets the v0.8.0 release artifact.
- A full local `npm install`/Gradle build could not be completed in this sandbox because dependencies are not preinstalled and package installation timed out; the included GitHub workflow installs dependencies and performs the actual release build, zipalign, signing, `apksigner` verification, and `aapt2` package parsing.
