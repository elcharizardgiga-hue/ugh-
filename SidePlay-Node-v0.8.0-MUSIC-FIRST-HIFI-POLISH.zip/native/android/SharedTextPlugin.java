package app.sideplay.mobile;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "SharedText")
public class SharedTextPlugin extends Plugin {
    @PluginMethod
    public void getInitialShare(PluginCall call) {
        JSObject result = new JSObject();
        Intent intent = getActivity().getIntent();
        if (intent == null) { call.resolve(result); return; }

        String action = intent.getAction();
        String type = intent.getType();
        result.put("mimeType", type == null ? "" : type);

        if (Intent.ACTION_SEND.equals(action)) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null && !text.trim().isEmpty()) result.put("text", text);

            Uri stream = null;
            try {
                if (android.os.Build.VERSION.SDK_INT >= 33) stream = intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
                else stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            } catch (Exception ignored) {}
            if (stream != null) putUri(result, stream, type);
        } else if (Intent.ACTION_VIEW.equals(action)) {
            Uri data = intent.getData();
            if (data != null) {
                String scheme = data.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) result.put("text", data.toString());
                else putUri(result, data, type);
            }
        }
        // Consume this intent so a running SidePlay can poll for future shares without replaying the same item.
        try { intent.setAction(null); } catch (Exception ignored) {}
        call.resolve(result);
    }

    private void putUri(JSObject result, Uri uri, String type) {
        result.put("uri", uri.toString());
        String name = queryName(uri);
        if (name != null && !name.trim().isEmpty()) result.put("name", name);
        if ((type == null || type.isEmpty()) && getContext() != null) {
            try {
                String resolved = getContext().getContentResolver().getType(uri);
                if (resolved != null) result.put("mimeType", resolved);
            } catch (Exception ignored) {}
        }
    }

    private String queryName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContext().getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return null;
    }
}
