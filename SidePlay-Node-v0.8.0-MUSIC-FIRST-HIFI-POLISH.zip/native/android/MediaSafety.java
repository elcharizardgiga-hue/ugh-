package app.sideplay.mobile;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Download/import safety gate. Playback is intentionally permissive, but files
 * entering SidePlay's persistent vault must actually look like media and must
 * not look like executable/package/script/archive payloads.
 */
public final class MediaSafety {
    public static final long MAX_OFFLINE_BYTES = 4L * 1024L * 1024L * 1024L; // 4 GiB hard safety ceiling.
    public static final long STORAGE_RESERVE_BYTES = 192L * 1024L * 1024L;

    private static final Set<String> BLOCKED_EXTENSIONS = new HashSet<>(Arrays.asList(
        "apk", "apks", "xapk", "aab", "dex", "exe", "dll", "com", "scr", "msi", "msp", "msix", "appx",
        "bat", "cmd", "ps1", "psm1", "vbs", "vbe", "js", "jse", "wsf", "wsh", "hta", "reg", "lnk",
        "sh", "bash", "zsh", "fish", "command", "jar", "class", "war", "ear",
        "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "cab", "iso", "img", "dmg", "pkg", "deb", "rpm"
    ));

    private static final Set<String> SAFE_MEDIA_EXTENSIONS = new HashSet<>(Arrays.asList(
        "mp3", "mp2", "mpga", "m4a", "m4b", "aac", "adts", "ac3", "eac3", "ec3", "ac4", "amr", "3ga",
        "oga", "ogg", "opus", "flac", "wav", "mp4", "m4v", "mov", "3gp", "webm", "mkv", "mka", "flv", "f4v",
        "mpg", "mpeg", "mpegts", "ts", "mts", "m2ts"
    ));

    private MediaSafety() {}

    public static void validateMetadata(String finalUrl, String disposition, String mimeType, String requestedName) throws Exception {
        String mime = stripParams(mimeType);
        if (isDangerousMime(mime)) throw new Exception("Blocked potentially executable/package content type: " + mime + ".");
        if (!mime.isBlank() && !isMediaMime(mime) && !isGenericBinaryMime(mime)) {
            throw new Exception("Server returned " + mime + " instead of an audio/video file.");
        }

        String responseName = filenameFrom(finalUrl, disposition);
        rejectDangerousName(responseName);
        rejectDangerousName(requestedName);
        rejectDangerousName(pathName(finalUrl));
    }

    public static void validatePrefix(byte[] bytes, int length, String mimeType, String nameHint) throws Exception {
        if (bytes == null || length <= 0) throw new Exception("Downloaded file was empty.");
        int n = Math.min(length, bytes.length);
        String mime = stripParams(mimeType);

        if (looksExecutableOrArchive(bytes, n)) {
            throw new Exception("Blocked a file whose contents look executable, packaged, scripted, or archived rather than media.");
        }
        if (looksHtmlOrJson(bytes, n)) {
            throw new Exception("The URL returned a web/document payload rather than playable media.");
        }

        // A truthful audio/video MIME is enough once dangerous signatures are ruled out.
        // Generic binary/unknown responses need positive media evidence to avoid trusting
        // a misleading .mp3/.mp4 filename alone.
        if (!isMediaMime(mime) && !looksLikeMedia(bytes, n)) {
            String ext = extension(nameHint);
            if (!SAFE_MEDIA_EXTENSIONS.contains(ext)) {
                throw new Exception("SidePlay could not verify that this binary response is actually audio/video media.");
            }
            // Even with a media-looking filename, require a recognizable container/frame
            // for generic binary downloads. Playback can still use odd streams online.
            throw new Exception("The server labeled this as generic binary data and its file signature did not look like supported media. SidePlay refused to save it.");
        }
    }

    public static boolean isMediaMime(String value) {
        String mime = stripParams(value);
        return mime.startsWith("audio/") || mime.startsWith("video/") || mime.equals("application/ogg");
    }

    public static boolean isGenericBinaryMime(String value) {
        String mime = stripParams(value);
        return mime.isBlank() || mime.equals("application/octet-stream") || mime.equals("binary/octet-stream") || mime.equals("application/binary");
    }

    public static String stripParams(String value) {
        if (value == null) return "";
        int semi = value.indexOf(';');
        return (semi >= 0 ? value.substring(0, semi) : value).trim().toLowerCase(Locale.ROOT);
    }

    private static boolean isDangerousMime(String mime) {
        if (mime == null || mime.isBlank()) return false;
        return mime.contains("android.package") || mime.contains("java-archive") || mime.contains("x-java") ||
            mime.contains("x-msdownload") || mime.contains("x-msdos-program") || mime.contains("x-executable") ||
            mime.contains("x-sh") || mime.contains("shellscript") || mime.contains("powershell") ||
            mime.contains("x-bat") || mime.contains("x-rar") || mime.contains("zip") || mime.contains("7z") ||
            mime.contains("x-tar") || mime.contains("gzip") || mime.contains("x-iso9660");
    }

    private static void rejectDangerousName(String raw) throws Exception {
        String ext = extension(raw);
        if (!ext.isBlank() && BLOCKED_EXTENSIONS.contains(ext)) {
            throw new Exception("Blocked unsafe download type ." + ext + ". SidePlay only saves verified media files.");
        }
        String lower = raw == null ? "" : raw.toLowerCase(Locale.ROOT);
        // Catch double-extension tricks such as song.mp3.exe even if callers later
        // sanitize or replace the visible filename.
        for (String bad : BLOCKED_EXTENSIONS) {
            if (lower.matches(".*\\." + java.util.regex.Pattern.quote(bad) + "(?:[?#].*)?$")) {
                throw new Exception("Blocked unsafe download filename.");
            }
        }
    }

    private static boolean looksExecutableOrArchive(byte[] b, int n) {
        if (n >= 2 && b[0] == 'M' && b[1] == 'Z') return true; // PE/Windows executable
        if (n >= 4 && u(b[0]) == 0x7F && b[1] == 'E' && b[2] == 'L' && b[3] == 'F') return true;
        if (n >= 8 && asciiStarts(b, n, "dex\n")) return true;
        if (n >= 4 && u(b[0]) == 0x50 && u(b[1]) == 0x4B && (u(b[2]) == 0x03 || u(b[2]) == 0x05 || u(b[2]) == 0x07)) return true; // ZIP/APK/JAR
        if (n >= 6 && b[0] == 'R' && b[1] == 'a' && b[2] == 'r' && b[3] == '!' && u(b[4]) == 0x1A && u(b[5]) == 0x07) return true;
        if (n >= 6 && u(b[0]) == 0x37 && u(b[1]) == 0x7A && u(b[2]) == 0xBC && u(b[3]) == 0xAF && u(b[4]) == 0x27 && u(b[5]) == 0x1C) return true;
        if (n >= 4) {
            long magic = ((long)u(b[0]) << 24) | ((long)u(b[1]) << 16) | ((long)u(b[2]) << 8) | u(b[3]);
            if (magic == 0xCAFEBABEL || magic == 0xFEEDFACEL || magic == 0xCEFAEDFEL || magic == 0xFEEDFACFL || magic == 0xCFFAEDFEL) return true;
        }
        String lead = asciiLead(b, n, 96).trim().toLowerCase(Locale.ROOT);
        return lead.startsWith("#!") || lead.startsWith("@echo off") || lead.startsWith("powershell") || lead.startsWith("windows registry editor");
    }

    private static boolean looksHtmlOrJson(byte[] b, int n) {
        String lead = asciiLead(b, n, 512).trim().toLowerCase(Locale.ROOT);
        return lead.startsWith("<!doctype html") || lead.startsWith("<html") || lead.startsWith("<head") ||
            lead.startsWith("<body") || lead.startsWith("<?xml") || lead.startsWith("{") || lead.startsWith("[");
    }

    public static boolean looksLikeMediaPrefix(byte[] b, int n) { return looksLikeMedia(b, n); }

    private static boolean looksLikeMedia(byte[] b, int n) {
        if (n >= 3 && b[0] == 'I' && b[1] == 'D' && b[2] == '3') return true;
        if (n >= 4 && asciiStarts(b, n, "fLaC")) return true;
        if (n >= 4 && asciiStarts(b, n, "OggS")) return true;
        if (n >= 12 && asciiStarts(b, n, "RIFF") && b[8] == 'W' && b[9] == 'A' && b[10] == 'V' && b[11] == 'E') return true;
        if (n >= 8 && b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p') return true;
        if (n >= 4 && u(b[0]) == 0x1A && u(b[1]) == 0x45 && u(b[2]) == 0xDF && u(b[3]) == 0xA3) return true; // EBML/WebM/MKV
        if (n >= 3 && asciiStarts(b, n, "FLV")) return true;
        if (n >= 5 && asciiStarts(b, n, "#!AMR")) return true;
        if (n >= 2 && u(b[0]) == 0x0B && u(b[1]) == 0x77) return true; // AC-3/E-AC-3 sync
        if (n >= 2 && u(b[0]) == 0xFF && (u(b[1]) & 0xE0) == 0xE0) return true; // MP3/AAC ADTS style sync
        if (n >= 4 && u(b[0]) == 0x00 && u(b[1]) == 0x00 && u(b[2]) == 0x01 && (u(b[3]) == 0xBA || u(b[3]) == 0xB3)) return true; // MPEG PS/video
        if (n >= 188 && u(b[0]) == 0x47 && (n < 377 || u(b[188]) == 0x47)) return true; // MPEG-TS packets
        return false;
    }

    private static int u(byte b) { return b & 0xFF; }

    private static boolean asciiStarts(byte[] bytes, int length, String text) {
        byte[] wanted = text.getBytes(StandardCharsets.ISO_8859_1);
        if (length < wanted.length) return false;
        for (int i = 0; i < wanted.length; i++) if (bytes[i] != wanted[i]) return false;
        return true;
    }

    private static String asciiLead(byte[] bytes, int length, int max) {
        int n = Math.min(Math.min(length, bytes.length), max);
        return new String(bytes, 0, n, StandardCharsets.ISO_8859_1).replace("\u0000", "");
    }

    private static String filenameFrom(String rawUrl, String disposition) {
        if (disposition != null) {
            String lower = disposition.toLowerCase(Locale.ROOT);
            int utf = lower.indexOf("filename*=utf-8''");
            if (utf >= 0) {
                String value = disposition.substring(utf + 17).split(";", 2)[0].replace("\"", "").trim();
                try { return URLDecoder.decode(value, "UTF-8"); } catch (Exception ignored) {}
            }
            int plain = lower.indexOf("filename=");
            if (plain >= 0) {
                String value = disposition.substring(plain + 9).split(";", 2)[0].replace("\"", "").trim();
                if (!value.isBlank()) return value;
            }
        }
        return pathName(rawUrl);
    }

    private static String pathName(String raw) {
        try {
            String path = URI.create(raw).getPath();
            if (path == null || path.isBlank()) return "";
            int slash = path.lastIndexOf('/');
            String name = slash >= 0 ? path.substring(slash + 1) : path;
            try { return URLDecoder.decode(name, "UTF-8"); } catch (Exception ignored) { return name; }
        } catch (Exception ignored) { return raw == null ? "" : raw; }
    }

    private static String extension(String raw) {
        if (raw == null) return "";
        String value = raw.toLowerCase(Locale.ROOT);
        int q = value.indexOf('?'); if (q >= 0) value = value.substring(0, q);
        int h = value.indexOf('#'); if (h >= 0) value = value.substring(0, h);
        int slash = Math.max(value.lastIndexOf('/'), value.lastIndexOf('\\'));
        int dot = value.lastIndexOf('.');
        if (dot <= slash || dot + 1 >= value.length()) return "";
        return value.substring(dot + 1).replaceAll("[^a-z0-9]", "");
    }
}
