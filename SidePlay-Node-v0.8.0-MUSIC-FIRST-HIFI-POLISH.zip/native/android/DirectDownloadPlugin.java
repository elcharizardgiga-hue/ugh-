package app.sideplay.mobile;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.webkit.URLUtil;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

/** Legacy public-download bridge. The Offline Vault is preferred, but this path
 * now performs a media-only preflight before Android DownloadManager can save it. */
@CapacitorPlugin(name = "DirectDownload")
public class DirectDownloadPlugin extends Plugin {
    @PluginMethod
    public void start(PluginCall call) {
        String raw = call.getString("url");
        if (raw == null || !(raw.startsWith("https://") || raw.startsWith("http://"))) {
            call.reject("Only http(s) direct media URLs are supported.");
            return;
        }
        final String url = raw.trim();
        final String requested = call.getString("filename");

        try {
            String host = Uri.parse(url).getHost();
            String h = host == null ? "" : host.toLowerCase(Locale.ROOT);
            if (h.equals("youtube.com") || h.endsWith(".youtube.com") || h.equals("youtu.be") || h.endsWith(".googlevideo.com") ||
                h.endsWith("spotify.com") || h.endsWith("scdn.co") || h.endsWith("soundcloud.com") || h.endsWith("sndcdn.com")) {
                call.reject("This provider does not expose this file for SidePlay downloads.");
                return;
            }
        } catch (Exception ignored) {}

        new Thread(() -> {
            try {
                Preflight probe = preflight(url, requested);
                String filename = (requested == null || requested.trim().isEmpty())
                    ? URLUtil.guessFileName(probe.finalUrl, probe.disposition, probe.mimeType)
                    : sanitize(requested.trim());
                filename = sanitize(filename);
                MediaSafety.validateMetadata(probe.finalUrl, probe.disposition, probe.mimeType, filename);

                DownloadManager manager = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(probe.finalUrl));
                request.setTitle(filename);
                request.setDescription("Verified media download by SidePlay");
                request.setMimeType(probe.mimeType.isBlank() ? "application/octet-stream" : probe.mimeType);
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setAllowedOverMetered(true);
                request.setAllowedOverRoaming(true);

                String destination;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                    destination = "Downloads/" + filename;
                } else {
                    request.setDestinationInExternalFilesDir(getContext(), Environment.DIRECTORY_DOWNLOADS, filename);
                    destination = "SidePlay app files/Downloads/" + filename;
                }

                long id = manager.enqueue(request);
                JSObject out = new JSObject();
                out.put("id", Long.toString(id));
                out.put("destination", destination);
                out.put("verifiedMedia", true);
                call.resolve(out);
            } catch (Exception e) {
                call.reject("SidePlay refused that download: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
            }
        }, "SidePlaySafeDirectDownload").start();
    }

    private Preflight preflight(String raw, String requested) throws Exception {
        URL current = new URL(raw);
        for (int redirect = 0; redirect <= 5; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(15000);
            connection.setRequestProperty("User-Agent", "SidePlay/0.5.1 Android");
            connection.setRequestProperty("Accept", "audio/*,video/*,application/octet-stream;q=0.7,*/*;q=0.1");
            connection.setRequestProperty("Range", "bytes=0-8191");
            int code = connection.getResponseCode();
            if (code == HttpURLConnection.HTTP_MOVED_PERM || code == HttpURLConnection.HTTP_MOVED_TEMP || code == HttpURLConnection.HTTP_SEE_OTHER || code == 307 || code == 308) {
                String location = connection.getHeaderField("Location");
                if (location == null || location.isBlank()) throw new Exception("Redirect did not provide a destination.");
                URL next = new URL(current, location);
                connection.disconnect();
                if (!(next.getProtocol().equalsIgnoreCase("http") || next.getProtocol().equalsIgnoreCase("https"))) throw new Exception("Unsafe redirect scheme.");
                current = next;
                continue;
            }
            if (code < 200 || code >= 300) {
                connection.disconnect();
                throw new Exception("Server returned HTTP " + code + ".");
            }

            String mime = MediaSafety.stripParams(connection.getContentType());
            String disposition = connection.getHeaderField("Content-Disposition");
            long total = connection.getContentLengthLong();
            if (total > MediaSafety.MAX_OFFLINE_BYTES) {
                connection.disconnect();
                throw new Exception("File exceeds the 4 GiB media-download safety limit.");
            }
            MediaSafety.validateMetadata(connection.getURL().toString(), disposition, mime, requested);
            byte[] prefix = new byte[8192];
            int n;
            try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream())) {
                n = input.read(prefix);
            } finally {
                connection.disconnect();
            }
            MediaSafety.validatePrefix(prefix, n, mime, requested == null ? connectionName(current) : requested);
            return new Preflight(current.toString(), mime, disposition == null ? "" : disposition);
        }
        throw new Exception("Too many redirects.");
    }

    private static String connectionName(URL url) {
        String path = url == null ? "" : url.getPath();
        if (path == null || path.isBlank()) return "media";
        int slash = path.lastIndexOf('/');
        return slash >= 0 ? path.substring(slash + 1) : path;
    }

    private String sanitize(String input) {
        String value = input == null ? "media" : input.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return value.isBlank() ? "media" : value;
    }

    private static final class Preflight {
        final String finalUrl;
        final String mimeType;
        final String disposition;
        Preflight(String finalUrl, String mimeType, String disposition) {
            this.finalUrl = finalUrl == null ? "" : finalUrl;
            this.mimeType = mimeType == null ? "" : mimeType;
            this.disposition = disposition == null ? "" : disposition;
        }
    }
}
