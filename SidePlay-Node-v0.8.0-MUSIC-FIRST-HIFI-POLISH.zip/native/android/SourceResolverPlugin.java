package app.sideplay.mobile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@CapacitorPlugin(name = "SourceResolver")
public class SourceResolverPlugin extends Plugin {
    private static final int CONNECT_TIMEOUT = 9000;
    private static final int READ_TIMEOUT = 12000;
    public static final int REQUEST_CAPTURE = 9433;
    private static PluginCall pendingCaptureCall;
    private static SourceResolverPlugin activeCapturePlugin;

    @PluginMethod
    public void resolve(PluginCall call) {
        String raw = call.getString("url");
        if (raw == null || raw.trim().isEmpty()) {
            call.reject("A URL is required.");
            return;
        }
        final String url = raw.trim();
        if (!(url.startsWith("https://") || url.startsWith("http://") || url.startsWith("rtsp://"))) {
            call.reject("Only http(s) and rtsp URLs are supported.");
            return;
        }

        new Thread(() -> {
            try {
                call.resolve(resolveInternal(url));
            } catch (Exception e) {
                call.reject("Could not resolve media URL: " + safe(e));
            }
        }, "SidePlaySourceResolver").start();
    }


    @PluginMethod
    public void capture(PluginCall call) {
        String raw = call.getString("url");
        if (raw == null || raw.trim().isEmpty()) {
            call.reject("A URL is required.");
            return;
        }
        String url = raw.trim();
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            call.reject("Only http(s) URLs are supported.");
            return;
        }
        if (pendingCaptureCall != null) {
            call.reject("A media capture browser is already open.");
            return;
        }
        pendingCaptureCall = call;
        activeCapturePlugin = this;
        try {
            Intent intent = new Intent(getContext(), MediaCaptureActivity.class);
            intent.putExtra(MediaCaptureActivity.EXTRA_URL, url);
            getActivity().startActivityForResult(intent, REQUEST_CAPTURE);
        } catch (Exception e) {
            pendingCaptureCall = null;
            activeCapturePlugin = null;
            call.reject("Could not open SidePlay media catcher: " + safe(e));
        }
    }

    public static boolean handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQUEST_CAPTURE || pendingCaptureCall == null) return false;
        PluginCall call = pendingCaptureCall;
        pendingCaptureCall = null;
        activeCapturePlugin = null;

        if (resultCode != Activity.RESULT_OK || data == null) {
            call.reject("Media capture cancelled.");
            return true;
        }
        try {
            String source = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_SOURCE_URL));
            String playback = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_PLAYBACK_URL));
            if (playback.isBlank()) {
                call.reject("No playable media stream was captured.");
                return true;
            }
            String title = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_TITLE));
            String artist = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_ARTIST));
            String mime = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_MIME_TYPE));
            String kind = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_MEDIA_KIND));
            String download = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_DOWNLOAD_URL));
            String headersJson = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_HEADERS_JSON));
            String note = nvl(data.getStringExtra(MediaCaptureActivity.EXTRA_NOTE));

            JSObject out = base(stableId(source + "|" + playback), title.isBlank() ? filenameFrom(playback, "") : title, artist, "direct", source.isBlank() ? playback : source);
            out.put("playbackUrl", playback);
            if (!download.isBlank()) out.put("downloadUrl", download);
            if (!mime.isBlank()) out.put("mimeType", mime);
            if (!kind.isBlank()) out.put("mediaKind", kind);
            if (!headersJson.isBlank()) {
                try { out.put("requestHeaders", new JSONObject(headersJson)); } catch (Exception ignored) {}
            }
            out.put("playable", true);
            out.put("downloadable", !download.isBlank());
            out.put("sessionBound", true);
            if (!note.isBlank()) out.put("note", note);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Could not finish media capture: " + safe(e));
        }
        return true;
    }

    @PluginMethod
    public void openExternal(PluginCall call) {
        String raw = call.getString("url");
        if (raw == null || raw.trim().isEmpty()) {
            call.reject("A URL is required.");
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(raw.trim()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open link: " + safe(e));
        }
    }

    private JSObject resolveInternal(String raw) throws Exception {
        URI uri = URI.create(raw);
        String host = lower(uri.getHost());
        String path = uri.getPath() == null ? "" : uri.getPath();

        if ("rtsp".equalsIgnoreCase(uri.getScheme())) {
            JSObject out = base(stableId(raw), filenameFrom(raw, ""), host.isBlank() ? "RTSP" : host, "direct", raw);
            out.put("playbackUrl", raw);
            out.put("mediaKind", "video");
            out.put("playable", true);
            out.put("downloadable", false);
            out.put("note", "RTSP live playback is supported by SidePlay's native Media3 engine. RTSP streams are not saved by the offline downloader.");
            return out;
        }

        if (isYouTubeHost(host)) {
            String videoId = youtubeId(uri);
            String canonical = videoId == null ? raw : "https://www.youtube.com/watch?v=" + videoId;
            JSObject out = providerOnly(canonical, "youtube", "YouTube video", "YouTube",
                videoId == null ? null : "youtube:" + videoId,
                "On Android, SidePlay can hand the exact video to the official YouTube app. With YouTube Premium, that app can keep audio playing in the background/screen-off. SidePlay does not extract or rip YouTube media streams.");
            if (videoId != null) {
                out.put("id", videoId);
                out.put("mediaKind", "video");
                try {
                    JSONObject meta = getJson("https://www.youtube.com/oembed?format=json&url=" + enc(canonical));
                    String title = meta.optString("title", "");
                    if (!title.isBlank()) out.put("title", title);
                    String author = meta.optString("author_name", "");
                    if (!author.isBlank()) out.put("artist", author);
                    String thumb = meta.optString("thumbnail_url", "");
                    if (!thumb.isBlank()) out.put("thumbnail", thumb);
                } catch (Exception ignored) {}
            }
            return out;
        }

        if (isSpotifyHost(host)) {
            String spotifyUri = spotifyUri(path);
            JSObject out = providerOnly(raw, "spotify", "Spotify track", "Spotify", spotifyUri,
                "Spotify links use provider/session handoff. Spotify audio is not downloaded by SidePlay.");
            try {
                JSONObject meta = getJson("https://open.spotify.com/oembed?url=" + enc(raw));
                String title = meta.optString("title", "");
                if (!title.isBlank()) out.put("title", title);
                String thumb = meta.optString("thumbnail_url", "");
                if (!thumb.isBlank()) out.put("thumbnail", thumb);
            } catch (Exception ignored) {}
            return out;
        }

        if (isSoundCloudHost(host)) {
            JSObject out = providerOnly(raw, "soundcloud", "SoundCloud", host, null,
                "This SoundCloud page needs an authorized SoundCloud API stream. SidePlay does not scrape or rip hidden SoundCloud streams.");
            try {
                JSONObject meta = getJson("https://soundcloud.com/oembed?format=json&url=" + enc(raw));
                String title = meta.optString("title", "");
                if (!title.isBlank()) out.put("title", title);
                String author = meta.optString("author_name", "");
                if (!author.isBlank()) out.put("artist", author);
                String thumb = meta.optString("thumbnail_url", "");
                if (!thumb.isBlank()) out.put("thumbnail", thumb);
            } catch (Exception ignored) {}
            return out;
        }

        String peerId = peerTubeId(path);
        if (peerId != null) {
            try {
                return resolvePeerTube(raw, uri, peerId);
            } catch (Exception ignored) {
                // Not every /w/... URL is PeerTube. Fall through to direct-content probing.
            }
        }

        String lowerPath = path.toLowerCase(Locale.ROOT);
        if (lowerPath.endsWith(".pls") || (lowerPath.endsWith(".m3u") && !lowerPath.endsWith(".m3u8"))) {
            String stream = resolvePublicRadioPlaylist(raw);
            if (stream != null && !stream.isBlank()) {
                Probe streamProbe = probe(stream);
                if (streamProbe.playable) {
                    JSObject out = base(stableId(raw + "|" + streamProbe.finalUrl), filenameFrom(raw, ""), host, "direct", raw);
                    out.put("playbackUrl", streamProbe.finalUrl);
                    out.put("mediaKind", isVideo(streamProbe.finalUrl, streamProbe.contentType) ? "video" : "audio");
                    if (!streamProbe.contentType.isBlank()) out.put("mimeType", streamProbe.contentType);
                    out.put("playable", true);
                    out.put("downloadable", false);
                    out.put("note", "SidePlay unwrapped the public radio playlist and is playing its live stream. Live playlist streams are not saved as offline files.");
                    return out;
                }
            }
        }

        Probe probe = probe(raw);
        if (probe.playable) {
            boolean segmented = isSegmented(raw, probe.contentType);
            String filename = filenameFrom(raw, probe.contentDisposition);
            JSObject out = base(stableId(raw), filename.isBlank() ? host : filename, host, "direct", raw);
            out.put("playbackUrl", probe.finalUrl);
            if (!segmented) out.put("downloadUrl", probe.finalUrl);
            out.put("mediaKind", isVideo(raw, probe.contentType) ? "video" : "audio");
            if (!probe.contentType.isBlank()) out.put("mimeType", probe.contentType);
            out.put("playable", true);
            out.put("downloadable", !segmented);
            if (segmented) out.put("note", "Segmented HLS/DASH playback is supported online; this build only saves progressive media files for offline playback.");
            return out;
        }

        try {
            JSObject discovered = discoverPublicHtmlMedia(raw, uri, host);
            if (discovered != null) return discovered;
        } catch (Exception ignored) {}

        JSObject out = base(stableId(raw), host.isBlank() ? "Web link" : host, "Web link", "unknown", raw);
        out.put("playable", false);
        out.put("downloadable", false);
        out.put("note", "No static media URL was exposed by the initial page response. On Android, SidePlay can open Media Catcher to watch clear media requests created by the browser session. DRM/encrypted playback is not bypassed.");
        return out;
    }


    private String resolvePublicRadioPlaylist(String raw) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(raw).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            conn.setReadTimeout(READ_TIMEOUT);
            conn.setRequestProperty("User-Agent", "SidePlay/0.5.1 Android");
            conn.setRequestProperty("Accept", "audio/x-scpls,audio/x-mpegurl,text/plain,*/*;q=0.2");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 400) return null;
            StringBuilder body = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                int remaining = 256 * 1024;
                while (remaining > 0 && (line = reader.readLine()) != null) {
                    remaining -= line.length() + 1;
                    String trimmed = line.trim();
                    if (trimmed.isBlank() || trimmed.startsWith("#") || trimmed.equalsIgnoreCase("[playlist]")) continue;
                    if (trimmed.regionMatches(true, 0, "File", 0, 4)) {
                        int eq = trimmed.indexOf('=');
                        if (eq > 0) trimmed = trimmed.substring(eq + 1).trim();
                    }
                    if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed;
                    body.append(trimmed).append('\n');
                }
            }
            Matcher url = Pattern.compile("https?://[^\\s\\\"'<>]+", Pattern.CASE_INSENSITIVE).matcher(body);
            return url.find() ? url.group() : null;
        } catch (Exception ignored) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /**
     * Conservative generic page resolver. It only follows media URLs that a normal
     * public HTML document explicitly publishes through standard HTML5/OpenGraph
     * fields. It does not execute page JavaScript, inspect private APIs, decrypt
     * manifests, or look behind authentication.
     */
    private JSObject discoverPublicHtmlMedia(String source, URI page, String host) throws Exception {
        HtmlPage html = fetchHtml(source);
        if (html == null || html.body.isBlank()) return null;

        String[] patterns = new String[] {
            "<meta[^>]+property=[\\\"']og:audio(?::url)?[\\\"'][^>]+content=[\\\"']([^\\\"']+)[\\\"']",
            "<meta[^>]+content=[\\\"']([^\\\"']+)[\\\"'][^>]+property=[\\\"']og:audio(?::url)?[\\\"']",
            "<meta[^>]+property=[\\\"']og:video(?::url)?[\\\"'][^>]+content=[\\\"']([^\\\"']+)[\\\"']",
            "<meta[^>]+content=[\\\"']([^\\\"']+)[\\\"'][^>]+property=[\\\"']og:video(?::url)?[\\\"']",
            "<meta[^>]+(?:name|property)=[\\\"']twitter:(?:player:stream|audio|video)[\\\"'][^>]+content=[\\\"']([^\\\"']+)[\\\"']",
            "<meta[^>]+content=[\\\"']([^\\\"']+)[\\\"'][^>]+(?:name|property)=[\\\"']twitter:(?:player:stream|audio|video)[\\\"']",
            "<(?:audio|video)[^>]+src=[\\\"']([^\\\"']+)[\\\"']",
            "<source[^>]+src=[\\\"']([^\\\"']+)[\\\"']",
            "[\\\"'](?:contentUrl|streamUrl|playbackUrl|fileUrl)[\\\"']\\s*:\\s*[\\\"'](https?:\\\\?/\\\\?/[^\\\"']+)[\\\"']",
            "[\\\"'](https?:\\\\?/\\\\?/[^\\\"']+\\.(?:m3u8|mpd|mp4|m4a|mp3|webm|mkv|flac|ogg|opus)(?:\\?[^\\\"']*)?)[\\\"']"
        };

        for (String regex : patterns) {
            Matcher matcher = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(html.body);
            int checked = 0;
            while (matcher.find() && checked++ < 8) {
                String candidate = decodeHtml(matcher.group(1)).replace("\\/", "/").trim();
                if (candidate.isBlank() || candidate.startsWith("blob:") || candidate.startsWith("data:")) continue;
                String absolute = resolveAgainst(source, candidate);
                if (!(absolute.startsWith("https://") || absolute.startsWith("http://"))) continue;
                Probe probe = probe(absolute);
                if (!probe.playable) continue;

                boolean segmented = isSegmented(probe.finalUrl, probe.contentType);
                String title = html.title.isBlank() ? filenameFrom(probe.finalUrl, probe.contentDisposition) : html.title;
                JSObject out = base(stableId(source + "|" + probe.finalUrl), title, host, "direct", source);
                out.put("playbackUrl", probe.finalUrl);
                if (!segmented) out.put("downloadUrl", probe.finalUrl);
                out.put("mediaKind", isVideo(probe.finalUrl, probe.contentType) ? "video" : "audio");
                if (!probe.contentType.isBlank()) out.put("mimeType", probe.contentType);
                out.put("requestHeaders", pagePlaybackHeaders(source));
                out.put("playable", true);
                out.put("downloadable", !segmented);
                out.put("note", segmented
                    ? "This page publicly exposed an HTML5 HLS/DASH stream. SidePlay can play it natively online."
                    : "This page publicly exposed a standard HTML5 media file. SidePlay can play and save the actual file.");
                return out;
            }
        }
        return null;
    }

    private HtmlPage fetchHtml(String raw) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(raw).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            conn.setReadTimeout(READ_TIMEOUT);
            conn.setRequestProperty("User-Agent", "SidePlay/0.5.1 Android");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.2");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 400) return null;
            String type = stripParams(conn.getContentType());
            if (!type.isBlank() && !type.contains("html")) return null;
            StringBuilder sb = new StringBuilder();
            try (InputStream in = conn.getInputStream(); InputStreamReader ir = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                char[] buffer = new char[8192];
                int read;
                int remaining = 768 * 1024;
                while (remaining > 0 && (read = ir.read(buffer, 0, Math.min(buffer.length, remaining))) != -1) {
                    sb.append(buffer, 0, read);
                    remaining -= read;
                }
            }
            String body = sb.toString();
            String title = "";
            Matcher tm = Pattern.compile("<title[^>]*>(.*?)</title>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(body);
            if (tm.find()) title = decodeHtml(tm.group(1)).replaceAll("\\s+", " ").trim();
            return new HtmlPage(body, title);
        } catch (Exception ignored) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String resolveAgainst(String base, String candidate) {
        try { return URI.create(base).resolve(candidate).toString(); }
        catch (Exception e) { return candidate; }
    }

    private static String decodeHtml(String value) {
        if (value == null) return "";
        return value.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">");
    }

    private static String youtubeId(URI uri) {
        if (uri == null) return null;
        String host = lower(uri.getHost());
        String path = uri.getPath() == null ? "" : uri.getPath();
        if (host.equals("youtu.be")) {
            String id = path.startsWith("/") ? path.substring(1) : path;
            int slash = id.indexOf('/');
            if (slash >= 0) id = id.substring(0, slash);
            return validYouTubeId(id) ? id : null;
        }
        if (path.startsWith("/shorts/") || path.startsWith("/embed/") || path.startsWith("/live/")) {
            String id = path.substring(path.indexOf('/', 1) + 1);
            int slash = id.indexOf('/');
            if (slash >= 0) id = id.substring(0, slash);
            return validYouTubeId(id) ? id : null;
        }
        String query = uri.getRawQuery();
        if (query != null) {
            for (String pair : query.split("&")) {
                int eq = pair.indexOf('=');
                if (eq > 0 && pair.substring(0, eq).equals("v")) {
                    try {
                        String id = java.net.URLDecoder.decode(pair.substring(eq + 1), "UTF-8");
                        return validYouTubeId(id) ? id : null;
                    } catch (Exception ignored) {}
                }
            }
        }
        return null;
    }

    private static boolean validYouTubeId(String id) {
        return id != null && id.matches("[A-Za-z0-9_-]{6,20}");
    }

    private JSObject resolvePeerTube(String source, URI page, String id) throws Exception {
        String origin = page.getScheme() + "://" + page.getHost() + (page.getPort() > 0 ? ":" + page.getPort() : "");
        JSONObject video = getJson(origin + "/api/v1/videos/" + encPath(id));
        String title = video.optString("name", "PeerTube video");
        String artist = "PeerTube";
        JSONObject channel = video.optJSONObject("channel");
        if (channel != null) artist = firstNonBlank(channel.optString("displayName", ""), channel.optString("name", ""), artist);
        JSONObject account = video.optJSONObject("account");
        if ((artist.equals("PeerTube") || artist.isBlank()) && account != null) artist = firstNonBlank(account.optString("displayName", ""), account.optString("name", ""), "PeerTube");

        String thumbnail = absolute(origin, video.optString("thumbnailPath", ""));
        long durationMs = Math.max(0L, video.optLong("duration", 0L) * 1000L);

        Candidate progressive = bestProgressive(video.optJSONArray("files"));
        JSONArray playlists = video.optJSONArray("streamingPlaylists");
        if (progressive == null && playlists != null) {
            for (int i = 0; i < playlists.length(); i++) {
                JSONObject list = playlists.optJSONObject(i);
                if (list == null) continue;
                Candidate nested = bestProgressive(list.optJSONArray("files"));
                if (nested != null && (progressive == null || nested.height > progressive.height)) progressive = nested;
            }
        }

        String hls = "";
        if (playlists != null) {
            for (int i = 0; i < playlists.length(); i++) {
                JSONObject list = playlists.optJSONObject(i);
                if (list == null) continue;
                String candidate = list.optString("playlistUrl", "");
                if (!candidate.isBlank()) { hls = candidate; break; }
            }
        }

        String playback = progressive != null ? firstNonBlank(progressive.fileUrl, progressive.downloadUrl, "") : hls;
        if (playback.isBlank()) throw new Exception("PeerTube did not expose a public playable file/playlist.");
        String download = progressive == null ? "" : firstNonBlank(progressive.downloadUrl, progressive.fileUrl, "");

        JSObject out = base(firstNonBlank(video.optString("uuid", ""), stableId(source)), title, artist, "peertube", source);
        out.put("playbackUrl", playback);
        if (!download.isBlank()) out.put("downloadUrl", download);
        out.put("mediaKind", "video");
        out.put("playable", true);
        out.put("downloadable", !download.isBlank());
        if (!thumbnail.isBlank()) out.put("thumbnail", thumbnail);
        if (durationMs > 0) out.put("durationMs", durationMs);
        if (progressive != null && !progressive.mimeType.isBlank()) out.put("mimeType", progressive.mimeType);
        out.put("note", download.isBlank()
            ? "PeerTube HLS playback is available, but this instance did not expose a progressive downloadable file."
            : "PeerTube public media resolved directly for native background playback and offline save.");
        return out;
    }

    private Candidate bestProgressive(JSONArray files) {
        if (files == null) return null;
        Candidate best = null;
        for (int i = 0; i < files.length(); i++) {
            JSONObject f = files.optJSONObject(i);
            if (f == null) continue;
            String fileUrl = f.optString("fileUrl", "");
            String downloadUrl = f.optString("fileDownloadUrl", "");
            if (fileUrl.isBlank() && downloadUrl.isBlank()) continue;
            int height = 0;
            JSONObject resolution = f.optJSONObject("resolution");
            if (resolution != null) height = resolution.optInt("id", 0);
            String mime = ""; // PeerTube file payloads do not consistently expose MIME.
            Candidate c = new Candidate(fileUrl, downloadUrl, height, mime);
            if (best == null || c.height > best.height) best = c;
        }
        return best;
    }

    private Probe probe(String raw) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(raw).openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            conn.setReadTimeout(READ_TIMEOUT);
            conn.setRequestMethod("HEAD");
            conn.setRequestProperty("User-Agent", "SidePlay/0.5.1 Android");
            int code = conn.getResponseCode();
            if (code == HttpURLConnection.HTTP_BAD_METHOD || code == HttpURLConnection.HTTP_NOT_IMPLEMENTED) {
                conn.disconnect();
                conn = (HttpURLConnection) new URL(raw).openConnection();
                conn.setInstanceFollowRedirects(true);
                conn.setConnectTimeout(CONNECT_TIMEOUT);
                conn.setReadTimeout(READ_TIMEOUT);
                conn.setRequestProperty("Range", "bytes=0-0");
                conn.setRequestProperty("User-Agent", "SidePlay/0.5.1 Android");
                code = conn.getResponseCode();
            }
            String type = stripParams(conn.getContentType());
            String finalUrl = conn.getURL().toString();
            String disposition = nvl(conn.getHeaderField("Content-Disposition"));
            boolean playable = isPlayableContent(type) || looksDirectMedia(finalUrl);
            if (!playable && (type.isBlank() || type.equals("application/octet-stream") || type.equals("binary/octet-stream") || type.equals("text/plain") || type.contains("xml"))) {
                Probe sniffed = sniffProbe(finalUrl, disposition);
                if (sniffed.playable) return sniffed;
            }
            return new Probe(playable, finalUrl, type, disposition);
        } catch (Exception ignored) {
            return new Probe(looksDirectMedia(raw), raw, "", "");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private Probe sniffProbe(String raw, String disposition) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(raw).openConnection();
            connection.setInstanceFollowRedirects(true);
            connection.setConnectTimeout(CONNECT_TIMEOUT);
            connection.setReadTimeout(READ_TIMEOUT);
            connection.setRequestProperty("Range", "bytes=0-8191");
            connection.setRequestProperty("User-Agent", "SidePlay/0.5.1 Android");
            connection.setRequestProperty("Accept", "audio/*,video/*,application/octet-stream,text/plain,application/xml,*/*;q=0.2");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 400) return new Probe(false, raw, "", disposition);
            byte[] prefix = new byte[8192];
            int n;
            try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream())) { n = input.read(prefix); }
            String finalUrl = connection.getURL().toString();
            if (n <= 0) return new Probe(false, finalUrl, "", disposition);
            String lead = new String(prefix, 0, Math.min(n, 1024), StandardCharsets.UTF_8).trim();
            if (lead.startsWith("#EXTM3U")) return new Probe(true, finalUrl, "application/x-mpegURL", disposition);
            if (lead.startsWith("<MPD") || lead.contains("<MPD ") || lead.contains("<MPD>")) return new Probe(true, finalUrl, "application/dash+xml", disposition);
            if (MediaSafety.looksLikeMediaPrefix(prefix, n)) return new Probe(true, finalUrl, "application/octet-stream", disposition);
        } catch (Exception ignored) {
        } finally {
            if (connection != null) connection.disconnect();
        }
        return new Probe(false, raw, "", disposition);
    }

    private JSONObject getJson(String raw) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(raw).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(CONNECT_TIMEOUT);
        conn.setReadTimeout(READ_TIMEOUT);
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("User-Agent", "SidePlay/0.5.1 Android");
        try {
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            try (InputStream in = conn.getInputStream(); BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                return new JSONObject(sb.toString());
            }
        } finally {
            conn.disconnect();
        }
    }

    private static JSObject pagePlaybackHeaders(String source) {
        JSObject headers = new JSObject();
        headers.put("User-Agent", "SidePlay/0.5.1 Android");
        if (source != null && !source.isBlank()) headers.put("Referer", source);
        return headers;
    }

    private JSObject providerOnly(String source, String provider, String title, String artist, String providerUri, String note) {
        JSObject out = base(stableId(source), title, artist, provider, source);
        if (providerUri != null && !providerUri.isBlank()) out.put("providerUri", providerUri);
        out.put("playable", false);
        out.put("downloadable", false);
        out.put("note", note);
        return out;
    }

    private static JSObject base(String id, String title, String artist, String provider, String source) {
        JSObject out = new JSObject();
        out.put("id", id);
        out.put("title", title);
        out.put("artist", artist);
        out.put("provider", provider);
        out.put("sourceUrl", source);
        return out;
    }

    private static boolean isYouTubeHost(String h) { return h.equals("youtube.com") || h.endsWith(".youtube.com") || h.equals("youtu.be"); }
    private static boolean isSpotifyHost(String h) { return h.equals("open.spotify.com") || h.endsWith(".spotify.com"); }
    private static boolean isSoundCloudHost(String h) { return h.equals("soundcloud.com") || h.endsWith(".soundcloud.com"); }

    private static String peerTubeId(String path) {
        if (path == null) return null;
        String[] patterns = {"/videos/watch/", "/w/", "/videos/embed/"};
        for (String p : patterns) {
            int at = path.indexOf(p);
            if (at >= 0) {
                String rest = path.substring(at + p.length());
                int slash = rest.indexOf('/');
                if (slash >= 0) rest = rest.substring(0, slash);
                if (!rest.isBlank()) return rest;
            }
        }
        return null;
    }

    private static String spotifyUri(String path) {
        if (path == null) return null;
        String[] bits = path.split("/");
        for (int i = 0; i < bits.length - 1; i++) {
            if (bits[i].equals("track") && !bits[i + 1].isBlank()) return "spotify:track:" + bits[i + 1];
        }
        return null;
    }

    private static boolean isPlayableContent(String type) {
        String t = lower(type);
        return t.startsWith("audio/") || t.startsWith("video/") || t.contains("mpegurl") || t.contains("dash+xml") || t.equals("application/ogg");
    }

    private static boolean isSegmented(String url, String type) {
        String u = lower(url);
        String t = lower(type);
        return u.matches(".*\\.(m3u8|mpd)(?:[?#].*)?$") || t.contains("mpegurl") || t.contains("dash+xml");
    }

    private static boolean looksDirectMedia(String url) {
        String u = lower(url);
        return u.matches(".*\\.(mp3|mp2|mpga|m4a|m4b|aac|adts|ac3|eac3|ec3|ac4|amr|3ga|oga|ogg|opus|flac|wav|mp4|m4v|mov|3gp|webm|mkv|mka|flv|f4v|mpg|mpeg|mpegts|m2ts|mts|ts|m3u8|mpd)(?:[?#].*)?$");
    }

    private static boolean isVideo(String url, String type) {
        String t = lower(type);
        String u = lower(url);
        return t.startsWith("video/") || u.matches(".*\\.(mp4|m4v|mov|3gp|webm|mkv|flv|f4v|mpg|mpeg|mpegts|m2ts|mts|ts|mpd)(?:[?#].*)?$");
    }

    private static String filenameFrom(String raw, String disposition) {
        if (disposition != null) {
            int p = lower(disposition).indexOf("filename=");
            if (p >= 0) {
                String n = disposition.substring(p + 9).replace("\"", "").trim();
                int semi = n.indexOf(';');
                if (semi >= 0) n = n.substring(0, semi);
                if (!n.isBlank()) return n;
            }
        }
        try {
            String path = URI.create(raw).getPath();
            if (path != null) {
                int slash = path.lastIndexOf('/');
                String n = slash >= 0 ? path.substring(slash + 1) : path;
                if (!n.isBlank()) return java.net.URLDecoder.decode(n, "UTF-8");
            }
        } catch (Exception ignored) {}
        return "Direct media";
    }

    private static String absolute(String origin, String value) {
        if (value == null || value.isBlank()) return "";
        if (value.startsWith("http://") || value.startsWith("https://")) return value;
        return origin + (value.startsWith("/") ? value : "/" + value);
    }

    private static String firstNonBlank(String... values) {
        for (String v : values) if (v != null && !v.isBlank()) return v;
        return "";
    }

    private static String stripParams(String value) {
        if (value == null) return "";
        int semi = value.indexOf(';');
        return (semi >= 0 ? value.substring(0, semi) : value).trim().toLowerCase(Locale.ROOT);
    }

    private static String lower(String value) { return value == null ? "" : value.toLowerCase(Locale.ROOT); }
    private static String nvl(String value) { return value == null ? "" : value; }
    private static String enc(String value) { try { return URLEncoder.encode(value, "UTF-8"); } catch (Exception e) { return value; } }
    private static String encPath(String value) { try { return URLEncoder.encode(value, "UTF-8").replace("+", "%20"); } catch (Exception e) { return value; } }
    private static String stableId(String value) { return "src-" + Integer.toUnsignedString(value.hashCode(), 36); }
    private static String safe(Exception e) { String m = e.getMessage(); return m == null || m.isBlank() ? e.getClass().getSimpleName() : m; }

    private static final class HtmlPage {
        final String body;
        final String title;
        HtmlPage(String body, String title) { this.body = body == null ? "" : body; this.title = title == null ? "" : title; }
    }

    private static final class Candidate {
        final String fileUrl;
        final String downloadUrl;
        final int height;
        final String mimeType;
        Candidate(String fileUrl, String downloadUrl, int height, String mimeType) {
            this.fileUrl = fileUrl == null ? "" : fileUrl;
            this.downloadUrl = downloadUrl == null ? "" : downloadUrl;
            this.height = height;
            this.mimeType = mimeType == null ? "" : mimeType;
        }
    }

    private static final class Probe {
        final boolean playable;
        final String finalUrl;
        final String contentType;
        final String contentDisposition;
        Probe(boolean playable, String finalUrl, String contentType, String contentDisposition) {
            this.playable = playable;
            this.finalUrl = finalUrl;
            this.contentType = contentType == null ? "" : contentType;
            this.contentDisposition = contentDisposition == null ? "" : contentDisposition;
        }
    }
}
