package app.sideplay.mobile;

import android.app.ActivityManager;
import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.List;

/**
 * User-authorized NotificationListener used by SidePlay to discover provider-owned
 * media sessions.
 *
 * v0.4.6 adds a second discovery path that is deliberately independent from
 * MediaSessionManager#getActiveSessions(): whenever Android posts a media
 * notification we cache its MediaSession.Token. Some browser builds expose a
 * perfectly functional media notification while their session is missing from
 * getActiveSessions() for a short time (or entirely). SidePlay can now attach
 * directly to the exact token Android put in that notification.
 */
public class SpotifySessionListenerService extends NotificationListenerService {
    private final Handler handler = new Handler(Looper.getMainLooper());

    private static volatile MediaSession.Token lastMediaToken;
    private static volatile String lastMediaPackage = "";
    private static volatile String lastMediaTitle = "";
    private static volatile String lastMediaText = "";
    private static volatile Notification.Action[] lastMediaActions = new Notification.Action[0];
    private static volatile boolean lastLikelyPlaying = false;
    private static volatile boolean lastLikelyPlayingKnown = false;
    private static volatile long lastMediaAt = 0L;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        super.onNotificationPosted(sbn);
        if (sbn == null) return;

        Notification n = sbn.getNotification();
        boolean mediaish = isMediaNotification(n);
        if (mediaish) cacheMediaNotification(sbn, n);

        SharedPreferences prefs = getSharedPreferences(ProviderSessionPlugin.PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(ProviderSessionPlugin.PREF_PENDING_RETURN, false)) return;

        long since = prefs.getLong(ProviderSessionPlugin.PREF_PENDING_SINCE, 0L);
        if (since <= 0L || System.currentTimeMillis() - since > 15000L) {
            clearPending(prefs);
            return;
        }
        if (!mediaish) return;

        String target = prefs.getString(ProviderSessionPlugin.PREF_PENDING_PACKAGE, "");
        String postedBy = sbn.getPackageName() == null ? "" : sbn.getPackageName();

        // Prefer the exact package SidePlay launched. If a browser delegates its
        // media notification to another package, still allow a one-shot return;
        // ProviderSessionPlugin will verify the actual controller before attaching.
        boolean exactPackage = !target.isEmpty() && target.equals(postedBy);
        long delay = exactPackage ? 250L : 650L;

        handler.postDelayed(() -> {
            if (moveSidePlayToFront()) clearPending(prefs);
        }, delay);
    }

    private static boolean isMediaNotification(Notification n) {
        if (n == null) return false;
        if (Notification.CATEGORY_TRANSPORT.equals(n.category)) return true;
        Bundle extras = n.extras;
        return extras != null && extras.containsKey(Notification.EXTRA_MEDIA_SESSION);
    }

    @SuppressWarnings("deprecation")
    private static MediaSession.Token tokenFrom(Notification n) {
        if (n == null || n.extras == null) return null;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                return n.extras.getParcelable(Notification.EXTRA_MEDIA_SESSION, MediaSession.Token.class);
            }
            return (MediaSession.Token) n.extras.getParcelable(Notification.EXTRA_MEDIA_SESSION);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String extraText(Notification n, String key) {
        if (n == null || n.extras == null) return "";
        try {
            CharSequence value = n.extras.getCharSequence(key);
            return value == null ? "" : value.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private static void cacheMediaNotification(StatusBarNotification sbn, Notification n) {
        MediaSession.Token token = tokenFrom(n);
        lastMediaToken = token;
        lastMediaPackage = sbn.getPackageName() == null ? "" : sbn.getPackageName();
        lastMediaTitle = extraText(n, Notification.EXTRA_TITLE);
        lastMediaText = extraText(n, Notification.EXTRA_TEXT);
        lastMediaActions = n != null && n.actions != null ? n.actions : new Notification.Action[0];
        boolean[] inferred = inferPlaying(lastMediaActions);
        lastLikelyPlayingKnown = inferred[0];
        lastLikelyPlaying = inferred[1];
        lastMediaAt = System.currentTimeMillis();
    }

    private static boolean[] inferPlaying(Notification.Action[] actions) {
        if (actions == null) return new boolean[] { false, false };
        for (Notification.Action action : actions) {
            String title = action == null || action.title == null ? "" : action.title.toString().toLowerCase();
            if (title.contains("pause") || title.contains("pausa") || title.contains("pausar")) return new boolean[] { true, true };
            if (title.equals("play") || title.contains("reproduc") || title.contains("resume") || title.contains("reanudar")) return new boolean[] { true, false };
        }
        return new boolean[] { false, false };
    }

    /** Return the most recently posted media controller when it is still fresh. */
    public static MediaController cachedController(Context context, String preferredPackage) {
        MediaSession.Token token = lastMediaToken;
        if (context == null || token == null) return null;
        if (System.currentTimeMillis() - lastMediaAt > 180000L) return null;
        if (preferredPackage != null && !preferredPackage.isEmpty()
            && !preferredPackage.equals(lastMediaPackage)) return null;
        try {
            return new MediaController(context, token);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String cachedPackage() { return lastMediaPackage == null ? "" : lastMediaPackage; }
    public static String cachedTitle() { return lastMediaTitle == null ? "" : lastMediaTitle; }
    public static String cachedText() { return lastMediaText == null ? "" : lastMediaText; }
    public static boolean cachedLikelyPlayingKnown() { return lastLikelyPlayingKnown; }
    public static boolean cachedLikelyPlaying() { return lastLikelyPlaying; }

    public static boolean sendCachedAction(String actionName, String preferredPackage) {
        if (System.currentTimeMillis() - lastMediaAt > 180000L) return false;
        if (preferredPackage != null && !preferredPackage.isEmpty() && !preferredPackage.equals(lastMediaPackage)) return false;
        Notification.Action[] actions = lastMediaActions;
        if (actions == null || actions.length == 0) return false;

        int index = findActionIndex(actions, actionName);
        if (index < 0 || index >= actions.length) return false;
        Notification.Action action = actions[index];
        if (action == null || action.actionIntent == null) return false;
        try {
            action.actionIntent.send();
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static int findActionIndex(Notification.Action[] actions, String actionName) {
        String wanted = actionName == null ? "" : actionName.toLowerCase();
        for (int i = 0; i < actions.length; i++) {
            Notification.Action action = actions[i];
            String title = action == null || action.title == null ? "" : action.title.toString().toLowerCase();
            if (wanted.equals("pause") && (title.contains("pause") || title.contains("pausa") || title.contains("pausar"))) return i;
            if (wanted.equals("play") && (title.equals("play") || title.contains("reproduc") || title.contains("resume") || title.contains("reanudar"))) return i;
            if (wanted.equals("next") && (title.contains("next") || title.contains("siguiente"))) return i;
            if (wanted.equals("previous") && (title.contains("previous") || title.contains("anterior") || title.contains("prev"))) return i;
        }

        // Media notifications conventionally place previous / play-pause / next
        // in that order. Use it only as a last resort when labels are localized.
        if (actions.length >= 3) {
            if (wanted.equals("previous")) return 0;
            if (wanted.equals("play") || wanted.equals("pause")) return actions.length / 2;
            if (wanted.equals("next")) return actions.length - 1;
        }
        return -1;
    }

    public static long cachedAgeMs() {
        if (lastMediaAt <= 0L) return Long.MAX_VALUE;
        return Math.max(0L, System.currentTimeMillis() - lastMediaAt);
    }

    private boolean moveSidePlayToFront() {
        try {
            ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            if (manager != null) {
                List<ActivityManager.AppTask> tasks = manager.getAppTasks();
                for (ActivityManager.AppTask task : tasks) {
                    try {
                        ActivityManager.RecentTaskInfo info = task.getTaskInfo();
                        Intent base = info == null ? null : info.baseIntent;
                        ComponentName component = base == null ? null : base.getComponent();
                        if (component == null || getPackageName().equals(component.getPackageName())) {
                            task.moveToFront();
                            return true;
                        }
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}

        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(launch);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void clearPending(SharedPreferences prefs) {
        prefs.edit()
            .remove(ProviderSessionPlugin.PREF_PENDING_RETURN)
            .remove(ProviderSessionPlugin.PREF_PENDING_PACKAGE)
            .remove(ProviderSessionPlugin.PREF_PENDING_SINCE)
            .apply();
    }
}
