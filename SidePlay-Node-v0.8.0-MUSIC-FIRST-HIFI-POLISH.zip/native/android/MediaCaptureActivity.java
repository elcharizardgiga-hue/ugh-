package app.sideplay.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Interactive browser-session media catcher used only as a fallback after the
 * normal public/direct resolver fails. It does not decrypt DRM or bypass login.
 * It simply watches the requests/resources produced by the page the user can
 * already open, then hands a playable clear media URL plus its request context
 * back to SidePlay's Media3 player.
 */
public class MediaCaptureActivity extends Activity {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_SOURCE_URL = "sourceUrl";
    public static final String EXTRA_PLAYBACK_URL = "playbackUrl";
    public static final String EXTRA_DOWNLOAD_URL = "downloadUrl";
    public static final String EXTRA_MIME_TYPE = "mimeType";
    public static final String EXTRA_MEDIA_KIND = "mediaKind";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_ARTIST = "artist";
    public static final String EXTRA_HEADERS_JSON = "headersJson";
    public static final String EXTRA_NOTE = "note";

    private static final int CONNECT_TIMEOUT = 8000;
    private static final int READ_TIMEOUT = 10000;
    private static final int MAX_CANDIDATES = 48;

    private final LinkedHashMap<String, Candidate> candidates = new LinkedHashMap<>();
    private WebView webView;
    private TextView status;
    private Button useButton;
    private String sourceUrl = "";
    private String pageUrl = "";
    private String pageTitle = "";
    private String userAgent = "";
    private volatile boolean resolving = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sourceUrl = getIntent().getStringExtra(EXTRA_URL);
        if (sourceUrl == null) sourceUrl = "";
        if (!(sourceUrl.startsWith("https://") || sourceUrl.startsWith("http://"))) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }
        pageUrl = sourceUrl;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(10, 12, 16));

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(dp(10), dp(8), dp(10), dp(8));
        toolbar.setGravity(android.view.Gravity.CENTER_VERTICAL);

        Button cancel = new Button(this);
        cancel.setText("Cancel");
        cancel.setOnClickListener(v -> finishCanceled());
        toolbar.addView(cancel, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(13f);
        status.setPadding(dp(10), 0, dp(10), 0);
        status.setText("Open/play the media on this page. SidePlay is listening…");
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        toolbar.addView(status, statusParams);

        useButton = new Button(this);
        useButton.setText("Use media");
        useButton.setEnabled(false);
        useButton.setOnClickListener(v -> resolveBestCandidate());
        toolbar.addView(useButton, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        root.addView(toolbar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        userAgent = settings.getUserAgentString();

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new CaptureBridge(), "SidePlayCapture");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onReceivedTitle(WebView view, String title) {
                if (title != null && !title.isBlank()) pageTitle = title.trim();
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri == null ? "" : lower(uri.getScheme());
                if (scheme.equals("http") || scheme.equals("https")) return false;
                return true;
            }

            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                try {
                    Uri uri = request.getUrl();
                    if (uri != null) observe(uri.toString(), request.getRequestHeaders(), "request");
                } catch (Exception ignored) {}
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) pageUrl = url;
                injectResourceMonitor();
                super.onPageFinished(view, url);
            }
        });

        webView.loadUrl(sourceUrl);
    }

    private void injectResourceMonitor() {
        if (webView == null) return;
        String script = "(function(){if(window.__sideplayCaptureInstalled)return;window.__sideplayCaptureInstalled=true;"
            + "function send(){try{var a=[];document.querySelectorAll('audio,video,source').forEach(function(el){var u=el.currentSrc||el.src;if(u)a.push({url:u,kind:(el.tagName||'media').toLowerCase()});});"
            + "if(window.performance&&performance.getEntriesByType){performance.getEntriesByType('resource').slice(-160).forEach(function(e){if(e&&e.name)a.push({url:e.name,kind:e.initiatorType||'resource'});});}"
            + "SidePlayCapture.report(JSON.stringify({url:location.href,title:document.title||'',items:a}));}catch(e){}}"
            + "document.addEventListener('play',send,true);document.addEventListener('loadedmetadata',send,true);setInterval(send,900);send();})();";
        webView.evaluateJavascript(script, null);
    }

    private final class CaptureBridge {
        @JavascriptInterface
        public void report(String json) {
            if (json == null || json.isBlank()) return;
            try {
                JSONObject payload = new JSONObject(json);
                String url = payload.optString("url", "");
                if (url.startsWith("http://") || url.startsWith("https://")) pageUrl = url;
                String title = payload.optString("title", "");
                if (!title.isBlank()) pageTitle = title.trim();
                JSONArray items = payload.optJSONArray("items");
                if (items == null) return;
                int start = Math.max(0, items.length() - 160);
                for (int i = start; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item == null) continue;
                    observe(item.optString("url", ""), Collections.emptyMap(), item.optString("kind", "resource"));
                }
            } catch (Exception ignored) {}
        }
    }

    private void observe(String raw, Map<String, String> requestHeaders, String reason) {
        if (raw == null) return;
        String url = raw.trim();
        if (!(url.startsWith("https://") || url.startsWith("http://"))) return;
        if ((looksLikeSegment(url) && !strongMediaObservation(reason, requestHeaders)) || looksLikeNonMediaAsset(url)) return;

        int score = score(url, reason, requestHeaders);
        if (score < 20) return;

        synchronized (candidates) {
            Candidate c = candidates.get(url);
            if (c == null) {
                if (candidates.size() >= MAX_CANDIDATES) {
                    String oldest = candidates.keySet().iterator().next();
                    candidates.remove(oldest);
                }
                c = new Candidate(url);
                candidates.put(url, c);
            }
            c.score = Math.max(c.score, score);
            c.lastSeen = System.currentTimeMillis();
            c.reason = reason == null ? "" : reason;
            if (requestHeaders != null) {
                for (Map.Entry<String, String> entry : requestHeaders.entrySet()) {
                    if (entry.getKey() != null && entry.getValue() != null && !entry.getValue().isBlank()) {
                        c.headers.put(entry.getKey(), entry.getValue());
                    }
                }
            }
        }
        runOnUiThread(this::updateCandidateStatus);
    }

    private void updateCandidateStatus() {
        if (resolving || useButton == null) return;
        int count;
        Candidate best = null;
        synchronized (candidates) {
            count = candidates.size();
            for (Candidate c : candidates.values()) if (best == null || effectiveScore(c) > effectiveScore(best)) best = c;
        }
        useButton.setEnabled(count > 0);
        if (count > 0 && best != null) {
            String host = host(best.url);
            status.setText("Detected " + count + " media candidate" + (count == 1 ? "" : "s") + (host.isBlank() ? "." : " · " + host));
        }
    }

    private void resolveBestCandidate() {
        if (resolving) return;
        resolving = true;
        useButton.setEnabled(false);
        status.setText("Checking detected streams…");

        new Thread(() -> {
            try {
                List<Candidate> ordered;
                synchronized (candidates) { ordered = new ArrayList<>(candidates.values()); }
                ordered.sort(Comparator.comparingInt(this::effectiveScore).reversed());

                Probe fallback = null;
                Candidate fallbackCandidate = null;
                int checked = 0;
                for (Candidate candidate : ordered) {
                    if (checked++ >= 18) break;
                    Map<String, String> headers = playbackHeaders(candidate);
                    Probe probe = probe(candidate.url, headers);
                    if (probe.playable) {
                        finishWithMedia(candidate, probe, headers);
                        return;
                    }
                    if (fallback == null && (looksDirectMedia(candidate.url) || looksManifest(candidate.url))) {
                        fallback = probe;
                        fallbackCandidate = candidate;
                    }
                }

                if (fallbackCandidate != null) {
                    Map<String, String> headers = playbackHeaders(fallbackCandidate);
                    Probe probe = fallback == null ? new Probe(false, fallbackCandidate.url, inferMime(fallbackCandidate.url), "") : fallback;
                    if (probe.mimeType.isBlank()) probe = new Probe(true, probe.finalUrl, inferMime(probe.finalUrl), probe.contentDisposition);
                    else probe = new Probe(true, probe.finalUrl, probe.mimeType, probe.contentDisposition);
                    finishWithMedia(fallbackCandidate, probe, headers);
                    return;
                }

                runOnUiThread(() -> {
                    resolving = false;
                    useButton.setEnabled(!candidates.isEmpty());
                    status.setText("I saw requests, but none looked like a clear playable media stream. Try starting the media, then tap Use media again.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    resolving = false;
                    useButton.setEnabled(!candidates.isEmpty());
                    status.setText("Could not validate that stream. Start playback on the page and try again.");
                });
            }
        }, "SidePlayCaptureResolver").start();
    }

    private void finishWithMedia(Candidate candidate, Probe probe, Map<String, String> headers) {
        String finalUrl = probe.finalUrl == null || probe.finalUrl.isBlank() ? candidate.url : probe.finalUrl;
        headers = headersForFinalUrl(headers, candidate.url, finalUrl);
        String mime = probe.mimeType == null ? "" : probe.mimeType;
        if (mime.isBlank()) mime = inferMime(finalUrl);
        boolean segmented = isSegmented(finalUrl, mime);
        String title = pageTitle;
        if (title == null || title.isBlank()) title = filenameFrom(finalUrl);
        if (title.isBlank()) title = host(pageUrl);

        Intent data = new Intent();
        data.putExtra(EXTRA_SOURCE_URL, sourceUrl);
        data.putExtra(EXTRA_PLAYBACK_URL, finalUrl);
        if (!segmented) data.putExtra(EXTRA_DOWNLOAD_URL, finalUrl);
        data.putExtra(EXTRA_MIME_TYPE, mime);
        data.putExtra(EXTRA_MEDIA_KIND, isVideo(finalUrl, mime) ? "video" : "audio");
        data.putExtra(EXTRA_TITLE, title);
        data.putExtra(EXTRA_ARTIST, host(pageUrl));
        JSONObject headerJson = new JSONObject();
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            try { headerJson.put(entry.getKey(), entry.getValue()); } catch (Exception ignored) {}
        }
        data.putExtra(EXTRA_HEADERS_JSON, headerJson.toString());
        data.putExtra(EXTRA_NOTE, segmented
            ? "Captured a browser-session HLS/DASH stream. SidePlay can play it natively while the session remains valid."
            : "Captured a browser-session media file. SidePlay can play it natively and may save it offline while the source remains valid.");
        runOnUiThread(() -> {
            setResult(RESULT_OK, data);
            finish();
        });
    }

    private Map<String, String> playbackHeaders(Candidate candidate) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        for (Map.Entry<String, String> entry : candidate.headers.entrySet()) {
            String key = entry.getKey();
            if (key == null) continue;
            String lk = lower(key);
            if (lk.equals("host") || lk.equals("content-length") || lk.equals("connection") || lk.equals("accept-encoding") || lk.equals("range") || lk.startsWith("sec-")) continue;
            out.put(key, entry.getValue());
        }
        if (!containsHeader(out, "User-Agent") && userAgent != null && !userAgent.isBlank()) out.put("User-Agent", userAgent);
        if (!containsHeader(out, "Referer") && pageUrl != null && !pageUrl.isBlank()) out.put("Referer", pageUrl);
        try {
            CookieManager.getInstance().flush();
            String cookie = CookieManager.getInstance().getCookie(candidate.url);
            if (cookie != null && !cookie.isBlank() && !containsHeader(out, "Cookie")) out.put("Cookie", cookie);
        } catch (Exception ignored) {}
        return out;
    }

    private Probe probe(String raw, Map<String, String> headers) {
        HttpURLConnection conn = null;
        try {
            conn = open(raw, headers, true, false);
            int code = conn.getResponseCode();
            if (code == HttpURLConnection.HTTP_BAD_METHOD || code == HttpURLConnection.HTTP_NOT_IMPLEMENTED || code == 403 || code == 401) {
                conn.disconnect();
                conn = open(raw, headers, false, true);
                code = conn.getResponseCode();
            }
            String type = stripParams(conn.getContentType());
            String finalUrl = conn.getURL().toString();
            String disposition = nvl(conn.getHeaderField("Content-Disposition"));
            boolean okCode = code >= 200 && code < 400;
            if (okCode && (type.isBlank() || type.equals("application/octet-stream") || type.equals("binary/octet-stream") || type.equals("text/plain") || type.contains("xml"))) {
                Probe sniffed = sniffProbe(finalUrl, headers, disposition);
                if (sniffed.playable) return sniffed;
            }
            boolean playable = okCode && (isPlayableContent(type) || looksDirectMedia(finalUrl) || looksManifest(finalUrl));
            return new Probe(playable, finalUrl, type, disposition);
        } catch (Exception ignored) {
            return new Probe(looksDirectMedia(raw) || looksManifest(raw), raw, inferMime(raw), "");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private Probe sniffProbe(String raw, Map<String, String> headers, String disposition) {
        HttpURLConnection connection = null;
        try {
            connection = open(raw, headers, false, true);
            int code = connection.getResponseCode();
            if (code < 200 || code >= 400) return new Probe(false, raw, "", disposition);
            byte[] prefix = new byte[8192];
            int n;
            try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream())) { n = input.read(prefix); }
            String finalUrl = connection.getURL().toString();
            if (n <= 0) return new Probe(false, finalUrl, "", disposition);
            String lead = new String(prefix, 0, Math.min(n, 1024), java.nio.charset.StandardCharsets.UTF_8).trim();
            if (lead.startsWith("#EXTM3U")) return new Probe(true, finalUrl, "application/x-mpegURL", disposition);
            if (lead.startsWith("<MPD") || lead.contains("<MPD ") || lead.contains("<MPD>")) return new Probe(true, finalUrl, "application/dash+xml", disposition);
            if (MediaSafety.looksLikeMediaPrefix(prefix, n)) return new Probe(true, finalUrl, "application/octet-stream", disposition);
        } catch (Exception ignored) {
        } finally {
            if (connection != null) connection.disconnect();
        }
        return new Probe(false, raw, "", disposition);
    }

    private HttpURLConnection open(String raw, Map<String, String> headers, boolean head, boolean rangeProbe) throws Exception {
        URL original = new URL(raw);
        URL current = original;
        for (int redirect = 0; redirect <= 6; redirect++) {
            HttpURLConnection conn = (HttpURLConnection) current.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(CONNECT_TIMEOUT);
            conn.setReadTimeout(READ_TIMEOUT);
            if (head) conn.setRequestMethod("HEAD");

            Map<String, String> requestHeaders = headersForTarget(headers, original, current);
            for (Map.Entry<String, String> entry : requestHeaders.entrySet()) {
                try { conn.setRequestProperty(entry.getKey(), entry.getValue()); } catch (Exception ignored) {}
            }
            if (!containsHeader(requestHeaders, "Accept")) conn.setRequestProperty("Accept", "audio/*,video/*,application/vnd.apple.mpegurl,application/x-mpegURL,application/dash+xml,*/*;q=0.5");
            if (rangeProbe) conn.setRequestProperty("Range", "bytes=0-8191");

            int code = conn.getResponseCode();
            if (code == HttpURLConnection.HTTP_MOVED_PERM || code == HttpURLConnection.HTTP_MOVED_TEMP ||
                code == HttpURLConnection.HTTP_SEE_OTHER || code == 307 || code == 308) {
                String location = conn.getHeaderField("Location");
                if (location == null || location.isBlank()) return conn;
                URL next = new URL(current, location);
                conn.disconnect();
                if (!("http".equalsIgnoreCase(next.getProtocol()) || "https".equalsIgnoreCase(next.getProtocol()))) {
                    throw new Exception("Unsupported redirect scheme.");
                }
                current = next;
                continue;
            }
            return conn;
        }
        throw new Exception("Too many media redirects.");
    }

    private Map<String, String> headersForFinalUrl(Map<String, String> headers, String originalRaw, String finalRaw) {
        try {
            return headersForTarget(headers, new URL(originalRaw), new URL(finalRaw));
        } catch (Exception ignored) {
            return new LinkedHashMap<>(headers);
        }
    }

    private Map<String, String> headersForTarget(Map<String, String> headers, URL original, URL target) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        boolean sameHost = original != null && target != null && original.getHost() != null && target.getHost() != null && original.getHost().equalsIgnoreCase(target.getHost());
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            String key = entry.getKey();
            if (key == null || entry.getValue() == null || entry.getValue().isBlank()) continue;
            String lower = lower(key);
            if (!sameHost && isSensitiveHeader(lower)) continue;
            out.put(key, entry.getValue());
        }
        try {
            String cookie = CookieManager.getInstance().getCookie(target.toString());
            if (cookie != null && !cookie.isBlank()) out.put("Cookie", cookie);
            else if (!sameHost) removeHeaderIgnoreCase(out, "Cookie");
        } catch (Exception ignored) {}
        return out;
    }

    private static boolean isSensitiveHeader(String lowerKey) {
        String lower = lower(lowerKey);
        return lower.equals("cookie") || lower.equals("authorization") || lower.equals("proxy-authorization") || lower.equals("x-csrf-token") || lower.equals("x-xsrf-token");
    }

    private static void removeHeaderIgnoreCase(Map<String, String> headers, String wanted) {
        String found = null;
        for (String key : headers.keySet()) if (key != null && key.equalsIgnoreCase(wanted)) { found = key; break; }
        if (found != null) headers.remove(found);
    }

    private int effectiveScore(Candidate c) {
        long age = Math.max(0L, System.currentTimeMillis() - c.lastSeen);
        int recency = (int) Math.max(0L, 28L - Math.min(28L, age / 1400L));
        return c.score + recency;
    }

    private static boolean strongMediaObservation(String reason, Map<String, String> headers) {
        String r = lower(reason);
        if (r.equals("video") || r.equals("audio") || r.contains("media")) return true;
        String destination = lower(header(headers, "Sec-Fetch-Dest"));
        if (destination.equals("video") || destination.equals("audio")) return true;
        String accept = lower(header(headers, "Accept"));
        return accept.contains("video/") || accept.contains("audio/");
    }

    private static int score(String url, String reason, Map<String, String> headers) {
        String u = lower(url);
        String r = lower(reason);
        int score = 0;
        if (looksManifest(u)) score += 130;
        else if (looksDirectMedia(u)) score += 105;
        if (r.equals("video") || r.equals("audio")) score += 95;
        else if (r.contains("media")) score += 60;
        else if (r.equals("fetch") || r.equals("xmlhttprequest")) score += 22;
        else if (r.equals("resource")) score += 8;
        if (u.contains("manifest") || u.contains("playlist") || u.contains("master.") || u.contains("stream")) score += 35;
        if (u.contains("mime=video") || u.contains("mime=audio") || u.contains("content-type=video") || u.contains("content-type=audio")) score += 40;
        if (headers != null) {
            String accept = header(headers, "Accept");
            if (lower(accept).contains("video") || lower(accept).contains("audio")) score += 25;
            String destination = lower(header(headers, "Sec-Fetch-Dest"));
            if (destination.equals("video") || destination.equals("audio")) score += 95;
            if (!header(headers, "Range").isBlank()) score += 28;
        }
        return score;
    }

    private static boolean looksLikeSegment(String url) {
        String u = lower(url);
        return u.matches(".*\\.(ts|m4s|cmfv|cmfa|m4f)(?:$|[?#].*)") || u.contains("/segment-") || u.contains("/segments/") || u.contains("/chunk-");
    }

    private static boolean looksLikeNonMediaAsset(String url) {
        String u = lower(url);
        return u.matches(".*\\.(js|css|json|xml|html?|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|otf)(?:$|[?#].*)");
    }

    private static boolean looksManifest(String url) {
        String u = lower(url);
        return u.matches(".*\\.(m3u8|mpd)(?:$|[?#].*)") || u.contains("manifest.mpd") || u.contains("master.m3u8");
    }

    private static boolean looksDirectMedia(String url) {
        String u = lower(url);
        return u.matches(".*\\.(mp3|mp2|mpga|m4a|m4b|aac|adts|ac3|eac3|ec3|ac4|amr|3ga|oga|ogg|opus|flac|wav|mp4|m4v|webm|mkv|mka|mov|3gp|flv|f4v|mpg|mpeg|mpegts|m2ts|mts|ts|m3u8|mpd)(?:$|[?#].*)");
    }

    private static boolean isPlayableContent(String type) {
        String t = lower(type);
        return t.startsWith("audio/") || t.startsWith("video/") || t.contains("mpegurl") || t.contains("dash+xml") || t.equals("application/ogg") || t.equals("application/octet-stream");
    }

    private static boolean isSegmented(String url, String type) {
        String t = lower(type);
        return looksManifest(url) || t.contains("mpegurl") || t.contains("dash+xml");
    }

    private static boolean isVideo(String url, String type) {
        String t = lower(type);
        String u = lower(url);
        return t.startsWith("video/") || u.matches(".*\\.(mp4|m4v|webm|mkv|mov|3gp|flv|f4v|mpg|mpeg|mpegts|m2ts|mts|ts|mpd)(?:$|[?#].*)");
    }

    private static String inferMime(String url) {
        String u = lower(url);
        if (u.matches(".*\\.m3u8(?:$|[?#].*)")) return "application/x-mpegURL";
        if (u.matches(".*\\.mpd(?:$|[?#].*)")) return "application/dash+xml";
        if (u.matches(".*\\.(mp3|mp2|mpga)(?:$|[?#].*)")) return "audio/mpeg";
        if (u.matches(".*\\.(m4a|m4b|aac)(?:$|[?#].*)")) return "audio/mp4";
        if (u.matches(".*\\.(oga|ogg|opus)(?:$|[?#].*)")) return "audio/ogg";
        if (u.matches(".*\\.flac(?:$|[?#].*)")) return "audio/flac";
        if (u.matches(".*\\.wav(?:$|[?#].*)")) return "audio/wav";
        if (u.matches(".*\\.(mp4|m4v|mov)(?:$|[?#].*)")) return "video/mp4";
        if (u.matches(".*\\.webm(?:$|[?#].*)")) return "video/webm";
        if (u.matches(".*\\.(flv|f4v)(?:$|[?#].*)")) return "video/x-flv";
        if (u.matches(".*\\.(mpg|mpeg)(?:$|[?#].*)")) return "video/mpeg";
        if (u.matches(".*\\.(ts|mts|m2ts|mpegts)(?:$|[?#].*)")) return "video/mp2t";
        if (u.matches(".*\\.(ac3|eac3|ec3)(?:$|[?#].*)")) return "audio/ac3";
        if (u.matches(".*\\.ac4(?:$|[?#].*)")) return "audio/ac4";
        if (u.matches(".*\\.(amr|3ga)(?:$|[?#].*)")) return "audio/amr";
        return "";
    }

    private static String filenameFrom(String raw) {
        try {
            String path = URI.create(raw).getPath();
            if (path == null || path.isBlank()) return "";
            int slash = path.lastIndexOf('/');
            return slash >= 0 ? path.substring(slash + 1) : path;
        } catch (Exception e) { return ""; }
    }

    private static String host(String raw) {
        try { return nvl(URI.create(raw).getHost()); } catch (Exception e) { return ""; }
    }

    private static String stripParams(String value) {
        if (value == null) return "";
        int semi = value.indexOf(';');
        return (semi >= 0 ? value.substring(0, semi) : value).trim().toLowerCase(Locale.ROOT);
    }

    private static String header(Map<String, String> headers, String wanted) {
        if (headers == null) return "";
        for (Map.Entry<String, String> entry : headers.entrySet()) if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(wanted)) return nvl(entry.getValue());
        return "";
    }

    private static boolean containsHeader(Map<String, String> headers, String wanted) {
        return !header(headers, wanted).isBlank();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private static String lower(String value) { return value == null ? "" : value.toLowerCase(Locale.ROOT); }
    private static String nvl(String value) { return value == null ? "" : value; }

    private void finishCanceled() {
        setResult(RESULT_CANCELED);
        finish();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else finishCanceled();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("SidePlayCapture");
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private static final class Candidate {
        final String url;
        final LinkedHashMap<String, String> headers = new LinkedHashMap<>();
        int score;
        long lastSeen;
        String reason = "";
        Candidate(String url) { this.url = url; }
    }

    private static final class Probe {
        final boolean playable;
        final String finalUrl;
        final String mimeType;
        final String contentDisposition;
        Probe(boolean playable, String finalUrl, String mimeType, String contentDisposition) {
            this.playable = playable;
            this.finalUrl = finalUrl == null ? "" : finalUrl;
            this.mimeType = mimeType == null ? "" : mimeType;
            this.contentDisposition = contentDisposition == null ? "" : contentDisposition;
        }
    }
}
