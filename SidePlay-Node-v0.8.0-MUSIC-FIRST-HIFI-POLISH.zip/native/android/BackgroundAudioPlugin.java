package app.sideplay.mobile;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "BackgroundAudio")
public class BackgroundAudioPlugin extends Plugin {
    private BroadcastReceiver receiver;

    @Override
    public void load() {
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                JSObject out = new JSObject();
                out.put("state", intent.getStringExtra("state"));
                out.put("positionMs", intent.getLongExtra("positionMs", 0L));
                out.put("durationMs", intent.getLongExtra("durationMs", 0L));
                String message = intent.getStringExtra("message");
                if (message != null) out.put("message", message);
                notifyListeners("playbackState", out, true);
            }
        };
        IntentFilter filter = new IntentFilter(PlaybackService.ACTION_EVENT);
        if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else getContext().registerReceiver(receiver, filter);
    }

    @Override
    protected void handleOnDestroy() {
        if (receiver != null) {
            try { getContext().unregisterReceiver(receiver); } catch (Exception ignored) {}
            receiver = null;
        }
        super.handleOnDestroy();
    }

    @PluginMethod
    public void play(PluginCall call) {
        String url = call.getString("url");
        if (url == null || url.isBlank()) {
            call.reject("A direct media URL is required.");
            return;
        }
        Intent intent = new Intent(getContext(), PlaybackService.class);
        intent.setAction(PlaybackService.ACTION_PLAY);
        intent.putExtra("url", url);
        intent.putExtra("title", call.getString("title", "SidePlay"));
        intent.putExtra("artist", call.getString("artist", ""));
        intent.putExtra("artwork", call.getString("artwork", ""));
        intent.putExtra("mimeType", call.getString("mimeType", ""));
        intent.putExtra("sourceUrl", call.getString("sourceUrl", ""));
        intent.putExtra("refreshMode", call.getString("refreshMode", ""));
        intent.putExtra("resumable", call.getBoolean("resumable", true));
        intent.putExtra("audioPreferred", call.getBoolean("audioPreferred", false));
        JSObject requestHeaders = call.getObject("requestHeaders");
        if (requestHeaders != null && requestHeaders.length() > 0) intent.putExtra("requestHeadersJson", requestHeaders.toString());
        Double requestedPosition = call.getDouble("positionMs", 0.0);
        long positionMs = requestedPosition == null ? 0L : Math.max(0L, requestedPosition.longValue());
        intent.putExtra("positionMs", positionMs);
        ContextCompat.startForegroundService(getContext(), intent);
        call.resolve(new JSObject());
    }

    @PluginMethod public void pause(PluginCall call) { send(PlaybackService.ACTION_PAUSE); call.resolve(); }
    @PluginMethod public void resume(PluginCall call) { send(PlaybackService.ACTION_RESUME); call.resolve(); }
    @PluginMethod public void stop(PluginCall call) { send(PlaybackService.ACTION_STOP); call.resolve(); }

    @PluginMethod
    public void seek(PluginCall call) {
        Double requestedPosition = call.getDouble("positionMs", 0.0);
        long positionMs = requestedPosition == null ? 0L : Math.max(0L, requestedPosition.longValue());
        PlaybackService service = PlaybackService.getInstance();
        if (service == null) {
            call.reject("Native playback is not active.");
            return;
        }
        service.seekTo(positionMs);
        call.resolve(snapshot(service));
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        PlaybackService service = PlaybackService.getInstance();
        if (service == null) {
            JSObject out = new JSObject();
            out.put("active", false);
            out.put("playing", false);
            out.put("positionMs", 0);
            out.put("durationMs", 0);
            call.resolve(out);
            return;
        }
        call.resolve(snapshot(service));
    }

    @PluginMethod
    public void getBackgroundHealth(PluginCall call) {
        PowerManager pm = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        boolean unrestricted = Build.VERSION.SDK_INT < 23 || (pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName()));
        JSObject out = new JSObject();
        out.put("unrestricted", unrestricted);
        out.put("androidVersion", Build.VERSION.SDK_INT);
        call.resolve(out);
    }

    @PluginMethod
    public void openBluetoothSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception first) {
            try {
                Intent intent = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
                call.resolve();
            } catch (Exception second) {
                call.reject("Could not open Android Bluetooth settings.", second);
            }
        }
    }

    @PluginMethod
    public void openBackgroundSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception first) {
            try {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getContext().getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
                call.resolve();
            } catch (Exception second) {
                call.reject("Could not open Android background settings.", second);
            }
        }
    }

    private JSObject snapshot(PlaybackService service) {
        JSObject out = new JSObject();
        out.put("active", true);
        out.put("playing", service.isPlayingNow());
        out.put("positionMs", service.getPositionMs());
        out.put("durationMs", service.getDurationMs());
        out.put("playbackState", service.getPlaybackStateValue());
        return out;
    }

    private void send(String action) {
        if (PlaybackService.getInstance() == null) return;
        Intent intent = new Intent(getContext(), PlaybackService.class);
        intent.setAction(action);
        getContext().startService(intent);
    }
}
