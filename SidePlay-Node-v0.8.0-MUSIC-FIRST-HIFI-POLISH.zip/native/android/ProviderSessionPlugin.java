package app.sideplay.mobile;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Toast;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Generic bridge for provider-owned Android playback.
 *
 * v0.4.4 hardens three weak points from the first browser bridge:
 *  - the Android browser ROLE is consulted before any stale remembered browser;
 *  - browser MediaSessions are discovered dynamically rather than by a tiny allow-list;
 *  - a short native handoff watcher brings SidePlay's own task back when playback starts.
 *
 * No protected provider stream is extracted here. Provider playback remains provider-owned.
 */
@CapacitorPlugin(name = "ProviderSession")
public class ProviderSessionPlugin extends Plugin {
    private static final String YOUTUBE = "com.google.android.youtube";
    private static final String YOUTUBE_MUSIC = "com.google.android.apps.youtube.music";
    private static final String SPOTIFY = "com.spotify.music";
    private static final String SOUNDCLOUD = "com.soundcloud.android";

    static final String PREFS = "sideplay_provider_bridge";
    static final String PREF_LAST_BROWSER = "last_browser_package_v2";
    static final String PREF_BROWSER_OVERRIDE = "browser_override_package";
    static final String PREF_PENDING_RETURN = "pending_auto_return";
    static final String PREF_PENDING_PACKAGE = "pending_auto_return_package";
    static final String PREF_PENDING_SINCE = "pending_auto_return_since";

    private static final List<String> KNOWN_BROWSERS = Arrays.asList(
        "com.brave.browser",
        "com.android.chrome",
        "com.google.android.apps.chrome",
        "com.sec.android.app.sbrowser",
        "org.mozilla.firefox",
        "org.mozilla.fenix",
        "com.microsoft.emmx",
        "com.opera.browser",
        "com.vivaldi.browser",
        "com.kiwibrowser.browser"
    );

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @PluginMethod
    public void hasAccess(PluginCall call) {
        String browser = chooseBrowserPackage();
        String systemDefault = systemDefaultBrowserPackage();
        JSObject out = new JSObject();
        out.put("granted", notificationAccessGranted());
        out.put("youtubeInstalled", installed(YOUTUBE));
        out.put("youtubeMusicInstalled", installed(YOUTUBE_MUSIC));
        out.put("spotifyInstalled", installed(SPOTIFY));
        out.put("soundcloudInstalled", installed(SOUNDCLOUD));
        out.put("browserAvailable", browser != null);
        out.put("browserPackage", browser == null ? "" : browser);
        out.put("browserLabel", browser == null ? "" : appLabel(browser));
        out.put("systemDefaultBrowserPackage", systemDefault == null ? "" : systemDefault);
        out.put("systemDefaultBrowserLabel", systemDefault == null ? "" : appLabel(systemDefault));
        out.put("browserOverridePackage", browserOverridePackage());
        call.resolve(out);
    }

    @PluginMethod
    public void listBrowsers(PluginCall call) {
        String selected = chooseBrowserPackage();
        String systemDefault = systemDefaultBrowserPackage();
        JSArray browsers = new JSArray();
        for (String pkg : installedBrowserPackages()) {
            JSObject row = new JSObject();
            row.put("packageName", pkg);
            row.put("label", appLabel(pkg));
            row.put("systemDefault", pkg.equals(systemDefault));
            row.put("selected", pkg.equals(selected));
            browsers.put(row);
        }
        JSObject out = new JSObject();
        out.put("browsers", browsers);
        out.put("selectedPackage", selected == null ? "" : selected);
        out.put("systemDefaultPackage", systemDefault == null ? "" : systemDefault);
        out.put("overridePackage", browserOverridePackage());
        call.resolve(out);
    }

    @PluginMethod
    public void setBrowserPreference(PluginCall call) {
        String requested = call.getString("packageName", "").trim();
        if (requested.isEmpty() || requested.equalsIgnoreCase("system")) {
            prefs().edit().remove(PREF_BROWSER_OVERRIDE).apply();
        } else {
            if (!installed(requested) || !canHandleWeb(requested)) {
                call.reject("That browser is not installed or cannot handle web links.");
                return;
            }
            prefs().edit().putString(PREF_BROWSER_OVERRIDE, requested).apply();
        }
        String selected = chooseBrowserPackage();
        JSObject out = new JSObject();
        out.put("browserPackage", selected == null ? "" : selected);
        out.put("browserLabel", selected == null ? "" : appLabel(selected));
        out.put("overridePackage", browserOverridePackage());
        call.resolve(out);
    }

    @PluginMethod
    public void openAccessSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open Notification Access settings.", e);
        }
    }

    @PluginMethod
    public void openExact(PluginCall call) {
        String provider = call.getString("provider", "").trim().toLowerCase(Locale.ROOT);
        String raw = call.getString("url", "").trim();
        String videoId = call.getString("videoId", "").trim();
        String expectedTitle = call.getString("title", "").trim();
        Boolean autoReturnValue = call.getBoolean("autoReturn");
        boolean autoReturn = autoReturnValue == null || autoReturnValue;
        if (provider.isEmpty()) { call.reject("provider is required."); return; }

        try {
            Intent intent;
            String packageName = providerPackage(provider);
            String route = "url";
            String beforeIdentity = "";

            if (provider.equals("youtube")) {
                MediaController before = findController(YOUTUBE);
                beforeIdentity = controllerIdentity(before);
                if (!videoId.isEmpty()) {
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + videoId));
                    intent.setPackage(YOUTUBE);
                    if (intent.resolveActivity(getContext().getPackageManager()) == null) {
                        raw = canonicalYouTubeUrl(videoId, raw, true);
                        intent = new Intent(Intent.ACTION_VIEW, Uri.parse(raw));
                        intent.setPackage(YOUTUBE);
                        route = "youtube-https";
                    } else {
                        route = "youtube-video-id";
                    }
                } else {
                    if (raw.isEmpty()) { call.reject("YouTube videoId or URL is required."); return; }
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse(raw));
                    intent.setPackage(YOUTUBE);
                    route = "youtube-url";
                }
            } else if (provider.equals("youtubeweb")) {
                raw = canonicalYouTubeUrl(videoId, raw, true);
                if (raw.isEmpty()) { call.reject("YouTube videoId or URL is required."); return; }
                String browserPackage = chooseBrowserPackage();
                if (browserPackage == null) {
                    call.reject("No web browser is available for the YouTube Web route.");
                    return;
                }
                MediaController before = findBrowserController(expectedTitle, videoId);
                beforeIdentity = controllerIdentity(before);
                packageName = browserPackage;
                rememberBrowser(browserPackage);
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(raw));
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setPackage(browserPackage);
                route = "youtube-web";
            } else {
                if (raw.isEmpty()) { call.reject("url is required."); return; }
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(raw));
                if (packageName != null) intent.setPackage(packageName);
                route = provider + "-url";
            }

            PackageManager pm = getContext().getPackageManager();
            if (intent.resolveActivity(pm) == null) {
                if (provider.equals("youtubeweb")) {
                    call.reject("The selected browser cannot open this YouTube URL.");
                    return;
                }
                if (raw.isEmpty() && provider.equals("youtube") && !videoId.isEmpty()) {
                    raw = canonicalYouTubeUrl(videoId, raw, true);
                }
                if (raw.isEmpty()) { call.reject("No app can open this provider item."); return; }
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(raw));
                route += "-fallback";
            }

            if (autoReturn && (provider.equals("youtube") || provider.equals("youtubeweb")) && packageName != null) {
                armAutoReturn(packageName);
            }

            if (getActivity() != null) getActivity().startActivity(intent);
            else {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
            }

            if (autoReturn && (provider.equals("youtube") || provider.equals("youtubeweb")) && packageName != null) {
                scheduleAutoReturn(provider, packageName, expectedTitle, videoId, beforeIdentity, System.currentTimeMillis(), 0);
            }

            if (provider.equals("youtube")) {
                Toast.makeText(getContext(), "YouTube opened. SidePlay will reconnect automatically when playback starts.", Toast.LENGTH_SHORT).show();
            } else if (provider.equals("youtubeweb")) {
                Toast.makeText(getContext(), "YouTube Web opened in " + appLabel(packageName) + ". SidePlay will return automatically when playback starts.", Toast.LENGTH_SHORT).show();
            }

            JSObject out = new JSObject();
            out.put("accepted", true);
            out.put("route", route);
            out.put("packageName", packageName == null ? "" : packageName);
            out.put("browserLabel", provider.equals("youtubeweb") && packageName != null ? appLabel(packageName) : "");
            out.put("accessGranted", notificationAccessGranted());
            out.put("autoReturnArmed", autoReturn && notificationAccessGranted());
            call.resolve(out);
        } catch (Exception e) {
            clearAutoReturn();
            call.reject("Could not open provider item: " + safe(e), e);
        }
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        String provider = call.getString("provider", "").trim().toLowerCase(Locale.ROOT);
        String expectedTitle = call.getString("expectedTitle", "").trim();
        String videoId = call.getString("videoId", "").trim();
        MediaController controller = controllerForProvider(provider, expectedTitle, videoId);
        JSObject out = controller != null ? buildStatus(controller) : buildNotificationFallbackStatus(provider, expectedTitle, videoId);
        out.put("provider", provider);
        out.put("accessGranted", notificationAccessGranted());
        if (provider.equals("youtubeweb")) {
            String browser = controller != null ? controller.getPackageName() : chooseBrowserPackage();
            out.put("installed", browser != null);
            out.put("browserPackage", browser == null ? "" : browser);
            out.put("browserLabel", browser == null ? "" : appLabel(browser));
            out.put("systemDefaultBrowserPackage", nullToEmpty(systemDefaultBrowserPackage()));
            out.put("notificationMediaPackage", SpotifySessionListenerService.cachedPackage());
            out.put("notificationMediaTitle", SpotifySessionListenerService.cachedTitle());
            out.put("notificationMediaText", SpotifySessionListenerService.cachedText());
            out.put("notificationMediaAgeMs", SpotifySessionListenerService.cachedAgeMs());
        } else {
            String packageName = providerPackage(provider);
            out.put("installed", packageName != null && installed(packageName));
        }
        call.resolve(out);
    }

    @PluginMethod public void play(PluginCall call) { transport(call, "play"); }
    @PluginMethod public void pause(PluginCall call) { transport(call, "pause"); }
    @PluginMethod public void next(PluginCall call) { transport(call, "next"); }
    @PluginMethod public void previous(PluginCall call) { transport(call, "previous"); }

    @PluginMethod
    public void seek(PluginCall call) {
        String provider = call.getString("provider", "").trim().toLowerCase(Locale.ROOT);
        Long position = call.getLong("positionMs");
        if (position == null) { call.reject("positionMs is required."); return; }
        MediaController controller = requireController(provider, call);
        if (controller == null) return;
        try {
            controller.getTransportControls().seekTo(Math.max(0L, position));
            call.resolve(buildStatus(controller));
        } catch (Exception e) {
            call.reject("Provider seek failed.", e);
        }
    }

    private void transport(PluginCall call, String action) {
        String provider = call.getString("provider", "").trim().toLowerCase(Locale.ROOT);
        if (!notificationAccessGranted()) {
            call.reject("SidePlay needs Notification Access to mirror/control provider playback.");
            return;
        }
        if (!isSupportedProvider(provider)) {
            call.reject("Unsupported provider session: " + provider);
            return;
        }

        String expectedTitle = call.getString("expectedTitle", "").trim();
        String videoId = call.getString("videoId", "").trim();
        MediaController controller = controllerForProvider(provider, expectedTitle, videoId);
        if (controller == null) {
            if (provider.equals("youtubeweb")) {
                String preferred = firstNonBlank(
                    prefs().getString(PREF_PENDING_PACKAGE, ""),
                    lastBrowserPackage(),
                    chooseBrowserPackage(), "");
                if (SpotifySessionListenerService.sendCachedAction(action, preferred)) {
                    call.resolve(buildNotificationFallbackStatus(provider, expectedTitle, videoId));
                    return;
                }
            }
            String label = provider.equals("youtubeweb") ? "browser" : provider;
            call.reject("No active " + label + " media session is visible to SidePlay yet.");
            return;
        }

        try {
            switch (action) {
                case "play": controller.getTransportControls().play(); break;
                case "pause": controller.getTransportControls().pause(); break;
                case "next": controller.getTransportControls().skipToNext(); break;
                case "previous": controller.getTransportControls().skipToPrevious(); break;
                default: throw new IllegalArgumentException("Unknown action");
            }
            call.resolve(buildStatus(controller));
        } catch (Exception e) {
            call.reject("Provider " + action + " failed.", e);
        }
    }

    private MediaController requireController(String provider, PluginCall call) {
        if (!notificationAccessGranted()) {
            call.reject("SidePlay needs Notification Access to mirror/control provider playback.");
            return null;
        }
        if (!isSupportedProvider(provider)) {
            call.reject("Unsupported provider session: " + provider);
            return null;
        }
        String expectedTitle = call.getString("expectedTitle", "").trim();
        String videoId = call.getString("videoId", "").trim();
        MediaController controller = controllerForProvider(provider, expectedTitle, videoId);
        if (controller == null) {
            String label = provider.equals("youtubeweb") ? "browser" : provider;
            call.reject("No active " + label + " media session is visible to SidePlay yet.");
            return null;
        }
        return controller;
    }

    private boolean isSupportedProvider(String provider) {
        return provider.equals("youtubeweb") || providerPackage(provider) != null;
    }

    private MediaController controllerForProvider(String provider, String expectedTitle, String videoId) {
        if (provider.equals("youtubeweb")) return findBrowserController(expectedTitle, videoId);
        String packageName = providerPackage(provider);
        return packageName == null ? null : findController(packageName);
    }

    private List<MediaController> activeControllers() {
        if (!notificationAccessGranted()) return Collections.emptyList();
        ArrayList<MediaController> result = new ArrayList<>();
        try {
            MediaSessionManager manager = (MediaSessionManager) getContext().getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (manager != null) {
                ComponentName listener = new ComponentName(getContext(), SpotifySessionListenerService.class);
                List<MediaController> controllers = manager.getActiveSessions(listener);
                if (controllers != null) result.addAll(controllers);
            }
        } catch (SecurityException ignored) {}

        // Browser media notifications can contain a perfectly usable MediaSession.Token
        // even while getActiveSessions() temporarily omits that session. Add the token
        // captured by our NotificationListener as a second discovery path.
        MediaController cached = SpotifySessionListenerService.cachedController(getContext(), "");
        if (cached != null) {
            boolean duplicate = false;
            for (MediaController existing : result) {
                try {
                    if (existing.getSessionToken().equals(cached.getSessionToken())) {
                        duplicate = true;
                        break;
                    }
                } catch (Exception ignored) {}
            }
            if (!duplicate) result.add(cached);
        }
        return result;
    }

    private MediaController findController(String packageName) {
        for (MediaController controller : activeControllers()) {
            if (packageName.equals(controller.getPackageName())) return controller;
        }
        return SpotifySessionListenerService.cachedController(getContext(), packageName);
    }

    private MediaController findBrowserController(String expectedTitle, String videoId) {
        List<MediaController> controllers = activeControllers();
        if (controllers.isEmpty()) return null;

        String chosen = nullToEmpty(chooseBrowserPackage());
        String last = nullToEmpty(lastBrowserPackage());
        String pending = prefs().getString(PREF_PENDING_PACKAGE, "");
        String notificationPackage = nullToEmpty(SpotifySessionListenerService.cachedPackage());
        MediaController best = null;
        int bestScore = Integer.MIN_VALUE;

        for (MediaController controller : controllers) {
            if (controller == null) continue;
            String pkg = nullToEmpty(controller.getPackageName());
            if (pkg.isEmpty() || pkg.equals(getContext().getPackageName())) continue;

            boolean browserish = isBrowserPackage(pkg);
            boolean launchedPackage = pkg.equals(chosen) || pkg.equals(last) || pkg.equals(pending);
            boolean notificationPackageMatch = pkg.equals(notificationPackage) && SpotifySessionListenerService.cachedAgeMs() < 180000L;
            boolean exactMetadata = metadataMatches(controller, expectedTitle, videoId);

            // Do not accidentally attach to Spotify/another player just because it is
            // active. But if Android's own media notification says this controller is
            // the fresh session, or the title matches the requested YouTube item, keep it.
            if (!browserish && !launchedPackage && !notificationPackageMatch && !exactMetadata) continue;

            int score = 10;
            if (browserish) score += 40;
            if (pkg.equals(chosen)) score += 130;
            if (pkg.equals(last)) score += 70;
            if (pkg.equals(pending)) score += 150;
            if (notificationPackageMatch) score += 160;
            if (isPlaying(controller)) score += 55;
            if (exactMetadata) score += 300;

            if (score > bestScore) {
                best = controller;
                bestScore = score;
            }
        }
        return best;
    }

    private boolean metadataMatches(MediaController controller, String expectedTitle, String videoId) {
        if (controller == null) return false;
        MediaMetadata metadata = controller.getMetadata();
        if (metadata != null) {
            String mediaId = nullToEmpty(metadata.getString(MediaMetadata.METADATA_KEY_MEDIA_ID));
            if (!videoId.isEmpty() && mediaId.contains(videoId)) return true;
            String actual = firstNonBlank(
                metadata.getString(MediaMetadata.METADATA_KEY_TITLE),
                metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE), "");
            if (titlesOverlap(actual, expectedTitle)) return true;
        }

        // Some browsers put useful title/text in the media notification while their
        // MediaMetadata is blank or delayed. Use that as a fallback, but only for the
        // same package as the controller.
        String cachedPackage = SpotifySessionListenerService.cachedPackage();
        if (controller.getPackageName() != null && controller.getPackageName().equals(cachedPackage)) {
            String notificationTitle = SpotifySessionListenerService.cachedTitle();
            String notificationText = SpotifySessionListenerService.cachedText();
            if (titlesOverlap(notificationTitle, expectedTitle) || titlesOverlap(notificationText, expectedTitle)) return true;
            String joined = (notificationTitle + " " + notificationText).trim();
            if (titlesOverlap(joined, expectedTitle)) return true;
        }
        return false;
    }

    private boolean isPlaying(MediaController controller) {
        PlaybackState state = controller == null ? null : controller.getPlaybackState();
        if (state == null) return false;
        int code = state.getState();
        return code == PlaybackState.STATE_PLAYING || code == PlaybackState.STATE_BUFFERING;
    }

    private String chooseBrowserPackage() {
        String override = browserOverridePackage();
        if (!override.isEmpty() && installed(override) && canHandleWeb(override)) return override;

        String systemDefault = systemDefaultBrowserPackage();
        if (systemDefault != null && installed(systemDefault) && canHandleWeb(systemDefault)) return systemDefault;

        String last = lastBrowserPackage();
        if (!last.isEmpty() && installed(last) && canHandleWeb(last)) return last;

        for (String pkg : installedBrowserPackages()) return pkg;
        return null;
    }

    private String systemDefaultBrowserPackage() {
        return resolveDefaultBrowserPackage();
    }

    /**
     * Android does not expose RoleManager#getRoleHolders() as a public app API.
     * The supported way for an ordinary app to discover what ACTION_VIEW would
     * open by default is PackageManager.resolveActivity(..., MATCH_DEFAULT_ONLY).
     * This mirrors Context.startActivity() resolution and avoids the v0.4.3
     * compile failure while still honoring the user's real default browser.
     */
    private String resolveDefaultBrowserPackage() {
        try {
            Intent probe = new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com/"));
            probe.addCategory(Intent.CATEGORY_BROWSABLE);
            ResolveInfo resolved = getContext().getPackageManager().resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY);
            if (resolved != null && resolved.activityInfo != null) {
                String pkg = resolved.activityInfo.packageName;
                if (pkg != null && !pkg.isEmpty() && !pkg.equals("android") && !pkg.equals(YOUTUBE) && canHandleWeb(pkg)) {
                    return pkg;
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private List<String> installedBrowserPackages() {
        ArrayList<String> result = new ArrayList<>();
        String systemDefault = systemDefaultBrowserPackageNoRecursion();
        if (systemDefault != null && !result.contains(systemDefault)) result.add(systemDefault);

        try {
            Intent query = new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com/"));
            query.addCategory(Intent.CATEGORY_BROWSABLE);
            List<ResolveInfo> infos = getContext().getPackageManager().queryIntentActivities(query, 0);
            for (ResolveInfo info : infos) {
                if (info.activityInfo == null) continue;
                String pkg = info.activityInfo.packageName;
                if (pkg != null && !pkg.equals(YOUTUBE) && !result.contains(pkg)) result.add(pkg);
            }
        } catch (Exception ignored) {}

        for (String pkg : KNOWN_BROWSERS) if (installed(pkg) && canHandleWeb(pkg) && !result.contains(pkg)) result.add(pkg);
        return result;
    }

    // Same lookup without calling installedBrowserPackages(), preventing a recursion loop.
    private String systemDefaultBrowserPackageNoRecursion() {
        return resolveDefaultBrowserPackage();
    }

    private boolean isBrowserPackage(String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        if (packageName.equals(getContext().getPackageName())) return false;
        if (KNOWN_BROWSERS.contains(packageName)) return true;
        if (packageName.equals(browserOverridePackage())) return true;
        if (packageName.equals(lastBrowserPackage())) return true;
        return canHandleWeb(packageName);
    }

    private boolean canHandleWeb(String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        try {
            Intent probe = new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com/"));
            probe.addCategory(Intent.CATEGORY_BROWSABLE);
            probe.setPackage(packageName);
            return probe.resolveActivity(getContext().getPackageManager()) != null;
        } catch (Exception ignored) { return false; }
    }

    private void rememberBrowser(String packageName) {
        if (packageName == null || packageName.isEmpty()) return;
        prefs().edit().putString(PREF_LAST_BROWSER, packageName).apply();
    }

    private String lastBrowserPackage() {
        return prefs().getString(PREF_LAST_BROWSER, "");
    }

    private String browserOverridePackage() {
        return prefs().getString(PREF_BROWSER_OVERRIDE, "");
    }

    private String appLabel(String packageName) {
        if (packageName == null || packageName.isEmpty()) return "Browser";
        try {
            PackageManager pm = getContext().getPackageManager();
            ApplicationInfo info = pm.getApplicationInfo(packageName, 0);
            CharSequence label = pm.getApplicationLabel(info);
            return label == null ? packageName : label.toString();
        } catch (Exception ignored) { return packageName; }
    }

    private SharedPreferences prefs() {
        return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private void armAutoReturn(String packageName) {
        prefs().edit()
            .putBoolean(PREF_PENDING_RETURN, true)
            .putString(PREF_PENDING_PACKAGE, packageName)
            .putLong(PREF_PENDING_SINCE, System.currentTimeMillis())
            .apply();
    }

    private void clearAutoReturn() {
        prefs().edit()
            .remove(PREF_PENDING_RETURN)
            .remove(PREF_PENDING_PACKAGE)
            .remove(PREF_PENDING_SINCE)
            .apply();
    }

    private void scheduleAutoReturn(String provider, String packageName, String expectedTitle, String videoId, String beforeIdentity, long startedAt, int attempt) {
        if (attempt > 34 || System.currentTimeMillis() - startedAt > 12000L) {
            clearAutoReturn();
            return;
        }
        long delay = attempt < 4 ? 250L : 350L;
        mainHandler.postDelayed(() -> {
            try {
                MediaController controller = provider.equals("youtubeweb")
                    ? findBrowserController(expectedTitle, videoId)
                    : findController(packageName);

                if (controller != null && isPlaying(controller)) {
                    String nowIdentity = controllerIdentity(controller);
                    boolean exact = metadataMatches(controller, expectedTitle, videoId);
                    boolean changed = !nowIdentity.isEmpty() && !nowIdentity.equals(beforeIdentity);
                    PlaybackState state = controller.getPlaybackState();
                    long position = state == null ? Long.MAX_VALUE : Math.max(0L, state.getPosition());
                    boolean fresh = position <= 15000L;

                    if (exact || changed || fresh) {
                        if (moveSidePlayToFront()) {
                            clearAutoReturn();
                            return;
                        }
                    }
                }
            } catch (Exception ignored) {}
            scheduleAutoReturn(provider, packageName, expectedTitle, videoId, beforeIdentity, startedAt, attempt + 1);
        }, delay);
    }

    private boolean moveSidePlayToFront() {
        try {
            ActivityManager manager = (ActivityManager) getContext().getSystemService(Context.ACTIVITY_SERVICE);
            if (manager != null) {
                List<ActivityManager.AppTask> tasks = manager.getAppTasks();
                for (ActivityManager.AppTask task : tasks) {
                    try {
                        ActivityManager.RecentTaskInfo info = task.getTaskInfo();
                        Intent base = info == null ? null : info.baseIntent;
                        ComponentName component = base == null ? null : base.getComponent();
                        if (component == null || getContext().getPackageName().equals(component.getPackageName())) {
                            task.moveToFront();
                            return true;
                        }
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}

        try {
            Intent launch = getContext().getPackageManager().getLaunchIntentForPackage(getContext().getPackageName());
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                getContext().startActivity(launch);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private String controllerIdentity(MediaController controller) {
        if (controller == null) return "";
        MediaMetadata md = controller.getMetadata();
        String title = md == null ? "" : firstNonBlank(md.getString(MediaMetadata.METADATA_KEY_TITLE), md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE), "");
        String mediaId = md == null ? "" : nullToEmpty(md.getString(MediaMetadata.METADATA_KEY_MEDIA_ID));
        long duration = md == null ? 0L : Math.max(0L, md.getLong(MediaMetadata.METADATA_KEY_DURATION));
        return controller.getPackageName() + "|" + normalizeText(title) + "|" + mediaId + "|" + duration;
    }

    private boolean notificationAccessGranted() {
        String flat = Settings.Secure.getString(getContext().getContentResolver(), "enabled_notification_listeners");
        if (flat == null || flat.isEmpty()) return false;
        String packageName = getContext().getPackageName();
        for (String entry : flat.split(":")) {
            ComponentName component = ComponentName.unflattenFromString(entry);
            if (component != null && packageName.equals(component.getPackageName())) return true;
        }
        return false;
    }

    private boolean installed(String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        try {
            getContext().getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (Exception ignored) { return false; }
    }

    private String providerPackage(String provider) {
        switch (provider) {
            case "youtube": return YOUTUBE;
            case "youtubemusic": return YOUTUBE_MUSIC;
            case "spotify": return SPOTIFY;
            case "soundcloud": return SOUNDCLOUD;
            default: return null;
        }
    }

    private String canonicalYouTubeUrl(String videoId, String raw, boolean autoplay) {
        String url;
        if (videoId != null && !videoId.trim().isEmpty()) {
            url = "https://www.youtube.com/watch?v=" + Uri.encode(videoId.trim());
        } else {
            url = raw == null ? "" : raw.trim();
        }
        if (url.isEmpty() || !autoplay) return url;
        try {
            Uri uri = Uri.parse(url);
            if (uri.getQueryParameter("autoplay") == null) {
                uri = uri.buildUpon().appendQueryParameter("autoplay", "1").build();
            }
            return uri.toString();
        } catch (Exception ignored) { return url; }
    }

    private JSObject buildNotificationFallbackStatus(String provider, String expectedTitle, String videoId) {
        JSObject out = new JSObject();
        if (!provider.equals("youtubeweb")) {
            out.put("sessionAvailable", false);
            return out;
        }

        String cachedPackage = SpotifySessionListenerService.cachedPackage();
        String chosen = nullToEmpty(chooseBrowserPackage());
        String last = nullToEmpty(lastBrowserPackage());
        String pending = prefs().getString(PREF_PENDING_PACKAGE, "");
        boolean fresh = SpotifySessionListenerService.cachedAgeMs() < 180000L;
        boolean packageFits = !cachedPackage.isEmpty() && (
            cachedPackage.equals(chosen) || cachedPackage.equals(last) || cachedPackage.equals(pending) || isBrowserPackage(cachedPackage));
        String title = SpotifySessionListenerService.cachedTitle();
        String text = SpotifySessionListenerService.cachedText();
        boolean metadataFits = titlesOverlap(title, expectedTitle) || titlesOverlap(text, expectedTitle)
            || titlesOverlap((title + " " + text).trim(), expectedTitle);
        boolean available = fresh && packageFits && (metadataFits || expectedTitle.isEmpty());

        out.put("sessionAvailable", available);
        out.put("notificationFallback", available);
        out.put("sessionSource", available ? "notification-actions" : "none");
        out.put("packageName", cachedPackage);
        out.put("title", title);
        out.put("artist", text);
        out.put("durationMs", 0L);
        out.put("positionMs", 0L);
        out.put("supportsSeek", false);
        out.put("supportsNext", true);
        out.put("supportsPrevious", true);
        boolean playing = SpotifySessionListenerService.cachedLikelyPlayingKnown()
            ? SpotifySessionListenerService.cachedLikelyPlaying()
            : (available && SpotifySessionListenerService.cachedAgeMs() < 15000L);
        out.put("playing", playing);
        out.put("state", playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED);
        return out;
    }

    private JSObject buildStatus(MediaController controller) {
        JSObject out = new JSObject();
        out.put("sessionAvailable", controller != null);
        if (controller == null) return out;

        PlaybackState state = controller.getPlaybackState();
        long actions = state == null ? 0L : state.getActions();
        int stateCode = state == null ? PlaybackState.STATE_NONE : state.getState();
        long position = state == null ? 0L : Math.max(0L, state.getPosition());
        boolean playing = stateCode == PlaybackState.STATE_PLAYING || stateCode == PlaybackState.STATE_BUFFERING;

        out.put("packageName", controller.getPackageName());
        out.put("playing", playing);
        out.put("state", stateCode);
        out.put("positionMs", position);
        out.put("actions", actions);
        out.put("supportsSeek", (actions & PlaybackState.ACTION_SEEK_TO) != 0L);
        out.put("supportsNext", (actions & PlaybackState.ACTION_SKIP_TO_NEXT) != 0L);
        out.put("supportsPrevious", (actions & PlaybackState.ACTION_SKIP_TO_PREVIOUS) != 0L);

        MediaMetadata metadata = controller.getMetadata();
        String title = "";
        String artist = "";
        String album = "";
        String mediaId = "";
        long duration = 0L;
        if (metadata != null) {
            title = firstNonBlank(
                metadata.getString(MediaMetadata.METADATA_KEY_TITLE),
                metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE), "");
            artist = firstNonBlank(
                metadata.getString(MediaMetadata.METADATA_KEY_ARTIST),
                metadata.getString(MediaMetadata.METADATA_KEY_AUTHOR), "");
            album = nullToEmpty(metadata.getString(MediaMetadata.METADATA_KEY_ALBUM));
            mediaId = nullToEmpty(metadata.getString(MediaMetadata.METADATA_KEY_MEDIA_ID));
            duration = Math.max(0L, metadata.getLong(MediaMetadata.METADATA_KEY_DURATION));
        }

        // Browser MediaMetadata is occasionally empty even though the browser's
        // media notification already contains the title. Surface the notification
        // metadata so the JS verifier can attach to the session instead of waiting forever.
        if (controller.getPackageName() != null
            && controller.getPackageName().equals(SpotifySessionListenerService.cachedPackage())) {
            if (title.isEmpty()) title = SpotifySessionListenerService.cachedTitle();
            if (artist.isEmpty()) artist = SpotifySessionListenerService.cachedText();
            out.put("sessionSource", "notification-token");
        } else {
            out.put("sessionSource", "active-sessions");
        }

        out.put("title", title);
        out.put("artist", artist);
        out.put("album", album);
        out.put("mediaId", mediaId);
        out.put("durationMs", duration);
        return out;
    }

    private static boolean titlesOverlap(String a, String b) {
        String left = normalizeText(a);
        String right = normalizeText(b);
        if (left.isEmpty() || right.isEmpty()) return false;
        if (left.equals(right) || left.contains(right) || right.contains(left)) return true;
        String[] words = right.split(" ");
        int meaningful = 0;
        int hits = 0;
        for (String word : words) {
            if (word.length() < 3) continue;
            meaningful++;
            if (left.contains(word)) hits++;
        }
        return meaningful > 0 && hits >= Math.max(1, (int) Math.ceil(meaningful * 0.6));
    }

    private static String normalizeText(String value) {
        if (value == null) return "";
        String n = Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
    }

    private static String firstNonBlank(String... values) {
        for (String v : values) if (v != null && !v.isBlank()) return v;
        return "";
    }

    private static String nullToEmpty(String value) { return value == null ? "" : value; }

    private static String safe(Exception e) {
        String m = e.getMessage();
        return m == null || m.isBlank() ? e.getClass().getSimpleName() : m;
    }
}
