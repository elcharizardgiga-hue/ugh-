package app.sideplay.mobile;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.ResolvingDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.SettableFuture;

import org.json.JSONObject;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.net.URI;
import java.net.URLDecoder;

public class PlaybackService extends MediaSessionService {
    public static final String ACTION_PLAY = "app.sideplay.mobile.PLAY";
    public static final String ACTION_PAUSE = "app.sideplay.mobile.PAUSE";
    public static final String ACTION_RESUME = "app.sideplay.mobile.RESUME";
    public static final String ACTION_STOP = "app.sideplay.mobile.STOP";
    public static final String ACTION_EVENT = "app.sideplay.mobile.PLAYBACK_EVENT";

    private static final String PREFS = "sideplay-playback-resume-v1";
    private static final String K_URL = "url";
    private static final String K_TITLE = "title";
    private static final String K_ARTIST = "artist";
    private static final String K_ARTWORK = "artwork";
    private static final String K_MIME = "mime";
    private static final String K_HEADERS = "headers";
    private static final String K_SOURCE_URL = "sourceUrl";
    private static final String K_REFRESH_MODE = "refreshMode";
    private static final String K_POSITION = "position";
    private static final String K_RESUMABLE = "resumable";
    private static final String K_WANT_PLAY = "wantPlay";
    private static final String K_AUDIO_PREFERRED = "audioPreferred";
    private static final String K_UPDATED = "updated";

    private static volatile PlaybackService instance;

    private ExoPlayer player;
    private MediaSession mediaSession;
    private SharedPreferences resumePrefs;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    private final Handler retryHandler = new Handler(Looper.getMainLooper());
    private final Handler checkpointHandler = new Handler(Looper.getMainLooper());
    private int retryCount = 0;
    private int retryGeneration = 0;
    private volatile boolean wantPlay = false;
    private volatile boolean pendingNetworkRecovery = false;
    private volatile boolean currentResumable = false;
    private volatile Uri currentOriginalUri;
    private volatile Map<String, String> currentHeaders = Collections.emptyMap();
    private volatile String currentSourceUrl = "";
    private volatile String currentRefreshMode = "";
    private volatile boolean currentAudioPreferred = false;
    private volatile boolean extractorRefreshInFlight = false;
    private volatile int extractorRefreshCount = 0;

    private final Runnable checkpointRunnable = new Runnable() {
        @Override public void run() {
            try { persistCurrent(); } catch (Exception ignored) {}
            if (player != null && player.getMediaItemCount() > 0) {
                checkpointHandler.postDelayed(this, 5000L);
            }
        }
    };

    public static @Nullable PlaybackService getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        resumePrefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
            .setUserAgent("SidePlay/0.8.0 Android")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(12000)
            .setReadTimeoutMs(30000);
        DefaultDataSource.Factory baseDataSourceFactory = new DefaultDataSource.Factory(this, httpFactory);
        DataSource.Factory resolvingDataSourceFactory = new ResolvingDataSource.Factory(
            baseDataSourceFactory,
            dataSpec -> dataSpec.withRequestHeaders(headersForUri(currentHeaders, currentOriginalUri, dataSpec.uri))
        );
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(this)
            .setDataSourceFactory(resolvingDataSourceFactory);

        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
            .setBufferDurationsMsForStreaming(15000, 60000, 1200, 2800)
            .setBufferDurationsMsForLocalPlayback(1000, 30000, 500, 900)
            .setBackBuffer(15000, true)
            .setPrioritizeTimeOverSizeThresholdsForStreaming(true)
            .build();

        player = new ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build();

        TrackSelectionParameters.AudioOffloadPreferences offloadPreferences =
            new TrackSelectionParameters.AudioOffloadPreferences.Builder()
                .setAudioOffloadMode(TrackSelectionParameters.AudioOffloadPreferences.AUDIO_OFFLOAD_MODE_ENABLED)
                .setIsGaplessSupportRequired(true)
                .build();
        player.setTrackSelectionParameters(
            player.getTrackSelectionParameters().buildUpon()
                .setAudioOffloadPreferences(offloadPreferences)
                .build()
        );

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build();
        player.setAudioAttributes(audioAttributes, true);
        player.setHandleAudioBecomingNoisy(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                broadcast(isPlaying ? "playing" : "paused", null);
                persistCurrent();
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_ENDED) {
                    wantPlay = false;
                    pendingNetworkRecovery = false;
                    broadcast("ended", null);
                    persistCurrent();
                } else if (playbackState == Player.STATE_BUFFERING) {
                    broadcast("buffering", null);
                } else if (playbackState == Player.STATE_READY) {
                    retryCount = 0;
                    extractorRefreshCount = 0;
                    pendingNetworkRecovery = false;
                    broadcast(player.isPlaying() ? "playing" : "ready", null);
                    persistCurrent();
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (player != null && player.getMediaItemCount() > 0 && retryCount < 3) {
                    final int generation = retryGeneration;
                    final int attempt = ++retryCount;
                    broadcast("buffering", "Connection interrupted. Retrying " + attempt + "/3…");
                    retryHandler.postDelayed(() -> {
                        if (generation != retryGeneration || player == null || player.getMediaItemCount() == 0) return;
                        try {
                            player.prepare();
                            if (wantPlay) player.play();
                        } catch (Exception retryError) {
                            broadcast("error", retryError.getMessage() == null ? "Native playback retry failed." : retryError.getMessage());
                        }
                    }, attempt == 1 ? 900L : attempt == 2 ? 2600L : 6500L);
                    return;
                }
                if ("extractor".equals(currentRefreshMode) && isSafeDurableSource(currentSourceUrl) && extractorRefreshCount < 2) {
                    refreshExtractorCurrent("Stream expired or provider URL changed. Refreshing source…");
                    return;
                }
                pendingNetworkRecovery = wantPlay && player != null && player.getMediaItemCount() > 0;
                broadcast("error", error == null ? "Native playback failed. Waiting for network recovery." : error.getMessage());
            }
        });

        MediaSession.Callback sessionCallback = new MediaSession.Callback() {
            @Override
            @UnstableApi
            public ListenableFuture<MediaSession.MediaItemsWithStartPosition> onPlaybackResumption(
                MediaSession session,
                MediaSession.ControllerInfo controller,
                boolean isForPlayback
            ) {
                ResumeState state = readResumeState();
                if (state == null) {
                    return Futures.immediateFailedFuture(new IllegalStateException("No resumable SidePlay item is available."));
                }
                wantPlay = isForPlayback || state.wantPlay;
                if ("extractor".equals(state.refreshMode) && isSafeDurableSource(state.sourceUrl)) {
                    SettableFuture<MediaSession.MediaItemsWithStartPosition> future = SettableFuture.create();
                    new Thread(() -> {
                        try {
                            FreshExtractor fresh = resolveFreshExtractor(state.sourceUrl, state.audioPreferred || (state.mimeType != null && state.mimeType.startsWith("audio/")));
                            applyFreshExtractorState(fresh, state);
                            MediaItem item = buildMediaItem(fresh.url, state.title, state.artist, state.artwork, fresh.mimeType);
                            future.set(new MediaSession.MediaItemsWithStartPosition(
                                Collections.singletonList(item), 0, Math.max(0L, state.positionMs)
                            ));
                        } catch (Throwable e) {
                            future.setException(e);
                        }
                    }, "SidePlayResumeExtractor").start();
                    return future;
                }
                applyResumeNetworkState(state);
                MediaItem item = buildMediaItem(state.url, state.title, state.artist, state.artwork, state.mimeType);
                return Futures.immediateFuture(
                    new MediaSession.MediaItemsWithStartPosition(
                        Collections.singletonList(item),
                        0,
                        Math.max(0L, state.positionMs)
                    )
                );
            }
        };

        mediaSession = new MediaSession.Builder(this, player)
            .setCallback(sessionCallback)
            .build();

        registerNetworkRecovery();
        checkpointHandler.postDelayed(checkpointRunnable, 5000L);
    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        int baseResult = super.onStartCommand(intent, flags, startId);

        // START_STICKY process recreation: if Android killed SidePlay while actively
        // playing a stable native item, reconstruct the player without requiring the UI.
        if (intent == null) {
            ResumeState state = readResumeState();
            if (state != null && state.wantPlay) {
                try {
                    restoreIntoPlayerSmart(state, true);
                    return START_STICKY;
                } catch (Exception e) {
                    broadcast("error", "Could not restore background playback: " + safe(e));
                }
            }
            return baseResult;
        }

        String action = intent.getAction();

        if (ACTION_PLAY.equals(action)) {
            retryGeneration++;
            retryCount = 0;
            pendingNetworkRecovery = false;
            String url = intent.getStringExtra("url");
            String title = intent.getStringExtra("title");
            String artist = intent.getStringExtra("artist");
            String artwork = intent.getStringExtra("artwork");
            String mimeType = intent.getStringExtra("mimeType");
            String headersJson = intent.getStringExtra("requestHeadersJson");
            String sourceUrl = intent.getStringExtra("sourceUrl");
            String refreshMode = intent.getStringExtra("refreshMode");
            boolean requestedResumable = intent.getBooleanExtra("resumable", true);
            boolean audioPreferred = intent.getBooleanExtra("audioPreferred", false);
            long positionMs = Math.max(0L, intent.getLongExtra("positionMs", 0L));

            if (url != null && !url.isBlank()) {
                try {
                    currentOriginalUri = Uri.parse(url);
                    currentHeaders = parseHeaders(headersJson);
                    currentSourceUrl = sourceUrl == null ? "" : sourceUrl.trim();
                    currentRefreshMode = refreshMode == null ? "" : refreshMode.trim();
                    currentAudioPreferred = audioPreferred;
                    extractorRefreshCount = 0;
                    extractorRefreshInFlight = false;
                    boolean durableExtractor = "extractor".equals(currentRefreshMode) && isSafeDurableSource(currentSourceUrl);
                    currentResumable = requestedResumable && !containsSensitiveHeaders(currentHeaders) && (!"extractor".equals(currentRefreshMode) || durableExtractor);
                    wantPlay = true;
                    MediaItem item = buildMediaItem(url, title, artist, artwork, mimeType);
                    player.setMediaItem(item);
                    if (positionMs > 0L) player.seekTo(positionMs);
                    persistSnapshot(url, title, artist, artwork, mimeType, currentHeaders, currentSourceUrl, currentRefreshMode, positionMs, currentResumable, true);
                    player.prepare();
                    player.play();
                    checkpointHandler.removeCallbacks(checkpointRunnable);
                    checkpointHandler.postDelayed(checkpointRunnable, 5000L);
                } catch (Exception e) {
                    broadcast("error", e.getMessage() == null ? "Could not prepare captured media." : e.getMessage());
                }
            }
            return START_STICKY;
        }

        if (ACTION_PAUSE.equals(action)) {
            retryGeneration++;
            wantPlay = false;
            player.pause();
            persistCurrent();
            return START_STICKY;
        }

        if (ACTION_RESUME.equals(action)) {
            wantPlay = true;
            if (player.getMediaItemCount() > 0) {
                player.play();
            } else {
                ResumeState state = readResumeState();
                if (state != null) restoreIntoPlayerSmart(state, true);
            }
            persistCurrent();
            return START_STICKY;
        }

        if (ACTION_STOP.equals(action)) {
            retryGeneration++;
            wantPlay = false;
            pendingNetworkRecovery = false;
            player.stop();
            player.clearMediaItems();
            clearResumeState();
            stopSelf();
            return START_NOT_STICKY;
        }

        return baseResult;
    }

    private MediaItem buildMediaItem(String url, String title, String artist, String artwork, String mimeType) {
        MediaMetadata.Builder meta = new MediaMetadata.Builder()
            .setTitle(title == null || title.isBlank() ? "SidePlay" : title)
            .setArtist(artist == null ? "" : artist);
        if (artwork != null && !artwork.isBlank()) {
            try { meta.setArtworkUri(Uri.parse(artwork)); } catch (Exception ignored) {}
        }

        MediaItem.Builder itemBuilder = new MediaItem.Builder()
            .setUri(Uri.parse(url))
            .setMediaMetadata(meta.build());
        if (mimeType != null && !mimeType.isBlank()) itemBuilder.setMimeType(mimeType);
        return itemBuilder.build();
    }

    private void restoreIntoPlayerSmart(ResumeState state, boolean play) {
        if ("extractor".equals(state.refreshMode) && isSafeDurableSource(state.sourceUrl)) {
            broadcast("buffering", "Refreshing provider stream…");
            new Thread(() -> {
                try {
                    FreshExtractor fresh = resolveFreshExtractor(state.sourceUrl, state.audioPreferred || (state.mimeType != null && state.mimeType.startsWith("audio/")));
                    retryHandler.post(() -> {
                        try {
                            applyFreshExtractorState(fresh, state);
                            currentResumable = true;
                            wantPlay = play;
                            MediaItem item = buildMediaItem(fresh.url, state.title, state.artist, state.artwork, fresh.mimeType);
                            player.setMediaItem(item);
                            if (state.positionMs > 0L) player.seekTo(state.positionMs);
                            persistSnapshot(fresh.url, state.title, state.artist, state.artwork, fresh.mimeType, fresh.headers,
                                state.sourceUrl, "extractor", state.positionMs, true, play);
                            player.prepare();
                            if (play) player.play();
                        } catch (Exception e) {
                            broadcast("error", "Could not restore provider stream: " + safe(e));
                        }
                    });
                } catch (Throwable e) {
                    retryHandler.post(() -> broadcast("error", "Could not refresh provider stream: " + safe(e)));
                }
            }, "SidePlayRestoreExtractor").start();
            return;
        }
        restoreIntoPlayer(state, play);
    }

    private void refreshExtractorCurrent(String message) {
        if (extractorRefreshInFlight || !"extractor".equals(currentRefreshMode) || !isSafeDurableSource(currentSourceUrl)) return;
        extractorRefreshInFlight = true;
        extractorRefreshCount++;
        final long position = getPositionMs();
        final MediaItem current = player == null ? null : player.getCurrentMediaItem();
        final String title = current == null || current.mediaMetadata.title == null ? "SidePlay" : current.mediaMetadata.title.toString();
        final String artist = current == null || current.mediaMetadata.artist == null ? "" : current.mediaMetadata.artist.toString();
        final String artwork = current == null || current.mediaMetadata.artworkUri == null ? "" : current.mediaMetadata.artworkUri.toString();
        final String source = currentSourceUrl;
        broadcast("buffering", message);

        new Thread(() -> {
            try {
                FreshExtractor fresh = resolveFreshExtractor(source, currentAudioPreferred);
                retryHandler.post(() -> {
                    try {
                        currentOriginalUri = Uri.parse(fresh.url);
                        currentHeaders = fresh.headers;
                        retryCount = 0;
                        pendingNetworkRecovery = false;
                        MediaItem item = buildMediaItem(fresh.url, title, artist, artwork, fresh.mimeType);
                        player.setMediaItem(item);
                        if (position > 0L) player.seekTo(position);
                        persistSnapshot(fresh.url, title, artist, artwork, fresh.mimeType, fresh.headers,
                            source, "extractor", position, currentResumable, wantPlay);
                        player.prepare();
                        if (wantPlay) player.play();
                    } catch (Exception e) {
                        pendingNetworkRecovery = wantPlay;
                        broadcast("error", "Provider stream refresh failed: " + safe(e));
                    } finally {
                        extractorRefreshInFlight = false;
                    }
                });
            } catch (Throwable e) {
                retryHandler.post(() -> {
                    extractorRefreshInFlight = false;
                    pendingNetworkRecovery = wantPlay;
                    broadcast("error", "Provider stream refresh failed: " + safe(e));
                });
            }
        }, "SidePlayRefreshExtractor").start();
    }

    private FreshExtractor resolveFreshExtractor(String sourceUrl, boolean audioOnly) throws Exception {
        JSONObject resolved = YtDlpPlugin.resolveForPlayback(getApplicationContext(), sourceUrl, audioOnly);
        String url = resolved.optString("playbackUrl", "");
        if (url.isBlank()) throw new Exception("Extractor returned no playable URL.");
        String mime = resolved.optString("mimeType", "");
        JSONObject rawHeaders = resolved.optJSONObject("requestHeaders");
        Map<String, String> headers = rawHeaders == null ? Collections.emptyMap() : parseHeaders(rawHeaders.toString());
        return new FreshExtractor(url, mime, headers);
    }

    private void applyFreshExtractorState(FreshExtractor fresh, ResumeState state) {
        currentOriginalUri = Uri.parse(fresh.url);
        currentHeaders = fresh.headers;
        currentSourceUrl = state.sourceUrl == null ? "" : state.sourceUrl;
        currentRefreshMode = "extractor";
        currentAudioPreferred = state.audioPreferred;
        currentResumable = true;
    }

    private static final class FreshExtractor {
        final String url;
        final String mimeType;
        final Map<String, String> headers;
        FreshExtractor(String url, String mimeType, Map<String, String> headers) {
            this.url = url;
            this.mimeType = mimeType == null ? "" : mimeType;
            this.headers = headers == null ? Collections.emptyMap() : headers;
        }
    }

    private void restoreIntoPlayer(ResumeState state, boolean play) {
        applyResumeNetworkState(state);
        currentResumable = true;
        wantPlay = play;
        MediaItem item = buildMediaItem(state.url, state.title, state.artist, state.artwork, state.mimeType);
        player.setMediaItem(item);
        if (state.positionMs > 0L) player.seekTo(state.positionMs);
        player.prepare();
        if (play) player.play();
    }

    private void applyResumeNetworkState(ResumeState state) {
        currentOriginalUri = Uri.parse(state.url);
        currentHeaders = parseHeaders(state.headersJson);
        currentSourceUrl = state.sourceUrl == null ? "" : state.sourceUrl;
        currentRefreshMode = state.refreshMode == null ? "" : state.refreshMode;
        currentAudioPreferred = state.audioPreferred;
        currentResumable = true;
    }

    private void registerNetworkRecovery() {
        try {
            connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager == null) return;
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    retryHandler.post(() -> {
                        if (!pendingNetworkRecovery || !wantPlay || player == null || player.getMediaItemCount() == 0) return;
                        try {
                            retryCount = 0;
                            retryGeneration++;
                            pendingNetworkRecovery = false;
                            if ("extractor".equals(currentRefreshMode) && isSafeDurableSource(currentSourceUrl)) {
                                refreshExtractorCurrent("Network restored. Refreshing provider stream…");
                            } else {
                                player.prepare();
                                player.play();
                                broadcast("buffering", "Network restored. Reconnecting…");
                            }
                        } catch (Exception e) {
                            pendingNetworkRecovery = true;
                        }
                    });
                }
            };
            connectivityManager.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception ignored) {}
    }

    private void persistCurrent() {
        if (resumePrefs == null || player == null || player.getMediaItemCount() == 0 || !currentResumable) return;
        MediaItem item = player.getCurrentMediaItem();
        if (item == null || item.localConfiguration == null || item.localConfiguration.uri == null) return;
        MediaMetadata meta = item.mediaMetadata;
        String artwork = meta.artworkUri == null ? "" : meta.artworkUri.toString();
        String mime = item.localConfiguration.mimeType == null ? "" : item.localConfiguration.mimeType;
        persistSnapshot(
            item.localConfiguration.uri.toString(),
            meta.title == null ? "SidePlay" : meta.title.toString(),
            meta.artist == null ? "" : meta.artist.toString(),
            artwork,
            mime,
            currentHeaders,
            currentSourceUrl,
            currentRefreshMode,
            getPositionMs(),
            true,
            wantPlay
        );
    }

    private void persistSnapshot(
        String url,
        String title,
        String artist,
        String artwork,
        String mimeType,
        Map<String, String> headers,
        String sourceUrl,
        String refreshMode,
        long positionMs,
        boolean resumable,
        boolean shouldPlay
    ) {
        if (resumePrefs == null || !resumable || url == null || url.isBlank()) {
            if (!resumable) clearResumeState();
            return;
        }
        Map<String, String> safeHeaders = stripSensitiveHeaders(headers);
        resumePrefs.edit()
            .putString(K_URL, url)
            .putString(K_TITLE, title == null ? "SidePlay" : title)
            .putString(K_ARTIST, artist == null ? "" : artist)
            .putString(K_ARTWORK, artwork == null ? "" : artwork)
            .putString(K_MIME, mimeType == null ? "" : mimeType)
            .putString(K_HEADERS, toJson(safeHeaders))
            .putString(K_SOURCE_URL, sourceUrl == null ? "" : sourceUrl)
            .putString(K_REFRESH_MODE, refreshMode == null ? "" : refreshMode)
            .putLong(K_POSITION, Math.max(0L, positionMs))
            .putBoolean(K_RESUMABLE, true)
            .putBoolean(K_WANT_PLAY, shouldPlay)
            .putBoolean(K_AUDIO_PREFERRED, currentAudioPreferred)
            .putLong(K_UPDATED, System.currentTimeMillis())
            .apply();
    }

    private @Nullable ResumeState readResumeState() {
        if (resumePrefs == null || !resumePrefs.getBoolean(K_RESUMABLE, false)) return null;
        String url = resumePrefs.getString(K_URL, "");
        if (url == null || url.isBlank()) return null;
        ResumeState out = new ResumeState();
        out.url = url;
        out.title = resumePrefs.getString(K_TITLE, "SidePlay");
        out.artist = resumePrefs.getString(K_ARTIST, "");
        out.artwork = resumePrefs.getString(K_ARTWORK, "");
        out.mimeType = resumePrefs.getString(K_MIME, "");
        out.headersJson = resumePrefs.getString(K_HEADERS, "{}");
        out.sourceUrl = resumePrefs.getString(K_SOURCE_URL, "");
        out.refreshMode = resumePrefs.getString(K_REFRESH_MODE, "");
        out.positionMs = Math.max(0L, resumePrefs.getLong(K_POSITION, 0L));
        out.wantPlay = resumePrefs.getBoolean(K_WANT_PLAY, false);
        out.audioPreferred = resumePrefs.getBoolean(K_AUDIO_PREFERRED, out.mimeType != null && out.mimeType.startsWith("audio/"));
        return out;
    }

    private void clearResumeState() {
        if (resumePrefs != null) resumePrefs.edit().clear().apply();
    }

    private static class ResumeState {
        String url;
        String title;
        String artist;
        String artwork;
        String mimeType;
        String headersJson;
        String sourceUrl;
        String refreshMode;
        long positionMs;
        boolean wantPlay;
        boolean audioPreferred;
    }

    private static boolean isSafeDurableSource(@Nullable String raw) {
        if (raw == null || raw.isBlank()) return false;
        try {
            URI uri = URI.create(raw);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            if (!(scheme.equals("http") || scheme.equals("https")) || uri.getHost() == null || uri.getHost().isBlank()) return false;
            if (uri.getUserInfo() != null && !uri.getUserInfo().isBlank()) return false;
            String query = uri.getRawQuery();
            if (query == null || query.isBlank()) return true;
            for (String part : query.split("&")) {
                String rawKey = part.contains("=") ? part.substring(0, part.indexOf('=')) : part;
                String key;
                try { key = URLDecoder.decode(rawKey, "UTF-8").toLowerCase(Locale.ROOT); }
                catch (Exception ignored) { key = rawKey.toLowerCase(Locale.ROOT); }
                // Common public navigation parameters are safe to persist. Anything
                // resembling an auth/signed-CDN credential remains ephemeral.
                if (key.equals("v") || key.equals("list") || key.equals("index") || key.equals("t") || key.equals("start") || key.equals("si")) continue;
                if (key.contains("token") || key.contains("auth") || key.contains("signature") || key.equals("sig") ||
                    key.contains("credential") || key.contains("session") || key.contains("jwt") || key.contains("policy") ||
                    key.equals("key") || key.contains("expires")) return false;
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static Map<String, String> parseHeaders(@Nullable String raw) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (raw == null || raw.isBlank()) return out;
        try {
            JSONObject json = new JSONObject(raw);
            Iterator<String> keys = json.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                String value = json.optString(key, "");
                if (key == null || key.isBlank() || value.isBlank()) continue;
                String lower = key.toLowerCase(Locale.ROOT);
                if (lower.equals("host") || lower.equals("content-length") || lower.equals("connection") || lower.equals("accept-encoding") || lower.equals("range") || lower.startsWith("sec-")) continue;
                out.put(key, value);
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static boolean containsSensitiveHeaders(Map<String, String> headers) {
        for (String key : headers.keySet()) if (isSensitiveHeader(key)) return true;
        return false;
    }

    private static Map<String, String> stripSensitiveHeaders(Map<String, String> headers) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (headers == null) return out;
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            if (entry.getKey() == null || entry.getValue() == null || entry.getValue().isBlank()) continue;
            if (isSensitiveHeader(entry.getKey())) continue;
            out.put(entry.getKey(), entry.getValue());
        }
        return out;
    }

    private static String toJson(Map<String, String> headers) {
        JSONObject json = new JSONObject();
        if (headers != null) {
            for (Map.Entry<String, String> e : headers.entrySet()) {
                try { json.put(e.getKey(), e.getValue()); } catch (Exception ignored) {}
            }
        }
        return json.toString();
    }

    private static Map<String, String> headersForUri(Map<String, String> captured, Uri original, Uri target) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        if (captured == null) return out;
        String originalHost = original == null || original.getHost() == null ? "" : original.getHost();
        String targetHost = target == null || target.getHost() == null ? "" : target.getHost();
        boolean sameHost = !originalHost.isBlank() && originalHost.equalsIgnoreCase(targetHost);
        for (Map.Entry<String, String> entry : captured.entrySet()) {
            String key = entry.getKey();
            if (key == null || entry.getValue() == null || entry.getValue().isBlank()) continue;
            if (!sameHost && isSensitiveHeader(key)) continue;
            out.put(key, entry.getValue());
        }
        return out;
    }

    private static boolean isSensitiveHeader(String key) {
        String lower = key == null ? "" : key.toLowerCase(Locale.ROOT);
        return lower.equals("cookie") || lower.equals("authorization") || lower.equals("proxy-authorization") ||
            lower.equals("x-csrf-token") || lower.equals("x-xsrf-token");
    }

    @Override
    public void onTaskRemoved(@Nullable Intent rootIntent) {
        // Keep an active or paused media session alive when the user swipes the UI
        // away. If Android later reclaims the process, persisted resumption handles
        // stable native items without requiring the Activity/WebView.
        if (player != null && player.getMediaItemCount() > 0) {
            persistCurrent();
            return;
        }
        stopSelf();
    }

    public void seekTo(long positionMs) {
        if (player == null) return;
        long duration = normalizedDuration();
        long target = Math.max(0L, positionMs);
        if (duration > 0L) target = Math.min(target, duration);
        player.seekTo(target);
        persistCurrent();
    }

    public long getPositionMs() {
        return player == null ? 0L : Math.max(0L, player.getCurrentPosition());
    }

    public long getDurationMs() {
        return normalizedDuration();
    }

    public boolean isPlayingNow() {
        return player != null && player.isPlaying();
    }

    public int getPlaybackStateValue() {
        return player == null ? Player.STATE_IDLE : player.getPlaybackState();
    }

    private long normalizedDuration() {
        if (player == null) return 0L;
        long duration = player.getDuration();
        return duration == C.TIME_UNSET || duration < 0L ? 0L : duration;
    }

    private void broadcast(String state, @Nullable String message) {
        Intent event = new Intent(ACTION_EVENT);
        event.setPackage(getPackageName());
        event.putExtra("state", state);
        event.putExtra("positionMs", getPositionMs());
        event.putExtra("durationMs", getDurationMs());
        if (message != null && !message.isBlank()) event.putExtra("message", message);
        sendBroadcast(event);
    }

    @Nullable
    @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    @Override
    public void onDestroy() {
        persistCurrent();
        instance = null;
        retryGeneration++;
        retryHandler.removeCallbacksAndMessages(null);
        checkpointHandler.removeCallbacksAndMessages(null);
        try {
            if (connectivityManager != null && networkCallback != null) connectivityManager.unregisterNetworkCallback(networkCallback);
        } catch (Exception ignored) {}
        if (mediaSession != null) mediaSession.release();
        if (player != null) player.release();
        super.onDestroy();
    }

    private static String safe(Throwable t) {
        if (t == null) return "unknown error";
        String message = t.getMessage();
        return message == null || message.isBlank() ? t.getClass().getSimpleName() : message;
    }
}
