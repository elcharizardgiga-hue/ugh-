# SidePlay v0.5.1 — ANYWHERE / WHATEVER + Safe Media Gate

This release pushes SidePlay toward a permissive **play-first** model while making permanent downloads more conservative. The goal is simple: if Android can legitimately see a clear media resource, SidePlay should make a serious attempt to play it; saving that resource is allowed only after it passes media-safety checks.

## Playback reach

- Adds **RTSP** playback through Media3 alongside progressive HTTP(S), HLS and DASH.
- Broadens direct format/container recognition for MP3/MP2/AAC/ADTS/AC3/E-AC3/AC4/AMR/M4A/OGG/Opus/FLAC/WAV, MP4/M4V/MOV/3GP/WebM/MKV/MKA/FLV/F4V/MPEG/TS/M2TS/MTS and extensionless media endpoints.
- Adds byte-signature sniffing for ambiguous `application/octet-stream`, generic binary, text/plain and XML responses so extensionless CDN media/manifests can still be recognized.
- Static page discovery now checks standard HTML5/OpenGraph/Twitter media fields plus common public JSON-ish `contentUrl`, `streamUrl`, `playbackUrl` and `fileUrl` fields before falling back to Media Catcher.
- Adds public **`.m3u` / `.pls` internet-radio playlist unwrapping** so a station playlist resolves to its actual live HTTP(S) stream. Live radio remains play-only.
- Media Catcher is less eager to throw away transport-stream-looking requests when browser request metadata strongly indicates that the request itself is a playable media resource.
- Captured browser media keeps Referer/User-Agent/Cookie/safe request headers for the active session so protected-by-session but non-DRM streams do not immediately fail with 403.
- Session-bound captures now carry freshness metadata. Old/failed captures are re-caught instead of trusting an expired signed CDN URL indefinitely.
- Media3 uses network wake mode and performs two bounded automatic prepare/retry attempts for transient playback failures.
- Queue Previous/Next routes through the same resolver/catcher/native-player pipeline, so unresolved web items do not accidentally bypass the universal playback path.
- Existing Android Share / Open-with flows and local Offline Vault imports remain available for device media.
- Alexa/Echo remains a normal Android Bluetooth output route; the same native player feeds the Echo after pairing.

## Safe download gate

Playback and downloading intentionally use different trust levels. A strange stream may be attempted in memory; a permanent file must pass the offline safety gate first.

- Rejects Android/app packages, Windows/macOS/Linux executables, scripts, Java archives/classes, common archives/disk images and other obviously dangerous download types by extension/MIME.
- Inspects the initial bytes before committing a download/import and rejects PE/EXE, ELF, DEX, ZIP/RAR/7z, Java/class, script/shebang, HTML/document and other non-media signatures masquerading as media.
- Requires recognizable media signatures when a remote server only claims generic binary data.
- Rejects dangerous double-extension names such as `song.mp3.exe`.
- Applies a 4 GiB per-file safety ceiling and keeps a storage reserve before Offline Vault downloads.
- Validates actual bytes during the private Offline Vault transfer rather than trusting only a filename or URL.
- Does not forward captured cookies/auth headers across unrelated redirect hosts.
- Provider-owned download endpoints for YouTube/Spotify/SoundCloud remain blocked rather than being treated as generic downloadable files.
- Captured cookies/auth headers remain runtime-only and are stripped from persisted library/history/export data.

## Boundaries

SidePlay still does not decrypt DRM, defeat encrypted manifests, bypass paywalls/login authorization, or promise provider-owned background playback where the provider/OS forbids it. “Play whatever” means **clear media legitimately exposed to the device/session**, not breaking protection systems.

## Validation performed for this source release

- All Node/MJS scripts pass `node --check`.
- The new pure-Java `MediaSafety` gate compiles independently and passes focused positive/negative signature tests.
- Android patcher simulation verifies native-file copying, RTSP Media3 dependency injection and manifest registration.
- Java syntax/escaping checks on the resolver show no syntax-level errors before the expected missing Android/Capacitor SDK symbols in this sandbox.
- A full Gradle/APK build is not run in this sandbox because the project dependencies/Android SDK build environment are not installed here. Use the included GitHub workflow or the normal local build process for the final APK compile/sign step.
