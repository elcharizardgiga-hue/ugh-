@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where keytool >nul 2>&1
if errorlevel 1 (
  echo ERROR: keytool not found. Install/use the JDK that SidePlay Builder uses, then run this again.
  pause
  exit /b 1
)

set "KEYSTORE=sideplay-release.jks"
set "ALIAS=sideplay"

if exist "%KEYSTORE%" (
  echo %KEYSTORE% already exists. Refusing to overwrite your release signing key.
  echo Back this file up somewhere safe. Losing it means you cannot update APKs signed with it.
  pause
  exit /b 1
)

set /p STOREPASS=Choose a keystore password: 
if "%STOREPASS%"=="" (
  echo ERROR: password cannot be empty.
  pause
  exit /b 1
)

keytool -genkeypair -v ^
  -keystore "%KEYSTORE%" ^
  -storepass "%STOREPASS%" ^
  -keypass "%STOREPASS%" ^
  -alias "%ALIAS%" ^
  -keyalg RSA ^
  -keysize 3072 ^
  -validity 10000 ^
  -dname "CN=SidePlay Release, OU=Mobile, O=SidePlay, C=DO"
if errorlevel 1 (
  echo ERROR: key generation failed.
  pause
  exit /b 1
)

for /f "usebackq delims=" %%B in (`powershell -NoProfile -Command "[Convert]::ToBase64String([IO.File]::ReadAllBytes('%KEYSTORE%'))"`) do set "B64=%%B"

> GITHUB_SIGNING_SECRETS.txt echo SIDEPLAY_KEYSTORE_B64=%B64%
>>GITHUB_SIGNING_SECRETS.txt echo SIDEPLAY_KEYSTORE_PASSWORD=%STOREPASS%
>>GITHUB_SIGNING_SECRETS.txt echo SIDEPLAY_KEY_ALIAS=%ALIAS%
>>GITHUB_SIGNING_SECRETS.txt echo SIDEPLAY_KEY_PASSWORD=%STOREPASS%

echo.
echo DONE.
echo Keep %KEYSTORE% somewhere SAFE and private.
echo Add the four values in GITHUB_SIGNING_SECRETS.txt to GitHub: Settings ^> Secrets and variables ^> Actions.
echo Delete GITHUB_SIGNING_SECRETS.txt after copying the values.
echo.
pause
