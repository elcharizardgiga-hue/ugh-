@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SidePlay USB Installer / PackageManager Diagnostic

set "SIDEPLAY_TOOLS=%LOCALAPPDATA%\SidePlay\tools"
if "%LOCALAPPDATA%"=="" set "SIDEPLAY_TOOLS=%USERPROFILE%\AppData\Local\SidePlay\tools"
if exist "%SIDEPLAY_TOOLS%\sideplay-env.bat" call "%SIDEPLAY_TOOLS%\sideplay-env.bat"

set "APK=SidePlay-INSTALL.apk"
if not exist "%APK%" set "APK=SidePlay-debug.apk"
if not exist "%APK%" (
  echo [FAIL] Build the APK first.
  goto :done
)
where adb >nul 2>&1
if errorlevel 1 (
  echo [FAIL] adb is not available. Run BUILD_SIDEPLAY_APK.bat once first.
  goto :done
)

echo Connect the Android phone by USB, enable Developer options + USB debugging,
echo unlock it, and accept the computer authorization prompt if Android shows one.
echo.
adb start-server >nul 2>&1
adb devices
echo.
echo Attempting PackageManager install. The final line below is the exact Android reason if it fails:
echo --------------------------------------------------------------------------
adb install -r -d "%APK%"
echo --------------------------------------------------------------------------
echo.
echo Common results:
echo   INSTALL_FAILED_UPDATE_INCOMPATIBLE = an older SidePlay was signed with another key.
echo   INSTALL_FAILED_OLDER_SDK = phone Android version is below the APK minimum.
echo   INSTALL_PARSE_FAILED_* = Android rejected package structure/signature/manifest.
echo   INSTALL_FAILED_VERSION_DOWNGRADE = installed SidePlay has a higher versionCode.
echo.
echo This script never uninstalls the existing app automatically.

:done
pause
