# SidePlay v0.6.1 engine/background audit

## Background playback verified in source

- Native SidePlay media is owned by an Android Media3 `MediaSessionService`, independent of the Capacitor Activity/WebView.
- Manifest includes `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, `WAKE_LOCK`, `ACCESS_NETWORK_STATE`, a `mediaPlayback` foreground service, and Media3 `MediaButtonReceiver`.
- ExoPlayer uses `C.WAKE_MODE_NETWORK`, media audio attributes, audio-focus handling, and `handleAudioBecomingNoisy`.
- Swiping the UI from Recents does not stop a native session while a media item exists.
- `START_STICKY` recreation restores stable/local media that was actively playing.
- Media3 `onPlaybackResumption()` restores stable/local media and its last checkpointed position for media-button/system resumption.
- Position/state is checkpointed periodically and on pause/seek/state changes.
- Transient player errors get bounded retries; after exhaustion, Android network availability triggers another reconnect attempt if the user still wants playback.
- Playback request headers are applied by one resolving data-source layer; sensitive cross-host headers remain stripped.
- Cookies, Authorization and CSRF headers are never persisted in the resumption snapshot. Session-bound browser/extractor captures are therefore not claimed as OS-resumable after process death.

## Provider/offline engine retained from v0.6.0

- yt-dlp first-line provider extraction.
- FFmpeg-backed adaptive/separate audio+video offline assembly for clear sources.
- HLS/DASH/RTSP/direct/local Media3 playback.
- Generic resolver and interactive Media Catcher fallbacks.
- Signed provider streams are treated as refreshable, not permanent.
- Completed offline media passes SidePlay `MediaSafety` checks before vault admission.

## GitHub build/deploy

- Current workflow: `.github/workflows/build-apk.yml`.
- Accepts expanded source or `SidePlay-Node-v*.zip` in repository root.
- Uses current GitHub actions generations (`checkout@v7`, `setup-node@v7`, `setup-java@v6`) and Android SDK 36.
- Clean Gradle build, zipalign, signing, `apksigner` verification, and `aapt2 dump badging` package parse.
- Uploads a verified Actions artifact every build.
- `v*` tag publishes/updates a GitHub Release when persistent signing secrets are configured.
- Without persistent signing secrets, CI still emits a fresh-install test APK but deliberately skips tagged Release publication because a new ephemeral signing key would break Android in-place updates.

## Validation performed before packaging

- `PlaybackService.java` Javac syntax/API-shape smoke compile against stubs matching the documented Media3 resumption signatures: PASS.
- Android patcher JavaScript syntax: PASS.
- Synthetic generated-Android patch simulation: manifest XML parse + expected permissions/services/receiver/dependencies: PASS.
- Workflow YAML parse: PASS.
- TypeScript/TSX transpile syntax check: PASS (see packaging log).
- ZIP integrity check: PASS.

## Deliberate boundaries

- No DRM/Widevine decryption or protected-stream bypass.
- No paywall/authentication bypass.
- Browser-session media that requires persisted credentials is not made process-death-resumable by storing those credentials. While playback is active, the foreground native service remains the preferred route whenever SidePlay has obtained a clear Media3-compatible stream.
- A real Gradle dependency build must still occur on Windows or GitHub because the ChatGPT sandbox does not contain the full Android dependency graph. The included builders validate the resulting APK before handoff.
