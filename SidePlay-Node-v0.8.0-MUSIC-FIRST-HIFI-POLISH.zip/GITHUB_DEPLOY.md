# GitHub deploy / APK builds

SidePlay includes `.github/workflows/build-apk.yml`.

## Easiest build

1. Push either the expanded SidePlay source or the SidePlay source ZIP to a GitHub repository.
2. Open **Actions → Build SidePlay APK → Run workflow**.
3. Download the `SidePlay-v0.6.1-VERIFIED-APK` artifact.

## Real GitHub Releases that can update the same installed app

Android updates must keep the same signing key. Create one JKS locally and store it in GitHub repository secrets. Required secrets:

- `SIDEPLAY_KEYSTORE_B64` — base64 of the `.jks` file
- `SIDEPLAY_KEYSTORE_PASSWORD`
- `SIDEPLAY_KEY_ALIAS`
- `SIDEPLAY_KEY_PASSWORD`

On Windows PowerShell, convert a keystore to a one-line base64 value with:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("sideplay-release.jks"))
```

Then push a version tag, for example:

```bash
git tag v0.6.1
git push origin v0.6.1
```

The workflow uploads the normal Actions artifact on every build. For a `v*` tag **with stable signing secrets configured**, it also creates/updates a GitHub Release containing the APK, SHA-256 and release notes.

If signing secrets are missing, normal CI builds still produce an installable test-signed artifact, but tagged GitHub Release publication is intentionally skipped because each ephemeral key would make future APK updates signature-incompatible.
