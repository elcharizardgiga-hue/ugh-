# SidePlay v0.5.1 Hotfix 1

## Android compile fix

- Fixed `SourceResolverPlugin.handleActivityResult(...)` failing Javac because the helper `base(...)` was an instance method called from a static activity-result handler.
- `base(...)` is now `static`; it has no instance-state dependencies.
- Verified the full `SourceResolverPlugin.java` with Javac using Android/Capacitor compatibility stubs. No compile errors remain in this source file; only existing JDK URL-constructor deprecation warnings are emitted.
- No playback, capture, download-safety, Alexa/Echo, queue, resolver, or Media3 behavior was removed or weakened.
