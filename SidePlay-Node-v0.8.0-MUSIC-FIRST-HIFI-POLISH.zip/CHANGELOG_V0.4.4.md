# SidePlay v0.4.4 — engine + source + Android build repair

- Fixed the Android compile failure in `ProviderSessionPlugin.java`: removed the unavailable `RoleManager#getRoleHolders()` call and now resolves the real default browser through `PackageManager.resolveActivity(..., MATCH_DEFAULT_ONLY)`.
- Search is no longer YouTube-only. `All` searches Audius, PeerTube and YouTube in parallel and interleaves results; dedicated source chips let you search one provider explicitly.
- Native-first result ordering: Audius and PeerTube are surfaced before YouTube in `All` so SidePlay-owned Media3 playback is not buried behind provider handoffs.
- Audius results carry direct stream URLs and use SidePlay's native background engine. Downloads are only offered where Audius exposes download permission.
- PeerTube search results are resolved on play to the actual progressive/HLS stream, then handed to Media3. Progressive files remain eligible for the real offline vault.
- Partial provider failures no longer kill the whole search. SidePlay shows the sources that answered and reports only the unavailable source(s).
- Turning off Spotify Lab no longer resets an unrelated native/provider engine back to YouTube.
- Mobile shell reset: fixed mini-player/bottom-nav stacking, narrower track rows/actions, safer error banner, cleaner Now Playing/action sheets, and source filters that scroll instead of overlapping.
- PiP remains disabled.
