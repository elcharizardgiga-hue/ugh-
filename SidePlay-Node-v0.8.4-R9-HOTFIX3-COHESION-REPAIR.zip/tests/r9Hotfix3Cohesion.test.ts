import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { isGenericTrackTitle, mergeTrackMetadata } from '../src/lib/trackIdentity.ts'
import type { Track } from '../src/types.ts'

const baseTrack: Track = {
  videoId: 'dQw4w9WgXcQ',
  title: 'Artist - Real Song',
  channel: 'Artist - Topic',
  thumbnail: 'https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg',
  provider: 'youtube',
  sourceUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
}

test('placeholder resolver metadata never overwrites known song identity', () => {
  const merged = mergeTrackMetadata(baseTrack, {
    playbackUrl: 'https://cdn.example/audio.m4a',
    title: 'Untitled media',
    channel: 'YouTube',
    resolverEngine: 'ytdlp',
  })
  assert.equal(merged.title, baseTrack.title)
  assert.equal(merged.channel, baseTrack.channel)
  assert.equal(merged.playbackUrl, 'https://cdn.example/audio.m4a')
})

test('generic titles are recognized so they cannot poison search/history', () => {
  assert.equal(isGenericTrackTitle('Untitled media', baseTrack.videoId), true)
  assert.equal(isGenericTrackTitle(`YouTube video ${baseTrack.videoId}`, baseTrack.videoId), true)
  assert.equal(isGenericTrackTitle('Real Song', baseTrack.videoId), false)
})

test('taste events keep identity snapshots and ignore generic artist buckets', () => {
  const taste = fs.readFileSync(path.resolve('src/lib/tasteEngine.ts'), 'utf8')
  const store = fs.readFileSync(path.resolve('src/lib/store.tsx'), 'utf8')
  assert.match(store, /artistKey: identity\?\.artistKey/)
  assert.match(store, /canonicalKey: identity \? canonicalTrackKey/)
  assert.match(taste, /event\.artistKey \|\|/)
  assert.match(taste, /event\.title && event\.channel/)
  assert.match(taste, /identityIsUsable/)
  assert.match(taste, /scoreIdentity\(event\.videoId/)
})

test('search submit hides autocomplete and stale search generations cannot win', () => {
  const app = fs.readFileSync(path.resolve('src/App.tsx'), 'utf8')
  assert.match(app, /suggestionsEnabled&&!!query\.trim\(\)/)
  assert.match(app, /const requestId = \+\+searchRequestRef\.current/)
  assert.match(app, /searchRequestRef\.current !== requestId/)
  assert.match(app, /suggestionRequestRef\.current !== requestId/)
})

test('manual transitions feed skip behavior centrally', () => {
  const app = fs.readFileSync(path.resolve('src/App.tsx'), 'utf8')
  assert.match(app, /outgoing\.videoId !== track\.videoId/)
  assert.match(app, /sp\.recordSkip\(outgoing\.videoId/)
  assert.match(app, /sp\.recordDislike\(track\)/)
})

test('now playing is scrollable and lyrics have real fallback + retry paths', () => {
  const app = fs.readFileSync(path.resolve('src/App.tsx'), 'utf8')
  const css = fs.readFileSync(path.resolve('src/styles.css'), 'utf8')
  const lyrics = fs.readFileSync(path.resolve('src/lib/lyrics.ts'), 'utf8')
  assert.match(css, /\.now-playing\{[^}]*overflow-y:auto/)
  assert.match(css, /\.lyrics-scroll\{[^}]*overflow-y:auto/)
  assert.match(app, /lyrics-error/)
  assert.match(app, /Retry/)
  assert.match(app, /onSeek\(line\.startMs\)/)
  assert.match(lyrics, /https:\/\/lrclib\.net\/api/)
  assert.match(lyrics, /parseLrc/)
  assert.match(lyrics, /NativeYouTube\.lyrics/)
})
