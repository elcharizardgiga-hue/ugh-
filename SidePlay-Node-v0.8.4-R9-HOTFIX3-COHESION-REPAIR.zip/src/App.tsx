import { useEffect, useMemo, useRef, useState } from 'react'
import { Capacitor } from '@capacitor/core'
import { App as CapacitorApp } from '@capacitor/app'
import {
  ArrowDown, ArrowUp, BatteryCharging, Bluetooth, CheckCircle2, ChevronDown, Clock3, Compass, Download, ExternalLink, FolderOpen,
  Heart, History, Home, ListMusic, Menu, Moon, MoreHorizontal, Music2, Pause,
  Play, Plus, Radio, RefreshCw, Repeat2, Search, Settings, Shuffle, SkipBack,
  SkipForward, Sparkles, Trash2, UploadCloud, FileArchive, WifiOff, X, Mic2, SlidersHorizontal, ThumbsDown
} from 'lucide-react'
import type { LyricsResult, OfflineCopy, Playlist, RadioTuning, Track } from './types'
import { useSidePlay } from './lib/store'
import { extractVideoId, getTrackById, searchYouTube, suggestYouTube } from './lib/youtube'
import { BackgroundAudio, SharedText, WebPlayback, SpotifySession, ProviderSession, isNative } from './lib/nativeAudio'
import { YouTubePlayer } from './components/YouTubePlayer'
import { DEFAULT_RADIO_TUNING, discoverRadio, discoverRecommendations, localMixes, type Mix } from './lib/recommendations'
import { downloadOfflineCopy, formatBytes, importOfflineCopy, importSharedOfflineCopy, onOfflineDownloadProgress, removeOfflineCopy } from './lib/offlineMedia'
import { captureUniversalUrl, clearResolverCache, getResolverCacheHealth, isHttpUrl, openExternalUrl, prefetchUniversalUrl, providerLabel, resolutionToTrack, resolveUniversalUrl } from './lib/universalSource'
import { parseYouTubeExportFile } from './lib/youtubeTakeout'
import { interleaveSources, searchAudius, searchPeerTube } from './lib/sourceSearch'
import { searchWithYtDlp } from './lib/ytDlp'
import { NativeYouTube } from './lib/nativeYouTube'
import { hasGenericYouTubeMetadata, isGenericTrackChannel, isGenericTrackTitle, mergeTrackMetadata, repairTrackIdentity, repairTrackList } from './lib/trackIdentity'
import { rankAndDedupeMusicSearch } from './lib/musicIdentity'
import { getLyrics } from './lib/lyrics'

type Tab = 'home' | 'search' | 'library' | 'downloads' | 'queue' | 'settings'
type YouTubeBridgeMode = 'auto' | 'app' | 'web'
type SearchScope = 'all' | 'youtube' | 'soundcloud' | 'audius' | 'peertube'

export default function App() {
  const sp = useSidePlay()
  const [tab, setTab] = useState<Tab>('home')
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Track[]>([])
  const [searchScope, setSearchScope] = useState<SearchScope>(() => {
    const saved = localStorage.getItem('sideplay.searchScope')
    return saved === 'youtube' || saved === 'soundcloud' || saved === 'audius' || saved === 'peertube' ? saved : 'all'
  })
  const [searchSources, setSearchSources] = useState<string[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [resolvingTrackId, setResolvingTrackId] = useState<string | null>(null)
  const playbackRequestRef = useRef(0)
  const searchRequestRef = useRef(0)
  const suggestionRequestRef = useRef(0)
  const [expanded, setExpanded] = useState(false)
  const [playlistTarget, setPlaylistTarget] = useState<Track | null>(null)
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null)
  const [sleepUntil, setSleepUntil] = useState<number | null>(null)
  const [sleepAfterCurrent, setSleepAfterCurrent] = useState(false)
  const [paused, setPaused] = useState(false)
  const [recommendations, setRecommendations] = useState<Track[]>([])
  const [recsBusy, setRecsBusy] = useState(false)
  const [offlineBusy, setOfflineBusy] = useState<string | null>(null)
  const [downloadProgress, setDownloadProgress] = useState<Record<string, number>>({})
  const [trackMenu, setTrackMenu] = useState<Track | null>(null)
  const [positionMs, setPositionMs] = useState(0)
  const [durationMs, setDurationMs] = useState(0)
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('sideplay.recentSearches') || '[]').slice(0, 8) }
    catch { return [] }
  })
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [suggestionsEnabled, setSuggestionsEnabled] = useState(false)
  const [radioTuning, setRadioTuning] = useState<RadioTuning>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('sideplay.radioTuning.v1') || '{}')
      return {
        mode: ['balanced','stay','deeper','surprise','energy','chill'].includes(saved.mode) ? saved.mode : DEFAULT_RADIO_TUNING.mode,
        discovery: Math.max(0, Math.min(100, Number(saved.discovery ?? DEFAULT_RADIO_TUNING.discovery))),
        variety: Math.max(0, Math.min(100, Number(saved.variety ?? DEFAULT_RADIO_TUNING.variety))),
      } as RadioTuning
    } catch { return DEFAULT_RADIO_TUNING }
  })
  const [spotifyEngineEnabled, setSpotifyEngineEnabled] = useState(false)
  const [youtubeProviderEnabled, setYoutubeProviderEnabled] = useState(false)
  const [youtubeProviderRoute, setYoutubeProviderRoute] = useState<YouTubeBridgeMode>(() => {
    const saved = localStorage.getItem('sideplay.youtubeProviderRoute')
    return saved === 'app' || saved === 'web' ? saved : 'auto'
  })
  const [autoplayEnabled, setAutoplayEnabled] = useState(() => localStorage.getItem('sideplay.autoplay') !== '0')
  const [playbackEngine, setPlaybackEngine] = useState<'youtube' | 'youtube-provider' | 'youtube-provider-pending' | 'youtube-browser' | 'youtube-browser-pending' | 'spotify' | 'spotify-error' | 'native'>('youtube')
  const playerRef = useRef<any | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const endedRef = useRef<() => void>(() => {})
  const lastEndedRef = useRef<{ videoId: string; at: number }>({ videoId: '', at: 0 })
  const scrubbingRef = useRef(false)
  const nativeStartPositionRef = useRef(0)
  const wantsPlaybackRef = useRef(false)
  const useOfflineRef = useRef(false)
  const currentRef = useRef<Track | null>(null)
  const staleCaptureIdsRef = useRef<Set<string>>(new Set())
  const radioPromiseRef = useRef<Promise<Track[]> | null>(null)
  const radioSeedRef = useRef('')
  const tasteRefreshSeenRef = useRef(sp.state.tasteEvents[0]?.at || 0)
  const recommendationRequestRef = useRef(0)

  const current = sp.current
  const currentOffline = current ? sp.getOfflineCopy(current.videoId) : null
  const usableOffline = currentOffline && currentOffline.platform === (isNative() ? 'android' : 'pc') ? currentOffline : null
  // Android: if a persistent local copy exists, use Media3 from the user's Play action.
  // Starting the mediaPlayback foreground service while SidePlay is still foreground is
  // materially more reliable than trying to start it during the background transition.
  // PC keeps the user preference because browser playback does not need an Android FGS.
  const useOffline = !!usableOffline && (isNative() || sp.state.preferOffline)
  useOfflineRef.current = useOffline
  currentRef.current = current
  const mixes = useMemo(() => localMixes(sp.state), [sp.state.favorites, sp.state.history, sp.state.playlists, sp.state.playCounts, sp.state.skipCounts, sp.state.completionCounts, sp.state.tasteEvents, sp.state.offline])

  async function buildRadio(seed: Track) {
    const radioKey = `${seed.videoId}:${radioTuning.mode}:${radioTuning.discovery}:${radioTuning.variety}`
    if (radioPromiseRef.current && radioSeedRef.current === radioKey) return radioPromiseRef.current
    radioSeedRef.current = radioKey
    const snapshot = sp.state
    const work = discoverRadio(seed, snapshot, 18, radioTuning)
      .then((tracks) => {
        const clean = uniqueTracks(tracks).filter((t) => t.videoId !== seed.videoId)
        if (clean.length) {
          setRecommendations((prev) => uniqueTracks([...clean, ...prev]).slice(0, 30))
        }
        return clean
      })
      .finally(() => {
        if (radioSeedRef.current === radioKey) radioPromiseRef.current = null
      })
    radioPromiseRef.current = work
    return work
  }

  async function startRadio(seed: Track) {
    const radio = await buildRadio(seed)
    const autoplay = radio.map((item) => ({ ...item, queueOrigin: 'autoplay' as const }))
    const queue = uniqueTracks([{ ...seed, queueOrigin: 'manual' as const }, ...autoplay])
    await play({ ...seed, queueOrigin: 'manual' }, queue)
  }

  useEffect(() => {
    if (!isNative()) return
    // PiP is intentionally disabled. On Android, playback stays SidePlay-owned;
    // WebPlayback is retained only for non-native browser builds.
    WebPlayback.setPipEnabled({ enabled: false }).catch(() => {})
  }, [])

  useEffect(() => {
    if (!isNative()) return
    // v0.8.1: never auto-escape to YouTube/Spotify/browser from a Play tap.
    // Keep Open source as an explicit user action only.
    localStorage.setItem('sideplay.youtubeProvider', '0')
    localStorage.setItem('sideplay.spotifyEngine', '0')
  }, [])

  useEffect(() => {
    localStorage.setItem('sideplay.recentSearches', JSON.stringify(recentSearches.slice(0, 8)))
  }, [recentSearches])

  useEffect(() => {
    localStorage.setItem('sideplay.radioTuning.v1', JSON.stringify(radioTuning))
  }, [radioTuning])

  useEffect(() => {
    // Heal placeholder metadata left behind by older resolver builds. This is
    // intentionally bounded and only touches YouTube ids that can be hydrated
    // without invoking the heavy media extractor.
    const candidates = uniqueTracks([
      ...sp.state.queue,
      ...sp.state.history,
      ...sp.state.favorites,
      ...sp.state.playlists.flatMap((playlist) => playlist.tracks),
    ]).filter((track) => hasGenericYouTubeMetadata(track) && /^[A-Za-z0-9_-]{11}$/.test(track.videoId)).slice(0, 12)
    if (!candidates.length) return
    let cancelled = false
    void (async () => {
      for (const track of candidates) {
        if (cancelled) return
        try {
          const metadata = await getTrackById(track.videoId, sp.state.youtubeApiKey)
          if (cancelled) return
          const healed = repairTrackIdentity(mergeTrackMetadata(track, metadata))
          if (!hasGenericYouTubeMetadata(healed)) sp.updateTrackMetadata(healed)
        } catch {}
        await new Promise((resolve) => window.setTimeout(resolve, 120))
      }
    })()
    return () => { cancelled = true }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const requestId = ++suggestionRequestRef.current
    const q = query.trim()
    if (!suggestionsEnabled || tab !== 'search' || q.length < 2 || isHttpUrl(q) || !!extractVideoId(q)) { setSuggestions([]); return }
    let cancelled = false
    const normalized = q.toLowerCase()
    const localPool = [
      ...recentSearches,
      ...sp.state.history.slice(0, 35).flatMap((track) => [
        !isGenericTrackTitle(track.title, track.videoId) ? track.title : '',
        !isGenericTrackChannel(track.channel) ? track.channel : '',
        !isGenericTrackTitle(track.title, track.videoId) && !isGenericTrackChannel(track.channel) ? `${track.channel} ${track.title}` : '',
      ]),
      ...sp.state.favorites.slice(0, 20).flatMap((track) => [
        !isGenericTrackTitle(track.title, track.videoId) ? track.title : '',
        !isGenericTrackChannel(track.channel) ? track.channel : '',
      ]),
    ]
    const local = Array.from(new Set(localPool.map((x) => String(x || '').trim()).filter((x) => x && x.toLowerCase().includes(normalized)))).slice(0, 6)
    setSuggestions(local)
    const timer = window.setTimeout(() => {
      void suggestYouTube(q, 10).then((remote) => {
        if (cancelled || suggestionRequestRef.current !== requestId || !suggestionsEnabled) return
        const merged = Array.from(new Set([...local, ...remote].map((x) => x.trim()).filter(Boolean))).slice(0, 10)
        setSuggestions(merged)
      }).catch(() => {})
    }, 180)
    return () => { cancelled = true; window.clearTimeout(timer) }
  }, [query, tab, recentSearches, sp.state.history, sp.state.favorites, suggestionsEnabled])

  useEffect(() => {
    localStorage.setItem('sideplay.searchScope', searchScope)
  }, [searchScope])

  useEffect(() => {
    localStorage.setItem('sideplay.spotifyEngine', spotifyEngineEnabled ? '1' : '0')
    if (isNative()) WebPlayback.setPipEnabled({ enabled: false }).catch(() => {})
    if (!spotifyEngineEnabled && (playbackEngine === 'spotify' || playbackEngine === 'spotify-error')) setPlaybackEngine('youtube')
  }, [spotifyEngineEnabled])

  useEffect(() => {
    localStorage.setItem('sideplay.youtubeProvider', youtubeProviderEnabled ? '1' : '0')
    if (!youtubeProviderEnabled && (playbackEngine === 'youtube-provider' || playbackEngine === 'youtube-provider-pending' || playbackEngine === 'youtube-browser' || playbackEngine === 'youtube-browser-pending')) setPlaybackEngine('youtube')
  }, [youtubeProviderEnabled])

  useEffect(() => {
    localStorage.setItem('sideplay.youtubeProviderRoute', youtubeProviderRoute)
  }, [youtubeProviderRoute])

  useEffect(() => {
    localStorage.setItem('sideplay.autoplay', autoplayEnabled ? '1' : '0')
  }, [autoplayEnabled])

  useEffect(() => {
    if (!isNative()) return
    const queue = sp.state.queue
    const currentIndex = sp.state.currentIndex
    if (currentIndex < 0 || queue.length < 2) return

    let cancelled = false
    const candidates: Track[] = []
    for (let offset = 1; offset <= 2; offset++) {
      let idx = currentIndex + offset
      if (idx >= queue.length) {
        if (sp.state.repeat !== 'all') break
        idx %= queue.length
      }
      const track = queue[idx]
      if (track && track.videoId !== current?.videoId) candidates.push(track)
    }

    void (async () => {
      for (const track of candidates) {
        if (cancelled) return
        const local = sp.getOfflineCopy(track.videoId)
        if (local || track.playbackUrl || !track.sourceUrl || track.provider === 'spotify') continue
        await prefetchUniversalUrl(track.sourceUrl, { audioOnly: !!track.audioPreferred || track.mediaKind === 'audio' })
      }
    })()

    return () => { cancelled = true }
  }, [sp.state.currentIndex, sp.state.queue, sp.state.repeat, current?.videoId])

  // R6 RADIO AUTOPLAY: keep a small recommendation runway in Up Next even when
  // playback started from a single search result. This makes autoplay independent
  // of whether the user manually created/selected a playlist.
  useEffect(() => {
    if (!autoplayEnabled || !current || sp.state.repeat === 'one') return
    const index = sp.state.currentIndex
    if (index < 0) return
    const remaining = Math.max(0, sp.state.queue.length - index - 1)
    if (remaining >= 3) return
    let cancelled = false
    void buildRadio(current).then(async (radio) => {
      if (cancelled || !radio.length) return
      const already = new Set(sp.state.queue.map((t) => t.videoId))
      const additions = radio.filter((t) => !already.has(t.videoId)).slice(0, 8).map((t) => ({ ...t, queueOrigin: 'autoplay' as const }))
      if (!additions.length) return
      sp.appendQueue(additions)
      // Warm the first two radio items using lightweight resolvers only.
      for (const item of additions.slice(0, 2)) {
        if (cancelled || !item.sourceUrl) break
        await prefetchUniversalUrl(item.sourceUrl, { audioOnly: true })
      }
    }).catch(() => {})
    return () => { cancelled = true }
  }, [autoplayEnabled, current?.videoId, sp.state.currentIndex, sp.state.queue.length, sp.state.repeat, radioTuning.mode, radioTuning.discovery, radioTuning.variety])

  useEffect(() => {
    if (!isNative()) return
    let disposed = false
    const checkShare = async () => {
      try {
        const { text, uri, name, mimeType } = await SharedText.getInitialShare()
        if (disposed) return
        if (uri) {
          const mediaKind = mimeType?.startsWith('video/') ? 'video' : 'audio'
          const track: Track = {
            videoId: `shared-${Date.now()}`,
            title: name || 'Shared media',
            channel: 'Shared from Android',
            thumbnail: '',
            provider: 'local',
            mediaKind,
          }
          const copy = await importSharedOfflineCopy(track, uri)
          sp.setOfflineCopy(copy)
          await play({ ...track, playbackUrl: copy.localUri })
          setExpanded(true)
          return
        }
        if (!text) return
        const id = extractVideoId(text)
        let track: Track
        if (id) track = { ...(await getTrackById(id, sp.state.youtubeApiKey)), provider: 'youtube', sourceUrl: `https://www.youtube.com/watch?v=${id}` }
        else if (isHttpUrl(text.trim())) track = resolutionToTrack(await resolveUniversalUrl(text.trim()))
        else return
        await play(track)
        setExpanded(true)
      } catch (e: any) {
        if (!disposed) setError(e?.message || 'Could not open shared media.')
      }
    }
    checkShare()
    const timer = window.setInterval(checkShare, 1200)
    return () => { disposed = true; window.clearInterval(timer) }
  }, [])

  useEffect(() => {
    if (!isNative()) return
    let handle: any
    CapacitorApp.addListener('appStateChange', ({ isActive }) => {
      if (isActive) {
        // External providers/browsers often publish their MediaSession a beat
        // after SidePlay regains focus. Probe a few times instead of racing it.
        void syncYouTubeProviderSession()
        window.setTimeout(() => void syncYouTubeProviderSession(), 450)
        window.setTimeout(() => void syncYouTubeProviderSession(), 1100)
        window.setTimeout(() => void syncYouTubeProviderSession(), 2200)
      }
    }).then((h) => { handle = h }).catch(() => {})
    return () => { handle?.remove?.() }
  }, [youtubeProviderEnabled, youtubeProviderRoute, playbackEngine, current?.videoId])

  useEffect(() => {
    refreshRecommendations()
    // Home recommendations are deliberately refreshed only when the app starts.
    // A visible refresh button lets the user request another discovery pass.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (!isNative()) return
    let disposed = false
    let handle: any
    BackgroundAudio.addListener('playbackState', ({ state, positionMs: pos, durationMs: dur, message }) => {
      if (disposed) return
      if (state === 'playing') setPaused(false)
      if (state === 'paused') setPaused(true)
      if (typeof pos === 'number' && !scrubbingRef.current) setPositionMs(Math.max(0, pos))
      if (typeof dur === 'number' && dur > 0) setDurationMs(dur)
      if (state === 'error') {
        setPaused(true)
        const active = currentRef.current
        if (active?.sessionBound && active.sourceUrl) {
          staleCaptureIdsRef.current.add(active.videoId)
          setError('That browser-session stream expired or stopped responding. Tap Play again and SidePlay will refresh the media session.')
        } else setError(message || 'Native background playback failed.')
      }
      if (state === 'ended') endedRef.current()
    }).then((h) => { handle = h }).catch(() => {})
    return () => { disposed = true; handle?.remove?.() }
  }, [])

  useEffect(() => {
    if (!isNative()) return
    let handle: any
    onOfflineDownloadProgress(({ videoId, progress }) => {
      if (!videoId) return
      // yt-dlp emits indeterminate status lines before byte progress is known.
      // Keep the visible progress at its existing value (usually 0%) instead of
      // regressing the button to a permanent ellipsis.
      if (typeof progress !== 'number' || progress < 0) return
      setDownloadProgress((prev) => ({ ...prev, [videoId]: Math.max(prev[videoId] ?? 0, Math.min(1, progress)) }))
    }).then((h) => { handle = h }).catch(() => {})
    return () => { handle?.remove?.() }
  }, [])

  useEffect(() => {
    nativeStartPositionRef.current = 0
    setPositionMs(0)
    setDurationMs(0)
  }, [current?.videoId])

  useEffect(() => {
    if (!current) return
    setPaused(false)
    const nativeUrl = useOffline && usableOffline ? usableOffline.localUri : current.playbackUrl

    if (nativeUrl) {
      playerRef.current?.pauseVideo?.()
      if (isNative()) {
        WebPlayback.stop().catch(() => {})
        if (playbackEngine === 'spotify') SpotifySession.pause().catch(() => {})
        setPlaybackEngine('native')
        const startAt = Math.max(0, nativeStartPositionRef.current || 0)
        nativeStartPositionRef.current = 0
        BackgroundAudio.play({
          url: nativeUrl,
          title: current.title,
          artist: current.channel,
          artwork: current.thumbnail,
          mimeType: useOffline && usableOffline ? (usableOffline.mimeType || current.mimeType) : current.mimeType,
          // Offline/local copies never need the source page's browser headers.
          // Keeping those out also lets the native service safely persist a
          // resumable local snapshot even when the original stream used cookies.
          requestHeaders: useOffline ? undefined : current.requestHeaders,
          sourceUrl: useOffline ? undefined : current.sourceUrl,
          refreshMode: useOffline ? undefined : current.refreshMode,
          // Extractor-backed streams are resumable by their durable public source
          // page, not by persisting the short-lived CDN URL. Browser captures with
          // cookies/auth remain deliberately ephemeral.
          resumable: !!useOffline || !current.sessionBound || (current.refreshMode === 'extractor' || current.refreshMode === 'youtube-native'),
          audioPreferred: !!current.audioPreferred || current.mediaKind === 'audio',
          positionMs: startAt,
        }).catch((e) => { setError(e?.message || 'Native media playback failed.'); setPaused(true) })
      } else {
        const audio = audioRef.current
        if (audio) {
          audio.src = nativeUrl
          audio.load()
          audio.play().catch((e) => { setError(e?.message || 'Direct media playback failed.'); setPaused(true) })
        }
      }
      return
    }

    if (isNative()) {
      BackgroundAudio.stop().catch(() => {})
      WebPlayback.stop().catch(() => {})
    }
    const audio = audioRef.current
    if (audio) { audio.pause(); audio.removeAttribute('src'); audio.load() }
  }, [current?.videoId, current?.playbackUrl, usableOffline?.localUri, useOffline])

  useEffect(() => {
    if (!current) return
    let cancelled = false
    const readProgress = async () => {
      if (cancelled || scrubbingRef.current) return
      try {
        if ((playbackEngine === 'youtube-provider' || playbackEngine === 'youtube-browser') && isNative() && !useOffline) {
          const provider = playbackEngine === 'youtube-browser' ? 'youtubeweb' : 'youtube'
          const expectedVideoId = extractVideoId(current.sourceUrl || '') || current.videoId
          const status = await ProviderSession.getStatus({ provider, expectedTitle: current.title, videoId: expectedVideoId })
          if (cancelled || scrubbingRef.current) return
          setPositionMs(Math.max(0, status.positionMs || 0))
          if ((status.durationMs || 0) > 0) setDurationMs(status.durationMs || 0)
          if (status.sessionAvailable) setPaused(!status.playing)
        } else if (playbackEngine === 'spotify' && isNative() && !useOffline) {
          const status = await SpotifySession.getStatus()
          if (cancelled || scrubbingRef.current) return
          setPositionMs(Math.max(0, status.positionMs || 0))
          if ((status.durationMs || 0) > 0) setDurationMs(status.durationMs || 0)
          if (status.sessionAvailable) setPaused(!status.playing)
        } else if (useOffline || playbackEngine === 'native') {
          if (isNative()) {
            const status = await BackgroundAudio.getStatus()
            if (cancelled || scrubbingRef.current) return
            setPositionMs(Math.max(0, status.positionMs || 0))
            if ((status.durationMs || 0) > 0) setDurationMs(status.durationMs)
            if (status.active) setPaused(!status.playing)
          } else {
            const audio = audioRef.current
            if (!audio) return
            setPositionMs(Math.max(0, (audio.currentTime || 0) * 1000))
            if (Number.isFinite(audio.duration) && audio.duration > 0) setDurationMs(audio.duration * 1000)
          }
        } else {
          const player = playerRef.current
          const position = Number(player?.getCurrentTime?.() || 0)
          const duration = Number(player?.getDuration?.() || 0)
          setPositionMs(Math.max(0, position * 1000))
          if (duration > 0) setDurationMs(duration * 1000)
        }
      } catch {}
    }
    readProgress()
    const timer = window.setInterval(readProgress, 500)
    return () => { cancelled = true; window.clearInterval(timer) }
  }, [current?.videoId, useOffline, playbackEngine])

  useEffect(() => {
    if (!sleepUntil) return
    const tick = () => {
      if (Date.now() >= sleepUntil) {
        pausePlayback()
        setSleepUntil(null)
      }
    }
    const timer = window.setInterval(tick, 1000)
    return () => window.clearInterval(timer)
  }, [sleepUntil, useOffline])

  async function refreshRecommendations() {
    const requestId = ++recommendationRequestRef.current
    setRecsBusy(true)
    try {
      const next = await discoverRecommendations(sp.state, 24, radioTuning)
      if (recommendationRequestRef.current === requestId) setRecommendations(next)
    } catch {
      if (recommendationRequestRef.current === requestId) setRecommendations([])
    } finally {
      if (recommendationRequestRef.current === requestId) setRecsBusy(false)
    }
  }

  // Taste should become visible without requiring an app restart/manual Refresh.
  // Only meaningful feedback events trigger a debounced network discovery pass;
  // ordinary queue/play state churn keeps using the local mixes immediately.
  useEffect(() => {
    const latest = sp.state.tasteEvents[0]
    if (!latest || latest.at <= tasteRefreshSeenRef.current) return
    tasteRefreshSeenRef.current = latest.at
    if (!['play', 'complete', 'skip', 'dislike', 'like', 'unlike', 'queue', 'playlist'].includes(latest.kind)) return
    const timer = window.setTimeout(() => { void refreshRecommendations() }, 1400)
    return () => window.clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp.state.tasteEvents[0]?.at])

  async function runSearch(term?: string, scopeOverride?: SearchScope) {
    const q = (term ?? query).trim()
    if (!q) return
    const requestId = ++searchRequestRef.current
    if (term !== undefined) setQuery(q)
    const scope = scopeOverride ?? searchScope
    setSuggestionsEnabled(false)
    setSuggestions([])
    setBusy(true)
    setError('')
    setSearchSources([])
    setResults([])
    try {
      const id = extractVideoId(q)
      if (id) {
        const track = await getTrackById(id, sp.state.youtubeApiKey)
        if (searchRequestRef.current !== requestId) return
        setResults([{ ...track, provider: 'youtube', sourceUrl: `https://www.youtube.com/watch?v=${id}` }])
        setSearchSources(['YouTube'])
      } else if (isHttpUrl(q)) {
        const resolved = await resolveUniversalUrl(q)
        if (searchRequestRef.current !== requestId) return
        const track = resolutionToTrack(resolved)
        setResults([track])
        setSearchSources([providerLabel(track)])
        if (!resolved.playable && resolved.note) setError(resolved.note)
      } else {
        setRecentSearches((prev) => [q, ...prev.filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 8))

        const jobs: Array<Promise<{ name: string; tracks: Track[]; error?: string }>> = []
        if (scope === 'audius') jobs.push(searchAudius(q, 18).then((tracks) => ({ name: 'Audius', tracks })).catch((e: any) => ({ name: 'Audius', tracks: [], error: e?.message || 'unavailable' })))
        if (scope === 'peertube') jobs.push(searchPeerTube(q, 18).then((tracks) => ({ name: 'PeerTube', tracks })).catch((e: any) => ({ name: 'PeerTube', tracks: [], error: e?.message || 'unavailable' })))

        if (scope === 'all' || scope === 'youtube') {
          // FAST PATH: catalog search must not boot Python/yt-dlp. Extraction
          // starts only when the user actually taps a result.
          jobs.push(searchYouTube(q, sp.state.youtubeApiKey)
            .then((found) => ({
              name: 'YouTube',
              tracks: rankAndDedupeMusicSearch(q, found, scope === 'all' ? 18 : 30).map((track) => ({
                ...track,
                provider: 'youtube' as const,
                sourceUrl: `https://www.youtube.com/watch?v=${track.videoId}`,
                ...(scope === 'all' ? { mediaKind: 'audio' as const, audioPreferred: true } : {})
              }))
            }))
            .catch((e: any) => ({ name: 'YouTube', tracks: [], error: e?.message || 'unavailable' })))
        }

        // Provider-specific heavy discovery remains opt-in through its own tab. This
        // is intentionally independent of the public Audius/PeerTube APIs.
        if (scope === 'soundcloud' && isNative()) jobs.push(searchWithYtDlp(q, 'soundcloud', 25).then((tracks) => ({ name: 'SoundCloud', tracks })).catch((e: any) => ({ name: 'SoundCloud', tracks: [], error: e?.message || 'unavailable' })))

        const settled = await Promise.all(jobs)
        if (searchRequestRef.current !== requestId) return
        const working = settled.filter((r) => r.tracks.length > 0)
        setSearchSources(working.map((r) => r.name))
        const ordered = scope === 'all'
          ? (() => {
              // "Music" should feel like a music catalog, not a random blend of
              // videos. Interleave the audio-first catalogs at the top and keep
              // PeerTube discovery below them; the explicit YouTube/PeerTube tabs
              // remain available when the user actually wants video-first results.
              const music = interleaveSources([
                settled.find((r) => r.name === 'YouTube')?.tracks || [],
                settled.find((r) => r.name === 'SoundCloud')?.tracks || [],
                settled.find((r) => r.name === 'Audius')?.tracks || [],
              ])
              const video = settled.find((r) => r.name === 'PeerTube')?.tracks || []
              return uniqueTracks([...music, ...video])
            })()
          : (settled.find((r) => r.name === ({youtube:'YouTube',soundcloud:'SoundCloud',audius:'Audius',peertube:'PeerTube'} as any)[scope])?.tracks || settled[0]?.tracks || [])
        setResults(ordered)

        if (!ordered.length) {
          const details = settled.map((r) => r.error).filter(Boolean).join(' · ')
          setError(details || `No ${scope === 'all' ? '' : scope + ' '}results found.`)
        } else if (settled.some((r) => r.error)) {
          const down = settled.filter((r) => r.error).map((r) => r.name).join(', ')
          setError(`${down} search is temporarily unavailable; showing the sources that answered.`)
        }
      }
    } catch (e: any) {
      if (searchRequestRef.current === requestId) setError(e?.message ?? 'Search failed.')
    } finally {
      if (searchRequestRef.current === requestId) setBusy(false)
    }
  }

  async function onEnded() {
    const endedTrack = currentRef.current
    if (!endedTrack) return
    const now = Date.now()
    if (lastEndedRef.current.videoId === endedTrack.videoId && now - lastEndedRef.current.at < 2_000) return
    lastEndedRef.current = { videoId: endedTrack.videoId, at: now }
    sp.recordCompletion(endedTrack.videoId, 1)
    if (sleepAfterCurrent) {
      setSleepAfterCurrent(false)
      setPaused(true)
      return
    }
    const next = sp.next()
    if (next) {
      // Queue entries are often lightweight provider search results. Run the next
      // item through the normal resolver instead of relying on current-index state
      // alone; otherwise a queue could stop when the next signed stream was not yet
      // resolved.
      await play(next, undefined, { preserveQueue: true })
      return
    }
    if (autoplayEnabled && currentRef.current) {
      // The recommendation runway normally means sp.next() already has something.
      // If the song ended before radio discovery completed, build/fetch radio now
      // instead of stopping just because the original queue had one item.
      const radio = await buildRadio(currentRef.current).catch(() => [] as Track[])
      const pool = uniqueTracks([...sp.state.queue, ...radio, ...recommendations])
        .filter((item) => item.videoId !== currentRef.current?.videoId)
      const auto = radio[0] || pool[0]
      if (auto) {
        const additions = radio.filter((item) => !sp.state.queue.some((queued) => queued.videoId === item.videoId)).map((item) => ({ ...item, queueOrigin: 'autoplay' as const }))
        if (additions.length) sp.appendQueue(additions)
        await play({ ...auto, queueOrigin: 'autoplay' }, undefined, { preserveQueue: true })
        return
      }
    }
    wantsPlaybackRef.current = false
    if (isNative()) WebPlayback.stop().catch(() => {})
    setPaused(true)
  }
  endedRef.current = onEnded

  function youtubeSessionProviderForEngine(): 'youtube' | 'youtubeweb' {
    if (playbackEngine === 'youtube-browser' || playbackEngine === 'youtube-browser-pending') return 'youtubeweb'
    return 'youtube'
  }

  async function syncYouTubeProviderSession(trackOverride?: Track) {
    if (!isNative() || !youtubeProviderEnabled) return false
    const track = trackOverride || currentRef.current
    if (!track || track.provider !== 'youtube') return false

    const preferred: Array<'youtube' | 'youtubeweb'> = (() => {
      if (playbackEngine === 'youtube-browser' || playbackEngine === 'youtube-browser-pending') return ['youtubeweb']
      if (playbackEngine === 'youtube-provider' || playbackEngine === 'youtube-provider-pending') return ['youtube']
      if (youtubeProviderRoute === 'web') return ['youtubeweb']
      if (youtubeProviderRoute === 'app') return ['youtube']
      return ['youtube', 'youtubeweb']
    })()

    const videoId = extractVideoId(track.sourceUrl || '') || track.videoId
    for (const provider of preferred) {
      try {
        const status = await ProviderSession.getStatus({ provider, expectedTitle: track.title, videoId })
        if (!status.sessionAvailable) continue
        const matches = providerStatusMatches(status, track)
        if (!matches) {
          const label = provider === 'youtubeweb' ? 'browser' : 'YouTube app'
          const actual = status.title ? `“${status.title}”` : 'another item'
          setError(`${label} has an active media session for ${actual}, not “${track.title}”. SidePlay did not attach to the wrong session.`)
          continue
        }
        setPlaybackEngine(provider === 'youtubeweb' ? 'youtube-browser' : 'youtube-provider')
        setPaused(!status.playing)
        setPositionMs(Math.max(0, status.positionMs || 0))
        if ((status.durationMs || 0) > 0) setDurationMs(status.durationMs || 0)
        playerRef.current?.pauseVideo?.()
        WebPlayback.stop().catch(() => {})
        setError(status.playing ? '' : `${provider === 'youtubeweb' ? 'Browser' : 'YouTube'} session matched, but playback is paused.`)
        return true
      } catch {}
    }

    if (playbackEngine === 'youtube-provider-pending' || playbackEngine === 'youtube-browser-pending') {
      const label = playbackEngine === 'youtube-browser-pending' ? 'browser' : 'YouTube app'
      setPaused(true)
      setError(`Waiting for the ${label} media session. SidePlay will reconnect automatically as soon as playback becomes visible to Android.`)
    }
    return false
  }

  async function handoffYouTubePremium(track: Track, queue?: Track[]) {
    if (!isNative() || !youtubeProviderEnabled || track.provider !== 'youtube') return false
    const videoId = extractVideoId(track.sourceUrl || '') || track.videoId
    if (!videoId) return false

    try {
      sp.playNow(track, queue)
      setPaused(true)
      setError('')
      playerRef.current?.pauseVideo?.()
      WebPlayback.stop().catch(() => {})
      BackgroundAudio.stop().catch(() => {})

      const retryingBrowser = playbackEngine === 'youtube-browser-pending'
      let provider: 'youtube' | 'youtubeweb' = retryingBrowser || youtubeProviderRoute === 'web' ? 'youtubeweb' : 'youtube'
      if (youtubeProviderRoute === 'auto' && !retryingBrowser) {
        try {
          const access = await ProviderSession.hasAccess()
          provider = access.youtubeInstalled ? 'youtube' : 'youtubeweb'
        } catch {
          provider = 'youtube'
        }
      }

      setPlaybackEngine(provider === 'youtubeweb' ? 'youtube-browser-pending' : 'youtube-provider-pending')

      try {
        await ProviderSession.openExact({
          provider,
          videoId,
          title: track.title,
          autoReturn: true,
          url: track.sourceUrl || `https://www.youtube.com/watch?v=${videoId}`,
        })
      } catch (firstError: any) {
        // Auto mode gets one clean browser fallback when the official-app route
        // cannot even be opened. We do not silently switch after a valid app
        // launch because that would bounce the user between apps unexpectedly.
        if (youtubeProviderRoute === 'auto' && provider === 'youtube') {
          setPlaybackEngine('youtube-browser-pending')
          await ProviderSession.openExact({
            provider: 'youtubeweb',
            videoId,
            title: track.title,
            autoReturn: true,
            url: track.sourceUrl || `https://www.youtube.com/watch?v=${videoId}`,
          })
        } else throw firstError
      }
      return true
    } catch (e: any) {
      setPlaybackEngine('youtube')
      setError(e?.message || 'Could not hand this video to YouTube.')
      return false
    }
  }

  async function trySpotifyPlayback(track: Track) {
    if (!isNative() || !spotifyEngineEnabled) return false
    const copy = sp.getOfflineCopy(track.videoId)
    if (copy?.platform === 'android') return false

    const wanted = spotifyIdentityForTrack(track)
    const sleep = (ms: number) => new Promise((resolve) => window.setTimeout(resolve, ms))

    const read = async () => SpotifySession.getStatus()
    const waitForExactTrack = async (timeoutMs: number, requirePlaying = false) => {
      const deadline = Date.now() + timeoutMs
      let status = await read()
      while (Date.now() < deadline) {
        if (spotifyStatusMatches(status, wanted) && (!requirePlaying || status.playing)) return status
        await sleep(220)
        status = await read()
      }
      return status
    }

    const verifyAndStart = async () => {
      let status = await waitForExactTrack(1900, false)
      if (!spotifyStatusMatches(status, wanted)) return status
      if (!status.playing) {
        await SpotifySession.play().catch(() => {})
        status = await waitForExactTrack(1800, true)
      }
      return status
    }

    try {
      setPlaybackEngine('spotify-error')
      setPaused(true)
      setError('')

      const access = await SpotifySession.hasAccess()
      if (!access.granted) throw new Error('Spotify control needs Notification Access.')
      if (!access.spotifyInstalled) throw new Error('Spotify is not installed.')

      let before = await read()
      if (!before.sessionAvailable) throw new Error('No active Spotify media session. Open Spotify and play any song once.')

      // If Spotify is already on the requested track, do not re-search it.
      if (spotifyStatusMatches(before, wanted)) {
        if (!before.playing) await SpotifySession.play().catch(() => {})
        const same = await waitForExactTrack(1600, true)
        if (spotifyStatusMatches(same, wanted) && same.playing) {
          setPlaybackEngine('spotify')
          playerRef.current?.pauseVideo?.()
          WebPlayback.stop().catch(() => {})
          return true
        }
      }

      // Freeze the previous song so a generic PLAY command cannot be mistaken for a handoff.
      if (before.playing) {
        await SpotifySession.pause().catch(() => {})
        await sleep(180)
      }

      // Exact provider URI beats fuzzy search when the user pasted a Spotify track URL.
      if (track.providerUri) {
        try {
          await SpotifySession.playFromUri({ uri: track.providerUri })
          let exactUriStatus = await waitForExactTrack(2600, false)
          if (spotifyStatusMatches(exactUriStatus, wanted)) {
            exactUriStatus = await verifyAndStart()
            if (spotifyStatusMatches(exactUriStatus, wanted) && exactUriStatus.playing) {
              setPlaybackEngine('spotify')
              playerRef.current?.pauseVideo?.()
              WebPlayback.stop().catch(() => {})
              setPaused(false)
              return true
            }
          }
        } catch {}
      }

      const titleOnly = wanted.title
      const combined = `${wanted.title} ${wanted.artist}`.trim()
      const quoted = `"${wanted.title}" ${wanted.artist}`.trim()
      const reversed = `${wanted.artist} ${wanted.title}`.trim()

      const attempts: Array<{ label: string; run: () => Promise<any>; wait?: number }> = [
        {
          label: 'prepare structured title',
          run: () => SpotifySession.prepareFromSearch({ query: titleOnly, title: wanted.title, artist: wanted.artist }),
          wait: 1500,
        },
        {
          label: 'media-session structured title',
          run: () => SpotifySession.playFromSearch({ query: titleOnly, title: wanted.title, artist: wanted.artist }),
        },
        {
          label: 'media-session structured combined',
          run: () => SpotifySession.playFromSearch({ query: combined, title: wanted.title, artist: wanted.artist }),
        },
        {
          label: 'media-session quoted query',
          run: () => SpotifySession.playFromSearch({ query: quoted, title: wanted.title, artist: wanted.artist }),
        },
        {
          label: 'Spotify structured search intent',
          run: () => SpotifySession.playFromSearchIntent({ query: titleOnly, title: wanted.title, artist: wanted.artist, structured: true }),
        },
        {
          label: 'Spotify structured combined intent',
          run: () => SpotifySession.playFromSearchIntent({ query: combined, title: wanted.title, artist: wanted.artist, structured: true }),
        },
        {
          label: 'Spotify unstructured reversed intent',
          run: () => SpotifySession.playFromSearchIntent({ query: reversed, title: wanted.title, artist: wanted.artist, structured: false }),
        },
      ]

      const failures: string[] = []
      let after = before
      for (const attempt of attempts) {
        try {
          await attempt.run()
          after = await waitForExactTrack(attempt.wait || 2200, false)
          if (spotifyStatusMatches(after, wanted)) {
            after = await verifyAndStart()
            if (spotifyStatusMatches(after, wanted) && after.playing) break
          }
          failures.push(`${attempt.label}: stayed on ${[after.title, after.artist].filter(Boolean).join(' — ') || 'old track'}`)
        } catch (err: any) {
          failures.push(`${attempt.label}: ${err?.message || 'rejected'}`)
        }
      }

      // Aggressive final pass: briefly prime Spotify's own search screen, return
      // to SidePlay automatically, then retry the two strongest Android commands.
      if (!(spotifyStatusMatches(after, wanted) && after.playing)) {
        try {
          await SpotifySession.warmSpotifySearch({ query: combined })
          await sleep(1250)
          await SpotifySession.playFromSearch({ query: titleOnly, title: wanted.title, artist: wanted.artist })
          after = await waitForExactTrack(2600, false)
          if (!spotifyStatusMatches(after, wanted)) {
            await SpotifySession.playFromSearchIntent({ query: titleOnly, title: wanted.title, artist: wanted.artist, structured: true })
            after = await waitForExactTrack(2600, false)
          }
          if (spotifyStatusMatches(after, wanted)) after = await verifyAndStart()
        } catch (err: any) {
          failures.push(`Spotify foreground warm-up: ${err?.message || 'failed'}`)
        }
      }

      if (!(spotifyStatusMatches(after, wanted) && after.playing)) {
        const actual = [after.title, after.artist].filter(Boolean).join(' — ') || 'unknown track'
        setPlaybackEngine('spotify-error')
        throw new Error(`Spotify handoff failed for “${wanted.title} — ${wanted.artist}”. Spotify stayed on “${actual}”. SidePlay tried ${attempts.length + 2} verified routes.`)
      }

      setPlaybackEngine('spotify')
      playerRef.current?.pauseVideo?.()
      WebPlayback.stop().catch(() => {})
      setPaused(false)
      setError('')
      return true
    } catch (e: any) {
      setPlaybackEngine('spotify-error')
      setPaused(true)
      setError(e?.message ?? 'Spotify handoff failed.')
      return false
    }
  }

  async function play(track: Track, queue?: Track[], options: { preserveQueue?: boolean } = {}) {
    // Centralize abandonment feedback so Taste learns from ANY manual transition
    // (search result, queue row, radio card, Next), not just the dedicated Next button.
    const outgoing = currentRef.current
    if (outgoing && outgoing.videoId !== track.videoId && positionMs >= 1_500 && (durationMs <= 0 || positionMs < durationMs * .85)) {
      sp.recordSkip(outgoing.videoId, durationMs > 0 ? positionMs / durationMs : undefined)
    }
    // R8 PLAYBACK ATOMICITY: every Play intent invalidates older async work before
    // metadata hydration/resolution starts. An older tap can never wake up later and
    // steal playback back from the newer selection.
    const requestId = ++playbackRequestRef.current
    // R7 LEGACY QUEUE SANITIZER: R5 and older recommendation rows could contain a
    // YouTube videoId/title without provider/sourceUrl. Repair them before any
    // resolver decision so autoplay can never fall through to generic "Web".
    track = repairTrackIdentity(track)
    queue = queue ? repairTrackList(queue) : queue
    if (hasGenericYouTubeMetadata(track) && /^[A-Za-z0-9_-]{11}$/.test(track.videoId)) {
      try {
        const metadata = await getTrackById(track.videoId, sp.state.youtubeApiKey)
        track = repairTrackIdentity(mergeTrackMetadata(track, metadata))
        sp.updateTrackMetadata(track)
      } catch {}
    }
    if (playbackRequestRef.current !== requestId) return
    const needsResolution = isNative() && !sp.getOfflineCopy(track.videoId) && !track.playbackUrl && !!track.sourceUrl && track.provider !== 'spotify'
    if (needsResolution) setResolvingTrackId(track.videoId)
    wantsPlaybackRef.current = true
    setError('')
    try {
    const copy = sp.getOfflineCopy(track.videoId)
    const localCopy = copy?.platform === (isNative() ? 'android' : 'pc')

    // Browser-captured URLs can be short-lived and their cookies/headers are never
    // persisted. If this item came back from history/library after a restart,
    // refresh the browser session instead of blindly replaying a stale CDN URL.
    const captureStale = !!track.sessionBound && (!!track.sourceUrl) && (
      (track.refreshMode === 'extractor' || track.refreshMode === 'youtube-native')
        ? (!track.playbackUrl || !track.capturedAt || Date.now() - track.capturedAt > 20 * 60 * 1000 || staleCaptureIdsRef.current.has(track.videoId))
        : (!track.requestHeaders || !track.capturedAt || Date.now() - track.capturedAt > 20 * 60 * 1000 || staleCaptureIdsRef.current.has(track.videoId))
    )
    if (!localCopy && isNative() && captureStale && track.sourceUrl) {
      try {
        const extractorRefresh = track.refreshMode === 'extractor' || track.refreshMode === 'youtube-native'
        let resolved: Track
        if (extractorRefresh) {
          resolved = resolutionToTrack(await resolveUniversalUrl(track.sourceUrl, { audioOnly: !!track.audioPreferred || track.mediaKind === 'audio' }))
          if (!resolved.playbackUrl) throw new Error('Provider extractor did not return a playable stream.')
        } else {
          throw new Error('This browser-captured stream expired. Re-capture it manually from Downloads → Add from a link or file.')
        }
        if (playbackRequestRef.current !== requestId) return
        staleCaptureIdsRef.current.delete(track.videoId)
        if (!resolved.playbackUrl) throw new Error('SidePlay could not refresh a playable stream.')
        const nativeTrack: Track = mergeTrackMetadata(track, { ...resolved, videoId: track.videoId })
        sp.updateTrackMetadata(nativeTrack)
        setError('')
        setPlaybackEngine('native')
        sp.playNow(nativeTrack, queue?.map((item) => item.videoId === track.videoId ? nativeTrack : item), options)
        setPaused(false)
      } catch (e: any) {
        if (playbackRequestRef.current === requestId) setError(/cancel/i.test(e?.message || '') ? 'Media Catcher closed.' : (e?.message || 'Could not refresh this captured stream.'))
      }
      return
    }

    // SidePlay-owned media always wins: downloaded/local files and direct public
    // media go straight through the native Media3 service on Android.
    if (localCopy || track.playbackUrl) {
      if (playbackEngine === 'spotify' && isNative()) SpotifySession.pause().catch(() => {})
      setPlaybackEngine('native')
      sp.playNow(track, queue, options)
      setPaused(false)
      return
    }

    // Any unresolved public web item gets the broad provider extractor before
    // provider handoff/capture. This is the Snaptube-style functional path:
    // maintained site extractor -> SidePlay native/static resolver. Browser capture is manual-only.
    if (isNative() && track.sourceUrl && track.provider !== 'spotify') {
      try {
        const resolved = resolutionToTrack(await resolveUniversalUrl(track.sourceUrl, { audioOnly: !!track.audioPreferred || track.mediaKind === 'audio' }))
        if (playbackRequestRef.current !== requestId) return
        if (resolved.playbackUrl) {
          const nativeTrack: Track = mergeTrackMetadata(track, { ...resolved, videoId: track.videoId })
          sp.updateTrackMetadata(nativeTrack)
          setError('')
          setPlaybackEngine('native')
          sp.playNow(nativeTrack, queue?.map((item) => item.videoId === track.videoId ? nativeTrack : item), options)
          setPaused(false)
          return
        }
      } catch {
        // Continue to the explicit in-app failure path; browser capture stays manual-only.
      }
      setError('')
    }

    // PeerTube search results are lightweight catalog entries. Resolve the
    // selected origin only when the user actually plays it, then hand the real
    // HLS/progressive URL to SidePlay's own Media3 engine.
    if (track.provider === 'peertube' && track.sourceUrl) {
      try {
        const resolved = resolutionToTrack(await resolveUniversalUrl(track.sourceUrl, { audioOnly: !!track.audioPreferred || track.mediaKind === 'audio' }))
        if (playbackRequestRef.current !== requestId) return
        if (resolved.playbackUrl) {
          const nativeTrack: Track = mergeTrackMetadata(track, { ...resolved, videoId: track.videoId })
          sp.updateTrackMetadata(nativeTrack)
          setError('')
          setPlaybackEngine('native')
          sp.playNow(nativeTrack, queue?.map((item) => item.videoId === track.videoId ? nativeTrack : item), options)
          setPaused(false)
          return
        }
        throw new Error(resolved.sourceUrl ? 'PeerTube did not expose a playable stream for this item.' : 'PeerTube resolution failed.')
      } catch (e: any) {
        setError(e?.message || 'Could not resolve this PeerTube item.')
        return
      }
    }

    // Provider bridges are now manual-only on Android. A normal Play tap must
    // never launch another app/browser and destroy SidePlay's background path.
    if (track.provider === 'spotify') {
      setPaused(true)
      setError('Spotify streams are not SidePlay-native. Use Open source manually if you want the provider app.')
      return
    }

    // Media Catcher is intentionally manual-only. Normal Play never launches a
    // browser/webview as a surprise. Difficult pages can still be captured explicitly
    // from Downloads → Add from a link or file.
    if (isNative() && track.sourceUrl && /^https?:\/\//i.test(track.sourceUrl)) {
      setPaused(true)
      setError(`${providerLabel(track)} did not expose a SidePlay-native stream. Use Downloads → Add from a link or file if you want to try browser capture.`)
      return
    }

    // Browser builds can still use the embedded foreground player. Android never
    // auto-falls back to it because it breaks true background ownership.
    if (!isNative()) {
      setPlaybackEngine('youtube')
      sp.playNow(track, queue, options)
      setPaused(false)
      return
    }

    setPaused(true)
    setError(`${providerLabel(track)} could not be resolved inside SidePlay. Try again or use Open source manually.`)
    } finally {
      if (playbackRequestRef.current === requestId) setResolvingTrackId(null)
    }
  }

  function previous() {
    wantsPlaybackRef.current = true
    const target = sp.previous()
    if (!target) return
    void play(target, undefined, { preserveQueue: true })
  }

  function next() {
    wantsPlaybackRef.current = true
    const target = sp.next()
    if (!target) return
    void play(target, undefined, { preserveQueue: true })
  }

  function pausePlayback() {
    wantsPlaybackRef.current = false
    if ((playbackEngine === 'youtube-provider' || playbackEngine === 'youtube-browser') && isNative() && !useOffline) {
      ProviderSession.pause({ provider: youtubeSessionProviderForEngine() }).catch(() => {})
    } else if (playbackEngine === 'spotify' && isNative() && !useOffline) {
      SpotifySession.pause().catch(() => {})
    } else if (useOffline || playbackEngine === 'native') {
      if (isNative()) BackgroundAudio.pause().catch(() => {})
      else audioRef.current?.pause()
    } else { playerRef.current?.pauseVideo?.(); if (isNative()) WebPlayback.stop().catch(() => {}) }
    setPaused(true)
  }

  function resumePlayback() {
    wantsPlaybackRef.current = true
    if ((playbackEngine === 'youtube-provider-pending' || playbackEngine === 'youtube-browser-pending') && isNative() && current) {
      void handoffYouTubePremium(current)
      return
    }
    if ((playbackEngine === 'youtube-provider' || playbackEngine === 'youtube-browser') && isNative() && !useOffline) {
      ProviderSession.play({ provider: youtubeSessionProviderForEngine() }).catch(() => {})
    } else if (playbackEngine === 'spotify-error' && isNative() && !useOffline && current) {
      void trySpotifyPlayback(current)
      return
    } else if (playbackEngine === 'spotify' && isNative() && !useOffline) {
      SpotifySession.play().catch(() => {})
    } else if (useOffline || playbackEngine === 'native') {
      if (isNative()) BackgroundAudio.resume().catch(() => {})
      else audioRef.current?.play().catch(() => {})
    } else playerRef.current?.playVideo?.()
    setPaused(false)
  }

  async function seekPlayback(nextMs: number) {
    const target = Math.max(0, durationMs > 0 ? Math.min(nextMs, durationMs) : nextMs)
    setPositionMs(target)
    try {
      if ((playbackEngine === 'youtube-provider' || playbackEngine === 'youtube-browser') && isNative() && !useOffline) {
        await ProviderSession.seek({ provider: youtubeSessionProviderForEngine(), positionMs: target })
      } else if (playbackEngine === 'spotify' && isNative() && !useOffline) {
        await SpotifySession.seek({ positionMs: target })
      } else if (useOffline || playbackEngine === 'native') {
        if (isNative()) await BackgroundAudio.seek({ positionMs: target })
        else if (audioRef.current) audioRef.current.currentTime = target / 1000
      } else {
        playerRef.current?.seekTo?.(target / 1000, true)
      }
    } catch {}
  }

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null
      const typing = !!target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)
      const key = event.key.toLowerCase()

      if ((event.ctrlKey || event.metaKey) && key === 'k') {
        event.preventDefault()
        setTab('search')
        window.requestAnimationFrame(() => document.getElementById('sideplay-search')?.focus())
        return
      }
      if (typing) return
      if (event.key === 'Escape' && expanded) { event.preventDefault(); setExpanded(false); return }
      if (!current) return
      if (event.code === 'Space' || key === 'k') { event.preventDefault(); paused ? resumePlayback() : pausePlayback(); return }
      if (key === 'j' || event.key === 'ArrowLeft') { event.preventDefault(); seekPlayback(positionMs - 10000); return }
      if (key === 'l' || event.key === 'ArrowRight') { event.preventDefault(); seekPlayback(positionMs + 10000); return }
      if (event.shiftKey && key === 'n') { event.preventDefault(); next(); return }
      if (event.shiftKey && key === 'p') { event.preventDefault(); previous(); return }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [current?.videoId, paused, expanded, positionMs, durationMs, useOffline, playbackEngine])

  async function addOffline(track: Track) {
    setOfflineBusy(track.videoId)
    setDownloadProgress((prev) => ({ ...prev, [track.videoId]: 0 }))
    setError('')
    try {
      // Snaptube-style behavior: a provider/search item does not need to be played
      // once before it can be saved. Resolve it on demand, then use either the
      // verified direct downloader or the yt-dlp/FFmpeg adaptive downloader.
      let downloadableTrack = track
      if (isNative() && !track.downloadUrl && track.provider !== 'local' && track.provider !== 'spotify' && track.sourceUrl && (track.downloadEngine !== 'ytdlp' || track.provider === 'youtube')) {
        try {
          // R6: for YouTube, first ask the lightweight NewPipe/InnerTube ladder for
          // a fresh progressive media object. If NewPipe returns the same sort of
          // googlevideo URL Media3 is already playing, Offline Vault can save it
          // directly and completely avoid the yt-dlp PO-token path. Adaptive-only
          // results keep downloadEngine=ytdlp and fall through to the existing path.
          const resolved = resolutionToTrack(await resolveUniversalUrl(track.sourceUrl, { audioOnly: !!track.audioPreferred || track.mediaKind === 'audio' }))
          downloadableTrack = mergeTrackMetadata(track, { ...resolved, videoId: track.videoId, sourceUrl: track.sourceUrl })
        } catch {
          // yt-dlp remains the adaptive/provider fallback when direct resolution is unavailable.
        }
      }
      const previous = sp.getOfflineCopy(track.videoId)
      const copy = (downloadableTrack.downloadUrl || downloadableTrack.downloadEngine === 'ytdlp')
        ? await downloadOfflineCopy(downloadableTrack)
        : await importOfflineCopy(downloadableTrack)
      if (isNative() && current?.videoId === track.videoId) {
        nativeStartPositionRef.current = Math.max(0, positionMs || 0)
        playerRef.current?.pauseVideo?.()
      }
      sp.setOfflineCopy(copy)
      if (previous && previous.localUri !== copy.localUri) {
        try { await removeOfflineCopy(previous) } catch {}
      }
      setDownloadProgress((prev) => ({ ...prev, [track.videoId]: 1 }))
    } catch (e: any) {
      if (!/cancel|no .* selected/i.test(e?.message || '')) setError(e?.message || 'Could not save media offline.')
    } finally {
      setOfflineBusy(null)
      window.setTimeout(() => setDownloadProgress((prev) => {
        const next = { ...prev }
        delete next[track.videoId]
        return next
      }), 1200)
    }
  }

  async function deleteOffline(videoId: string) {
    const copy = sp.getOfflineCopy(videoId)
    if (!copy) return
    try { await removeOfflineCopy(copy) } catch (e: any) { setError(e?.message || 'Could not delete offline copy.'); return }
    sp.removeOfflineCopy(videoId)
  }

  const sleepText = useMemo(() => {
    if (sleepAfterCurrent) return 'end of track'
    if (!sleepUntil) return null
    return `${Math.max(0, Math.ceil((sleepUntil - Date.now()) / 60000))}m`
  }, [sleepAfterCurrent, sleepUntil, current])

  const common = { sp, play, setPlaylistTarget, addOffline, offlineBusy, setTrackMenu, downloadProgress, resolvingTrackId }

  return <div className="app-shell">
    <aside className="side-rail">
      <Brand />
      <nav className="rail-nav">
        <NavItem active={tab==='home'} label="Home" icon={<Home/>} onClick={()=>setTab('home')} />
        <NavItem active={tab==='search'} label="Search" icon={<Search/>} onClick={()=>setTab('search')} />
        <NavItem active={tab==='library'} label="Library" icon={<ListMusic/>} onClick={()=>setTab('library')} />
        <NavItem active={tab==='downloads'} label="Offline" icon={<Download/>} onClick={()=>setTab('downloads')} badge={Object.keys(sp.state.offline || {}).length} />
              </nav>
      <button className="rail-settings" onClick={()=>setTab('settings')}><Settings/><span>Settings</span></button>
    </aside>

    <div className="main-pane">
      <header className="topbar">
        <Brand compact />
        <div className="top-actions">
          {tab !== 'search' && <button className="search-pill" onClick={()=>setTab('search')}><Search/><span>Search or paste URL</span></button>}
          <button className="icon-btn" onClick={()=>setTab('settings')} aria-label="Settings"><Settings size={20}/></button>
        </div>
      </header>

      {error && <div className="global-error"><span>{error}</span><button onClick={()=>setError('')}><X/></button></div>}

      <main className="content">
        <div className="page-stage" key={tab}>
          {tab === 'home' && <HomeView {...common} mixes={mixes} recommendations={recommendations} recsBusy={recsBusy} refreshRecommendations={refreshRecommendations} setTab={setTab} />}
          {tab === 'search' && <SearchView {...common} query={query} setQuery={setQuery} runSearch={runSearch} busy={busy} results={results} recentSearches={recentSearches} clearRecentSearches={()=>setRecentSearches([])} searchScope={searchScope} setSearchScope={setSearchScope} searchSources={searchSources} suggestions={suggestions} suggestionsEnabled={suggestionsEnabled} setSuggestionsEnabled={setSuggestionsEnabled} />}
          {tab === 'library' && <LibraryView {...common} setSelectedPlaylist={setSelectedPlaylist} setTab={setTab} />}
          {tab === 'downloads' && <DownloadsView sp={sp} play={play} addOffline={addOffline} deleteOffline={deleteOffline} offlineBusy={offlineBusy} setTrackMenu={setTrackMenu} downloadProgress={downloadProgress} />}
          {tab === 'queue' && <QueueView sp={sp} play={play} />}
          {tab === 'settings' && <SettingsView sp={sp} autoplayEnabled={autoplayEnabled} setAutoplayEnabled={setAutoplayEnabled} spotifyEngineEnabled={spotifyEngineEnabled} setSpotifyEngineEnabled={setSpotifyEngineEnabled} youtubeProviderEnabled={youtubeProviderEnabled} setYoutubeProviderEnabled={setYoutubeProviderEnabled} youtubeProviderRoute={youtubeProviderRoute} setYoutubeProviderRoute={setYoutubeProviderRoute} />}
        </div>
      </main>
    </div>

    {current && <>
      <div className={`mini-player ${useOffline?'offline-playing':''}`} onClick={()=>setExpanded(true)}>
        <img src={current.thumbnail} alt="" />
        <div className="mini-meta"><b>{current.title}</b><span>{current.channel}</span>{useOffline?<em><WifiOff/> Offline · native</em>:playbackEngine==='native'?<em className="native-ready"><Radio/> SidePlay · background</em>:playbackEngine==='youtube-provider'?<em className="background-ready"><Play/> YouTube app · background</em>:playbackEngine==='youtube-browser'?<em className="background-ready"><Play/> YouTube Web · background</em>:playbackEngine==='youtube-provider-pending'?<em className="foreground-only"><ExternalLink/> YouTube app · connecting</em>:playbackEngine==='youtube-browser-pending'?<em className="foreground-only"><ExternalLink/> YouTube Web · connecting</em>:usableOffline?<em className="background-ready"><WifiOff/> Offline available</em>:playbackEngine==='spotify'?<em className="spotify-ready"><Music2/> Spotify · background</em>:playbackEngine==='spotify-error'?<em className="foreground-only"><Music2/> Spotify · handoff failed</em>:isNative()?<em>SidePlay</em>:null}</div>
        <button className="icon-btn player-control" onClick={(e)=>{e.stopPropagation(); paused?resumePlayback():pausePlayback()}}>{paused?<Play/>:<Pause/>}</button>
        <button className="icon-btn player-control" onClick={(e)=>{e.stopPropagation();next()}}><SkipForward/></button>
        <div className="mini-progress"><span style={{width:`${durationMs>0?Math.min(100,(positionMs/durationMs)*100):0}%`}}/></div>
      </div>
      {!isNative() && !useOffline && playbackEngine === 'youtube' && <div className="hidden-player"><YouTubePlayer key={current.videoId} videoId={current.videoId} onEnded={onEnded} controllerRef={playerRef} onReady={()=>setPaused(false)} onPlaybackState={(state)=>{if(state==='playing'){setPaused(false);if(isNative()&&wantsPlaybackRef.current&&!useOfflineRef.current&&currentRef.current)WebPlayback.start({title:currentRef.current.title,artist:currentRef.current.channel}).catch(()=>{})}else if(state==='paused'){setPaused(true);if(isNative()&&!wantsPlaybackRef.current)WebPlayback.stop().catch(()=>{})}else if(state==='ended'){setPaused(true);if(isNative())WebPlayback.stop().catch(()=>{})}}} /></div>}
      <audio ref={audioRef} className="hidden-audio" onEnded={onEnded} onPlay={()=>setPaused(false)} onPause={()=>setPaused(true)} />
    </>}

    <nav className="bottom-nav">
      <NavButton active={tab==='home'} label="Home" icon={<Home/>} onClick={()=>setTab('home')} />
      <NavButton active={tab==='search'} label="Search" icon={<Search/>} onClick={()=>setTab('search')} />
      <NavButton active={tab==='library'} label="Library" icon={<ListMusic/>} onClick={()=>setTab('library')} />
      <NavButton active={tab==='downloads'} label="Offline" icon={<Download/>} onClick={()=>setTab('downloads')} badge={Object.keys(sp.state.offline || {}).length} />
    </nav>

    {expanded && current && <NowPlaying track={current} sp={sp} paused={paused} pausePlayback={pausePlayback} resumePlayback={resumePlayback} previous={previous} next={next} close={()=>setExpanded(false)} setPlaylistTarget={setPlaylistTarget} sleepText={sleepText} setSleepUntil={setSleepUntil} sleepAfterCurrent={sleepAfterCurrent} setSleepAfterCurrent={setSleepAfterCurrent} offline={usableOffline} useOffline={useOffline} addOffline={addOffline} offlineBusy={offlineBusy} positionMs={positionMs} durationMs={durationMs} onSeek={seekPlayback} setScrubbing={(v:boolean)=>{scrubbingRef.current=v}} playbackEngine={playbackEngine} openQueue={()=>{setExpanded(false);setTab('queue')}} downloadProgress={downloadProgress} startRadio={startRadio} radioTuning={radioTuning} setRadioTuning={setRadioTuning} />}
    {trackMenu && <TrackActionsSheet track={trackMenu} sp={sp} close={()=>setTrackMenu(null)} play={play} startRadio={startRadio} addOffline={addOffline} offlineBusy={offlineBusy} downloadProgress={downloadProgress} setPlaylistTarget={(track:Track)=>{setTrackMenu(null);setPlaylistTarget(track)}} />}
    {playlistTarget && <PlaylistPicker track={playlistTarget} sp={sp} close={()=>setPlaylistTarget(null)} />}
    {selectedPlaylist && <PlaylistDetail playlistId={selectedPlaylist.id} sp={sp} play={play} close={()=>setSelectedPlaylist(null)} addOffline={addOffline} offlineBusy={offlineBusy} />}
  </div>
}

function Brand({compact=false}:{compact?:boolean}) {
  return <div className={`brand ${compact?'compact':''}`}><div className="brand-mark"><Play fill="currentColor"/></div><div><b>SidePlay</b><small>play anything</small></div></div>
}

function HomeView({sp,play,addOffline,offlineBusy,setTrackMenu,downloadProgress,mixes,recommendations,recsBusy,refreshRecommendations,setTab}:any) {
  const quick = uniqueTracks([...sp.state.history, ...sp.state.favorites, ...sp.state.playlists.flatMap((p:Playlist)=>p.tracks)]).slice(0,8)
  const last = sp.state.history[0]
  const offlineTracks = (Object.values(sp.state.offline || {}) as OfflineCopy[]).sort((a,b)=>b.addedAt-a.addedAt).slice(0,6).map((copy)=>({ videoId:copy.videoId, title:copy.title||copy.filename, channel:copy.channel||'Offline audio', thumbnail:copy.thumbnail||'' } as Track))
  const surprisePool = uniqueTracks([...recommendations, ...quick, ...mixes.flatMap((m:Mix)=>m.tracks)])
  const surprise = () => { if (!surprisePool.length) return; play(surprisePool[Math.floor(Math.random()*surprisePool.length)]) }
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'
  return <section className="home-view">
    <div className="home-welcome">
      <div><p className="eyebrow"><Sparkles/> SIDEPLAY</p><h1>{greeting}</h1><p>Pick up where you left off or find something new.</p></div>
      <div className="hero-actions"><button className="primary" onClick={()=>setTab('search')}><Search/> Search</button>{last&&<button className="soft-button" onClick={()=>play(last)}><Play/> Resume</button>}<button className="soft-button" disabled={!surprisePool.length} onClick={surprise}><Shuffle/> Shuffle</button></div>
    </div>

    {!!quick.length && <Section title="Jump back in" eyebrow="RECENTLY PLAYED"><div className="quick-grid">{quick.map((t:Track)=><QuickCard key={t.videoId} track={t} onPlay={()=>play(t)} offline={!!sp.getOfflineCopy(t.videoId)} />)}</div></Section>}

    {!!mixes.length && <Section title="Made for you" eyebrow="YOUR MIXES" action={<button className="text-button" onClick={refreshRecommendations}><RefreshCw className={recsBusy?'spin':''}/> Refresh</button>}>
      <div className="mix-grid">{mixes.map((mix:Mix)=><MixCard key={mix.id} mix={mix} play={play}/>)}</div>
    </Section>}

    {!!offlineTracks.length && <Section title="Ready without signal" eyebrow="OFFLINE NOW" action={<button className="text-button" onClick={()=>setTab('downloads')}><WifiOff/> See all</button>}><div className="quick-grid">{offlineTracks.map((t:Track)=><QuickCard key={t.videoId} track={t} onPlay={()=>play(t)} offline />)}</div></Section>}

    <Section title={recommendations[0]?.recommendationReason || (last?`More for your rotation`:'Discover something')} eyebrow="SMART RADIO" action={<button className="text-button" onClick={refreshRecommendations}><Compass/> Explore</button>}>
      {recsBusy&&!recommendations.length?<LoadingCards/>:recommendations.length?<div className="recommend-grid">{recommendations.slice(0,12).map((t:Track)=><TrackTile key={t.videoId} track={t} sp={sp} onPlay={()=>play(t)} onOffline={()=>addOffline(t)} offlineBusy={offlineBusy} setTrackMenu={setTrackMenu} downloadProgress={downloadProgress}/>)}</div>:<Empty text="Play or like a few things and SidePlay will start building recommendations here."/>}
    </Section>
  </section>
}

function SearchView({query,setQuery,runSearch,busy,results,play,sp,addOffline,offlineBusy,setTrackMenu,downloadProgress,recentSearches,clearRecentSearches,searchScope,setSearchScope,searchSources,resolvingTrackId,suggestions,suggestionsEnabled,setSuggestionsEnabled}:any) {
  const scopes:Array<{id:SearchScope;label:string}>=[{id:'all',label:'Music'},{id:'youtube',label:'YouTube'},{id:'soundcloud',label:'SoundCloud'},{id:'audius',label:'Audius'},{id:'peertube',label:'PeerTube'}]
  const[activeSuggestion,setActiveSuggestion]=useState(-1)
  useEffect(()=>setActiveSuggestion(-1),[query,suggestions?.length])
  const submit=(term?:string)=>{setSuggestionsEnabled(false);setActiveSuggestion(-1);document.getElementById('sideplay-search')?.blur();runSearch(term)}
  const onSearchKey=(e:any)=>{
    const list=suggestions||[]
    if(e.key==='ArrowDown'&&list.length){e.preventDefault();setActiveSuggestion((v:number)=>Math.min(list.length-1,v+1));return}
    if(e.key==='ArrowUp'&&list.length){e.preventDefault();setActiveSuggestion((v:number)=>Math.max(-1,v-1));return}
    if((e.key==='Tab'||e.key==='Enter')&&activeSuggestion>=0&&list[activeSuggestion]){
      e.preventDefault();setQuery(list[activeSuggestion]);submit(list[activeSuggestion]);return
    }
    if(e.key==='Enter'){e.preventDefault();submit();return}
    if(e.key==='Escape'){setSuggestionsEnabled(false);setActiveSuggestion(-1)}
  }
  return <section><PageTitle eyebrow="SEARCH" title="What do you want to hear?" subtitle="Autocomplete, canonical song matching, and audio-first ranking before SidePlay resolves anything."/>
    <div className="searchbox-wrap">
      <div className="searchbar"><Search/><input id="sideplay-search" autoFocus value={query} onFocus={()=>setSuggestionsEnabled(true)} onBlur={()=>window.setTimeout(()=>setSuggestionsEnabled(false),120)} onChange={e=>{setSuggestionsEnabled(true);setQuery(e.target.value)}} onKeyDown={onSearchKey} placeholder="Song, artist, video, or paste a URL" autoComplete="off" role="combobox" aria-autocomplete="list" aria-expanded={!!suggestions?.length}/><button onClick={()=>submit()}>{busy?'Searching…':'Search'}</button></div>
      {suggestionsEnabled&&!!query.trim()&&!!suggestions?.length&&!busy&&<div className="search-suggestions" role="listbox">{suggestions.map((term:string,i:number)=><button key={`${term}-${i}`} className={i===activeSuggestion?'active':''} onMouseDown={(e)=>e.preventDefault()} onClick={()=>{setSuggestionsEnabled(false);setQuery(term);submit(term)}} role="option" aria-selected={i===activeSuggestion}><Search/><span>{term}</span>{recentSearches.some((x:string)=>x.toLowerCase()===term.toLowerCase())&&<Clock3/>}</button>)}</div>}
    </div>
    <div className="source-filter" role="tablist" aria-label="Search source">{scopes.map((scope)=><button key={scope.id} className={searchScope===scope.id?'active':''} onClick={()=>{setSearchScope(scope.id);if(query.trim())runSearch(undefined,scope.id)}}>{scope.label}</button>)}</div>
    {!results.length&&!!recentSearches.length&&<div className="recent-searches"><div className="recent-searches-head"><span>Recent</span><button onClick={clearRecentSearches}>Clear</button></div><div className="search-chips">{recentSearches.map((term:string)=><button key={term} onClick={()=>submit(term)}><Clock3/>{term}</button>)}</div></div>}
    {!results.length&&!busy&&<div className="search-empty"><Radio/><h3>Search across SidePlay.</h3><p>Start with a song, artist, video, or URL. SidePlay prefers the canonical/official song upload and pushes covers, slowed edits and duplicate lyric uploads down unless you explicitly ask for them.</p></div>}
    <div className="track-list">{results.map((t:Track)=><TrackRow key={`${t.provider||'unknown'}-${t.videoId}`} track={t} sp={sp} onPlay={()=>play(t)} onOffline={()=>addOffline(t)} offlineBusy={offlineBusy} setTrackMenu={setTrackMenu} downloadProgress={downloadProgress} resolving={resolvingTrackId===t.videoId}/>)}</div>
  </section>
}

function LibraryView({sp,play,setSelectedPlaylist,addOffline,offlineBusy,setTrackMenu,downloadProgress,setTab}:any) {
  const [name,setName]=useState('')
  return <section><PageTitle eyebrow="YOUR STUFF" title="Library" subtitle="Favorites, playlists and everything you keep coming back to."/>
    <div className="library-grid">
      <button className="library-card favorite-card" onClick={()=>sp.state.favorites[0]&&play(sp.state.favorites[0],sp.state.favorites)}><div className="card-icon"><Heart fill="currentColor"/></div><div><b>Liked Songs</b><span>{sp.state.favorites.length} tracks</span></div></button>
      <button className="library-card history-card" onClick={()=>document.getElementById('history')?.scrollIntoView({behavior:'smooth'})}><div className="card-icon"><History/></div><div><b>History</b><span>{sp.state.history.length} recent</span></div></button>
      <button className="library-card offline-card" onClick={()=>setTab('downloads')}><div className="card-icon"><WifiOff/></div><div><b>Offline</b><span>{Object.keys(sp.state.offline||{}).length} local copies</span></div></button>
    </div>
    <div className="create-playlist"><input value={name} onChange={e=>setName(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&name.trim()){sp.createPlaylist(name);setName('')}}} placeholder="New playlist name"/><button onClick={()=>{if(name.trim()){sp.createPlaylist(name);setName('')}}}><Plus/> Create</button></div>
    <Section title="Playlists" eyebrow="COLLECTIONS"><div className="playlist-grid">{sp.state.playlists.length?sp.state.playlists.map((p:Playlist)=><button key={p.id} className="playlist-card" onClick={()=>setSelectedPlaylist(p)}><div className="playlist-art">{p.tracks.slice(0,4).map((t:Track)=><img key={t.videoId} src={t.thumbnail} alt=""/>)}{!p.tracks.length&&<Music2/>}</div><b>{p.name}</b><span>{p.tracks.length} tracks</span></button>):<Empty text="Create a playlist and it will show up here."/>}</div></Section>
    <Section title="History" eyebrow="RECENTLY PLAYED" id="history" action={sp.state.history.length?<button className="text-button danger-text" onClick={()=>{if(confirm('Clear SidePlay listening history?'))sp.clearHistory()}}><Trash2/> Clear</button>:null}><div className="track-list">{sp.state.history.length?sp.state.history.map((t:any)=><TrackRow key={`${t.videoId}-${t.playedAt}`} track={t} sp={sp} onPlay={()=>play(t)} onOffline={()=>addOffline(t)} offlineBusy={offlineBusy} setTrackMenu={setTrackMenu} downloadProgress={downloadProgress}/>):<Empty text="Your listening history will appear here."/>}</div></Section>
  </section>
}

function DownloadsView({sp,play,addOffline,deleteOffline,offlineBusy,setTrackMenu,downloadProgress}:any) {
  const copies = Object.values(sp.state.offline || {}) as OfflineCopy[]
  const [url,setUrl]=useState('')
  const [status,setStatus]=useState('')
  const [resolving,setResolving]=useState(false)
  const [resolvedTrack,setResolvedTrack]=useState<Track|null>(null)

  async function resolveUrl(){
    const q=url.trim()
    if(!q)return
    setResolving(true);setStatus('Resolving source…');setResolvedTrack(null)
    try{
      const result=await resolveUniversalUrl(q)
      const track=resolutionToTrack(result)
      setResolvedTrack(track)
      setStatus(result.note || (result.playable?'Ready to play in SidePlay.':'This provider did not expose a direct playable stream.'))
    }catch(e:any){setStatus(e?.message||'Could not resolve that URL.')}
    finally{setResolving(false)}
  }

  async function captureUrl(){
    const q=(resolvedTrack?.sourceUrl||url).trim()
    if(!q||!isNative())return
    setResolving(true);setStatus('Open the page, start the media, then tap Use media…')
    try{
      const result=await captureUniversalUrl(q)
      const track=resolutionToTrack(result)
      setResolvedTrack(track)
      setStatus(result.note||'Captured media is ready.')
    }catch(e:any){if(!/cancel/i.test(e?.message||''))setStatus(e?.message||'Could not capture media from that page.')}
    finally{setResolving(false)}
  }

  async function importLocal(){
    setStatus('Choose an audio or video file…')
    try{
      const seed:Track={videoId:`local-${Date.now()}`,title:'Local media',channel:'On this device',thumbnail:'',provider:'local'}
      const copy=await importOfflineCopy(seed)
      copy.title=copy.filename || 'Local media'
      copy.channel='On this device'
      copy.provider='local'
      sp.setOfflineCopy(copy)
      setStatus(`Saved ${copy.filename} to the SidePlay vault.`)
    }catch(e:any){if(!/cancel/i.test(e?.message||''))setStatus(e?.message||'Could not import local media.')}
  }

  return <section><PageTitle eyebrow="OFFLINE" title="Downloads" subtitle="Your saved music and media, ready whenever the connection isn't."/>
    <div className="offline-banner"><div className="offline-banner-icon"><WifiOff/></div><div><b>{copies.length} {copies.length===1?'download':'downloads'} ready</b><p>Saved items play through SidePlay's native audio engine, including with the screen off and over Bluetooth.</p></div></div>

    <Section title="Downloaded" eyebrow="YOUR MUSIC">
      {!copies.length?<Empty text="Nothing downloaded yet. Save a song from Search or add one below."/>:<div className="track-list">{copies.sort((a,b)=>b.addedAt-a.addedAt).map((copy)=>{const t:Track={videoId:copy.videoId,title:copy.title||copy.filename,channel:copy.channel||'Offline media',thumbnail:copy.thumbnail||'',provider:copy.provider||'local',sourceUrl:copy.sourceUrl,mediaKind:copy.mediaKind||'audio'};return <div className="track-row" key={copy.videoId}><button className="track-main" onClick={()=>play(t)}>{t.thumbnail?<img src={t.thumbnail} alt="" loading="lazy"/>:<div className="fallback-thumb"><Music2/></div>}<div><b>{t.title}</b><span>{t.channel} · {formatBytes(copy.bytes)}</span><div className="source-line"><em className="offline-chip"><CheckCircle2/> Downloaded</em></div></div></button><div className="compact-actions"><button aria-label="More actions" onClick={()=>setTrackMenu(t)}><MoreHorizontal/></button><button className="danger" aria-label="Delete offline copy" onClick={()=>deleteOffline(t.videoId)}><Trash2/></button></div></div>})}</div>}
    </Section>

    <details className="settings-disclosure offline-add-disclosure"><summary><Plus/> Add from a link or file</summary>
      <div className="settings-card universal-download-card nested-settings">
        <p>Paste a media link or choose a file from this device. SidePlay will resolve the playable source automatically; advanced browser capture only appears when a normal resolver cannot.</p>
        <div className="direct-download"><input value={url} onChange={e=>setUrl(e.target.value)} onKeyDown={e=>e.key==='Enter'&&resolveUrl()} placeholder="Paste a media link"/><button disabled={!url.trim()||resolving} onClick={resolveUrl}>{resolving?<RefreshCw className="spin"/>:<Search/>} Add</button></div><div className="button-row"><button className="soft-button" onClick={importLocal}><FolderOpen/> Choose from device</button></div>
        {status&&<small className="resolver-status">{status}</small>}
        {resolvedTrack&&<div className="resolved-media-card">
          <div className="resolved-media-main">{resolvedTrack.thumbnail?<img src={resolvedTrack.thumbnail} alt=""/>:<div className="fallback-thumb"><Music2/></div>}<div><b>{resolvedTrack.title}</b><span>{resolvedTrack.channel}</span></div></div>
          <div className="resolved-actions">{resolvedTrack.playbackUrl&&<button className="primary" onClick={()=>play(resolvedTrack)}><Play/> Play</button>}{!resolvedTrack.playbackUrl&&resolvedTrack.sourceUrl&&isNative()&&<button className="primary" disabled={resolving} onClick={captureUrl}><Radio/> Try browser capture</button>}{(resolvedTrack.downloadUrl||resolvedTrack.downloadEngine==='ytdlp'||(isNative()&&!!resolvedTrack.sourceUrl&&resolvedTrack.provider!=='spotify'))&&<button className="soft-button" disabled={offlineBusy===resolvedTrack.videoId} onClick={()=>addOffline(resolvedTrack)}><Download/> {offlineBusy===resolvedTrack.videoId?downloadLabel(downloadProgress[resolvedTrack.videoId]):'Download'}</button>}{resolvedTrack.sourceUrl&&<button className="soft-button" onClick={()=>openExternalUrl(resolvedTrack.sourceUrl!)}><ExternalLink/> Open source</button>}</div>
        </div>}
      </div>
    </details>
  </section>
}

function QueueView({sp,play}:any){
  const first=sp.state.currentIndex<0?0:sp.state.currentIndex+1
  const upcoming=sp.state.queue.map((track:Track,index:number)=>({track,index})).filter(({index}:any)=>index>=first)
  const manual=upcoming.filter(({track}:any)=>track.queueOrigin!=='autoplay')
  const autoplay=upcoming.filter(({track}:any)=>track.queueOrigin==='autoplay')
  const render=(items:any[],kind:'manual'|'autoplay')=><div className="queue-list">{items.map(({track:t,index:i}:any,v:number)=><div className={`queue-row ${kind==='autoplay'?'autoplay-row':''}`} key={`${t.videoId}-${i}`}><button className="queue-main" onClick={()=>play(t,undefined,{preserveQueue:true})}><span className="queue-num">{v+1}</span><img src={t.thumbnail}/><div><b>{t.title}</b><span>{t.channel}</span>{kind==='autoplay'&&<em className="radio-reason"><Sparkles/> {t.recommendationReason||'Autoplay recommendation'}</em>}</div></button><div className="row-actions"><button disabled={v===0} onClick={()=>sp.moveQueue(i,items[v-1].index)}><ArrowUp/></button><button disabled={v===items.length-1} onClick={()=>sp.moveQueue(i,items[v+1].index)}><ArrowDown/></button><button onClick={()=>sp.removeQueue(i)}><X/></button></div></div>)}</div>
  return <section><div className="section-head"><PageTitle eyebrow="UP NEXT" title="Queue" subtitle="Your picks stay ahead of smart Autoplay. You can move or remove either."/><button className="ghost" disabled={!upcoming.length} onClick={sp.clearQueue}>Clear</button></div>{!upcoming.length&&<Empty text="Nothing up next yet. Queue a song or leave Autoplay on and SidePlay will build a runway."/>}{!!manual.length&&<Section eyebrow="YOUR PICKS" title="Queued by you">{render(manual,'manual')}</Section>}{!!autoplay.length&&<Section eyebrow="AUTOPLAY" title="SidePlay Radio">{render(autoplay,'autoplay')}</Section>}</section>
}

function SettingsView({sp,autoplayEnabled,setAutoplayEnabled,spotifyEngineEnabled,setSpotifyEngineEnabled,youtubeProviderEnabled,setYoutubeProviderEnabled,youtubeProviderRoute,setYoutubeProviderRoute}:any){
  const [io,setIo]=useState('')
  return <section><PageTitle eyebrow="PLAYBACK" title="Settings" subtitle="Tune SidePlay for a music-first, native listening experience."/>
    <div className="settings-card listening-card"><div className="settings-card-title"><span className="settings-icon"><Sparkles/></span><div><label>Listening experience</label><p>SidePlay keeps your manual queue ahead of Autoplay, builds radio from the song you are actually hearing, learns from skips and completions, and still prefers the best available original audio stream for playback and offline saves.</p></div></div><div className="setting-toggle"><div><b>Autoplay</b><span>Keep the music going with watch-next radio, local taste ranking, duplicate filtering and artist diversity when your picks run out.</span></div><button className={autoplayEnabled?'toggle on':'toggle'} onClick={()=>setAutoplayEnabled(!autoplayEnabled)}><span/></button></div><div className="capability-row"><span className="status-pill success">Best available audio ✓</span><span className="status-pill success">No forced re-encode ✓</span><span className="status-pill success">Process-isolated playback ✓</span></div></div>
    <BackgroundPlaybackSettings/>
    <ResolverDoctorSettings/>
    <AlexaBluetoothSettings/>
    <details className="settings-disclosure"><summary>Advanced playback & source tools</summary><div className="settings-card universal-engine-card nested-settings"><div className="settings-card-title"><span className="settings-icon"><Radio/></span><div><label>Universal playback engine</label><p>SidePlay normally handles source extraction, adaptive streams and browser capture automatically. These tools are here only for difficult sources or provider handoff.</p></div></div><div className="capability-row"><span className="status-pill success">HLS / DASH / RTSP ✓</span><span className="status-pill success">Dynamic capture ✓</span><span className="status-pill success">Safe offline vault ✓</span></div></div><ProviderBridgeSettings youtubeEnabled={youtubeProviderEnabled} setYoutubeEnabled={setYoutubeProviderEnabled} route={youtubeProviderRoute} setRoute={setYoutubeProviderRoute}/><SpotifySessionSettings enabled={spotifyEngineEnabled} setEnabled={setSpotifyEngineEnabled}/></details>
    <details className="settings-disclosure"><summary>YouTube library import</summary><YouTubeLocalImportSettings sp={sp}/></details>
    <details className="settings-disclosure"><summary>Library backup</summary><div className="settings-card nested-settings"><textarea value={io} onChange={e=>setIo(e.target.value)} placeholder="Paste backup JSON here, or export yours below."/><div className="button-row"><button className="soft-button" onClick={()=>setIo(sp.exportLibrary())}>Export</button><button className="primary" onClick={()=>{try{sp.importLibrary(io);alert('Imported.')}catch{alert('Invalid backup JSON.')}}}>Import</button></div></div></details>
    <details className="settings-disclosure"><summary>Desktop shortcuts</summary><div className="settings-card nested-settings"><div className="shortcut-grid"><span><kbd>Ctrl K</kbd><b>Search</b></span><span><kbd>Space / K</kbd><b>Play / pause</b></span><span><kbd>J / ←</kbd><b>Back 10 sec</b></span><span><kbd>L / →</kbd><b>Forward 10 sec</b></span><span><kbd>Shift N</kbd><b>Next</b></span><span><kbd>Shift P</kbd><b>Previous</b></span></div></div></details>
  </section>
}

function ResolverDoctorSettings(){
  const[snapshot,setSnapshot]=useState<any>(null)
  const[busy,setBusy]=useState(false)
  const refresh=async()=>{
    setBusy(true)
    try{
      const cache=getResolverCacheHealth()
      const native=isNative()?await NativeYouTube.getResolverHealth().catch(()=>null):null
      const playback=isNative()?await BackgroundAudio.getStatus().catch(()=>null):null
      const nativePlayback=isNative()?await BackgroundAudio.getNativeDiagnostics().catch(()=>null):null
      setSnapshot({cache,native,playback,nativePlayback,updatedAt:Date.now()})
    }finally{setBusy(false)}
  }
  useEffect(()=>{void refresh()},[])
  const reset=async()=>{
    clearResolverCache()
    if(isNative())await NativeYouTube.resetResolverHealth().catch(()=>{})
    await refresh()
  }
  const copy=async()=>{
    const payload={sideplay:'0.8.4-r9',...snapshot}
    const text=JSON.stringify(payload,null,2)
    try{await navigator.clipboard.writeText(text);alert('Engine diagnostics copied.')}catch{prompt('Copy Engine diagnostics:',text)}
  }
  const c=snapshot?.cache
  const n=snapshot?.native
  const pdiag=snapshot?.nativePlayback
  const lastExit=pdiag?.recentExits?.[0]
  return <div className="settings-card resolver-doctor-card">
    <div className="settings-card-title"><span className="settings-icon"><RefreshCw/></span><div><label>Engine Doctor</label><p>Live resolver telemetry with no URLs, cookies or tokens. Use this when a video refuses to play so we can see exactly which engine failed.</p></div></div>
    <div className="doctor-grid">
      <div className="doctor-stat"><span>NewPipe</span><b>{n?`${n.newPipeSuccesses} ok · ${n.newPipeFailures} fail`:'—'}</b></div>
      <div className="doctor-stat"><span>InnerTube SAFE</span><b>{n?`${n.innerTubeSuccesses} ok · ${n.innerTubeFailures} fail`:'—'}</b></div>
      <div className="doctor-stat"><span>yt-dlp isolated</span><b>{n?`${n.ytdlpSuccesses} ok · ${n.ytdlpFailures} fail`:'—'}</b></div>
      <div className="doctor-stat"><span>Zero-Wait cache</span><b>{c?`${c.entries} ready · ${c.hits} hits`:'—'}</b></div>
      <div className="doctor-stat"><span>Native playback</span><b>{pdiag?.stage||'—'}</b></div>
      <div className="doctor-stat"><span>Process shield</span><b>{pdiag?.playbackIsolation||':playback'}</b></div>
    </div>
    <div className="capability-row">
      {n&&<span className="status-pill success">{n.extractorIsolation||':extractor'} ✓</span>}
      {c&&<span className="status-pill success">{c.prefetches} prefetched</span>}
      {c&&<span className="status-pill">{c.inFlight} resolving now</span>}
      {n?.innerTubeCooldownMs>0&&<span className="status-pill">InnerTube cooldown {Math.ceil(n.innerTubeCooldownMs/1000)}s</span>}{n?.ytdlpCooldownMs>0&&<span className="status-pill">yt-dlp cooldown {Math.ceil(n.ytdlpCooldownMs/1000)}s</span>}
    </div>
    {n?.lastResolverEngine&&n.lastResolverEngine!=='none'&&<small>Last resolver: <b>{n.lastResolverEngine}</b>{n.lastResolverTrail?` · ${n.lastResolverTrail}`:''}</small>}
    {(n?.lastResolverError||c?.lastError)&&<small className="doctor-error">Last resolver error: {n?.lastResolverError||c?.lastError}</small>}
    {pdiag?.message&&<small className={String(pdiag.stage||'').includes('failed')?'doctor-error':''}>Native stage: <b>{pdiag.stage}</b> · {pdiag.message}</small>}{pdiag?.recovery&&pdiag.recovery!=='none'&&<small className={String(pdiag.recovery).includes('waiting')?'doctor-error':''}>Recovery: <b>{pdiag.recovery}</b>{pdiag.recoveryMessage?` · ${pdiag.recoveryMessage}`:''}{pdiag.recoveryAttempts?` · attempts ${pdiag.recoveryAttempts}`:''}</small>}
    {lastExit&&<small className="doctor-error">Last Android process exit: <b>{lastExit.process||'unknown'}</b> · {lastExit.reasonName||`reason ${lastExit.reason}`} · status {lastExit.status}{lastExit.description?` · ${lastExit.description}`:''}</small>}
    <div className="button-row"><button className="soft-button" disabled={busy} onClick={refresh}><RefreshCw/> {busy?'Checking…':'Refresh'}</button><button className="soft-button" onClick={copy}>Copy diagnostics</button><button className="text-button" onClick={reset}>Reset cache + counters</button></div>
    <small>NewPipe {n?.newPipeVersion||'—'} · yt-dlp-android {n?.ytDlpAndroidVersion||'—'} · short-lived cache TTL 7 min · next two queue items are prefetched when possible.</small>
  </div>
}

function AlexaBluetoothSettings(){
  if(!isNative())return null
  async function openBluetooth(){
    try{await BackgroundAudio.openBluetoothSettings()}
    catch(e:any){alert(e?.message||'Could not open Bluetooth settings.')}
  }
  return <div className="settings-card alexa-output-card">
    <div className="settings-card-title"><span className="settings-icon"><Bluetooth/></span><div><label>Alexa / Echo output</label><p>Echo speakers work as normal Android Bluetooth media outputs. Say “Alexa, pair Bluetooth,” then pair the Echo in Android. SidePlay's Media3 playback, lock-screen controls and captured streams will route through it automatically.</p></div></div>
    <div className="button-row"><button className="primary" onClick={openBluetooth}><Bluetooth/> Pair / Bluetooth settings</button></div>
    <small>Voice commands like “Alexa, play X on SidePlay” need a separate Alexa Skill/cloud service; Bluetooth playback itself does not.</small>
  </div>
}

function YouTubeLocalImportSettings({sp}:any){
  const [busy,setBusy]=useState(false)
  const [status,setStatus]=useState('No Google Cloud required.')
  const [summary,setSummary]=useState<any>(null)
  async function choose(file:File|undefined){
    if(!file)return
    setBusy(true);setStatus(`Reading ${file.name}…`)
    try{
      const result=await parseYouTubeExportFile(file)
      let playlistTracks=0
      for(const p of result.playlists){const local=sp.createPlaylist(p.name);for(const t of p.tracks)sp.addToPlaylist(local.id,t);playlistTracks+=p.tracks.length}
      for(const t of result.favorites)if(!sp.isFavorite(t.videoId))sp.toggleFavorite(t)
      if(result.history.length)sp.mergeHistory(result.history)
      if(result.subscriptions.length)localStorage.setItem('sideplay.youtube.subscriptions',JSON.stringify(result.subscriptions))
      const s={playlists:result.playlists.length,playlistTracks,favorites:result.favorites.length,history:result.history.length,subscriptions:result.subscriptions.length,filesRead:result.filesRead}
      setSummary(s)
      setStatus(`Imported ${s.playlists} playlists, ${s.favorites} likes, ${s.history} history tracks and ${s.subscriptions} subscriptions.`)
    }catch(e:any){setStatus(e?.message||'Could not read that YouTube export.')}
    finally{setBusy(false)}
  }
  return <div className="settings-card youtube-account-card"><label>YouTube library — no cloud</label><div className="connect-prompt"><div className="connect-icon"><FileArchive/></div><div><b>Import your YouTube data locally</b><p>Use a Google Takeout YouTube/YouTube Music ZIP, or a compatible exported CSV/JSON/HTML file. SidePlay reads it on your device and never needs OAuth.</p></div></div><label className={`primary import-file-button ${busy?'disabled':''}`}><UploadCloud/> {busy?'Importing…':'Choose YouTube export'}<input type="file" accept=".zip,.csv,.json,.html,.htm" disabled={busy} onChange={e=>{choose(e.target.files?.[0]);e.currentTarget.value=''}}/></label><small className="account-status">{status}</small>{summary&&<div className="account-summary"><b>{summary.playlists+summary.favorites+summary.history}</b><span>library items discovered across {summary.filesRead} relevant export files · subscriptions feed Made for You</span></div>}<small>Tip: in Google Takeout, export only “YouTube and YouTube Music” for a smaller ZIP. SidePlay recognizes common playlist, liked-video, subscription and watch-history exports.</small></div>
}

function ProviderBridgeSettings({youtubeEnabled,setYoutubeEnabled,route,setRoute}:any){
  const[status,setStatus]=useState<any>(null)
  const[browserInfo,setBrowserInfo]=useState<any>(null)
  const[busy,setBusy]=useState(false)
  const refresh=async()=>{
    if(!isNative())return
    try{
      const [access,browsers]=await Promise.all([ProviderSession.hasAccess(),ProviderSession.listBrowsers()])
      setStatus(access);setBrowserInfo(browsers)
    }catch{setStatus(null);setBrowserInfo(null)}
  }
  useEffect(()=>{refresh()},[])
  if(!isNative())return null
  const routeText=route==='app'?'Official YouTube app only':route==='web'?'Browser only':'Auto: app first, browser fallback'
  const selectedBrowser=status?.browserLabel||status?.browserPackage||'System browser'
  return <div className="settings-card provider-bridge-card">
    <div className="settings-card-title"><span className="settings-icon"><ExternalLink/></span><div><label>YouTube external tools</label><p>Optional diagnostic/manual provider controls. Normal Play stays inside SidePlay and uses the native extractor + Media3 path.</p></div></div>
    <div className="capability-row"><span className={status?.youtubeInstalled?'status-pill success':'status-pill'}>{status?.youtubeInstalled?'YouTube app ✓':'YouTube app missing'}</span><span className={status?.browserAvailable?'status-pill success':'status-pill'}>{status?.browserAvailable?`${selectedBrowser} ✓`:'Browser not found'}</span><span className={status?.granted?'status-pill success':'status-pill'}>{status?.granted?'Media session access ✓':'Media session access needed'}</span></div>
    <div className="setting-toggle"><div><b>External YouTube tools</b><span>{youtubeEnabled?routeText:'Disabled — normal Play never leaves SidePlay.'}</span></div><button className={youtubeEnabled?'toggle on':'toggle'} onClick={()=>setYoutubeEnabled(!youtubeEnabled)}><span/></button></div>
    {youtubeEnabled&&<div className="bridge-route" role="group" aria-label="YouTube handoff route"><button className={route==='auto'?'active':''} onClick={()=>setRoute('auto')}>Auto</button><button className={route==='app'?'active':''} onClick={()=>setRoute('app')}>YT app</button><button className={route==='web'?'active':''} onClick={()=>setRoute('web')}>Web</button></div>}
    {youtubeEnabled&&(route==='web'||route==='auto')&&<div className="browser-choice"><label htmlFor="sideplay-browser">Web browser</label><select id="sideplay-browser" value={browserInfo?.overridePackage||'system'} onChange={async e=>{setBusy(true);try{await ProviderSession.setBrowserPreference({packageName:e.target.value});await refresh()}finally{setBusy(false)}}}><option value="system">System default{browserInfo?.systemDefaultPackage?` · ${status?.systemDefaultBrowserLabel||browserInfo.systemDefaultPackage}`:''}</option>{(browserInfo?.browsers||[]).map((b:any)=><option key={b.packageName} value={b.packageName}>{b.label}{b.systemDefault?' · default':''}</option>)}</select><small>SidePlay checks Android's Browser role first, so a stale Samsung Internet choice can no longer override Brave. You can still pin a browser here.</small></div>}
    <div className="button-row provider-actions"><button className="soft-button" disabled={busy} onClick={async()=>{setBusy(true);try{await ProviderSession.openAccessSettings()}finally{setBusy(false);window.setTimeout(refresh,900)}}}>Media session access</button><button className="text-button" onClick={refresh}>Refresh</button></div>
    <small>Browser sessions are discovered dynamically, not only from a hard-coded browser list. SidePlay scores the browser that actually owns the active media session and verifies its title against the selected video before calling the bridge connected.</small>
  </div>
}

function SpotifySessionSettings({enabled,setEnabled}:any){
  const[status,setStatus]=useState<any>(null)
  const[busy,setBusy]=useState(false)
  const refresh=async()=>{if(!isNative())return;try{setStatus(await SpotifySession.getStatus())}catch{setStatus(null)}}
  useEffect(()=>{refresh();const id=window.setInterval(refresh,3000);return()=>window.clearInterval(id)},[])
  if(!isNative())return null
  const ready=!!status?.accessGranted&&!!status?.spotifyInstalled&&!!status?.sessionAvailable
  return <div className="settings-card spotify-session-card">
    <div className="settings-card-title"><span className="settings-icon"><Music2/></span><div><label>Spotify provider bridge <small>LAB</small></label><p>Optional Android handoff for Spotify links/YouTube matches. Direct and offline SidePlay playback does not depend on this.</p></div></div>
    <div className="spotify-status-row"><span className={status?.accessGranted?'status-pill success':'status-pill'}>{status?.accessGranted?'Notification access ✓':'Notification access needed'}</span><span className={status?.sessionAvailable?'status-pill success':'status-pill'}>{status?.sessionAvailable?'Spotify session found':'No active Spotify session'}</span>{status?.supportsPlayFromSearch&&<span className="status-pill success">PLAY_FROM_SEARCH ✓</span>}</div>
    <div className="setting-toggle"><div><b>Try Spotify for provider tracks</b><span>{ready?'Ready: provider tracks can attempt a Spotify handoff.':'Grant access and start any song in Spotify once to enable the optional handoff.'}</span></div><button className={enabled?'toggle on':'toggle'} onClick={()=>setEnabled(!enabled)}><span/></button></div>
    <div className="button-row"><button className="soft-button" disabled={busy} onClick={async()=>{setBusy(true);try{await SpotifySession.openAccessSettings()}finally{setBusy(false);window.setTimeout(refresh,900)}}}>Grant notification access</button><button className="soft-button" onClick={async()=>{try{await SpotifySession.openSpotify()}catch{};window.setTimeout(refresh,1200)}}>Open Spotify once</button><button className="soft-button" onClick={refresh}>Refresh</button></div>
    {status?.sessionAvailable&&<p className="spotify-now">Spotify session: <b>{status.title||'active'}</b>{status.artist?` · ${status.artist}`:''}</p>}
  </div>
}

function BackgroundPlaybackSettings(){
  const[health,setHealth]=useState<{unrestricted:boolean;androidVersion:number}|null>(null)
  const[busy,setBusy]=useState(false)
  const refresh=async()=>{if(!isNative())return;try{setHealth(await BackgroundAudio.getBackgroundHealth())}catch{setHealth(null)}}
  useEffect(()=>{refresh()},[])
  if(!isNative())return <div className="settings-card"><label>Background playback</label><p>PC offline audio stays available through the local SidePlay media bridge. Android-specific battery controls appear in the APK.</p></div>
  return <div className="settings-card background-health"><div className="settings-card-title"><span className="settings-icon"><BatteryCharging/></span><div><label>Background playback health</label><p>{health?.unrestricted?'Android is not battery-optimizing SidePlay.':'If your phone kills native offline playback, set SidePlay to Unrestricted / Not optimized in Android battery settings.'}</p></div></div><button className="soft-button" disabled={busy} onClick={async()=>{setBusy(true);try{await BackgroundAudio.openBackgroundSettings()}finally{setBusy(false);window.setTimeout(refresh,900)}}}>{health?.unrestricted?'Review battery settings':'Open Android battery settings'}</button></div>
}

function TrackRow({track,sp,onPlay,onOffline,offlineBusy,setTrackMenu,downloadProgress,resolving=false}:any){
  const offline=sp.getOfflineCopy(track.videoId)
  const progress=downloadProgress?.[track.videoId]
  return <div className={`track-row compact-track-row ${resolving?'is-resolving':''}`}><button className="track-main" onClick={onPlay} disabled={resolving}>{track.thumbnail?<span className="track-thumb-wrap"><img src={track.thumbnail}/>{resolving&&<span className="resolve-spinner"><RefreshCw/></span>}</span>:<div className="fallback-thumb">{resolving?<RefreshCw className="spin"/>:<Music2/>}</div>}<div><b>{track.title}</b><span>{resolving?'Getting the best stream…':track.channel}</span><div className="source-line"><em className="source-chip">{providerLabel(track)}</em>{resolving&&<em className="resolving-chip">Resolving</em>}{offline&&<em className="offline-chip"><WifiOff/> Offline</em>}</div></div></button><div className="compact-actions">{(offline||track.downloadUrl||track.downloadEngine==='ytdlp')&&<button className={offline?'offline-action':''} disabled={offlineBusy===track.videoId} onClick={onOffline} aria-label={offline?'Replace offline copy':'Download'}>{offline?<CheckCircle2/>:offlineBusy===track.videoId?<span className="action-progress">{downloadLabel(progress)}</span>:<Download/>}</button>}<button onClick={()=>setTrackMenu(track)} aria-label="More actions"><MoreHorizontal/></button></div></div>
}

function TrackTile({track,sp,onPlay,setTrackMenu}:any){
  const offline=sp.getOfflineCopy(track.videoId)
  return <article className="track-tile compact-track-tile"><button className="tile-art" onClick={onPlay}>{track.thumbnail?<img src={track.thumbnail}/>:<div className="fallback-thumb tile-fallback"><Music2/></div>}<span className="tile-play"><Play fill="currentColor"/></span>{offline&&<span className="tile-offline"><WifiOff/></span>}</button><div className="tile-copy"><b>{track.title}</b><span>{track.channel}</span><div className="tile-meta-line"><em className="source-chip">{providerLabel(track)}</em>{track.recommendationReason&&<em className="recommend-reason"><Sparkles/> {track.recommendationReason}</em>}</div></div><button className="tile-menu" onClick={()=>setTrackMenu(track)} aria-label="More actions"><MoreHorizontal/></button></article>
}

function TrackActionsSheet({track,sp,close,play,startRadio,addOffline,offlineBusy,downloadProgress,setPlaylistTarget}:any){
  const liked=sp.isFavorite(track.videoId)
  const offline=sp.getOfflineCopy(track.videoId)
  const progress=downloadProgress?.[track.videoId]
  const run=(fn:()=>any)=>{Promise.resolve(fn()).finally(close)}
  return <div className="overlay action-overlay" onClick={close}><div className="sheet action-sheet" onClick={e=>e.stopPropagation()}><div className="sheet-head"><div><p className="eyebrow">{providerLabel(track).toUpperCase()}</p><h3>{track.title}</h3><span>{track.channel}</span></div><button className="icon-btn" onClick={close}><X/></button></div><div className="action-sheet-grid"><button onClick={()=>run(()=>play(track))}><Play/><span><b>Play</b><small>Start this item</small></span></button><button onClick={()=>run(()=>startRadio(track))}><Radio/><span><b>Start radio</b><small>Build a smart queue from this song</small></span></button><button className={liked?'liked':''} onClick={()=>{sp.toggleFavorite(track);close()}}><Heart fill={liked?'currentColor':'none'}/><span><b>{liked?'Liked':'Like'}</b><small>Keep in Library</small></span></button><button onClick={()=>{sp.playNext(track);close()}}><SkipForward/><span><b>Play next</b><small>Put it after current</small></span></button><button onClick={()=>{sp.addQueue(track);close()}}><Plus/><span><b>Add to queue</b><small>Keep it coming</small></span></button><button onClick={()=>{sp.recordDislike(track);close()}}><ThumbsDown/><span><b>Less like this</b><small>Teach SidePlay to back off</small></span></button><button onClick={()=>setPlaylistTarget(track)}><ListMusic/><span><b>Playlist</b><small>Add to a collection</small></span></button>{(offline||track.downloadUrl||track.downloadEngine==='ytdlp'||track.provider==='local'||(isNative()&&!!track.sourceUrl&&track.provider!=='spotify'))&&<button disabled={offlineBusy===track.videoId} onClick={()=>run(()=>addOffline(track))}>{offline?<CheckCircle2/>:(track.downloadUrl||track.downloadEngine==='ytdlp')?<Download/>:<FolderOpen/>}<span><b>{offline?'Replace offline copy':(track.downloadUrl||track.downloadEngine==='ytdlp')?'Download':'Import file'}</b><small>{offlineBusy===track.videoId?`${downloadLabel(progress)}`:(track.downloadUrl||track.downloadEngine==='ytdlp')?'Save verified media offline':'Choose a local media file'}</small></span></button>}{track.sourceUrl&&<button onClick={()=>run(()=>openExternalUrl(track.sourceUrl!))}><ExternalLink/><span><b>Open source</b><small>{providerLabel(track)}</small></span></button>}</div></div></div>
}

function QuickCard({track,onPlay,offline}:any){return <button className="quick-card" onClick={onPlay}><img src={track.thumbnail}/><div><b>{track.title}</b><span>{track.channel}</span></div>{offline?<WifiOff/>:<Play fill="currentColor"/>}</button>}
function MixCard({mix,play}:{mix:Mix;play:(t:Track,q?:Track[])=>void}){const cover=mix.tracks.slice(0,4);return <button className={`mix-card ${mix.accent}`} disabled={!mix.tracks.length} onClick={()=>mix.tracks[0]&&play(mix.tracks[0],mix.tracks)}><div className="mix-cover">{cover.map((t)=><img key={t.videoId} src={t.thumbnail}/>)}</div><div><b>{mix.title}</b><span>{mix.subtitle}</span></div><Play className="mix-play" fill="currentColor"/></button>}

function PlaylistPicker({track,sp,close}:any){const[name,setName]=useState('');return <div className="overlay" onClick={close}><div className="sheet" onClick={e=>e.stopPropagation()}><div className="sheet-head"><div><p className="eyebrow">SAVE IT</p><h3>Add to playlist</h3></div><button className="icon-btn" onClick={close}><X/></button></div><div className="create-playlist"><input value={name} onChange={e=>setName(e.target.value)} placeholder="New playlist"/><button onClick={()=>{const p=sp.createPlaylist(name);sp.addToPlaylist(p.id,track);close()}}><Plus/> New</button></div><div className="playlist-list">{sp.state.playlists.map((p:Playlist)=><button className="playlist-row" key={p.id} onClick={()=>{sp.addToPlaylist(p.id,track);close()}}><div className="playlist-cover-mini"><Music2/></div><div><b>{p.name}</b><span>{p.tracks.length} tracks</span></div><Plus/></button>)}</div></div></div>}

function PlaylistDetail({playlistId,sp,play,close,addOffline,offlineBusy}:any){const p=sp.state.playlists.find((x:Playlist)=>x.id===playlistId);const[name,setName]=useState(p?.name??'');if(!p)return null;return <div className="overlay"><div className="full-sheet"><div className="sheet-head"><button className="icon-btn" onClick={close}><X/></button><div className="playlist-title"><input value={name} onChange={e=>setName(e.target.value)} onBlur={()=>sp.renamePlaylist(p.id,name)}/><span>{p.tracks.length} tracks</span></div><button className="icon-btn danger" onClick={()=>{if(confirm('Delete this playlist?')){sp.deletePlaylist(p.id);close()}}}><Trash2/></button></div><button className="primary wide" disabled={!p.tracks.length} onClick={()=>play(p.tracks[0],p.tracks)}><Play/> Play playlist</button><div className="queue-list">{p.tracks.map((t:Track,i:number)=><div className="queue-row" key={`${t.videoId}-${i}`}><button className="queue-main" onClick={()=>play(t,p.tracks)}><img src={t.thumbnail}/><div><b>{t.title}</b><span>{t.channel}</span>{sp.getOfflineCopy(t.videoId)&&<em className="offline-chip"><WifiOff/> Offline</em>}</div></button><div className="row-actions"><button disabled={i===0} onClick={()=>sp.movePlaylistTrack(p.id,i,i-1)}><ArrowUp/></button><button disabled={i===p.tracks.length-1} onClick={()=>sp.movePlaylistTrack(p.id,i,i+1)}><ArrowDown/></button><button disabled={offlineBusy===t.videoId} onClick={()=>addOffline(t)}>{sp.getOfflineCopy(t.videoId)?<CheckCircle2/>:<Download/>}</button><button onClick={()=>sp.removeFromPlaylist(p.id,t.videoId)}><X/></button></div></div>)}</div></div></div>}

function NowPlaying({track,sp,paused,pausePlayback,resumePlayback,previous,next,close,setPlaylistTarget,sleepText,setSleepUntil,sleepAfterCurrent,setSleepAfterCurrent,offline,useOffline,addOffline,offlineBusy,positionMs,durationMs,onSeek,setScrubbing,playbackEngine,openQueue,downloadProgress,startRadio,radioTuning,setRadioTuning}:any){
  const[showSleep,setShowSleep]=useState(false)
  const[showTune,setShowTune]=useState(false)
  const[showLyrics,setShowLyrics]=useState(false)
  const[lyrics,setLyrics]=useState<LyricsResult|null>(null)
  const[lyricsBusy,setLyricsBusy]=useState(false)
  const[lyricsError,setLyricsError]=useState('')
  const[dragY,setDragY]=useState(0)
  const dragStart=useRef<number|null>(null)
  const lyricsScrollRef=useRef<HTMLDivElement|null>(null)
  const lyricLineRefs=useRef<Array<HTMLButtonElement|null>>([])
  const liked=sp.isFavorite(track.videoId)
  const pct=durationMs>0?Math.min(100,(positionMs/durationMs)*100):0
  const progress=downloadProgress?.[track.videoId]
  const startDrag=(e:any)=>{dragStart.current=e.clientY;e.currentTarget.setPointerCapture?.(e.pointerId)}
  const moveDrag=(e:any)=>{if(dragStart.current===null)return;setDragY(Math.max(0,e.clientY-dragStart.current))}
  const endDrag=()=>{if(dragY>105)close();setDragY(0);dragStart.current=null}
  const status=useOffline?'OFFLINE · SIDEPLAY':playbackEngine==='native'?'SIDEPLAY · BACKGROUND':playbackEngine==='youtube-provider'?'YOUTUBE APP · BACKGROUND':playbackEngine==='youtube-browser'?'YOUTUBE WEB · BACKGROUND':playbackEngine==='youtube-provider-pending'?'YOUTUBE APP · CONNECTING':playbackEngine==='youtube-browser-pending'?'YOUTUBE WEB · CONNECTING':playbackEngine==='spotify'?'SPOTIFY · BACKGROUND':playbackEngine==='spotify-error'?'SPOTIFY · HANDOFF FAILED':isNative()?'SIDEPLAY':'BROWSER PLAYBACK'
  const visualMedia=track.mediaKind==='video'||(!track.mediaKind&&(/video\//i.test(track.mimeType||'')||track.provider==='peertube'||/\.(mp4|m4v|webm|mkv)(?:$|[?#])/i.test(track.playbackUrl||track.sourceUrl||'')))
  const activeLyricIndex=useMemo(()=>{
    const lines=lyrics?.lines||[]
    if(!lines.length)return -1
    let active=-1
    for(let i=0;i<lines.length;i++){
      if(lines[i].startMs<=positionMs+120)active=i
      else break
    }
    return active
  },[lyrics?.lines,positionMs])

  useEffect(()=>{
    setLyrics(null)
    setLyricsError('')
    setShowLyrics(false)
    lyricLineRefs.current=[]
  },[track.videoId])

  useEffect(()=>{
    if(!showLyrics||activeLyricIndex<0)return
    const panel=lyricsScrollRef.current
    const line=lyricLineRefs.current[activeLyricIndex]
    if(!panel||!line)return
    const target=Math.max(0,line.offsetTop-panel.clientHeight/2+line.clientHeight/2)
    if(Math.abs(panel.scrollTop-target)>28)panel.scrollTo({top:target,behavior:'smooth'})
  },[showLyrics,activeLyricIndex])

  const loadLyrics=async()=>{
    if(lyricsBusy)return
    setLyricsBusy(true)
    setLyricsError('')
    try{
      let lyricTrack=repairTrackIdentity(track)
      if(hasGenericYouTubeMetadata(lyricTrack)&&/^[A-Za-z0-9_-]{11}$/.test(lyricTrack.videoId)){
        try{
          const metadata=await getTrackById(lyricTrack.videoId,sp.state.youtubeApiKey)
          lyricTrack=repairTrackIdentity(mergeTrackMetadata(lyricTrack,metadata))
          sp.updateTrackMetadata(lyricTrack)
        }catch{}
      }
      setLyrics(await getLyrics(lyricTrack))
    }catch(e:any){
      setLyricsError(e?.message||'Lyrics are unavailable for this track.')
    }finally{
      setLyricsBusy(false)
    }
  }

  const openLyrics=()=>{
    const nextOpen=!showLyrics
    setShowLyrics(nextOpen)
    setShowTune(false)
    setShowSleep(false)
    if(nextOpen&&!lyrics&&!lyricsBusy)void loadLyrics()
  }
  const tuneMode=(mode:string)=>setRadioTuning((v:RadioTuning)=>({...v,mode}))
  const presets=[['stay','Stay here'],['deeper','Go deeper'],['surprise','Surprise me'],['energy','Energy'],['chill','Chill'],['balanced','Balanced']]

  return <div className="overlay now-overlay"><div className={`now-playing ${paused?'is-paused':''} ${visualMedia?'visual-player':'audio-player'}`} style={{transform:`translateY(${dragY}px)`,opacity:String(Math.max(.74,1-dragY/700))}}>
    {track.thumbnail&&<div className="now-backdrop" style={{backgroundImage:`url(${track.thumbnail})`}} aria-hidden="true"/>}<div className="now-vignette" aria-hidden="true"/>
    <div className="now-grabber-zone" onPointerDown={startDrag} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag}><span/><ChevronDown/></div>
    <div className="now-top"><button className="icon-btn" onClick={close}><X/></button><span>{providerLabel(track).toUpperCase()}</span><button className="icon-btn" onClick={openQueue} aria-label="Queue"><ListMusic/></button></div>
    <div className={`now-art-wrap ${visualMedia?'is-video':'is-audio'}`}>{track.mediaKind==='video'&&(track.playbackUrl||(useOffline&&offline?.localUri))?<VideoPreview src={useOffline&&offline?.localUri?Capacitor.convertFileSrc(offline.localUri):track.playbackUrl} positionMs={positionMs} paused={paused}/>:track.thumbnail?<img className="now-art" src={track.thumbnail}/>:<div className="now-art fallback-now"><Music2/></div>}<span className={`engine-badge ${playbackEngine==='native'||useOffline?'success':''}`}>{status}</span></div>
    <div className="now-meta"><div><h2>{track.title}</h2><p>{track.channel}</p></div><button className={liked?'now-like liked':'now-like'} onClick={()=>sp.toggleFavorite(track)} aria-label={liked?'Unlike':'Like'}><Heart fill={liked?'currentColor':'none'}/></button></div>
    <div className="seek-wrap"><input aria-label="Playback position" type="range" min={0} max={Math.max(1,durationMs)} step={500} value={Math.min(positionMs,Math.max(1,durationMs))} style={{'--seek-pct':`${pct}%`} as any} onPointerDown={()=>setScrubbing(true)} onPointerUp={()=>setScrubbing(false)} onPointerCancel={()=>setScrubbing(false)} onChange={e=>onSeek(Number(e.target.value))}/><div className="time-row"><span>{formatTime(positionMs)}</span><span>{durationMs>0?`-${formatTime(Math.max(0,durationMs-positionMs))}`:'--:--'}</span></div></div>
    <div className="now-controls"><button onClick={()=>sp.setShuffle(!sp.state.shuffle)} className={sp.state.shuffle?'active-control':''}><Shuffle/></button><button onClick={previous}><SkipBack/></button><button className="play-big" onClick={()=>paused?resumePlayback():pausePlayback()}>{paused?<Play fill="currentColor"/>:<Pause fill="currentColor"/>}</button><button onClick={next}><SkipForward/></button><button onClick={()=>sp.setRepeat(sp.state.repeat==='off'?'all':sp.state.repeat==='all'?'one':'off')} className={sp.state.repeat!=='off'?'active-control':''}><Repeat2/><small>{sp.state.repeat==='one'?'1':''}</small></button></div>
    <div className="now-actions compact-now-actions"><button className={showTune?'active-now-action':''} onClick={()=>{setShowTune(!showTune);setShowLyrics(false);setShowSleep(false)}}><SlidersHorizontal/> Tune</button><button className={showLyrics?'active-now-action':''} onClick={openLyrics}><Mic2/> Lyrics</button>{(offline||track.downloadUrl||track.downloadEngine==='ytdlp'||track.provider==='local'||(isNative()&&!!track.sourceUrl&&track.provider!=='spotify'))&&<button className={offline?'offline-action':''} disabled={offlineBusy===track.videoId} onClick={()=>addOffline(track)}>{offline?<CheckCircle2/>:(track.downloadUrl||track.downloadEngine==='ytdlp')?<Download/>:<FolderOpen/>} {offline?'Offline':offlineBusy===track.videoId?`${downloadLabel(progress)}`:(track.downloadUrl||track.downloadEngine==='ytdlp')?'Download':'Import'}</button>}<button onClick={()=>setPlaylistTarget(track)}><Plus/> Playlist</button></div>
    {showTune&&<div className="now-panel tune-panel"><div className="panel-head"><div><b>Tune this radio</b><span>Tell SidePlay where to take the next songs.</span></div><Radio/></div><div className="tune-presets">{presets.map(([id,label])=><button key={id} className={radioTuning.mode===id?'active':''} onClick={()=>tuneMode(id)}>{label}</button>)}</div><label className="tune-slider"><span><b>Discovery</b><em>{radioTuning.discovery}%</em></span><input type="range" min="0" max="100" step="5" value={radioTuning.discovery} onChange={e=>setRadioTuning((v:RadioTuning)=>({...v,discovery:Number(e.target.value)}))}/><small>Familiar ←→ new artists</small></label><label className="tune-slider"><span><b>Variety</b><em>{radioTuning.variety}%</em></span><input type="range" min="0" max="100" step="5" value={radioTuning.variety} onChange={e=>setRadioTuning((v:RadioTuning)=>({...v,variety:Number(e.target.value)}))}/><small>Coherent ←→ more artist diversity</small></label><button className="primary wide" onClick={()=>startRadio(track)}><Radio/> Restart radio with this tune</button></div>}
    {showLyrics&&<div className="now-panel lyrics-panel" aria-live="polite"><div className="panel-head"><div><b>Lyrics</b><span>{lyrics?`${lyrics.source}${lyrics.synced?' · synced':''}`:'Synced when available'}</span></div><Mic2/></div>{lyricsBusy?<div className="panel-loading"><RefreshCw className="spin"/> Looking up lyrics…</div>:lyricsError?<div className="panel-empty lyrics-error"><span>{lyricsError}</span><button onClick={()=>void loadLyrics()}><RefreshCw/> Retry</button></div>:lyrics?.lines?.length?<div className="lyrics-scroll synced-lyrics" ref={lyricsScrollRef}>{lyrics.lines.map((line:any,i:number)=><button key={`${line.startMs}-${i}`} ref={(el)=>{lyricLineRefs.current[i]=el}} className={i===activeLyricIndex?'active':''} onClick={()=>onSeek(line.startMs)}><span>{line.text||'♪'}</span></button>)}</div>:lyrics?<div className="lyrics-scroll lyrics-text" ref={lyricsScrollRef}>{lyrics.text}</div>:<div className="panel-empty"><span>No lyrics loaded yet.</span><button onClick={()=>void loadLyrics()}><RefreshCw/> Load lyrics</button></div>}</div>}
    <button className="sleep-toggle" onClick={()=>{setShowSleep(!showSleep);setShowTune(false);setShowLyrics(false)}}><Moon/> {sleepText?`Sleep: ${sleepText}`:'Sleep timer'}</button>{showSleep&&<div className="sleep-options"><button onClick={()=>{setSleepUntil(Date.now()+15*60000);setSleepAfterCurrent(false)}}>15 min</button><button onClick={()=>{setSleepUntil(Date.now()+30*60000);setSleepAfterCurrent(false)}}>30 min</button><button onClick={()=>{setSleepUntil(Date.now()+60*60000);setSleepAfterCurrent(false)}}>60 min</button><button className={sleepAfterCurrent?'active':''} onClick={()=>{setSleepAfterCurrent(true);setSleepUntil(null)}}>End of track</button><button onClick={()=>{setSleepUntil(null);setSleepAfterCurrent(false)}}>Off</button></div>}
    {track.sourceUrl&&<button className="now-source-link" onClick={()=>openExternalUrl(track.sourceUrl)}><ExternalLink/> Open source</button>}
  </div></div>
}


function VideoPreview({src,positionMs,paused}:any){
  const ref=useRef<HTMLVideoElement|null>(null)
  useEffect(()=>{const el=ref.current;if(!el||!src)return;const target=Math.max(0,positionMs/1000);if(Number.isFinite(el.currentTime)&&Math.abs(el.currentTime-target)>1.4){try{el.currentTime=target}catch{}}},[src,positionMs])
  useEffect(()=>{const el=ref.current;if(!el)return;if(paused)el.pause();else el.play().catch(()=>{})},[paused,src])
  return <video ref={ref} className="now-art native-video-preview" src={src} muted playsInline preload="metadata"/>
}

function Section({title,eyebrow,action,children,id}:any){return <section className="home-section" id={id}><div className="section-title"><div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2></div>{action}</div>{children}</section>}
function PageTitle({eyebrow,title,subtitle}:any){return <div className="page-title"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{subtitle}</p></div>}
function NavItem({active,label,icon,onClick,badge}:any){return <button className={active?'active':''} onClick={onClick}>{icon}<span>{label}</span>{badge>0&&<em>{badge}</em>}</button>}
function NavButton({active,label,icon,onClick,badge}:any){return <button data-tab={label.toLowerCase()} className={active?'active':''} onClick={onClick}>{icon}<span>{label}</span>{badge>0&&<em>{badge}</em>}</button>}
function Empty({text}:{text:string}){return <div className="empty"><Clock3/><p>{text}</p></div>}
function LoadingCards(){return <div className="recommend-grid">{Array.from({length:6}).map((_,i)=><div className="skeleton-card" key={i}><div/><span/><small/></div>)}</div>}
function uniqueTracks(tracks:Track[]){const seen=new Set<string>();return tracks.filter(t=>t?.videoId&&!seen.has(t.videoId)&&seen.add(t.videoId))}
function trimTitle(s:string){return s.replace(/\s*[\[(].*?[\])]/g,'').split(/[-–—]/)[0].trim().slice(0,34)}
function downloadLabel(progress?:number){return typeof progress==='number'&&progress>=0?`${Math.round(progress*100)}%`:'…'}
function formatTime(ms:number){if(!Number.isFinite(ms)||ms<0)return'0:00';const total=Math.floor(ms/1000);const m=Math.floor(total/60);const sec=String(total%60).padStart(2,'0');return`${m}:${sec}`}


function providerStatusMatches(status: { title?: string; artist?: string }, track: Track) {
  const actualTitle = normalizeProviderText(status.title)
  const wantedTitle = normalizeProviderText(track.title)
  if (!actualTitle || !wantedTitle) return false
  if (actualTitle === wantedTitle || actualTitle.includes(wantedTitle) || wantedTitle.includes(actualTitle)) return true
  // Provider notifications sometimes trim bracketed suffixes / "official video" text.
  const compactWanted = wantedTitle.replace(/\b(official|video|audio|lyrics|visualizer|hd|4k)\b/g, ' ').replace(/\s+/g, ' ').trim()
  const compactActual = actualTitle.replace(/\b(official|video|audio|lyrics|visualizer|hd|4k)\b/g, ' ').replace(/\s+/g, ' ').trim()
  return !!compactWanted && !!compactActual && (compactActual.includes(compactWanted) || compactWanted.includes(compactActual))
}

function normalizeProviderText(value?: string) {
  return (value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
}

type SpotifyWanted = { title: string; artist: string; query: string }

function normalizeSpotifyText(value?: string) {
  return (value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
}

function spotifyIdentityForTrack(track: Track): SpotifyWanted {
  const artist = track.channel
    .replace(/\s*-\s*Topic$/i, '')
    .replace(/VEVO$/i, '')
    .trim()

  let title = track.title
    .replace(/\s*[\[(](official|lyrics?|audio|video|visualizer|live|hd)[^\])]*[\])]/ig, '')
    .replace(/\s*\|.*$/g, '')
    .trim()

  // YouTube uploads often prefix the artist: "BAD BUNNY - SI VEO A TU MAMÁ".
  // Spotify wants the song title and artist as separate structured fields.
  const prefix = new RegExp(`^${escapeRegExp(artist)}\\s*[-–—:]\\s*`, 'i')
  title = title.replace(prefix, '').trim()

  return { title, artist, query: `${title} ${artist}`.trim() }
}

function spotifyStatusMatches(status: { title?: string; artist?: string }, wanted: SpotifyWanted) {
  const actualTitle = normalizeSpotifyText(status.title)
  const actualArtist = normalizeSpotifyText(status.artist)
  const wantedTitle = normalizeSpotifyText(wanted.title)
  const wantedArtist = normalizeSpotifyText(wanted.artist)
  if (!actualTitle || !wantedTitle) return false

  const titleMatch = actualTitle === wantedTitle || actualTitle.includes(wantedTitle) || wantedTitle.includes(actualTitle)
  const artistMatch = !wantedArtist || !actualArtist || actualArtist.includes(wantedArtist) || wantedArtist.includes(actualArtist)
  return titleMatch && artistMatch
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function spotifyQueryForTrack(track: Track) {
  return spotifyIdentityForTrack(track).query
}
