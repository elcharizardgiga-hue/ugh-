package app.sideplay.mobile;

import android.content.Context;
import android.net.Uri;
import android.webkit.MimeTypeMap;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.yausername.ffmpeg.FFmpeg;
import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLRequest;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import org.json.JSONArray;
import org.json.JSONObject;

import kotlin.Unit;
import kotlin.jvm.functions.Function3;

/**
 * Broad public-media extraction/download layer backed by yt-dlp.
 *
 * This deliberately does not enable DRM/decryption bypasses. yt-dlp is asked for
 * clear playable/downloadable formats only. SidePlay's MediaSafety gate still
 * validates completed files before they are admitted to the persistent vault.
 */
@CapacitorPlugin(name = "YtDlp")
public class YtDlpPlugin extends Plugin {
    private static final Object INIT_LOCK = new Object();
    private static volatile boolean initialized = false;
    private static final Object FFMPEG_INIT_LOCK = new Object();
    private static final Object EXTRACTOR_LOCK = new Object();
    private static volatile boolean ffmpegInitialized = false;
    // Serialize the embedded Python/QuickJS extractor. Multiple overlapping runs
    // can cause large memory spikes on OEM Android builds and take the whole app down.
    private static final ExecutorService EXTRACTOR_EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "SidePlayExtractor");
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
    });
    private static final AtomicBoolean RESOLVE_RUNNING = new AtomicBoolean(false);

    @PluginMethod
    public void search(PluginCall call) {
        String rawQuery = call.getString("query");
        String rawEngine = call.getString("engine", "youtube");
        Integer requestedLimit = call.getInt("limit", 20);
        if (rawQuery == null || rawQuery.isBlank()) {
            call.reject("A search query is required.");
            return;
        }
        final String query = rawQuery.trim();
        final String engine = rawEngine == null ? "youtube" : rawEngine.trim().toLowerCase(Locale.ROOT);
        final int limit = Math.max(1, Math.min(requestedLimit == null ? 20 : requestedLimit, 40));

        EXTRACTOR_EXECUTOR.execute(() -> {
            try {
                JSArray results;
                synchronized (EXTRACTOR_LOCK) {
                    ensureInitialized();
                    results = searchInternal(query, engine, limit);
                }
                JSObject out = new JSObject();
                out.put("tracks", results);
                out.put("engine", engine);
                out.put("count", results.length());
                call.resolve(out);
            } catch (Throwable e) {
                call.reject("Provider search failed: " + safe(e));
            }
        });
    }

    @PluginMethod
    public void resolve(PluginCall call) {
        String raw = call.getString("url");
        if (raw == null || raw.isBlank() || !(raw.startsWith("https://") || raw.startsWith("http://"))) {
            call.reject("A public http(s) media page URL is required.");
            return;
        }
        final String source = raw.trim();
        final boolean audioOnly = Boolean.TRUE.equals(call.getBoolean("audioOnly", false));
        if (!RESOLVE_RUNNING.compareAndSet(false, true)) {
            call.reject("SidePlay resolver is already working. Wait a moment and tap again.");
            return;
        }

        // Playback extraction is deliberately OUT-OF-PROCESS. Python/QuickJS/yt-dlp
        // live in :extractor so a native crash or hard timeout cannot kill SidePlay UI/Media3.
        YtDlpIsolatedClient.resolve(getContext(), source, audioOnly, 24_000L, new YtDlpIsolatedClient.Callback() {
            @Override
            public void onSuccess(String json) {
                try {
                    JSONObject parsed = new JSONObject(json);
                    JSObject out = new JSObject();
                    java.util.Iterator<String> keys = parsed.keys();
                    while (keys.hasNext()) {
                        String key = keys.next();
                        out.put(key, parsed.get(key));
                    }
                    out.put("extractorIsolation", "android-process:extractor");
                    call.resolve(out);
                } catch (Throwable error) {
                    call.reject("Isolated extractor returned invalid JSON: " + safe(error));
                } finally {
                    RESOLVE_RUNNING.set(false);
                }
            }

            @Override
            public void onError(String message) {
                RESOLVE_RUNNING.set(false);
                call.reject(message == null || message.isBlank() ? "Provider extractor failed." : message);
            }
        });
    }

    @PluginMethod
    public void download(PluginCall call) {
        String raw = call.getString("url");
        String videoId = call.getString("videoId");
        String title = call.getString("title");
        String mediaKind = call.getString("mediaKind");
        if (raw == null || raw.isBlank() || !(raw.startsWith("https://") || raw.startsWith("http://"))) {
            call.reject("A public http(s) source URL is required.");
            return;
        }
        final String source = raw.trim();
        final String id = videoId == null || videoId.isBlank() ? stableId(source) : videoId;
        final String wantedTitle = title == null || title.isBlank() ? "SidePlay media" : title;
        final boolean audioOnly = "audio".equalsIgnoreCase(mediaKind);

        EXTRACTOR_EXECUTOR.execute(() -> {
            File work = null;
            try {
                emitProgress(id, 0f, "Resolving provider media…");
                File out = null;
                synchronized (EXTRACTOR_LOCK) {
                    ensureInitialized();
                    ensureFfmpegInitialized(getContext());
                    work = new File(getContext().getCacheDir(), "ytdlp-" + System.currentTimeMillis() + "-" + Math.abs(id.hashCode()));
                    if (!work.mkdirs()) throw new Exception("Could not create temporary extractor storage.");
                    try {
                        out = downloadInternal(source, id, work, audioOnly, "");
                    } catch (Throwable first) {
                        if (!isYouTubeSource(source) || !looksLikeHttp403(first)) throw first;

                        // YouTube currently enforces PO tokens on several GVS/client paths.
                        // A 403 after successful extraction means the selected CDN format is
                        // not actually fetchable from that client. Refresh yt-dlp once, then
                        // try clients which currently expose token-free public-media paths.
                        emitProgress(id, 0f, "YouTube returned 403; refreshing extractor…");
                        maybeUpdateExtractor(getContext(), true);
                        Throwable last = first;
                        String[] clients = new String[]{"web_safari", "android_vr", "web_embedded", "tv"};
                        for (String client : clients) {
                            deleteChildren(work);
                            emitProgress(id, 0f, "Retrying YouTube via " + client + "…");
                            try {
                                out = downloadInternal(source, id, work, audioOnly, client);
                                last = null;
                                break;
                            } catch (Throwable retry) {
                                last = retry;
                            }
                        }
                        if (last != null) {
                            throw new Exception(
                                "YouTube refused the media download with HTTP 403 after SidePlay tried default, web_safari HLS, android_vr, web_embedded and tv clients. " +
                                "This video may currently require a YouTube PO token for GVS delivery. Playback can still work even when offline download is blocked. Last error: " + safe(last),
                                last
                            );
                        }
                    }
                }
                if (out == null) throw new Exception("Extractor download ended without producing a media file.");
                JSObject result = admitDownloadedFile(out, id, wantedTitle, source);
                emitProgress(id, 100f, "Complete");
                call.resolve(result);
            } catch (Throwable e) {
                call.reject("Provider download failed: " + safe(e));
            } finally {
                if (work != null) deleteTree(work);
            }
        });
    }

    private void ensureInitialized() throws Exception {
        ensureInitialized(getContext());
    }

    public static void ensureInitialized(Context context) throws Exception {
        if (initialized) return;
        synchronized (INIT_LOCK) {
            if (initialized) return;
            YoutubeDL.getInstance().init(context.getApplicationContext());
            initialized = true;
        }
    }

    private static void maybeUpdateExtractor(Context context, boolean force) {
        try {
            long now = System.currentTimeMillis();
            long last = context.getSharedPreferences("sideplay-ytdlp", 0).getLong(force ? "lastFailureUpdate" : "lastUpdate", 0L);
            long minimumAge = force ? 15L * 60L * 1000L : 24L * 60L * 60L * 1000L;
            if (now - last < minimumAge) return;
            Class<?> channelClass = Class.forName("com.yausername.youtubedl_android.YoutubeDL$UpdateChannel");
            @SuppressWarnings({"rawtypes", "unchecked"})
            Object nightly = Enum.valueOf((Class<? extends Enum>) channelClass.asSubclass(Enum.class), "NIGHTLY");
            Method target = null;
            for (Method m : YoutubeDL.class.getMethods()) {
                if (m.getName().equals("updateYoutubeDL") && m.getParameterCount() == 2) { target = m; break; }
            }
            if (target == null) return;
            target.invoke(YoutubeDL.getInstance(), context, nightly);
            context.getSharedPreferences("sideplay-ytdlp", 0).edit()
                .putLong(force ? "lastFailureUpdate" : "lastUpdate", now)
                .apply();
        } catch (Throwable ignored) {
            // Keep the bundled extractor usable when offline or when update servers fail.
        }
    }

    private static void ensureFfmpegInitialized(Context context) throws Exception {
        if (ffmpegInitialized) return;
        synchronized (FFMPEG_INIT_LOCK) {
            if (ffmpegInitialized) return;
            FFmpeg.getInstance().init(context.getApplicationContext());
            ffmpegInitialized = true;
        }
    }

    public static JSObject resolveForPlayback(Context context, String source) throws Exception {
        return resolveForPlayback(context, source, false);
    }

    public static JSObject resolveForPlayback(Context context, String source, boolean audioOnly) throws Exception {
        requireIsolatedExtractorProcess(context);
        synchronized (EXTRACTOR_LOCK) {
            ensureInitialized(context);
            try {
                JSObject out = resolveInternal(source, audioOnly);
                out.put("resolverEngine", "yt-dlp");
                out.put("resolvedAt", System.currentTimeMillis());
                return out;
            } catch (Exception first) {
                // yt-dlp changes much faster than the Android wrapper. Because this path is
                // already the LAST fallback, allow one guarded nightly self-update and retry.
                // The shared lock guarantees we never overlap updater/extractor/download work.
                maybeUpdateExtractor(context, true);
                try {
                    JSObject recovered = resolveInternal(source, audioOnly);
                    recovered.put("resolverEngine", "yt-dlp");
                    recovered.put("resolverRecovery", "nightly-update-retry");
                    recovered.put("resolvedAt", System.currentTimeMillis());
                    return recovered;
                } catch (Exception second) {
                    throw new Exception("yt-dlp failed before and after guarded refresh. First: "
                        + safe(first) + " | Retry: " + safe(second), second);
                }
            }
        }
    }

    private static void requireIsolatedExtractorProcess(Context context) throws Exception {
        String processName = "";
        try (FileInputStream in = new FileInputStream("/proc/self/cmdline")) {
            byte[] bytes = new byte[256];
            int n = in.read(bytes);
            if (n > 0) {
                int end = 0;
                while (end < n && bytes[end] != 0) end++;
                processName = new String(bytes, 0, end, java.nio.charset.StandardCharsets.UTF_8).trim();
            }
        } catch (Throwable ignored) {}
        String expectedSuffix = ":extractor";
        if (processName.isBlank() || !processName.endsWith(expectedSuffix)) {
            throw new Exception("Refusing yt-dlp playback extraction outside SidePlay's isolated :extractor process"
                + (processName.isBlank() ? "." : " (current=" + processName + ")."));
        }
    }

    private static JSArray searchInternal(String query, String engine, int limit) throws Exception {
        String prefix;
        String provider;
        String mediaKind;
        switch (engine) {
            case "soundcloud":
                prefix = "scsearch";
                provider = "soundcloud";
                mediaKind = "audio";
                break;
            case "youtube-music":
            case "ytmusic":
                prefix = "ytmsearch";
                provider = "youtube";
                mediaKind = "audio";
                break;
            case "youtube":
            default:
                prefix = "ytsearch";
                provider = "youtube";
                mediaKind = "video";
                break;
        }

        YoutubeDLRequest request = new YoutubeDLRequest(prefix + limit + ":" + query);
        request.addOption("--flat-playlist");
        request.addOption("--dump-single-json");
        request.addOption("--skip-download");
        request.addOption("--no-warnings");
        request.addOption("--ignore-config");
        addModernJsSupport(request);

        Object response = YoutubeDL.getInstance().execute(request);
        String raw = str(response, "getOut");
        if (raw.isBlank()) throw new Exception("Extractor returned no search data.");
        int start = raw.indexOf('{');
        int end = raw.lastIndexOf('}');
        if (start < 0 || end <= start) throw new Exception("Extractor search output was not valid JSON.");
        JSONObject root = new JSONObject(raw.substring(start, end + 1));
        JSONArray entries = root.optJSONArray("entries");
        if (entries == null) throw new Exception("Extractor search returned no entries.");

        JSArray out = new JSArray();
        for (int i = 0; i < entries.length() && out.length() < limit; i++) {
            JSONObject item = entries.optJSONObject(i);
            if (item == null) continue;
            String id = firstNonBlank(item.optString("id", ""), stableId(item.toString()));
            String source = firstNonBlank(
                item.optString("webpage_url", ""),
                item.optString("original_url", ""),
                item.optString("url", "")
            );
            if ("youtube".equals(provider) && !source.startsWith("http://") && !source.startsWith("https://")) {
                source = "https://www.youtube.com/watch?v=" + id;
            }
            if (!(source.startsWith("http://") || source.startsWith("https://"))) continue;

            JSObject track = new JSObject();
            track.put("videoId", "youtube".equals(provider) ? id : provider + "-" + id);
            String title = firstNonBlank(
                item.optString("title", ""),
                item.optString("fulltitle", ""),
                item.optString("track", ""),
                item.optString("alt_title", "")
            );
            if (title.isBlank()) continue;
            track.put("title", title);
            track.put("channel", firstNonBlank(
                item.optString("uploader", ""),
                item.optString("channel", ""),
                item.optString("artist", ""),
                provider
            ));
            String thumb = firstNonBlank(item.optString("thumbnail", ""), bestThumbnail(item));
            if (!thumb.isBlank()) track.put("thumbnail", thumb);
            track.put("provider", provider);
            track.put("sourceUrl", source);
            track.put("mediaKind", mediaKind);
            if ("audio".equals(mediaKind)) track.put("audioPreferred", true);
            double duration = item.optDouble("duration", -1d);
            if (duration > 0) track.put("durationMs", Math.round(duration * 1000d));
            out.put(track);
        }
        if (out.length() == 0) throw new Exception("No playable search results were returned.");
        return out;
    }

    private static String bestThumbnail(JSONObject item) {
        JSONArray thumbs = item.optJSONArray("thumbnails");
        if (thumbs == null) return "";
        for (int i = thumbs.length() - 1; i >= 0; i--) {
            JSONObject t = thumbs.optJSONObject(i);
            if (t == null) continue;
            String url = t.optString("url", "");
            if (!url.isBlank()) return url;
        }
        return "";
    }

    private static void addModernJsSupport(YoutubeDLRequest request) {
        // yt-dlp's current YouTube extractor uses external JS challenge solving.
        // youtubedl-android 0.18.1 bundles QuickJS; remote EJS components are
        // fetched only when yt-dlp needs them. Failure still falls through to
        // SidePlay's other extractor/capture layers.
        request.addOption("--js-runtimes", "quickjs");
        request.addOption("--remote-components", "ejs:github");
    }

    private static JSObject resolveInternal(String source, boolean audioOnly) throws Exception {
        YoutubeDLRequest request = baseRequest(source);
        // Music-first playback should never accept a lower-quality muxed A/V stream
        // merely because it is convenient. When the caller marks the item as audio,
        // ask yt-dlp for the best clear audio representation directly. Video items
        // still prefer one self-contained A/V URL so Media3 can render them normally.
        request.addOption("-f", audioOnly
            ? "bestaudio[acodec!=none]/best[acodec!=none]"
            : "best[acodec!=none][vcodec!=none]/bestaudio[acodec!=none]/best");
        Object info = YoutubeDL.getInstance().getInfo(request);
        String playback = str(info, "getUrl");
        String mime = inferMime(playback);
        String kind = inferKind(playback, mime, info);

        // Some providers/YouTube clients expose the complete adaptive presentation as
        // a manifest even when yt-dlp's selected direct URL is audio-only. Media3 can
        // consume DASH/HLS itself, so prefer that manifest for a requested video.
        if (!audioOnly && (playback.isBlank() || !"video".equals(kind))) {
            String manifest = firstNonBlank(
                str(info, "getManifestUrl", "getManifest_url"),
                str(info, "getHlsManifestUrl", "getHls_manifest_url")
            );
            if (manifest.startsWith("https://") || manifest.startsWith("http://")) {
                playback = manifest;
                mime = inferMime(playback);
                kind = "video";
            }
        }
        if (playback.isBlank()) throw new Exception("Extractor returned metadata but no clear playable URL/manifest.");

        String title = firstNonBlank(str(info, "getTitle"), filenameFrom(playback), "Media");
        String artist = firstNonBlank(str(info, "getUploader"), str(info, "getChannel"), str(info, "getArtist"), host(source));
        String thumb = firstNonBlank(str(info, "getThumbnail"), str(info, "getThumbnailUrl"));
        long durationMs = durationMs(info);
        String provider = providerFor(source);

        JSObject out = new JSObject();
        out.put("id", firstNonBlank(str(info, "getId"), stableId(source)));
        out.put("title", title);
        out.put("artist", artist);
        if (!thumb.isBlank()) out.put("thumbnail", thumb);
        out.put("provider", provider);
        out.put("sourceUrl", source);
        out.put("playbackUrl", playback);
        if (!mime.isBlank()) out.put("mimeType", mime);
        out.put("mediaKind", audioOnly ? "audio" : kind);
        out.put("audioPreferred", audioOnly);
        if (durationMs > 0) out.put("durationMs", durationMs);
        JSObject headers = headers(info);
        if (headers.length() > 0) out.put("requestHeaders", headers);
        out.put("playable", true);
        out.put("downloadable", true);
        out.put("downloadEngine", "ytdlp");
        out.put("refreshMode", "extractor");
        out.put("sessionBound", true);
        out.put("resolverDelivery", mime.contains("mpegURL") ? "hls-manifest" : mime.contains("dash") ? "dash-manifest" : "direct-url");
        out.put("note", "Resolved with SidePlay provider extractor. Clear media only; protected DRM streams are not bypassed.");
        return out;
    }

    private File downloadInternal(String source, String videoId, File work, boolean audioOnly, String youtubeClient) throws Exception {
        YoutubeDLRequest request = baseRequest(source);
        applyYouTubeClient(request, source, youtubeClient);
        request.addOption("--no-mtime");
        request.addOption("--restrict-filenames");
        request.addOption("--max-filesize", "4096M");
        request.addOption("-o", new File(work, "%(title).120B-%(id)s.%(ext)s").getAbsolutePath());
        boolean safariHls = "web_safari".equals(youtubeClient) && isYouTubeSource(source);
        if (audioOnly) {
            // Preserve the provider's best original audio representation. Avoid
            // lossy transcoding to M4A: remuxing/transcoding cannot invent quality.
            // On web_safari, prefer HLS first: yt-dlp currently documents Safari HLS
            // as a YouTube path which does not require a GVS PO token.
            request.addOption("-f", safariHls
                ? "bestaudio[protocol^=m3u8]/bestaudio/best[protocol^=m3u8]/best"
                : "bestaudio[acodec!=none]/best[acodec!=none]");
        } else {
            request.addOption("-f", safariHls
                ? "best[protocol^=m3u8]/bestvideo[protocol^=m3u8]+bestaudio[protocol^=m3u8]/best"
                : "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best");
            request.addOption("--merge-output-format", "mp4");
        }

        String processId = "sideplay-" + videoId + "-" + System.nanoTime();
        Function3<Float, Long, String, Unit> callback = new Function3<Float, Long, String, Unit>() {
            @Override public Unit invoke(Float progress, Long eta, String line) {
                emitProgress(videoId, progress == null ? -1f : progress, line == null ? "" : line);
                return Unit.INSTANCE;
            }
        };
        try {
            YoutubeDL.getInstance().execute(request, processId, callback);
        } catch (Throwable first) {
            if (audioOnly) throw first;
            // Some providers expose codecs that cannot be cleanly remuxed to MP4.
            // Retry once with Matroska, which is deliberately supported by SidePlay.
            deleteChildren(work);
            YoutubeDLRequest fallback = baseRequest(source);
            applyYouTubeClient(fallback, source, youtubeClient);
            fallback.addOption("--no-mtime");
            fallback.addOption("--restrict-filenames");
            fallback.addOption("--max-filesize", "4096M");
            fallback.addOption("-o", new File(work, "%(title).120B-%(id)s.%(ext)s").getAbsolutePath());
            fallback.addOption("-f", safariHls
                ? "best[protocol^=m3u8]/bestvideo[protocol^=m3u8]+bestaudio[protocol^=m3u8]/best"
                : "bestvideo+bestaudio/best");
            fallback.addOption("--merge-output-format", "mkv");
            YoutubeDL.getInstance().execute(fallback, processId + "-mkv", callback);
        }

        File chosen = null;
        File[] files = work.listFiles();
        if (files != null) {
            for (File f : files) {
                if (!f.isFile()) continue;
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (n.endsWith(".part") || n.endsWith(".ytdl") || n.endsWith(".json") || n.endsWith(".temp")) continue;
                if (chosen == null || f.length() > chosen.length()) chosen = f;
            }
        }
        if (chosen == null || !chosen.exists() || chosen.length() <= 0) throw new Exception("Extractor completed without a media file.");
        if (chosen.length() > MediaSafety.MAX_OFFLINE_BYTES) throw new Exception("Media exceeds SidePlay's 4 GiB offline safety limit.");
        return chosen;
    }

    private static void applyYouTubeClient(YoutubeDLRequest request, String source, String client) {
        if (request == null || client == null || client.isBlank() || !isYouTubeSource(source)) return;
        request.addOption("--extractor-args", "youtube:player_client=" + client);
    }

    private static boolean isYouTubeSource(String source) {
        if (source == null || source.isBlank()) return false;
        try {
            URI uri = URI.create(source.trim());
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            return host.equals("youtu.be") || host.endsWith(".youtu.be") || host.equals("youtube.com") || host.endsWith(".youtube.com");
        } catch (Exception ignored) {
            String lower = source.toLowerCase(Locale.ROOT);
            return lower.contains("youtube.com/") || lower.contains("youtu.be/");
        }
    }

    private static boolean looksLikeHttp403(Throwable error) {
        Throwable cursor = error;
        for (int depth = 0; cursor != null && depth < 8; depth++, cursor = cursor.getCause()) {
            String message = cursor.getMessage();
            if (message != null) {
                String lower = message.toLowerCase(Locale.ROOT);
                if (lower.contains("http error 403") || lower.contains("http 403") || lower.contains("403 forbidden") || lower.contains("status code: 403")) return true;
            }
        }
        return false;
    }

    private static YoutubeDLRequest baseRequest(String source) {
        YoutubeDLRequest request = new YoutubeDLRequest(source);
        request.addOption("--no-playlist");
        request.addOption("--ignore-config");
        addModernJsSupport(request);
        request.addOption("--no-warnings");
        request.addOption("--force-ipv4");
        request.addOption("--socket-timeout", "12");
        request.addOption("--retries", "2");
        request.addOption("--fragment-retries", "2");
        request.addOption("--extractor-retries", "2");
        // Keep memory predictable on Android; parallel fragment bursts were a source
        // of instability on aggressive OEM memory managers.
        request.addOption("--concurrent-fragments", "1");
        return request;
    }

    private JSObject admitDownloadedFile(File input, String videoId, String title, String source) throws Exception {
        String filename = sanitizeFilename(input.getName());
        String mime = mimeForName(filename);
        MediaSafety.validateMetadata(source, filename, mime, filename);
        try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(input))) {
            byte[] prefix = new byte[8192];
            int n = in.read(prefix);
            MediaSafety.validatePrefix(prefix, n, mime, filename);
        }

        File vault = new File(getContext().getFilesDir(), "offline");
        if (!vault.exists() && !vault.mkdirs()) throw new Exception("Could not create SidePlay offline storage.");
        if (vault.getUsableSpace() < input.length() + MediaSafety.STORAGE_RESERVE_BYTES) throw new Exception("Not enough free storage to save this media safely.");

        String ext = extensionWithDot(filename);
        File dest = new File(vault, sanitizeFilename(videoId) + "-" + System.currentTimeMillis() + ext);
        copyFile(input, dest);
        try {
            try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(dest))) {
                byte[] prefix = new byte[8192];
                int n = in.read(prefix);
                MediaSafety.validatePrefix(prefix, n, mime, filename);
            }
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            dest.delete();
            throw e;
        }

        JSObject out = new JSObject();
        out.put("localUri", Uri.fromFile(dest).toString());
        out.put("filename", filename.isBlank() ? sanitizeFilename(title) + ext : filename);
        out.put("mimeType", mime);
        out.put("bytes", dest.length());
        out.put("provider", providerFor(source));
        out.put("sourceUrl", source);
        out.put("mediaKind", mime.startsWith("video/") ? "video" : "audio");
        return out;
    }

    private void emitProgress(String videoId, float progress, String line) {
        JSObject event = new JSObject();
        event.put("videoId", videoId);
        event.put("progress", progress >= 0 ? Math.min(1d, progress / 100d) : -1d);
        event.put("line", line);
        notifyListeners("downloadProgress", event, true);
    }

    private static JSObject headers(Object info) {
        JSObject out = new JSObject();
        Object value = invoke(info, "getHttpHeaders", "getHttp_headers");
        if (value instanceof Map<?, ?>) {
            for (Map.Entry<?, ?> e : ((Map<?, ?>) value).entrySet()) {
                if (e.getKey() != null && e.getValue() != null) out.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
            }
        }
        return out;
    }

    private static long durationMs(Object info) {
        Object value = invoke(info, "getDuration");
        if (value instanceof Number) return Math.max(0L, Math.round(((Number) value).doubleValue() * 1000d));
        try { return Math.max(0L, Math.round(Double.parseDouble(String.valueOf(value)) * 1000d)); } catch (Exception ignored) { return 0L; }
    }

    private static String inferKind(String url, String mime, Object info) {
        String vcodec = str(info, "getVcodec", "getVideoCodec");
        if (!vcodec.isBlank() && !"none".equalsIgnoreCase(vcodec)) return "video";
        String lower = url.toLowerCase(Locale.ROOT);
        if (mime.startsWith("video/") || lower.contains(".mp4") || lower.contains(".webm") || lower.contains(".m3u8") || lower.contains(".mpd")) return "video";
        return "audio";
    }

    private static String inferMime(String url) {
        String lower = url.toLowerCase(Locale.ROOT);
        if (lower.contains(".m3u8")) return "application/x-mpegURL";
        if (lower.contains(".mpd")) return "application/dash+xml";
        return mimeForName(url);
    }

    private static String mimeForName(String name) {
        String clean = name == null ? "" : name.split("[?#]", 2)[0];
        String ext = extension(clean);
        String mime = ext.isBlank() ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.ROOT));
        if (mime != null) return mime;
        switch (ext.toLowerCase(Locale.ROOT)) {
            case "m4a": return "audio/mp4";
            case "opus": return "audio/ogg";
            case "mkv": return "video/x-matroska";
            case "webm": return "video/webm";
            case "ts": case "m2ts": case "mts": return "video/mp2t";
            default: return "application/octet-stream";
        }
    }

    private static String providerFor(String raw) {
        String h = host(raw).toLowerCase(Locale.ROOT);
        if (h.contains("youtube.com") || h.equals("youtu.be") || h.endsWith(".youtu.be")) return "youtube";
        if (h.contains("soundcloud.com")) return "soundcloud";
        if (h.contains("spotify.com")) return "spotify";
        if (h.contains("tiktok.com")) return "unknown";
        return "unknown";
    }

    private static Object invoke(Object target, String... names) {
        if (target == null) return null;
        for (String name : names) {
            try {
                Method m = target.getClass().getMethod(name);
                return m.invoke(target);
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private static String str(Object target, String... names) {
        Object value = invoke(target, names);
        return value == null ? "" : String.valueOf(value).trim();
    }

    private static String firstNonBlank(String... values) {
        for (String v : values) if (v != null && !v.isBlank() && !"null".equalsIgnoreCase(v)) return v;
        return "";
    }

    private static String host(String raw) {
        try { String h = URI.create(raw).getHost(); return h == null ? "" : h; } catch (Exception ignored) { return ""; }
    }

    private static String filenameFrom(String raw) {
        try {
            String p = URI.create(raw).getPath();
            if (p == null || p.isBlank()) return "";
            String n = p.substring(p.lastIndexOf('/') + 1);
            return n.isBlank() ? "" : n;
        } catch (Exception ignored) { return ""; }
    }

    private static String extension(String name) {
        if (name == null) return "";
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        int dot = name.lastIndexOf('.');
        return dot > slash && dot < name.length() - 1 ? name.substring(dot + 1) : "";
    }

    private static String extensionWithDot(String name) {
        String e = extension(name);
        return e.isBlank() ? "" : "." + e;
    }

    private static String sanitizeFilename(String raw) {
        String s = raw == null ? "media" : raw.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (s.isBlank()) s = "media";
        if (s.length() > 160) s = s.substring(0, 160);
        return s;
    }

    private static void copyFile(File from, File to) throws Exception {
        try (FileInputStream in = new FileInputStream(from); FileOutputStream out = new FileOutputStream(to)) {
            byte[] buffer = new byte[256 * 1024];
            int n;
            long total = 0;
            while ((n = in.read(buffer)) != -1) {
                total += n;
                if (total > MediaSafety.MAX_OFFLINE_BYTES) throw new Exception("Media exceeds SidePlay's 4 GiB offline safety limit.");
                out.write(buffer, 0, n);
            }
            out.flush();
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            to.delete();
            throw e;
        }
    }

    private static void deleteChildren(File dir) {
        if (dir == null || !dir.isDirectory()) return;
        File[] children = dir.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteTree(c);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private static String stableId(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder("ydl-");
            for (int i = 0; i < 8 && i < hash.length; i++) sb.append(String.format(Locale.ROOT, "%02x", hash[i]));
            return sb.toString();
        } catch (Exception e) { return "ydl-" + Integer.toUnsignedString(value.hashCode(), 36); }
    }

    private static String safe(Throwable e) {
        String m = e == null ? "unknown error" : e.getMessage();
        if (m == null || m.isBlank()) m = e == null ? "unknown error" : e.getClass().getSimpleName();
        m = m.replaceAll("(?i)(cookie|authorization|token|password)=?[^\\s,;]+", "$1=[redacted]");
        return m.length() > 700 ? m.substring(0, 700) : m;
    }
}
