# StickerForge Android

This is the native Android wrapper for the included StickerForge editor.

## What is actually native now
- `Add current sticker to pack` saves a verified 512×512 WebP into app-private storage.
- A `ContentProvider` exposes `/metadata`, `/metadata/<pack>`, `/stickers/<pack>`, and `/stickers_asset/<pack>/<file>` to WhatsApp.
- `Add pack to WhatsApp` fires `com.whatsapp.intent.action.ENABLE_STICKER_PACK` with the pack id, provider authority, and pack name.
- Pack size is enforced at 3–30 stickers for installation; individual stickers are verified as WebP, exactly 512×512, and ≤100 KB.
- The first sticker is converted to a 96×96 PNG tray icon.

## Build
Open this folder in Android Studio and let Gradle sync. Build/install the `app` module on your Android phone. Opening `index.html` by itself in a browser will NOT show the native pack buttons because the JavaScript bridge only exists inside the Android app.

The implementation follows WhatsApp's official Android sticker-pack ContentProvider/ENABLE_STICKER_PACK contract.
