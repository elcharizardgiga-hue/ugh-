package com.stickerforge.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 501;
    private WebView web;
    private ValueCallback<Uri[]> pendingFiles;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = callback;
                Intent intent = params.createIntent();
                intent.setType("image/*");
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (ActivityNotFoundException e) {
                    pendingFiles = null;
                    Toast.makeText(MainActivity.this, "No image picker is available.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        web.addJavascriptInterface(new Bridge(), "StickerForgeAndroid");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && pendingFiles != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            pendingFiles.onReceiveValue(result);
            pendingFiles = null;
        }
    }

    public class Bridge {
        @JavascriptInterface public int getPackCount() { return StickerStore.count(MainActivity.this); }

        @JavascriptInterface public String saveSticker(String dataUrl) {
            try { return StickerStore.saveDataUrl(MainActivity.this, dataUrl); }
            catch (Exception e) { return "Could not add sticker: " + e.getMessage(); }
        }

        @JavascriptInterface public String addPackToWhatsApp() {
            int count = StickerStore.count(MainActivity.this);
            if (count < 3) return "WhatsApp requires at least 3 stickers. You have " + count + ".";
            runOnUiThread(MainActivity.this::launchWhatsApp);
            return "Opening WhatsApp…";
        }
    }

    private void launchWhatsApp() {
        Intent i = new Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK");
        i.putExtra("sticker_pack_id", StickerStore.PACK_ID);
        i.putExtra("sticker_pack_authority", BuildConfig.CONTENT_PROVIDER_AUTHORITY);
        i.putExtra("sticker_pack_name", StickerStore.PACK_NAME);
        try { startActivityForResult(i, 200); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "WhatsApp is not installed or does not support sticker packs.", Toast.LENGTH_LONG).show(); }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
