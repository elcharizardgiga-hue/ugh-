package com.stickerforge.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

public class StickerContentProvider extends ContentProvider {
    private static final String METADATA = "metadata";
    private static final String STICKERS = "stickers";
    private static final String STICKERS_ASSET = "stickers_asset";
    private static final int ALL_META=1, ONE_META=2, LIST=3, ASSET=4;
    private UriMatcher matcher;

    @Override public boolean onCreate() {
        matcher = new UriMatcher(UriMatcher.NO_MATCH);
        String a = BuildConfig.CONTENT_PROVIDER_AUTHORITY;
        matcher.addURI(a, METADATA, ALL_META);
        matcher.addURI(a, METADATA + "/*", ONE_META);
        matcher.addURI(a, STICKERS + "/*", LIST);
        matcher.addURI(a, STICKERS_ASSET + "/*/*", ASSET);
        return true;
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        int m = matcher.match(uri);
        if (m == ALL_META || m == ONE_META) {
            MatrixCursor c = new MatrixCursor(new String[]{
                "sticker_pack_identifier","sticker_pack_name","sticker_pack_publisher","sticker_pack_icon",
                "android_play_store_link","ios_app_download_link","sticker_pack_publisher_email",
                "sticker_pack_publisher_website","sticker_pack_privacy_policy_website","sticker_pack_license_agreement_website",
                "image_data_version","whatsapp_will_not_cache_stickers","animated_sticker_pack"
            });
            if (m == ALL_META || StickerStore.PACK_ID.equals(uri.getLastPathSegment())) {
                c.addRow(new Object[]{StickerStore.PACK_ID, StickerStore.PACK_NAME, StickerStore.PUBLISHER, StickerStore.TRAY_ICON,
                    "", "", "", "", "", "", String.valueOf(StickerStore.version(getContext())), 0, 0});
            }
            c.setNotificationUri(getContext().getContentResolver(), uri);
            return c;
        }
        if (m == LIST) {
            MatrixCursor c = new MatrixCursor(new String[]{"sticker_file_name","sticker_emoji","sticker_accessibility_text"});
            if (StickerStore.PACK_ID.equals(uri.getLastPathSegment())) {
                for (File f : StickerStore.stickerFiles(getContext())) c.addRow(new Object[]{f.getName(), "😀", "User-created sticker"});
            }
            c.setNotificationUri(getContext().getContentResolver(), uri);
            return c;
        }
        throw new IllegalArgumentException("Unknown URI: " + uri);
    }

    @Override public AssetFileDescriptor openAssetFile(Uri uri, String mode) throws FileNotFoundException {
        if (matcher.match(uri) != ASSET) throw new FileNotFoundException("Unknown URI " + uri);
        List<String> p = uri.getPathSegments();
        if (p.size() != 3 || !StickerStore.PACK_ID.equals(p.get(1))) throw new FileNotFoundException("Bad sticker path");
        String name = p.get(2);
        if (TextUtils.isEmpty(name) || name.contains("/") || name.contains("..")) throw new FileNotFoundException("Bad file name");
        File file = new File(StickerStore.packDir(getContext()), name);
        boolean allowed = name.equals(StickerStore.TRAY_ICON);
        if (!allowed) for (File f : StickerStore.stickerFiles(getContext())) if (f.getName().equals(name)) { allowed = true; break; }
        if (!allowed || !file.exists()) throw new FileNotFoundException(name);
        ParcelFileDescriptor pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        return new AssetFileDescriptor(pfd, 0, AssetFileDescriptor.UNKNOWN_LENGTH);
    }

    @Override public String getType(Uri uri) {
        int m = matcher.match(uri);
        if (m == ALL_META) return "vnd.android.cursor.dir/vnd." + BuildConfig.CONTENT_PROVIDER_AUTHORITY + ".metadata";
        if (m == ONE_META) return "vnd.android.cursor.item/vnd." + BuildConfig.CONTENT_PROVIDER_AUTHORITY + ".metadata";
        if (m == LIST) return "vnd.android.cursor.dir/vnd." + BuildConfig.CONTENT_PROVIDER_AUTHORITY + ".stickers";
        if (m == ASSET) return uri.getLastPathSegment().endsWith(".png") ? "image/png" : "image/webp";
        throw new IllegalArgumentException("Unknown URI: " + uri);
    }

    @Override public int delete(Uri uri,String s,String[] a){throw new UnsupportedOperationException();}
    @Override public Uri insert(Uri uri,ContentValues v){throw new UnsupportedOperationException();}
    @Override public int update(Uri uri,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
