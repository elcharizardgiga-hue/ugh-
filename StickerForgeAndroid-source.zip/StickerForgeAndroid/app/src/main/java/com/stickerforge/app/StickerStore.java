package com.stickerforge.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public final class StickerStore {
    public static final String PACK_ID = "stickerforge_pack_1";
    public static final String PACK_NAME = "My StickerForge Pack";
    public static final String PUBLISHER = "StickerForge";
    public static final String TRAY_ICON = "tray.png";
    private static final int MAX_STICKERS = 30;

    private StickerStore() {}

    public static File packDir(Context c) {
        File d = new File(c.getFilesDir(), "stickers/" + PACK_ID);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static List<File> stickerFiles(Context c) {
        File[] files = packDir(c).listFiles((dir, name) -> name.endsWith(".webp"));
        List<File> out = new ArrayList<>();
        if (files != null) {
            Arrays.sort(files, Comparator.comparing(File::getName));
            out.addAll(Arrays.asList(files));
        }
        return out;
    }

    public static int count(Context c) { return stickerFiles(c).size(); }

    public static String saveDataUrl(Context c, String dataUrl) throws IOException {
        if (count(c) >= MAX_STICKERS) return "Pack already has 30 stickers";
        int comma = dataUrl.indexOf(',');
        if (comma < 0) throw new IOException("Invalid data URL");
        byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
        validateSticker(bytes);
        String name = String.format("sticker_%02d.webp", count(c) + 1);
        File out = new File(packDir(c), name);
        try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(bytes); }
        ensureTrayIcon(c, bytes);
        SharedPreferences p = c.getSharedPreferences("pack", Context.MODE_PRIVATE);
        p.edit().putInt("version", p.getInt("version", 0) + 1).apply();
        c.getContentResolver().notifyChange(android.net.Uri.parse("content://" + BuildConfig.CONTENT_PROVIDER_AUTHORITY + "/metadata"), null);
        return "Added to pack • " + count(c) + "/30";
    }

    private static void validateSticker(byte[] b) throws IOException {
        if (b.length > 100 * 1024) throw new IOException("Sticker is over 100 KB");
        if (b.length < 12 || b[0] != 'R' || b[1] != 'I' || b[2] != 'F' || b[3] != 'F' || b[8] != 'W' || b[9] != 'E' || b[10] != 'B' || b[11] != 'P')
            throw new IOException("Not a real WebP file");
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(b, 0, b.length, o);
        if (o.outWidth != 512 || o.outHeight != 512) throw new IOException("Sticker must be exactly 512×512");
    }

    private static void ensureTrayIcon(Context c, byte[] sticker) throws IOException {
        File tray = new File(packDir(c), TRAY_ICON);
        if (tray.exists()) return;
        Bitmap src = BitmapFactory.decodeByteArray(sticker, 0, sticker.length);
        if (src == null) throw new IOException("Could not decode sticker");
        Bitmap icon = Bitmap.createScaledBitmap(src, 96, 96, true);
        try (FileOutputStream fos = new FileOutputStream(tray)) { icon.compress(Bitmap.CompressFormat.PNG, 100, fos); }
        src.recycle(); icon.recycle();
        if (tray.length() > 50 * 1024) throw new IOException("Tray icon exceeds 50 KB");
    }

    public static int version(Context c) {
        return c.getSharedPreferences("pack", Context.MODE_PRIVATE).getInt("version", 1);
    }
}
