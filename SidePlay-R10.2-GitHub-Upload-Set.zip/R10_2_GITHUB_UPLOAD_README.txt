SIDEPLAY 0.9.2-r10.2 — SMART PLAYLISTS + OFFLINE RUNWAY

Upload:
1. SidePlay-Node-v0.9.2-R10.2-SMART-PLAYLISTS-OFFLINE.zip
   -> repository root

2. SIDEPLAY_R10_2_BUILD.yml
   -> .github/workflows/SIDEPLAY_R10_2_BUILD.yml

Run the workflow:
SidePlay 0.9.2 R10.2 Smart Playlists Offline ARM64

Expected proof line:
SIDEPLAY 0.9.2 R10.2 SMART PLAYLISTS + OFFLINE WORKFLOW V1 - PREINSTALLED SDK

Android:
versionCode 820
versionName 0.9.2-r10.2
ABI arm64-v8a

R10.2 adds:
- automatic persistent Discovery Mix
- Library Made for You smart playlists
- dedicated high-discovery profile for Discovery Mix
- Smart Cache catalog showing the real rolling-cache files
- direct offline playback from Smart Cache
- cached-offline labels in Queue
- next-20 sequential heavy fallback through the isolated extractor when lightweight resolution cannot produce cacheable bytes

Smart Cache remains separate from permanent Downloads and can be evicted automatically.

For in-place upgrades, keep using the same signing certificate/secrets as prior installed APKs.
