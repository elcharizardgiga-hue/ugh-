# SidePlay v0.3.4 — Strong Spotify Handoff

- Replaces the single-route Spotify handoff with a four-route verified handoff pipeline.
- Tries MediaSession structured song search, quoted query search, targeted Android MEDIA_PLAY_FROM_SEARCH song intent, then targeted unstructured search intent.
- Verifies Spotify title/artist metadata after every route before SidePlay reports `SPOTIFY · BACKGROUND`.
- Never treats “Spotify is playing something” as success.
- Keeps PiP removed and keeps silent YouTube fallback disabled when Spotify mode is selected.
- Resumes playback only after the requested track has been verified.
