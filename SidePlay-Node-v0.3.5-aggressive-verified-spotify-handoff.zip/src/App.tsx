import { useEffect, useMemo, useRef, useState } from 'react'
import {
  ArrowDown, ArrowUp, BatteryCharging, CheckCircle2, ChevronDown, Clock3, Compass, Download, FolderOpen,
  Heart, History, Home, ListMusic, Menu, Moon, MoreHorizontal, Music2, Pause,
  Play, Plus, Radio, RefreshCw, Repeat2, Search, Settings, Shuffle, SkipBack,
  SkipForward, Sparkles, Trash2, UploadCloud, FileArchive, WifiOff, X
} from 'lucide-react'
import type { OfflineCopy, Playlist, Track } from './types'
import { useSidePlay } from './lib/store'
import { extractVideoId, getTrackById, searchYouTube } from './lib/youtube'
import { BackgroundAudio, SharedText, WebPlayback, SpotifySession, isNative } from './lib/nativeAudio'
import { YouTubePlayer } from './components/YouTubePlayer'
import { discoverRecommendations, localMixes, type Mix } from './lib/recommendations'
import { formatBytes, importOfflineCopy, removeOfflineCopy } from './lib/offlineMedia'
import { startDirectDownload } from './lib/directDownload'
import { parseYouTubeExportFile } from './lib/youtubeTakeout'

type Tab = 'home' | 'search' | 'library' | 'downloads' | 'queue' | 'settings'

export default function App() {
  const sp = useSidePlay()
  const [tab, setTab] = useState<Tab>('home')
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Track[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [expanded, setExpanded] = useState(false)
  const [playlistTarget, setPlaylistTarget] = useState<Track | null>(null)
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null)
  const [sleepUntil, setSleepUntil] = useState<number | null>(null)
  const [sleepAfterCurrent, setSleepAfterCurrent] = useState(false)
  const [paused, setPaused] = useState(false)
  const [recommendations, setRecommendations] = useState<Track[]>([])
  const [recsBusy, setRecsBusy] = useState(false)
  const [offlineBusy, setOfflineBusy] = useState<string | null>(null)
  const [positionMs, setPositionMs] = useState(0)
  const [durationMs, setDurationMs] = useState(0)
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('sideplay.recentSearches') || '[]').slice(0, 8) }
    catch { return [] }
  })
  const [spotifyEngineEnabled, setSpotifyEngineEnabled] = useState(() => localStorage.getItem('sideplay.spotifyEngine') === '1')
  const [playbackEngine, setPlaybackEngine] = useState<'youtube' | 'spotify' | 'spotify-error'>('youtube')
  const playerRef = useRef<any | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const endedRef = useRef<() => void>(() => {})
  const scrubbingRef = useRef(false)
  const nativeStartPositionRef = useRef(0)
  const wantsPlaybackRef = useRef(false)
  const useOfflineRef = useRef(false)
  const currentRef = useRef<Track | null>(null)

  const current = sp.current
  const currentOffline = current ? sp.getOfflineCopy(current.videoId) : null
  const usableOffline = currentOffline && currentOffline.platform === (isNative() ? 'android' : 'pc') ? currentOffline : null
  // Android: if a persistent local copy exists, use Media3 from the user's Play action.
  // Starting the mediaPlayback foreground service while SidePlay is still foreground is
  // materially more reliable than trying to start it during the background transition.
  // PC keeps the user preference because browser playback does not need an Android FGS.
  const useOffline = !!usableOffline && (isNative() || sp.state.preferOffline)
  useOfflineRef.current = useOffline
  currentRef.current = current
  const mixes = useMemo(() => localMixes(sp.state), [sp.state.favorites, sp.state.history, sp.state.playlists, sp.state.playCounts, sp.state.offline])

  useEffect(() => {
    if (!isNative()) return
    // PiP is intentionally disabled. WebPlayback remains only as the foreground
    // YouTube fallback when Spotify mode is off.
    WebPlayback.setPipEnabled({ enabled: false }).catch(() => {})
  }, [])

  useEffect(() => {
    localStorage.setItem('sideplay.recentSearches', JSON.stringify(recentSearches.slice(0, 8)))
  }, [recentSearches])

  useEffect(() => {
    localStorage.setItem('sideplay.spotifyEngine', spotifyEngineEnabled ? '1' : '0')
    if (isNative()) WebPlayback.setPipEnabled({ enabled: false }).catch(() => {})
    if (!spotifyEngineEnabled && playbackEngine !== 'youtube') setPlaybackEngine('youtube')
  }, [spotifyEngineEnabled])

  useEffect(() => {
    if (!isNative()) return
    SharedText.getInitialShare().then(async ({ text }) => {
      if (!text) return
      const id = extractVideoId(text)
      if (!id) return
      try {
        const track = await getTrackById(id, sp.state.youtubeApiKey)
        wantsPlaybackRef.current = true
        sp.playNow(track)
        setExpanded(true)
      } catch {}
    }).catch(() => {})
  }, [])

  useEffect(() => {
    refreshRecommendations()
    // Home recommendations are deliberately refreshed only when the app starts.
    // A visible refresh button lets the user request another discovery pass.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (!isNative()) return
    let disposed = false
    let handle: any
    BackgroundAudio.addListener('playbackState', ({ state, positionMs: pos, durationMs: dur, message }) => {
      if (disposed) return
      if (state === 'playing') setPaused(false)
      if (state === 'paused') setPaused(true)
      if (typeof pos === 'number' && !scrubbingRef.current) setPositionMs(Math.max(0, pos))
      if (typeof dur === 'number' && dur > 0) setDurationMs(dur)
      if (state === 'error') { setPaused(true); setError(message || 'Native background playback failed.') }
      if (state === 'ended') endedRef.current()
    }).then((h) => { handle = h }).catch(() => {})
    return () => { disposed = true; handle?.remove?.() }
  }, [])

  useEffect(() => {
    nativeStartPositionRef.current = 0
    setPositionMs(0)
    setDurationMs(0)
  }, [current?.videoId])

  useEffect(() => {
    if (!current) return
    setPaused(false)
    if (useOffline && usableOffline) {
      if (isNative()) WebPlayback.stop().catch(() => {})
      playerRef.current?.pauseVideo?.()
      if (isNative()) {
        const startAt = Math.max(0, nativeStartPositionRef.current || 0)
        nativeStartPositionRef.current = 0
        BackgroundAudio.play({
          url: usableOffline.localUri,
          title: current.title,
          artist: current.channel,
          artwork: current.thumbnail,
          positionMs: startAt,
        }).catch((e) => { setError(e?.message || 'Offline playback failed.'); setPaused(true) })
      } else {
        const audio = audioRef.current
        if (audio) {
          audio.src = usableOffline.localUri
          audio.load()
          audio.play().catch((e) => { setError(e?.message || 'Offline playback failed.'); setPaused(true) })
        }
      }
    } else {
      if (isNative()) { BackgroundAudio.stop().catch(() => {}); WebPlayback.stop().catch(() => {}) }
      const audio = audioRef.current
      if (audio) { audio.pause(); audio.removeAttribute('src'); audio.load() }
    }
  }, [current?.videoId, usableOffline?.localUri, useOffline])

  useEffect(() => {
    if (!current) return
    let cancelled = false
    const readProgress = async () => {
      if (cancelled || scrubbingRef.current) return
      try {
        if (playbackEngine === 'spotify' && isNative() && !useOffline) {
          const status = await SpotifySession.getStatus()
          if (cancelled || scrubbingRef.current) return
          setPositionMs(Math.max(0, status.positionMs || 0))
          if ((status.durationMs || 0) > 0) setDurationMs(status.durationMs || 0)
          if (status.sessionAvailable) setPaused(!status.playing)
        } else if (useOffline) {
          if (isNative()) {
            const status = await BackgroundAudio.getStatus()
            if (cancelled || scrubbingRef.current) return
            setPositionMs(Math.max(0, status.positionMs || 0))
            if ((status.durationMs || 0) > 0) setDurationMs(status.durationMs)
            if (status.active) setPaused(!status.playing)
          } else {
            const audio = audioRef.current
            if (!audio) return
            setPositionMs(Math.max(0, (audio.currentTime || 0) * 1000))
            if (Number.isFinite(audio.duration) && audio.duration > 0) setDurationMs(audio.duration * 1000)
          }
        } else {
          const player = playerRef.current
          const position = Number(player?.getCurrentTime?.() || 0)
          const duration = Number(player?.getDuration?.() || 0)
          setPositionMs(Math.max(0, position * 1000))
          if (duration > 0) setDurationMs(duration * 1000)
        }
      } catch {}
    }
    readProgress()
    const timer = window.setInterval(readProgress, 500)
    return () => { cancelled = true; window.clearInterval(timer) }
  }, [current?.videoId, useOffline, playbackEngine])

  useEffect(() => {
    if (!sleepUntil) return
    const tick = () => {
      if (Date.now() >= sleepUntil) {
        pausePlayback()
        setSleepUntil(null)
      }
    }
    const timer = window.setInterval(tick, 1000)
    return () => window.clearInterval(timer)
  }, [sleepUntil, useOffline])

  async function refreshRecommendations() {
    setRecsBusy(true)
    try { setRecommendations(await discoverRecommendations(sp.state, 24)) }
    catch { setRecommendations([]) }
    finally { setRecsBusy(false) }
  }

  async function runSearch(term?: string) {
    const q = (term ?? query).trim()
    if (!q) return
    if (term !== undefined) setQuery(q)
    setBusy(true); setError('')
    try {
      const id = extractVideoId(q)
      if (id) setResults([await getTrackById(id, sp.state.youtubeApiKey)])
      else {
        setRecentSearches((prev) => [q, ...prev.filter((x) => x.toLowerCase() !== q.toLowerCase())].slice(0, 8))
        setResults(await searchYouTube(q, sp.state.youtubeApiKey))
      }
    } catch (e: any) {
      setError(e?.message ?? 'Search failed.')
    } finally { setBusy(false) }
  }

  function onEnded() {
    if (sleepAfterCurrent) {
      setSleepAfterCurrent(false)
      setPaused(true)
      return
    }
    const next = sp.next()
    if (!next) {
      wantsPlaybackRef.current = false
      if (isNative()) WebPlayback.stop().catch(() => {})
      setPaused(true)
    }
  }
  endedRef.current = onEnded

  async function trySpotifyPlayback(track: Track) {
    if (!isNative() || !spotifyEngineEnabled) return false
    const copy = sp.getOfflineCopy(track.videoId)
    if (copy?.platform === 'android') return false

    const wanted = spotifyIdentityForTrack(track)
    const sleep = (ms: number) => new Promise((resolve) => window.setTimeout(resolve, ms))

    const read = async () => SpotifySession.getStatus()
    const waitForExactTrack = async (timeoutMs: number, requirePlaying = false) => {
      const deadline = Date.now() + timeoutMs
      let status = await read()
      while (Date.now() < deadline) {
        if (spotifyStatusMatches(status, wanted) && (!requirePlaying || status.playing)) return status
        await sleep(220)
        status = await read()
      }
      return status
    }

    const verifyAndStart = async () => {
      let status = await waitForExactTrack(1900, false)
      if (!spotifyStatusMatches(status, wanted)) return status
      if (!status.playing) {
        await SpotifySession.play().catch(() => {})
        status = await waitForExactTrack(1800, true)
      }
      return status
    }

    try {
      setPlaybackEngine('spotify-error')
      setPaused(true)
      setError('')

      const access = await SpotifySession.hasAccess()
      if (!access.granted) throw new Error('Spotify control needs Notification Access.')
      if (!access.spotifyInstalled) throw new Error('Spotify is not installed.')

      let before = await read()
      if (!before.sessionAvailable) throw new Error('No active Spotify media session. Open Spotify and play any song once.')

      // If Spotify is already on the requested track, do not re-search it.
      if (spotifyStatusMatches(before, wanted)) {
        if (!before.playing) await SpotifySession.play().catch(() => {})
        const same = await waitForExactTrack(1600, true)
        if (spotifyStatusMatches(same, wanted) && same.playing) {
          setPlaybackEngine('spotify')
          playerRef.current?.pauseVideo?.()
          WebPlayback.stop().catch(() => {})
          return true
        }
      }

      // Freeze the previous song so a generic PLAY command cannot be mistaken for a handoff.
      if (before.playing) {
        await SpotifySession.pause().catch(() => {})
        await sleep(180)
      }

      const titleOnly = wanted.title
      const combined = `${wanted.title} ${wanted.artist}`.trim()
      const quoted = `"${wanted.title}" ${wanted.artist}`.trim()
      const reversed = `${wanted.artist} ${wanted.title}`.trim()

      const attempts: Array<{ label: string; run: () => Promise<any>; wait?: number }> = [
        {
          label: 'prepare structured title',
          run: () => SpotifySession.prepareFromSearch({ query: titleOnly, title: wanted.title, artist: wanted.artist }),
          wait: 1500,
        },
        {
          label: 'media-session structured title',
          run: () => SpotifySession.playFromSearch({ query: titleOnly, title: wanted.title, artist: wanted.artist }),
        },
        {
          label: 'media-session structured combined',
          run: () => SpotifySession.playFromSearch({ query: combined, title: wanted.title, artist: wanted.artist }),
        },
        {
          label: 'media-session quoted query',
          run: () => SpotifySession.playFromSearch({ query: quoted, title: wanted.title, artist: wanted.artist }),
        },
        {
          label: 'Spotify structured search intent',
          run: () => SpotifySession.playFromSearchIntent({ query: titleOnly, title: wanted.title, artist: wanted.artist, structured: true }),
        },
        {
          label: 'Spotify structured combined intent',
          run: () => SpotifySession.playFromSearchIntent({ query: combined, title: wanted.title, artist: wanted.artist, structured: true }),
        },
        {
          label: 'Spotify unstructured reversed intent',
          run: () => SpotifySession.playFromSearchIntent({ query: reversed, title: wanted.title, artist: wanted.artist, structured: false }),
        },
      ]

      const failures: string[] = []
      let after = before
      for (const attempt of attempts) {
        try {
          await attempt.run()
          after = await waitForExactTrack(attempt.wait || 2200, false)
          if (spotifyStatusMatches(after, wanted)) {
            after = await verifyAndStart()
            if (spotifyStatusMatches(after, wanted) && after.playing) break
          }
          failures.push(`${attempt.label}: stayed on ${[after.title, after.artist].filter(Boolean).join(' — ') || 'old track'}`)
        } catch (err: any) {
          failures.push(`${attempt.label}: ${err?.message || 'rejected'}`)
        }
      }

      // Aggressive final pass: briefly prime Spotify's own search screen, return
      // to SidePlay automatically, then retry the two strongest Android commands.
      if (!(spotifyStatusMatches(after, wanted) && after.playing)) {
        try {
          await SpotifySession.warmSpotifySearch({ query: combined })
          await sleep(1250)
          await SpotifySession.playFromSearch({ query: titleOnly, title: wanted.title, artist: wanted.artist })
          after = await waitForExactTrack(2600, false)
          if (!spotifyStatusMatches(after, wanted)) {
            await SpotifySession.playFromSearchIntent({ query: titleOnly, title: wanted.title, artist: wanted.artist, structured: true })
            after = await waitForExactTrack(2600, false)
          }
          if (spotifyStatusMatches(after, wanted)) after = await verifyAndStart()
        } catch (err: any) {
          failures.push(`Spotify foreground warm-up: ${err?.message || 'failed'}`)
        }
      }

      if (!(spotifyStatusMatches(after, wanted) && after.playing)) {
        const actual = [after.title, after.artist].filter(Boolean).join(' — ') || 'unknown track'
        setPlaybackEngine('spotify-error')
        throw new Error(`Spotify handoff failed for “${wanted.title} — ${wanted.artist}”. Spotify stayed on “${actual}”. SidePlay tried ${attempts.length + 2} verified routes.`)
      }

      setPlaybackEngine('spotify')
      playerRef.current?.pauseVideo?.()
      WebPlayback.stop().catch(() => {})
      setPaused(false)
      setError('')
      return true
    } catch (e: any) {
      setPlaybackEngine('spotify-error')
      setPaused(true)
      setError(e?.message ?? 'Spotify handoff failed.')
      return false
    }
  }

  async function play(track: Track, queue?: Track[]) {
    wantsPlaybackRef.current = true
    const copy = sp.getOfflineCopy(track.videoId)
    const localAndroid = isNative() && copy?.platform === 'android'
    if (localAndroid) {
      if (playbackEngine === 'spotify') SpotifySession.pause().catch(() => {})
      setPlaybackEngine('youtube')
      sp.playNow(track, queue)
      setPaused(false)
      return
    }

    const spotify = await trySpotifyPlayback(track)
    if (!spotify && spotifyEngineEnabled && isNative()) {
      // Never silently fall back to YouTube/PiP when the user explicitly chose
      // Spotify background playback. Keep the track selected and surface the
      // actual handoff error instead.
      setPlaybackEngine('spotify-error')
      sp.playNow(track, queue)
      setPaused(true)
      playerRef.current?.pauseVideo?.()
      WebPlayback.stop().catch(() => {})
      return
    }
    if (!spotify) setPlaybackEngine('youtube')
    sp.playNow(track, queue)
    setPaused(false)
  }

  function previous() {
    wantsPlaybackRef.current = true
    const target = sp.previous()
    if (spotifyEngineEnabled && isNative() && !useOffline && target) {
      void trySpotifyPlayback(target)
      return
    }
    if (playbackEngine === 'spotify' && isNative() && !useOffline) SpotifySession.previous().catch(() => {})
    setPaused(false)
  }

  function next() {
    wantsPlaybackRef.current = true
    const target = sp.next()
    if (spotifyEngineEnabled && isNative() && !useOffline && target) {
      void trySpotifyPlayback(target)
      return
    }
    if (playbackEngine === 'spotify' && isNative() && !useOffline) SpotifySession.next().catch(() => {})
    setPaused(false)
  }

  function pausePlayback() {
    wantsPlaybackRef.current = false
    if (playbackEngine === 'spotify' && isNative() && !useOffline) {
      SpotifySession.pause().catch(() => {})
    } else if (useOffline) {
      if (isNative()) BackgroundAudio.pause().catch(() => {})
      else audioRef.current?.pause()
    } else { playerRef.current?.pauseVideo?.(); if (isNative()) WebPlayback.stop().catch(() => {}) }
    setPaused(true)
  }

  function resumePlayback() {
    wantsPlaybackRef.current = true
    if (playbackEngine === 'spotify-error' && isNative() && !useOffline && current) {
      void trySpotifyPlayback(current)
      return
    }
    if (playbackEngine === 'spotify' && isNative() && !useOffline) {
      SpotifySession.play().catch(() => {})
    } else if (useOffline) {
      if (isNative()) BackgroundAudio.resume().catch(() => {})
      else audioRef.current?.play().catch(() => {})
    } else playerRef.current?.playVideo?.()
    setPaused(false)
  }

  async function seekPlayback(nextMs: number) {
    const target = Math.max(0, durationMs > 0 ? Math.min(nextMs, durationMs) : nextMs)
    setPositionMs(target)
    try {
      if (playbackEngine === 'spotify' && isNative() && !useOffline) {
        await SpotifySession.seek({ positionMs: target })
      } else if (useOffline) {
        if (isNative()) await BackgroundAudio.seek({ positionMs: target })
        else if (audioRef.current) audioRef.current.currentTime = target / 1000
      } else {
        playerRef.current?.seekTo?.(target / 1000, true)
      }
    } catch {}
  }

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null
      const typing = !!target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)
      const key = event.key.toLowerCase()

      if ((event.ctrlKey || event.metaKey) && key === 'k') {
        event.preventDefault()
        setTab('search')
        window.requestAnimationFrame(() => document.getElementById('sideplay-search')?.focus())
        return
      }
      if (typing) return
      if (event.key === 'Escape' && expanded) { event.preventDefault(); setExpanded(false); return }
      if (!current) return
      if (event.code === 'Space' || key === 'k') { event.preventDefault(); paused ? resumePlayback() : pausePlayback(); return }
      if (key === 'j' || event.key === 'ArrowLeft') { event.preventDefault(); seekPlayback(positionMs - 10000); return }
      if (key === 'l' || event.key === 'ArrowRight') { event.preventDefault(); seekPlayback(positionMs + 10000); return }
      if (event.shiftKey && key === 'n') { event.preventDefault(); next(); return }
      if (event.shiftKey && key === 'p') { event.preventDefault(); previous(); return }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [current?.videoId, paused, expanded, positionMs, durationMs, useOffline, playbackEngine])

  async function addOffline(track: Track) {
    setOfflineBusy(track.videoId); setError('')
    try {
      // Replacement is atomic from the user's point of view: keep the existing
      // copy until the newly selected file has been imported successfully.
      const previous = sp.getOfflineCopy(track.videoId)
      const copy = await importOfflineCopy(track)
      if (isNative() && current?.videoId === track.videoId) {
        nativeStartPositionRef.current = Math.max(0, positionMs || 0)
        playerRef.current?.pauseVideo?.()
      }
      sp.setOfflineCopy(copy)
      if (previous && previous.localUri !== copy.localUri) {
        try { await removeOfflineCopy(previous) } catch {
          // A failed cleanup should never make the newly imported copy disappear.
        }
      }
    } catch (e: any) {
      if (!/cancel|no audio file selected/i.test(e?.message || '')) setError(e?.message || 'Could not import offline audio.')
    } finally { setOfflineBusy(null) }
  }

  async function deleteOffline(videoId: string) {
    const copy = sp.getOfflineCopy(videoId)
    if (!copy) return
    try { await removeOfflineCopy(copy) } catch (e: any) { setError(e?.message || 'Could not delete offline copy.'); return }
    sp.removeOfflineCopy(videoId)
  }

  const sleepText = useMemo(() => {
    if (sleepAfterCurrent) return 'end of track'
    if (!sleepUntil) return null
    return `${Math.max(0, Math.ceil((sleepUntil - Date.now()) / 60000))}m`
  }, [sleepAfterCurrent, sleepUntil, current])

  const common = { sp, play, setPlaylistTarget, addOffline, offlineBusy }

  return <div className="app-shell">
    <aside className="side-rail">
      <Brand />
      <nav className="rail-nav">
        <NavItem active={tab==='home'} label="Home" icon={<Home/>} onClick={()=>setTab('home')} />
        <NavItem active={tab==='search'} label="Search" icon={<Search/>} onClick={()=>setTab('search')} />
        <NavItem active={tab==='library'} label="Library" icon={<ListMusic/>} onClick={()=>setTab('library')} />
        <NavItem active={tab==='downloads'} label="Offline" icon={<Download/>} onClick={()=>setTab('downloads')} badge={Object.keys(sp.state.offline || {}).length} />
        <NavItem active={tab==='queue'} label="Queue" icon={<Menu/>} onClick={()=>setTab('queue')} badge={Math.max(0, sp.state.queue.length - Math.max(0, sp.state.currentIndex + 1))} />
      </nav>
      <button className="rail-settings" onClick={()=>setTab('settings')}><Settings/><span>Settings</span></button>
    </aside>

    <div className="main-pane">
      <header className="topbar">
        <Brand compact />
        <div className="top-actions">
          {tab !== 'search' && <button className="search-pill" onClick={()=>setTab('search')}><Search/><span>Search YouTube</span></button>}
          <button className="icon-btn" onClick={()=>setTab('settings')} aria-label="Settings"><Settings size={20}/></button>
        </div>
      </header>

      {error && <div className="global-error"><span>{error}</span><button onClick={()=>setError('')}><X/></button></div>}

      <main className="content">
        <div className="page-stage" key={tab}>
          {tab === 'home' && <HomeView {...common} mixes={mixes} recommendations={recommendations} recsBusy={recsBusy} refreshRecommendations={refreshRecommendations} setTab={setTab} />}
          {tab === 'search' && <SearchView {...common} query={query} setQuery={setQuery} runSearch={runSearch} busy={busy} error={error} results={results} recentSearches={recentSearches} clearRecentSearches={()=>setRecentSearches([])} />}
          {tab === 'library' && <LibraryView {...common} setSelectedPlaylist={setSelectedPlaylist} setTab={setTab} />}
          {tab === 'downloads' && <DownloadsView sp={sp} play={play} addOffline={addOffline} deleteOffline={deleteOffline} offlineBusy={offlineBusy} />}
          {tab === 'queue' && <QueueView sp={sp} play={play} />}
          {tab === 'settings' && <SettingsView sp={sp} spotifyEngineEnabled={spotifyEngineEnabled} setSpotifyEngineEnabled={setSpotifyEngineEnabled} />}
        </div>
      </main>
    </div>

    {current && <>
      <div className={`mini-player ${useOffline?'offline-playing':''}`} onClick={()=>setExpanded(true)}>
        <img src={current.thumbnail} alt="" />
        <div className="mini-meta"><b>{current.title}</b><span>{current.channel}</span>{useOffline?<em><WifiOff/> Background ready</em>:usableOffline?<em className="background-ready"><WifiOff/> Background available</em>:playbackEngine==='spotify'?<em className="spotify-ready"><Music2/> Spotify · background</em>:playbackEngine==='spotify-error'?<em className="foreground-only"><Music2/> Spotify · handoff failed</em>:isNative()?<em className="foreground-only">YouTube · foreground only</em>:null}</div>
        <button className="icon-btn player-control" onClick={(e)=>{e.stopPropagation(); paused?resumePlayback():pausePlayback()}}>{paused?<Play/>:<Pause/>}</button>
        <button className="icon-btn player-control" onClick={(e)=>{e.stopPropagation();next()}}><SkipForward/></button>
        <div className="mini-progress"><span style={{width:`${durationMs>0?Math.min(100,(positionMs/durationMs)*100):0}%`}}/></div>
      </div>
      {!useOffline && playbackEngine === 'youtube' && <div className="hidden-player"><YouTubePlayer key={current.videoId} videoId={current.videoId} onEnded={onEnded} controllerRef={playerRef} onReady={()=>setPaused(false)} onPlaybackState={(state)=>{if(state==='playing'){setPaused(false);if(isNative()&&wantsPlaybackRef.current&&!useOfflineRef.current&&currentRef.current)WebPlayback.start({title:currentRef.current.title,artist:currentRef.current.channel}).catch(()=>{})}else if(state==='paused'){setPaused(true);if(isNative()&&!wantsPlaybackRef.current)WebPlayback.stop().catch(()=>{})}else if(state==='ended'){setPaused(true);if(isNative())WebPlayback.stop().catch(()=>{})}}} /></div>}
      <audio ref={audioRef} className="hidden-audio" onEnded={onEnded} onPlay={()=>setPaused(false)} onPause={()=>setPaused(true)} />
    </>}

    <nav className="bottom-nav">
      <NavButton active={tab==='home'} label="Home" icon={<Home/>} onClick={()=>setTab('home')} />
      <NavButton active={tab==='search'} label="Search" icon={<Search/>} onClick={()=>setTab('search')} />
      <NavButton active={tab==='library'} label="Library" icon={<ListMusic/>} onClick={()=>setTab('library')} />
      <NavButton active={tab==='downloads'} label="Offline" icon={<Download/>} onClick={()=>setTab('downloads')} badge={Object.keys(sp.state.offline || {}).length} />
      <NavButton active={tab==='queue'} label="Queue" icon={<Menu/>} onClick={()=>setTab('queue')} badge={Math.max(0,sp.state.queue.length-Math.max(0,sp.state.currentIndex+1))} />
    </nav>

    {expanded && current && <NowPlaying track={current} sp={sp} paused={paused} pausePlayback={pausePlayback} resumePlayback={resumePlayback} previous={previous} next={next} close={()=>setExpanded(false)} setPlaylistTarget={setPlaylistTarget} sleepText={sleepText} setSleepUntil={setSleepUntil} sleepAfterCurrent={sleepAfterCurrent} setSleepAfterCurrent={setSleepAfterCurrent} offline={usableOffline} useOffline={useOffline} addOffline={addOffline} offlineBusy={offlineBusy} positionMs={positionMs} durationMs={durationMs} onSeek={seekPlayback} setScrubbing={(v:boolean)=>{scrubbingRef.current=v}} playbackEngine={playbackEngine} />}
    {playlistTarget && <PlaylistPicker track={playlistTarget} sp={sp} close={()=>setPlaylistTarget(null)} />}
    {selectedPlaylist && <PlaylistDetail playlistId={selectedPlaylist.id} sp={sp} play={play} close={()=>setSelectedPlaylist(null)} addOffline={addOffline} offlineBusy={offlineBusy} />}
  </div>
}

function Brand({compact=false}:{compact?:boolean}) {
  return <div className={`brand ${compact?'compact':''}`}><div className="brand-mark"><Play fill="currentColor"/></div><div><b>SidePlay</b><small>music, your way</small></div></div>
}

function HomeView({sp,play,setPlaylistTarget,addOffline,offlineBusy,mixes,recommendations,recsBusy,refreshRecommendations,setTab}:any) {
  const quick = uniqueTracks([...sp.state.history, ...sp.state.favorites, ...sp.state.playlists.flatMap((p:Playlist)=>p.tracks)]).slice(0,8)
  const last = sp.state.history[0]
  const offlineTracks = (Object.values(sp.state.offline || {}) as OfflineCopy[]).sort((a,b)=>b.addedAt-a.addedAt).slice(0,6).map((copy)=>({ videoId:copy.videoId, title:copy.title||copy.filename, channel:copy.channel||'Offline audio', thumbnail:copy.thumbnail||'' } as Track))
  const surprisePool = uniqueTracks([...recommendations, ...quick, ...mixes.flatMap((m:Mix)=>m.tracks)])
  const surprise = () => { if (!surprisePool.length) return; play(surprisePool[Math.floor(Math.random()*surprisePool.length)]) }
  return <section className="home-view">
    <div className="sunset-hero">
      <div><p className="eyebrow"><Sparkles/> MADE FOR YOU</p><h1>Your music,<br/>warmer.</h1><p>SidePlay learns from what you actually play, like and save — then builds mixes around your rotation.</p><div className="hero-actions"><button className="primary" onClick={()=>setTab('search')}><Search/> Find music</button>{last&&<button className="soft-button" onClick={()=>play(last)}><Play/> Resume</button>}<button className="soft-button" disabled={!surprisePool.length} onClick={surprise}><Shuffle/> Surprise me</button></div></div>
      <div className="sun-orb"><Music2/></div>
    </div>

    {!!mixes.length && <Section title="Made for you" eyebrow="DAILY MIXES" action={<button className="text-button" onClick={refreshRecommendations}><RefreshCw className={recsBusy?'spin':''}/> Refresh</button>}>
      <div className="mix-grid">{mixes.map((mix:Mix)=><MixCard key={mix.id} mix={mix} play={play}/>)}</div>
    </Section>}

    {!!quick.length && <Section title="Quick picks" eyebrow="BACK IN ROTATION"><div className="quick-grid">{quick.map((t:Track)=><QuickCard key={t.videoId} track={t} onPlay={()=>play(t)} offline={!!sp.getOfflineCopy(t.videoId)} />)}</div></Section>}

    {!!offlineTracks.length && <Section title="Ready without signal" eyebrow="OFFLINE NOW" action={<button className="text-button" onClick={()=>setTab('downloads')}><WifiOff/> See all</button>}><div className="quick-grid">{offlineTracks.map((t:Track)=><QuickCard key={t.videoId} track={t} onPlay={()=>play(t)} offline />)}</div></Section>}

    <Section title={last?`Because you played ${trimTitle(last.title)}`:'Discover something'} eyebrow="DISCOVER" action={<button className="text-button" onClick={refreshRecommendations}><Compass/> Explore</button>}>
      {recsBusy&&!recommendations.length?<LoadingCards/>:recommendations.length?<div className="recommend-grid">{recommendations.slice(0,12).map((t:Track)=><TrackTile key={t.videoId} track={t} sp={sp} onPlay={()=>play(t)} onPlaylist={()=>setPlaylistTarget(t)} onOffline={()=>addOffline(t)} offlineBusy={offlineBusy}/>)}</div>:<Empty text="Play or like a few songs and SidePlay will start building recommendations here."/>}
    </Section>
  </section>
}

function SearchView({query,setQuery,runSearch,busy,error,results,play,sp,setPlaylistTarget,addOffline,offlineBusy,recentSearches,clearRecentSearches}:any) {
  return <section><PageTitle eyebrow="FIND YOUR NEXT TRACK" title="Search" subtitle="YouTube search, links, your library — one place."/>
    <div className="searchbar"><Search/><input id="sideplay-search" autoFocus value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>e.key==='Enter'&&runSearch()} placeholder="Song, artist, video, or YouTube link"/><button onClick={()=>runSearch()}>{busy?'Searching…':'Search'}</button></div>
    {!!recentSearches.length&&<div className="recent-searches"><div className="recent-searches-head"><span>Recent</span><button onClick={clearRecentSearches}>Clear</button></div><div className="search-chips">{recentSearches.map((term:string)=><button key={term} onClick={()=>runSearch(term)}><Clock3/>{term}</button>)}</div></div>}
    {error&&<div className="inline-error">{error}</div>}
    {!results.length&&!busy&&<div className="search-empty"><Radio/><h3>Search anything.</h3><p>No API key is required on Android or when PC SidePlay is started with its launcher. Press <kbd>Ctrl K</kbd> from anywhere on desktop.</p></div>}
    <div className="track-list">{results.map((t:Track)=><TrackRow key={t.videoId} track={t} sp={sp} onPlay={()=>play(t)} onPlaylist={()=>setPlaylistTarget(t)} onOffline={()=>addOffline(t)} offlineBusy={offlineBusy}/>)}</div>
  </section>
}

function LibraryView({sp,play,setPlaylistTarget,setSelectedPlaylist,addOffline,offlineBusy,setTab}:any) {
  const [name,setName]=useState('')
  return <section><PageTitle eyebrow="YOUR STUFF" title="Library" subtitle="Favorites, playlists and everything you keep coming back to."/>
    <div className="library-grid">
      <button className="library-card favorite-card" onClick={()=>sp.state.favorites[0]&&play(sp.state.favorites[0],sp.state.favorites)}><div className="card-icon"><Heart fill="currentColor"/></div><div><b>Liked Songs</b><span>{sp.state.favorites.length} tracks</span></div></button>
      <button className="library-card history-card" onClick={()=>document.getElementById('history')?.scrollIntoView({behavior:'smooth'})}><div className="card-icon"><History/></div><div><b>History</b><span>{sp.state.history.length} recent</span></div></button>
      <button className="library-card offline-card" onClick={()=>setTab('downloads')}><div className="card-icon"><WifiOff/></div><div><b>Offline</b><span>{Object.keys(sp.state.offline||{}).length} local copies</span></div></button>
    </div>
    <div className="create-playlist"><input value={name} onChange={e=>setName(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&name.trim()){sp.createPlaylist(name);setName('')}}} placeholder="New playlist name"/><button onClick={()=>{if(name.trim()){sp.createPlaylist(name);setName('')}}}><Plus/> Create</button></div>
    <Section title="Playlists" eyebrow="COLLECTIONS"><div className="playlist-grid">{sp.state.playlists.length?sp.state.playlists.map((p:Playlist)=><button key={p.id} className="playlist-card" onClick={()=>setSelectedPlaylist(p)}><div className="playlist-art">{p.tracks.slice(0,4).map((t:Track)=><img key={t.videoId} src={t.thumbnail} alt=""/>)}{!p.tracks.length&&<Music2/>}</div><b>{p.name}</b><span>{p.tracks.length} tracks</span></button>):<Empty text="Create a playlist and it will show up here."/>}</div></Section>
    <Section title="History" eyebrow="RECENTLY PLAYED" id="history" action={sp.state.history.length?<button className="text-button danger-text" onClick={()=>{if(confirm('Clear SidePlay listening history?'))sp.clearHistory()}}><Trash2/> Clear</button>:null}><div className="track-list">{sp.state.history.length?sp.state.history.map((t:any)=><TrackRow key={`${t.videoId}-${t.playedAt}`} track={t} sp={sp} onPlay={()=>play(t)} onPlaylist={()=>setPlaylistTarget(t)} onOffline={()=>addOffline(t)} offlineBusy={offlineBusy}/>):<Empty text="Your listening history will appear here."/>}</div></Section>
  </section>
}

function DownloadsView({sp,play,addOffline,deleteOffline,offlineBusy}:any) {
  const copies = Object.values(sp.state.offline || {}) as OfflineCopy[]
  const [directUrl,setDirectUrl]=useState('')
  const [directStatus,setDirectStatus]=useState('')
  async function directDownload(){
    try{setDirectStatus('Starting…');const r=await startDirectDownload(directUrl.trim());setDirectStatus(`Download started${r.destination?` → ${r.destination}`:''}.`);setDirectUrl('')}
    catch(e:any){setDirectStatus(e?.message||'Download failed.')}
  }
  return <section><PageTitle eyebrow="TAKE IT WITH YOU" title="Offline" subtitle="Keep local audio copies linked to your SidePlay tracks for reliable offline playback."/>
    <div className="offline-banner"><div className="offline-banner-icon"><WifiOff/></div><div><b>{copies.length} tracks available offline</b><p>On Android, SidePlay automatically uses Media3 whenever a matching local copy exists, so background and screen-off playback start from the original Play tap. On PC, “Prefer offline copies” controls local playback.</p></div></div>
    {isNative()?<div className="setting-toggle native-automatic"><div><b>Android native playback</b><span>Automatic whenever this track has a local copy. This starts Media3 while SidePlay is still foreground so lock-screen/background playback is reliable.</span></div><span className="status-pill"><CheckCircle2/> AUTO</span></div>:<div className="setting-toggle"><div><b>Prefer offline copies on PC</b><span>Use local audio whenever a matching copy exists.</span></div><button className={sp.state.preferOffline?'toggle on':'toggle'} onClick={()=>sp.setPreferOffline(!sp.state.preferOffline)}><span/></button></div>}
    <Section title="Offline library" eyebrow="LOCAL VAULT">
      {!copies.length?<Empty text="No offline copies yet. Use “Import offline audio” next to a track and choose a local audio file."/>:<div className="track-list">{copies.sort((a,b)=>b.addedAt-a.addedAt).map((copy)=>{const t:Track={videoId:copy.videoId,title:copy.title||copy.filename,channel:copy.channel||'Offline audio',thumbnail:copy.thumbnail||''};return <div className="track-row" key={copy.videoId}><button className="track-main" onClick={()=>play(t)}>{t.thumbnail?<img src={t.thumbnail}/>:<div className="fallback-thumb"><Music2/></div>}<div><b>{t.title}</b><span>{t.channel} · {formatBytes(copy.bytes)}</span><em className="offline-chip"><CheckCircle2/> Available offline</em></div></button><div className="row-actions"><button title="Replace offline audio" disabled={offlineBusy===t.videoId} onClick={()=>addOffline(t)}><FolderOpen/></button><button className="danger" title="Delete offline copy" onClick={()=>deleteOffline(t.videoId)}><Trash2/></button></div></div>})}</div>}
    </Section>
    <Section title="Direct file downloads" eyebrow="DOWNLOAD MANAGER"><div className="settings-card"><p>This is separate from Offline Library. Paste a direct downloadable media URL and SidePlay will save the file using Android's Download Manager or the PC bridge.</p><div className="direct-download"><input value={directUrl} onChange={e=>setDirectUrl(e.target.value)} placeholder="https://example.com/song.mp3"/><button disabled={!directUrl.trim()} onClick={directDownload}><Download/> Download</button></div>{directStatus&&<small>{directStatus}</small>}</div></Section>
  </section>
}

function QueueView({sp,play}:any){
  const first=sp.state.currentIndex<0?0:sp.state.currentIndex+1
  const upcoming=sp.state.queue.map((track:Track,index:number)=>({track,index})).filter(({index}:any)=>index>=first)
  return <section><div className="section-head"><PageTitle eyebrow="UP NEXT" title="Queue" subtitle="Only songs you intentionally queued live here."/><button className="ghost" disabled={!upcoming.length} onClick={sp.clearQueue}>Clear</button></div>{!upcoming.length&&<Empty text="Nothing queued. Playing a song by itself does not add it here."/>}<div className="queue-list">{upcoming.map(({track:t,index:i}:any,v:number)=><div className="queue-row" key={`${t.videoId}-${i}`}><button className="queue-main" onClick={()=>play(t,sp.state.queue)}><span className="queue-num">{v+1}</span><img src={t.thumbnail}/><div><b>{t.title}</b><span>{t.channel}</span></div></button><div className="row-actions"><button disabled={v===0} onClick={()=>sp.moveQueue(i,i-1)}><ArrowUp/></button><button disabled={v===upcoming.length-1} onClick={()=>sp.moveQueue(i,i+1)}><ArrowDown/></button><button onClick={()=>sp.removeQueue(i)}><X/></button></div></div>)}</div></section>
}

function SettingsView({sp,spotifyEngineEnabled,setSpotifyEngineEnabled}:any){
  const [io,setIo]=useState('')
  return <section><PageTitle eyebrow="TUNE IT" title="Settings" subtitle="Local-first playback and library controls."/>
    <YouTubeLocalImportSettings sp={sp}/>
    <BackgroundPlaybackSettings/>
    <SpotifySessionSettings enabled={spotifyEngineEnabled} setEnabled={setSpotifyEngineEnabled}/>
    <div className="settings-card"><label>Keyless YouTube search</label><p>SidePlay searches publicly available YouTube results through its Android/PC bridge. No Google Cloud project or API key is required.</p></div>
    <div className="settings-card"><label>Library backup</label><textarea value={io} onChange={e=>setIo(e.target.value)} placeholder="Paste backup JSON here, or export yours below."/><div className="button-row"><button className="soft-button" onClick={()=>setIo(sp.exportLibrary())}>Export</button><button className="primary" onClick={()=>{try{sp.importLibrary(io);alert('Imported.')}catch{alert('Invalid backup JSON.')}}}>Import</button></div></div>
    <div className="settings-card"><label>Playback engines</label><p><b>Spotify Session:</b> experimental no-cloud Android engine that controls Spotify through the OS media session for background/screen-off playback.<br/><b>YouTube:</b> discovery + fallback embedded player.<br/><b>Offline/direct media:</b> SidePlay Media3 service on Android.</p></div>
    <div className="settings-card"><label>Desktop shortcuts</label><div className="shortcut-grid"><span><kbd>Ctrl K</kbd><b>Search</b></span><span><kbd>Space / K</kbd><b>Play / pause</b></span><span><kbd>J / ←</kbd><b>Back 10 sec</b></span><span><kbd>L / →</kbd><b>Forward 10 sec</b></span><span><kbd>Shift N</kbd><b>Next track</b></span><span><kbd>Shift P</kbd><b>Previous track</b></span></div></div>
  </section>
}

function YouTubeLocalImportSettings({sp}:any){
  const [busy,setBusy]=useState(false)
  const [status,setStatus]=useState('No Google Cloud required.')
  const [summary,setSummary]=useState<any>(null)
  async function choose(file:File|undefined){
    if(!file)return
    setBusy(true);setStatus(`Reading ${file.name}…`)
    try{
      const result=await parseYouTubeExportFile(file)
      let playlistTracks=0
      for(const p of result.playlists){const local=sp.createPlaylist(p.name);for(const t of p.tracks)sp.addToPlaylist(local.id,t);playlistTracks+=p.tracks.length}
      for(const t of result.favorites)if(!sp.isFavorite(t.videoId))sp.toggleFavorite(t)
      if(result.history.length)sp.mergeHistory(result.history)
      if(result.subscriptions.length)localStorage.setItem('sideplay.youtube.subscriptions',JSON.stringify(result.subscriptions))
      const s={playlists:result.playlists.length,playlistTracks,favorites:result.favorites.length,history:result.history.length,subscriptions:result.subscriptions.length,filesRead:result.filesRead}
      setSummary(s)
      setStatus(`Imported ${s.playlists} playlists, ${s.favorites} likes, ${s.history} history tracks and ${s.subscriptions} subscriptions.`)
    }catch(e:any){setStatus(e?.message||'Could not read that YouTube export.')}
    finally{setBusy(false)}
  }
  return <div className="settings-card youtube-account-card"><label>YouTube library — no cloud</label><div className="connect-prompt"><div className="connect-icon"><FileArchive/></div><div><b>Import your YouTube data locally</b><p>Use a Google Takeout YouTube/YouTube Music ZIP, or a compatible exported CSV/JSON/HTML file. SidePlay reads it on your device and never needs OAuth.</p></div></div><label className={`primary import-file-button ${busy?'disabled':''}`}><UploadCloud/> {busy?'Importing…':'Choose YouTube export'}<input type="file" accept=".zip,.csv,.json,.html,.htm" disabled={busy} onChange={e=>{choose(e.target.files?.[0]);e.currentTarget.value=''}}/></label><small className="account-status">{status}</small>{summary&&<div className="account-summary"><b>{summary.playlists+summary.favorites+summary.history}</b><span>library items discovered across {summary.filesRead} relevant export files · subscriptions feed Made for You</span></div>}<small>Tip: in Google Takeout, export only “YouTube and YouTube Music” for a smaller ZIP. SidePlay recognizes common playlist, liked-video, subscription and watch-history exports.</small></div>
}

function SpotifySessionSettings({enabled,setEnabled}:any){
  const[status,setStatus]=useState<any>(null)
  const[busy,setBusy]=useState(false)
  const refresh=async()=>{if(!isNative())return;try{setStatus(await SpotifySession.getStatus())}catch{setStatus(null)}}
  useEffect(()=>{refresh();const id=window.setInterval(refresh,3000);return()=>window.clearInterval(id)},[])
  if(!isNative())return null
  const ready=!!status?.accessGranted&&!!status?.spotifyInstalled&&!!status?.sessionAvailable
  return <div className="settings-card spotify-session-card">
    <div className="settings-card-title"><span className="settings-icon"><Music2/></span><div><label>Spotify background engine <small>EXPERIMENTAL</small></label><p>Uses Android's user-authorized media-session controls. No Spotify Developer app, client ID, OAuth, Google Cloud or SidePlay server. Spotify must be installed and logged in.</p></div></div>
    <div className="spotify-status-row"><span className={status?.accessGranted?'status-pill success':'status-pill'}>{status?.accessGranted?'Notification access ✓':'Notification access needed'}</span><span className={status?.sessionAvailable?'status-pill success':'status-pill'}>{status?.sessionAvailable?'Spotify session found':'No active Spotify session'}</span>{status?.supportsPlayFromSearch&&<span className="status-pill success">PLAY_FROM_SEARCH ✓</span>}</div>
    <div className="setting-toggle"><div><b>Prefer Spotify for online tracks</b><span>{ready?'Ready: online Play actions will try Spotify first.':'Grant access and start any song in Spotify once; SidePlay will then try Spotify before the YouTube iframe.'}</span></div><button className={enabled?'toggle on':'toggle'} onClick={()=>setEnabled(!enabled)}><span/></button></div>
    <div className="button-row"><button className="soft-button" disabled={busy} onClick={async()=>{setBusy(true);try{await SpotifySession.openAccessSettings()}finally{setBusy(false);window.setTimeout(refresh,900)}}}>Grant notification access</button><button className="soft-button" onClick={async()=>{try{await SpotifySession.openSpotify()}catch{};window.setTimeout(refresh,1200)}}>Open Spotify once</button><button className="soft-button" onClick={refresh}>Refresh</button></div>
    {status?.sessionAvailable&&<p className="spotify-now">Spotify session: <b>{status.title||'active'}</b>{status.artist?` · ${status.artist}`:''}</p>}
  </div>
}

function BackgroundPlaybackSettings(){
  const[health,setHealth]=useState<{unrestricted:boolean;androidVersion:number}|null>(null)
  const[busy,setBusy]=useState(false)
  const refresh=async()=>{if(!isNative())return;try{setHealth(await BackgroundAudio.getBackgroundHealth())}catch{setHealth(null)}}
  useEffect(()=>{refresh()},[])
  if(!isNative())return <div className="settings-card"><label>Background playback</label><p>PC offline audio stays available through the local SidePlay media bridge. Android-specific battery controls appear in the APK.</p></div>
  return <div className="settings-card background-health"><div className="settings-card-title"><span className="settings-icon"><BatteryCharging/></span><div><label>Background playback health</label><p>{health?.unrestricted?'Android is not battery-optimizing SidePlay.':'If your phone kills native offline playback, set SidePlay to Unrestricted / Not optimized in Android battery settings.'}</p></div></div><button className="soft-button" disabled={busy} onClick={async()=>{setBusy(true);try{await BackgroundAudio.openBackgroundSettings()}finally{setBusy(false);window.setTimeout(refresh,900)}}}>{health?.unrestricted?'Review battery settings':'Open Android battery settings'}</button></div>
}

function TrackRow({track,sp,onPlay,onPlaylist,onOffline,offlineBusy}:any){const liked=sp.isFavorite(track.videoId);const offline=sp.getOfflineCopy(track.videoId);return <div className="track-row"><button className="track-main" onClick={onPlay}><img src={track.thumbnail}/><div><b>{track.title}</b><span>{track.channel}</span>{offline&&<em className="offline-chip"><WifiOff/> Offline</em>}</div></button><div className="row-actions"><button onClick={()=>sp.toggleFavorite(track)} className={liked?'liked':''}><Heart fill={liked?'currentColor':'none'}/></button><button onClick={()=>sp.playNext(track)} title="Play next"><SkipForward/></button><button onClick={()=>sp.addQueue(track)} title="Add to queue"><Plus/></button><button onClick={onPlaylist} title="Add to playlist"><ListMusic/></button><button className={offline?'offline-action':''} disabled={offlineBusy===track.videoId} onClick={onOffline} title={offline?'Replace offline audio':'Import offline audio'}>{offline?<CheckCircle2/>:<FolderOpen/>}</button></div></div>}

function TrackTile({track,sp,onPlay,onPlaylist,onOffline,offlineBusy}:any){const liked=sp.isFavorite(track.videoId);return <article className="track-tile"><button className="tile-art" onClick={onPlay}><img src={track.thumbnail}/><span className="tile-play"><Play fill="currentColor"/></span></button><b>{track.title}</b><span>{track.channel}</span><div className="tile-actions"><button className={liked?'liked':''} onClick={()=>sp.toggleFavorite(track)}><Heart fill={liked?'currentColor':'none'}/></button><button onClick={onPlaylist}><Plus/></button><button onClick={onOffline} disabled={offlineBusy===track.videoId}>{sp.getOfflineCopy(track.videoId)?<CheckCircle2/>:<FolderOpen/>}</button></div></article>}

function QuickCard({track,onPlay,offline}:any){return <button className="quick-card" onClick={onPlay}><img src={track.thumbnail}/><div><b>{track.title}</b><span>{track.channel}</span></div>{offline?<WifiOff/>:<Play fill="currentColor"/>}</button>}
function MixCard({mix,play}:{mix:Mix;play:(t:Track,q?:Track[])=>void}){const cover=mix.tracks.slice(0,4);return <button className={`mix-card ${mix.accent}`} disabled={!mix.tracks.length} onClick={()=>mix.tracks[0]&&play(mix.tracks[0],mix.tracks)}><div className="mix-cover">{cover.map((t)=><img key={t.videoId} src={t.thumbnail}/>)}</div><div><b>{mix.title}</b><span>{mix.subtitle}</span></div><Play className="mix-play" fill="currentColor"/></button>}

function PlaylistPicker({track,sp,close}:any){const[name,setName]=useState('');return <div className="overlay" onClick={close}><div className="sheet" onClick={e=>e.stopPropagation()}><div className="sheet-head"><div><p className="eyebrow">SAVE IT</p><h3>Add to playlist</h3></div><button className="icon-btn" onClick={close}><X/></button></div><div className="create-playlist"><input value={name} onChange={e=>setName(e.target.value)} placeholder="New playlist"/><button onClick={()=>{const p=sp.createPlaylist(name);sp.addToPlaylist(p.id,track);close()}}><Plus/> New</button></div><div className="playlist-list">{sp.state.playlists.map((p:Playlist)=><button className="playlist-row" key={p.id} onClick={()=>{sp.addToPlaylist(p.id,track);close()}}><div className="playlist-cover-mini"><Music2/></div><div><b>{p.name}</b><span>{p.tracks.length} tracks</span></div><Plus/></button>)}</div></div></div>}

function PlaylistDetail({playlistId,sp,play,close,addOffline,offlineBusy}:any){const p=sp.state.playlists.find((x:Playlist)=>x.id===playlistId);const[name,setName]=useState(p?.name??'');if(!p)return null;return <div className="overlay"><div className="full-sheet"><div className="sheet-head"><button className="icon-btn" onClick={close}><X/></button><div className="playlist-title"><input value={name} onChange={e=>setName(e.target.value)} onBlur={()=>sp.renamePlaylist(p.id,name)}/><span>{p.tracks.length} tracks</span></div><button className="icon-btn danger" onClick={()=>{if(confirm('Delete this playlist?')){sp.deletePlaylist(p.id);close()}}}><Trash2/></button></div><button className="primary wide" disabled={!p.tracks.length} onClick={()=>play(p.tracks[0],p.tracks)}><Play/> Play playlist</button><div className="queue-list">{p.tracks.map((t:Track,i:number)=><div className="queue-row" key={`${t.videoId}-${i}`}><button className="queue-main" onClick={()=>play(t,p.tracks)}><img src={t.thumbnail}/><div><b>{t.title}</b><span>{t.channel}</span>{sp.getOfflineCopy(t.videoId)&&<em className="offline-chip"><WifiOff/> Offline</em>}</div></button><div className="row-actions"><button disabled={i===0} onClick={()=>sp.movePlaylistTrack(p.id,i,i-1)}><ArrowUp/></button><button disabled={i===p.tracks.length-1} onClick={()=>sp.movePlaylistTrack(p.id,i,i+1)}><ArrowDown/></button><button disabled={offlineBusy===t.videoId} onClick={()=>addOffline(t)}>{sp.getOfflineCopy(t.videoId)?<CheckCircle2/>:<Download/>}</button><button onClick={()=>sp.removeFromPlaylist(p.id,t.videoId)}><X/></button></div></div>)}</div></div></div>}

function NowPlaying({track,sp,paused,pausePlayback,resumePlayback,previous,next,close,setPlaylistTarget,sleepText,setSleepUntil,sleepAfterCurrent,setSleepAfterCurrent,offline,useOffline,addOffline,offlineBusy,positionMs,durationMs,onSeek,setScrubbing,playbackEngine}:any){
  const[showSleep,setShowSleep]=useState(false)
  const[dragY,setDragY]=useState(0)
  const dragStart=useRef<number|null>(null)
  const liked=sp.isFavorite(track.videoId)
  const usableOffline=offline
  const pct=durationMs>0?Math.min(100,(positionMs/durationMs)*100):0
  const startDrag=(e:any)=>{dragStart.current=e.clientY;e.currentTarget.setPointerCapture?.(e.pointerId)}
  const moveDrag=(e:any)=>{if(dragStart.current===null)return;setDragY(Math.max(0,e.clientY-dragStart.current))}
  const endDrag=()=>{if(dragY>105)close();setDragY(0);dragStart.current=null}
  return <div className="overlay now-overlay"><div className={`now-playing ${paused?'is-paused':''}`} style={{transform:`translateY(${dragY}px)`,opacity:String(Math.max(.74,1-dragY/700))}}>
    <div className="now-grabber-zone" onPointerDown={startDrag} onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag}><span/><ChevronDown/></div>
    <div className="now-top"><button className="icon-btn" onClick={close}><X/></button><span>NOW PLAYING</span><button className="icon-btn" onClick={()=>setPlaylistTarget(track)}><ListMusic/></button></div>
    <div className="now-art-wrap"><img className="now-art" src={track.thumbnail}/>{useOffline?<span className="now-offline"><WifiOff/> BACKGROUND READY</span>:usableOffline?<span className="now-offline standby"><WifiOff/> BACKGROUND AVAILABLE</span>:playbackEngine==='spotify'?<span className="now-offline spotify-engine">SPOTIFY · BACKGROUND</span>:playbackEngine==='spotify-error'?<span className="now-source-warning">SPOTIFY · HANDOFF FAILED</span>:isNative()?<span className="now-source-warning">YOUTUBE · FOREGROUND ONLY</span>:null}</div>
    <div className="now-meta"><h2>{track.title}</h2><p>{track.channel}</p></div>
    <div className="seek-wrap"><input aria-label="Playback position" type="range" min={0} max={Math.max(1,durationMs)} step={500} value={Math.min(positionMs,Math.max(1,durationMs))} style={{'--seek-pct':`${pct}%`} as any} onPointerDown={()=>setScrubbing(true)} onPointerUp={()=>setScrubbing(false)} onPointerCancel={()=>setScrubbing(false)} onChange={e=>onSeek(Number(e.target.value))}/><div className="time-row"><span>{formatTime(positionMs)}</span><span>{durationMs>0?`-${formatTime(Math.max(0,durationMs-positionMs))}`:'--:--'}</span></div></div>
    <div className="now-controls"><button onClick={()=>sp.setShuffle(!sp.state.shuffle)} className={sp.state.shuffle?'active-control':''}><Shuffle/></button><button onClick={previous}><SkipBack/></button><button className="play-big" onClick={()=>paused?resumePlayback():pausePlayback()}>{paused?<Play fill="currentColor"/>:<Pause fill="currentColor"/>}</button><button onClick={next}><SkipForward/></button><button onClick={()=>sp.setRepeat(sp.state.repeat==='off'?'all':sp.state.repeat==='all'?'one':'off')} className={sp.state.repeat!=='off'?'active-control':''}><Repeat2/><small>{sp.state.repeat==='one'?'1':''}</small></button></div>
    <div className="now-actions"><button className={liked?'liked':''} onClick={()=>sp.toggleFavorite(track)}><Heart fill={liked?'currentColor':'none'}/> {liked?'Liked':'Like'}</button><button className={offline?'offline-action':''} disabled={offlineBusy===track.videoId} onClick={()=>addOffline(track)}>{offline?<CheckCircle2/>:<FolderOpen/>} {offline?'Offline ready':'Import audio'}</button><button onClick={()=>setShowSleep(!showSleep)}><Moon/> {sleepText?`Sleep: ${sleepText}`:'Sleep timer'}</button></div>{showSleep&&<div className="sleep-options"><button onClick={()=>{setSleepUntil(Date.now()+15*60000);setSleepAfterCurrent(false)}}>15 min</button><button onClick={()=>{setSleepUntil(Date.now()+30*60000);setSleepAfterCurrent(false)}}>30 min</button><button onClick={()=>{setSleepUntil(Date.now()+60*60000);setSleepAfterCurrent(false)}}>60 min</button><button className={sleepAfterCurrent?'active':''} onClick={()=>{setSleepAfterCurrent(true);setSleepUntil(null)}}>End of track</button><button onClick={()=>{setSleepUntil(null);setSleepAfterCurrent(false)}}>Off</button></div>}</div></div>
}

function Section({title,eyebrow,action,children,id}:any){return <section className="home-section" id={id}><div className="section-title"><div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2></div>{action}</div>{children}</section>}
function PageTitle({eyebrow,title,subtitle}:any){return <div className="page-title"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{subtitle}</p></div>}
function NavItem({active,label,icon,onClick,badge}:any){return <button className={active?'active':''} onClick={onClick}>{icon}<span>{label}</span>{badge>0&&<em>{badge}</em>}</button>}
function NavButton({active,label,icon,onClick,badge}:any){return <button data-tab={label.toLowerCase()} className={active?'active':''} onClick={onClick}>{icon}<span>{label}</span>{badge>0&&<em>{badge}</em>}</button>}
function Empty({text}:{text:string}){return <div className="empty"><Clock3/><p>{text}</p></div>}
function LoadingCards(){return <div className="recommend-grid">{Array.from({length:6}).map((_,i)=><div className="skeleton-card" key={i}><div/><span/><small/></div>)}</div>}
function uniqueTracks(tracks:Track[]){const seen=new Set<string>();return tracks.filter(t=>t?.videoId&&!seen.has(t.videoId)&&seen.add(t.videoId))}
function trimTitle(s:string){return s.replace(/\s*[\[(].*?[\])]/g,'').split(/[-–—]/)[0].trim().slice(0,34)}
function formatTime(ms:number){if(!Number.isFinite(ms)||ms<0)return'0:00';const total=Math.floor(ms/1000);const m=Math.floor(total/60);const sec=String(total%60).padStart(2,'0');return`${m}:${sec}`}


type SpotifyWanted = { title: string; artist: string; query: string }

function normalizeSpotifyText(value?: string) {
  return (value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
}

function spotifyIdentityForTrack(track: Track): SpotifyWanted {
  const artist = track.channel
    .replace(/\s*-\s*Topic$/i, '')
    .replace(/VEVO$/i, '')
    .trim()

  let title = track.title
    .replace(/\s*[\[(](official|lyrics?|audio|video|visualizer|live|hd)[^\])]*[\])]/ig, '')
    .replace(/\s*\|.*$/g, '')
    .trim()

  // YouTube uploads often prefix the artist: "BAD BUNNY - SI VEO A TU MAMÁ".
  // Spotify wants the song title and artist as separate structured fields.
  const prefix = new RegExp(`^${escapeRegExp(artist)}\\s*[-–—:]\\s*`, 'i')
  title = title.replace(prefix, '').trim()

  return { title, artist, query: `${title} ${artist}`.trim() }
}

function spotifyStatusMatches(status: { title?: string; artist?: string }, wanted: SpotifyWanted) {
  const actualTitle = normalizeSpotifyText(status.title)
  const actualArtist = normalizeSpotifyText(status.artist)
  const wantedTitle = normalizeSpotifyText(wanted.title)
  const wantedArtist = normalizeSpotifyText(wanted.artist)
  if (!actualTitle || !wantedTitle) return false

  const titleMatch = actualTitle === wantedTitle || actualTitle.includes(wantedTitle) || wantedTitle.includes(actualTitle)
  const artistMatch = !wantedArtist || !actualArtist || actualArtist.includes(wantedArtist) || wantedArtist.includes(actualArtist)
  return titleMatch && artistMatch
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function spotifyQueryForTrack(track: Track) {
  return spotifyIdentityForTrack(track).query
}
