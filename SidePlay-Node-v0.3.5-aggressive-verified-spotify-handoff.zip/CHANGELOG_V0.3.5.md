# SidePlay v0.3.5 — aggressive verified Spotify handoff

- Adds MediaSession `prepareFromSearch` before play attempts.
- Uses title-only, combined, quoted, structured and unstructured Android search variants.
- Adds a last-resort Spotify search deep-link warm-up that automatically returns to SidePlay, then retries exact handoff.
- Every route is verified against Spotify title + artist metadata and PLAYING state.
- A failed handoff now shows `Spotify · handoff failed`; it can no longer display the green background-success badge for the wrong song.
- PiP remains disabled.
- Offline Media3 playback is unchanged.
