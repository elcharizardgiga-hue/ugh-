import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const android = path.join(root, 'android')
if (!fs.existsSync(android)) throw new Error('android/ does not exist. Run: npx cap add android')

const nativeFiles = [
  'PlaybackService.java',
  'BackgroundAudioPlugin.java',
  'SharedTextPlugin.java',
  'NativeYouTubePlugin.java',
  'SidePlayNewPipeDownloader.java',
  'NewPipeYouTubeResolver.java',
  'YtDlpExtractorService.java',
  'YtDlpIsolatedClient.java',
  'DirectDownloadPlugin.java',
  'OfflineMediaPlugin.java',
  'RollingCachePlugin.java',
  'SourceResolverPlugin.java',
  'YtDlpPlugin.java',
  'MediaCaptureActivity.java',
  'MediaSafety.java',
  'WebPlaybackKeepAliveService.java',
  'WebPlaybackPlugin.java',
  'SpotifySessionListenerService.java',
  'SpotifySessionPlugin.java',
  'ProviderSessionPlugin.java',
]
for (const file of nativeFiles) {
  const source = path.join(root, 'native', 'android', file)
  if (!fs.existsSync(source)) throw new Error(`Missing native Android source: native/android/${file}. Re-extract a complete SidePlay release.`)
}

const pkgDir = path.join(android, 'app', 'src', 'main', 'java', 'app', 'sideplay', 'mobile')
fs.mkdirSync(pkgDir, { recursive: true })
for (const file of nativeFiles) {
  fs.copyFileSync(path.join(root, 'native', 'android', file), path.join(pkgDir, file))
}

// Capacitor 8's PluginCall.reject(String, Exception) does not accept Throwable.
// Fail during patching rather than later in javac if a stale native source ever
// reintroduces call.reject(..., t) from a catch(Throwable t) block.
const bgAudioTarget = path.join(pkgDir, 'BackgroundAudioPlugin.java')
const bgAudioSource = fs.readFileSync(bgAudioTarget, 'utf8')
if (/call\.reject\([^;\n]*,\s*t\);/.test(bgAudioSource)) {
  throw new Error('BackgroundAudioPlugin passes Throwable directly to PluginCall.reject; Capacitor 8 requires Exception.')
}
if (!bgAudioSource.includes('asException(Throwable t)')) {
  throw new Error('BackgroundAudioPlugin is missing the Capacitor 8 Throwable-to-Exception bridge.')
}

// Defense in depth for users upgrading by extracting over an older SidePlay folder.
// Old R5/R6 sources used javax.annotation.Nonnull, which is not on modern Android's
// default javac classpath. The canonical v0.8.4 source is already clean; this makes
// the generated shell clean too even if Windows preserved an old file unexpectedly.
const downloaderTarget = path.join(pkgDir, 'SidePlayNewPipeDownloader.java')
let downloaderSource = fs.readFileSync(downloaderTarget, 'utf8')
downloaderSource = downloaderSource
  .replace(/^import\s+javax\.annotation\.Nonnull;\s*$/gm, '')
  .replace(/@Nonnull\s+/g, '')
fs.writeFileSync(downloaderTarget, downloaderSource)


const mainActivity = path.join(pkgDir, 'MainActivity.java')
fs.writeFileSync(mainActivity, `package app.sideplay.mobile;\n\nimport android.Manifest;\nimport android.content.Intent;\nimport android.os.Build;\nimport android.os.Bundle;\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n  @Override\n  public void onCreate(Bundle savedInstanceState) {\n    registerPlugin(BackgroundAudioPlugin.class);\n    registerPlugin(SharedTextPlugin.class);\n    registerPlugin(NativeYouTubePlugin.class);\n    registerPlugin(DirectDownloadPlugin.class);\n    registerPlugin(OfflineMediaPlugin.class);\n    registerPlugin(RollingCachePlugin.class);\n    registerPlugin(SourceResolverPlugin.class);\n    registerPlugin(YtDlpPlugin.class);\n    registerPlugin(WebPlaybackPlugin.class);\n    registerPlugin(SpotifySessionPlugin.class);\n    registerPlugin(ProviderSessionPlugin.class);\n    super.onCreate(savedInstanceState);\n\n    // Android 13+: ask once for media notification permission. Background playback\n    // itself is owned by MediaSessionService; this permission makes the controls\n    // visible in the notification shade when the OS requires it.\n    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {\n      requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9404);\n    }\n  }\n\n  // Kept for WebPlaybackPlugin compatibility. PiP is deliberately disabled.\n  public void setSidePlayPipEnabled(boolean enabled) {}\n  public void setWebPlaybackWanted(boolean wanted) {}\n\n  @Override\n  protected void onActivityResult(int requestCode, int resultCode, Intent data) {\n    if (SourceResolverPlugin.handleActivityResult(requestCode, resultCode, data)) return;\n    if (OfflineMediaPlugin.handleActivityResult(requestCode, resultCode, data)) return;\n    super.onActivityResult(requestCode, resultCode, data);\n  }\n\n  @Override\n  protected void onNewIntent(Intent intent) {\n    super.onNewIntent(intent);\n    setIntent(intent);\n  }\n}\n`)


// SidePlay v0.8.4 launcher identity. Keep the launcher assets source-controlled
// in this patcher because `cap add android` recreates Android's default icons.
const resDir = path.join(android, 'app', 'src', 'main', 'res')
const drawableDir = path.join(resDir, 'drawable')
const mipmapDir = path.join(resDir, 'mipmap-anydpi')
const mipmapV26Dir = path.join(resDir, 'mipmap-anydpi-v26')
const valuesDir = path.join(resDir, 'values')
for (const dir of [drawableDir, mipmapDir, mipmapV26Dir, valuesDir]) fs.mkdirSync(dir, { recursive: true })

const foregroundVector = `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#FFFFFFFF" android:pathData="M29,29 C29,25 32,22 36,22 L72,22 C76,22 79,24 81,28 L84,34 L42,34 C39,34 37,36 37,39 C37,42 39,44 42,44 L64,48 C75,50 83,60 83,71 C83,80 76,87 67,87 L34,87 C30,87 27,85 25,81 L22,75 L65,75 C68,75 70,73 70,70 C70,67 68,65 65,65 L43,61 C32,59 24,49 24,38 C24,34 26,31 29,29 Z"/>
    <path android:fillColor="#FFE62055" android:pathData="M48,45 L66,54 L48,63 Z"/>
</vector>
`
const legacyVector = `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
    <path android:fillColor="#FFE62055" android:pathData="M0,0 H108 V108 H0 Z"/>
    <path android:fillColor="#FFFFFFFF" android:pathData="M29,29 C29,25 32,22 36,22 L72,22 C76,22 79,24 81,28 L84,34 L42,34 C39,34 37,36 37,39 C37,42 39,44 42,44 L64,48 C75,50 83,60 83,71 C83,80 76,87 67,87 L34,87 C30,87 27,85 25,81 L22,75 L65,75 C68,75 70,73 70,70 C70,67 68,65 65,65 L43,61 C32,59 24,49 24,38 C24,34 26,31 29,29 Z"/>
    <path android:fillColor="#FFE62055" android:pathData="M48,45 L66,54 L48,63 Z"/>
</vector>
`
const adaptiveIcon = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/sideplay_launcher_background"/>
    <foreground android:drawable="@drawable/ic_launcher_foreground"/>
</adaptive-icon>
`
const notificationVector = `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">
    <path android:fillColor="#FFFFFFFF" android:pathData="M7,4 L20,12 L7,20 Z"/>
</vector>
`
fs.writeFileSync(path.join(drawableDir, 'ic_launcher_foreground.xml'), foregroundVector)
fs.writeFileSync(path.join(drawableDir, 'ic_sideplay_notification.xml'), notificationVector)
fs.writeFileSync(path.join(mipmapDir, 'ic_launcher.xml'), legacyVector)
fs.writeFileSync(path.join(mipmapDir, 'ic_launcher_round.xml'), legacyVector)
fs.writeFileSync(path.join(mipmapV26Dir, 'ic_launcher.xml'), adaptiveIcon)
fs.writeFileSync(path.join(mipmapV26Dir, 'ic_launcher_round.xml'), adaptiveIcon)
const sideplayColors = path.join(valuesDir, 'sideplay_colors.xml')
fs.writeFileSync(sideplayColors, `<?xml version="1.0" encoding="utf-8"?>
<resources><color name="sideplay_launcher_background">#E62055</color></resources>
`)
const sideplayStrings = path.join(valuesDir, 'sideplay_strings.xml')
fs.writeFileSync(sideplayStrings, `<?xml version="1.0" encoding="utf-8"?>
<resources><string name="sideplay_playback_channel_name">SidePlay playback</string></resources>
`)

const gradle = path.join(android, 'app', 'build.gradle')
let g = fs.readFileSync(gradle, 'utf8')
// NewPipeExtractor 0.26.5 uses newer java.nio APIs below Android 13. Capacitor's app
// template does not define compileOptions, so inject the required core-library desugaring.
if (!g.includes('coreLibraryDesugaringEnabled true')) {
  g = g.replace(/android\s*\{/, `android {\n    compileOptions {\n        coreLibraryDesugaringEnabled true\n        sourceCompatibility JavaVersion.VERSION_21\n        targetCompatibility JavaVersion.VERSION_21\n    }`)
}
g = g.replace(/versionCode\s+\d+/, 'versionCode 818')
g = g.replace(/versionName\s+["'][^"']+["']/, 'versionName "0.9.0-r10"')

const mediaDeps = [
  'implementation "io.github.junkfood02.youtubedl-android:library:0.18.1"',
  'implementation "io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1"',
  'implementation "androidx.media3:media3-exoplayer:1.8.1"',
  'implementation "androidx.media3:media3-exoplayer-hls:1.8.1"',
  'implementation "androidx.media3:media3-exoplayer-dash:1.8.1"',
  'implementation "androidx.media3:media3-exoplayer-rtsp:1.8.1"',
  'implementation "androidx.media3:media3-session:1.8.1"',
  'implementation "com.github.teamnewpipe:newpipeextractor:0.26.5"',
  'coreLibraryDesugaring "com.android.tools:desugar_jdk_libs_nio:2.1.5"',
]
for (const dep of mediaDeps) {
  if (!g.includes(dep)) g = g.replace(/dependencies\s*\{/, `dependencies {\n    ${dep}`)
}
fs.writeFileSync(gradle, g)

const rootGradle = path.join(android, 'build.gradle')
let rg = fs.readFileSync(rootGradle, 'utf8')
if (!rg.includes('https://jitpack.io')) {
  rg = rg.replace(/allprojects\s*\{\s*repositories\s*\{/, `allprojects {\n    repositories {\n        maven { url 'https://jitpack.io' }`)
}
fs.writeFileSync(rootGradle, rg)

const proguard = path.join(android, 'app', 'proguard-rules.pro')
let pg = fs.existsSync(proguard) ? fs.readFileSync(proguard, 'utf8') : ''
if (!pg.includes('org.mozilla.javascript')) {
  pg += `\n# NewPipeExtractor / Rhino\n-keep class org.mozilla.javascript.** { *; }\n-keep class org.mozilla.classfile.ClassFileWriter\n-dontwarn org.mozilla.javascript.tools.**\n`
  fs.writeFileSync(proguard, pg)
}

const manifest = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml')
let m = fs.readFileSync(manifest, 'utf8')
const perms = [
  '<uses-permission android:name="android.permission.INTERNET" />',
  '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
  '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />',
  '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '<uses-permission android:name="android.permission.WAKE_LOCK" />',
  '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
  '<uses-permission android:name="android.permission.REORDER_TASKS" />',
]
for (const p of perms) if (!m.includes(p)) m = m.replace(/<application/, `    ${p}\n    <application`)

// PiP is intentionally absent in the universal player architecture.
m = m.replace(/\s+android:supportsPictureInPicture="true"/g, '')
// Direct HTTP radio/media is common. SidePlay only treats explicit media URLs as playable.
if (!m.includes('android:usesCleartextTraffic=')) m = m.replace(/<application/, '<application android:usesCleartextTraffic="true"')
if (!m.includes('android:extractNativeLibs=')) m = m.replace(/<application/, '<application android:extractNativeLibs="true"')

if (!m.includes('YtDlpExtractorService')) {
  m = m.replace(/<\/application>/, `        <service
            android:name=".YtDlpExtractorService"
            android:process=":extractor"
            android:exported="false" />
    </application>`)
}

if (!m.includes('PlaybackService')) {
  m = m.replace(/<\/application>/, `        <service\n            android:name=".PlaybackService"\n            android:process=":playback"\n            android:stopWithTask="false"\n            android:foregroundServiceType="mediaPlayback"\n            android:exported="true">\n            <intent-filter>\n                <action android:name="androidx.media3.session.MediaSessionService" />\n                <action android:name="android.media.browse.MediaBrowserService" />\n            </intent-filter>\n        </service>\n    </application>`)
} else {
  // Scope attribute checks to PlaybackService's own opening <service> tag. A broad
  // [\s\S]* scan can accidentally see :extractor's android:process later in the
  // manifest and falsely conclude PlaybackService is already isolated.
  m = m.replace(/<service\b[^>]*android:name="\.PlaybackService"[^>]*>/, (tag) => {
    let out = tag
    if (!/android:process=/.test(out)) {
      out = out.replace('android:name=".PlaybackService"', 'android:name=".PlaybackService"\n            android:process=":playback"')
    }
    if (!/android:stopWithTask=/.test(out)) {
      out = out.replace('android:name=".PlaybackService"', 'android:name=".PlaybackService"\n            android:stopWithTask="false"')
    }
    return out
  })
}


if (m.includes('android:name=".PlaybackService"') && !m.includes('android.media.browse.MediaBrowserService')) {
  m = m.replace('<action android:name="androidx.media3.session.MediaSessionService" />', '<action android:name="androidx.media3.session.MediaSessionService" />\n                <action android:name="android.media.browse.MediaBrowserService" />')
}

if (!m.includes('androidx.media3.session.MediaButtonReceiver')) {
  m = m.replace(/<\/application>/, `        <receiver
            android:name="androidx.media3.session.MediaButtonReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
    </application>`)
}

if (!m.includes('MediaCaptureActivity')) {
  m = m.replace(/<\/application>/, `        <activity
            android:name=".MediaCaptureActivity"
            android:exported="false" />
    </application>`)
}

if (!m.includes('WebPlaybackKeepAliveService')) {
  m = m.replace(/<\/application>/, `        <service\n            android:name=".WebPlaybackKeepAliveService"\n            android:stopWithTask="true"\n            android:foregroundServiceType="mediaPlayback"\n            android:exported="false" />\n    </application>`)
}

// Provider and browser package visibility for Android 11+.
// The VIEW intent query lets us resolve the user's default browser without
// accidentally handing youtube.com straight back to the YouTube app.
const queries = `    <queries>
        <package android:name="com.spotify.music" />
        <package android:name="com.google.android.youtube" />
        <package android:name="com.google.android.apps.youtube.music" />
        <package android:name="com.soundcloud.android" />
        <package android:name="com.android.chrome" />
        <package android:name="com.google.android.apps.chrome" />
        <package android:name="com.sec.android.app.sbrowser" />
        <package android:name="com.brave.browser" />
        <package android:name="org.mozilla.firefox" />
        <package android:name="org.mozilla.fenix" />
        <package android:name="com.microsoft.emmx" />
        <package android:name="com.opera.browser" />
        <package android:name="com.vivaldi.browser" />
        <package android:name="com.kiwibrowser.browser" />
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <category android:name="android.intent.category.BROWSABLE" />
            <data android:scheme="https" />
        </intent>
    </queries>
`
m = m.replace(/\s*<queries>[\s\S]*?<\/queries>\s*/m, '\n')
m = m.replace(/<application/, `${queries}    <application`)
if (!m.includes('SpotifySessionListenerService')) {
  m = m.replace(/<\/application>/, `        <service\n            android:name=".SpotifySessionListenerService"\n            android:label="SidePlay provider media control"\n            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"\n            android:exported="true">\n            <intent-filter>\n                <action android:name="android.service.notification.NotificationListenerService" />\n            </intent-filter>\n        </service>\n    </application>`)
}
if (!m.includes('android.intent.action.SEND')) {
  m = m.replace(/(<activity[\s\S]*?<intent-filter>[\s\S]*?<\/intent-filter>)/, `$1\n            <intent-filter>\n                <action android:name="android.intent.action.SEND" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <data android:mimeType="text/plain" />\n            </intent-filter>`)
}
if (!m.includes('sideplay.media.share')) {
  m = m.replace(/<\/activity>/, `            <!-- sideplay.media.share -->
            <intent-filter>
                <action android:name="android.intent.action.SEND" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="audio/*" />
                <data android:mimeType="video/*" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:scheme="content" />
                <data android:scheme="file" />
                <data android:mimeType="audio/*" />
                <data android:mimeType="video/*" />
            </intent-filter>
        </activity>`)
}
fs.writeFileSync(manifest, m)
console.log('Android project patched: SidePlay v0.8.4 R8 Smart Radio + Playback Atomicity + Queue Integrity + Legacy Sanitizer + MediaSession + Process Shield. PiP remains disabled.')
