import type { Track } from '../types'

const YOUTUBE_ID = /^[A-Za-z0-9_-]{11}$/
const GENERIC_TITLES = new Set([
  '', 'untitled', 'untitled media', 'unknown', 'unknown media', 'media', 'video', 'audio',
])
const GENERIC_CHANNELS = new Set([
  '', 'youtube', 'youtube.com', 'www.youtube.com', 'unknown', 'unknown channel', 'unknown artist',
])

function youtubeIdFromUrl(value?: string) {
  if (!value) return null
  try {
    const url = new URL(value)
    const host = url.hostname.toLowerCase().replace(/^www\./, '')
    if (host === 'youtu.be') {
      const id = url.pathname.split('/').filter(Boolean)[0]
      return id && YOUTUBE_ID.test(id) ? id : null
    }
    if (host === 'youtube.com' || host.endsWith('.youtube.com')) {
      const direct = url.searchParams.get('v')
      if (direct && YOUTUBE_ID.test(direct)) return direct
      const parts = url.pathname.split('/').filter(Boolean)
      const marker = parts.findIndex((part) => ['shorts', 'embed', 'live'].includes(part))
      const id = marker >= 0 ? parts[marker + 1] : null
      return id && YOUTUBE_ID.test(id) ? id : null
    }
  } catch {}
  return null
}

function normalized(value?: string) {
  return (value || '').trim().toLowerCase().replace(/\s+/g, ' ')
}

export function isGenericTrackTitle(value?: string, videoId?: string) {
  const title = normalized(value)
  if (GENERIC_TITLES.has(title)) return true
  if (videoId && title === normalized(videoId)) return true
  if (/^youtube video [a-z0-9_-]{11}$/i.test(title)) return true
  if (/^(?:video|media|audio) [a-z0-9_-]{6,}$/i.test(title)) return true
  return false
}

export function isGenericTrackChannel(value?: string) {
  const channel = normalized(value)
  if (GENERIC_CHANNELS.has(channel)) return true
  return /^(?:youtube|web|direct|unknown)(?:\s+(?:audio|video|media))?$/.test(channel)
}

function fallbackTitle(track: Partial<Track>) {
  if (track.provider === 'youtube' && track.videoId && YOUTUBE_ID.test(track.videoId)) {
    return `YouTube video ${track.videoId}`
  }
  try {
    if (track.sourceUrl) {
      const url = new URL(track.sourceUrl)
      const leaf = decodeURIComponent(url.pathname.split('/').filter(Boolean).pop() || '')
        .replace(/\.[a-z0-9]{2,5}$/i, '')
        .replace(/[-_]+/g, ' ')
        .trim()
      if (leaf) return leaf
      if (url.hostname) return url.hostname.replace(/^www\./, '')
    }
  } catch {}
  return 'Media item'
}

/**
 * Merge resolver/provider metadata without allowing low-quality placeholders to
 * overwrite a title/channel that SidePlay already knows. Technical resolver fields
 * still come from `incoming`; only human-facing identity is quality-aware.
 */
export function mergeTrackMetadata<T extends Track>(base: T, incoming: Partial<Track>): T {
  const merged = { ...base, ...incoming } as T
  const incomingId = incoming.videoId || base.videoId
  const baseTitleGood = !isGenericTrackTitle(base.title, base.videoId)
  const incomingTitleGood = !isGenericTrackTitle(incoming.title, incomingId)
  const baseChannelGood = !isGenericTrackChannel(base.channel)
  const incomingChannelGood = !isGenericTrackChannel(incoming.channel)

  merged.title = incomingTitleGood
    ? String(incoming.title).trim()
    : baseTitleGood
      ? base.title.trim()
      : fallbackTitle(merged)

  merged.channel = incomingChannelGood
    ? String(incoming.channel).trim()
    : baseChannelGood
      ? base.channel.trim()
      : merged.provider === 'youtube'
        ? 'YouTube'
        : (() => {
            try { return merged.sourceUrl ? new URL(merged.sourceUrl).hostname.replace(/^www\./, '') : 'Unknown source' }
            catch { return 'Unknown source' }
          })()

  merged.thumbnail = (incoming.thumbnail || '').trim() || (base.thumbnail || '').trim()
  // R10 single identity boundary: every metadata merge exits through the same
  // provider/canonical repair path. A resolver cannot quietly create a second
  // malformed representation of the same YouTube item.
  return repairTrackIdentity(merged)
}

function looksLikeYouTube(track: Track) {
  if (track.provider === 'youtube') return true
  if (youtubeIdFromUrl(track.sourceUrl)) return true
  if (!YOUTUBE_ID.test(track.videoId || '')) return false
  const fingerprint = `${track.thumbnail || ''} ${track.channel || ''}`.toLowerCase()
  return fingerprint.includes('ytimg.com') || fingerprint.includes('youtube')
}

/**
 * Repairs lightweight/legacy YouTube catalog entries before they reach the generic
 * Web resolver. Older SidePlay builds stored recommendations with only videoId,
 * title/channel and thumbnail, which made end-of-track autoplay degrade into
 * "Web could not be resolved" after persistence/relaunch.
 */
export function repairTrackIdentity<T extends Track>(input: T): T {
  if (!input) return input
  const urlId = youtubeIdFromUrl(input.sourceUrl)
  if (!looksLikeYouTube(input)) return input
  const videoId = urlId || input.videoId
  if (!videoId || !YOUTUBE_ID.test(videoId)) return input
  return {
    ...input,
    videoId,
    provider: 'youtube',
    sourceUrl: `https://www.youtube.com/watch?v=${videoId}`,
    mediaKind: input.mediaKind || 'audio',
    audioPreferred: input.audioPreferred ?? true,
  } as T
}

export function repairTrackList<T extends Track>(items: T[] | undefined | null): T[] {
  return (items || []).map((item) => repairTrackIdentity(item))
}

export function hasGenericYouTubeMetadata(track: Track) {
  if (track.provider !== 'youtube') return false
  return isGenericTrackTitle(track.title, track.videoId) || isGenericTrackChannel(track.channel)
}
