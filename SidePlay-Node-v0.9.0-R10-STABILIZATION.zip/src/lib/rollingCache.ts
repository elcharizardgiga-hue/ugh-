import { registerPlugin } from '@capacitor/core'
import type { OfflineCopy, Track } from '../types'
import { isNative } from './nativeAudio'

export type RollingCacheStats = {
  entries: number
  bytes: number
  maxBytesDefault?: number
  inFlight?: number
}

type RollingCacheEntry = {
  hit: boolean
  videoId: string
  localUri?: string
  filename?: string
  mimeType?: string
  bytes?: number
  title?: string
  cachedAt?: number
  lastAccessAt?: number
  rolling?: boolean
}

interface RollingCachePlugin {
  lookup(options: { videoId: string }): Promise<RollingCacheEntry>
  cache(options: {
    videoId: string
    title: string
    url: string
    mimeType?: string
    requestHeaders?: Record<string, string>
  }): Promise<RollingCacheEntry>
  prune(options: { keepIdsJson: string; maxBytes?: number }): Promise<RollingCacheStats>
  remove(options: { videoId: string }): Promise<void>
  clear(): Promise<RollingCacheStats>
  stats(): Promise<RollingCacheStats>
}

const RollingCache = registerPlugin<RollingCachePlugin>('RollingCache')
const inflight = new Map<string, Promise<OfflineCopy | null>>()

const SEGMENTED = /\.(m3u8|mpd)(?:$|[?#])/i
const HTTP = /^https?:\/\//i

function directCandidate(track: Track) {
  const candidate = track.downloadUrl || track.playbackUrl || ''
  if (!HTTP.test(candidate) || SEGMENTED.test(candidate)) return ''
  const mime = (track.mimeType || '').toLowerCase()
  if (mime.includes('mpegurl') || mime.includes('dash+xml')) return ''
  return candidate
}

function copyFromEntry(track: Track, entry: RollingCacheEntry): OfflineCopy | null {
  if (!entry.hit || !entry.localUri) return null
  return {
    videoId: track.videoId,
    localUri: entry.localUri,
    filename: entry.filename || `${track.videoId}.media`,
    mimeType: entry.mimeType || track.mimeType,
    bytes: entry.bytes,
    addedAt: entry.cachedAt || Date.now(),
    platform: 'android',
    title: track.title,
    channel: track.channel,
    thumbnail: track.thumbnail,
    provider: track.provider,
    sourceUrl: track.sourceUrl,
    mediaKind: track.mediaKind,
  }
}

export async function lookupRollingCopy(track: Track): Promise<OfflineCopy | null> {
  if (!isNative() || !track.videoId) return null
  try {
    return copyFromEntry(track, await RollingCache.lookup({ videoId: track.videoId }))
  } catch {
    return null
  }
}

export async function cacheRollingTrack(track: Track): Promise<OfflineCopy | null> {
  if (!isNative() || !track.videoId) return null
  const existing = await lookupRollingCopy(track)
  if (existing) return existing

  const url = directCandidate(track)
  if (!url) return null
  const previous = inflight.get(track.videoId)
  if (previous) return previous

  const task = RollingCache.cache({
    videoId: track.videoId,
    title: track.title,
    url,
    mimeType: track.mimeType,
    requestHeaders: track.requestHeaders,
  })
    .then((entry) => copyFromEntry(track, entry))
    .catch(() => null)
    .finally(() => inflight.delete(track.videoId))

  inflight.set(track.videoId, task)
  return task
}

export async function pruneRollingCache(keepIds: string[], maxBytes = 768 * 1024 * 1024) {
  if (!isNative()) return { entries: 0, bytes: 0 } as RollingCacheStats
  const unique = [...new Set(keepIds.filter(Boolean))]
  return RollingCache.prune({ keepIdsJson: JSON.stringify(unique), maxBytes })
}

export async function getRollingCacheStats(): Promise<RollingCacheStats> {
  if (!isNative()) return { entries: 0, bytes: 0, inFlight: 0 }
  try { return await RollingCache.stats() }
  catch { return { entries: 0, bytes: 0, inFlight: inflight.size } }
}

export async function clearRollingCache() {
  if (!isNative()) return { entries: 0, bytes: 0 } as RollingCacheStats
  inflight.clear()
  return RollingCache.clear()
}

export function rollingCacheInFlight() {
  return inflight.size
}
