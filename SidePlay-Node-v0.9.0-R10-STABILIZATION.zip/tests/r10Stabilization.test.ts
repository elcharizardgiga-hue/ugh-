import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { playbackMachine } from '../src/lib/playbackMachine.ts'

const read = (file: string) => fs.readFileSync(path.resolve(file), 'utf8')

test('R10 release identity is monotonic and TypeScript pin is valid', () => {
  const pkg = JSON.parse(read('package.json'))
  const patch = read('scripts/patch-android.mjs')
  assert.equal(pkg.version, '0.9.0-r10')
  assert.equal(pkg.devDependencies.typescript, '5.8.3')
  assert.match(patch, /versionCode 818/)
  assert.match(patch, /versionName "0\.9\.0-r10"/)
})

test('playback machine exposes explicit deterministic phases', () => {
  const resolving = playbackMachine.transition('resolving', 'track-a', 'test-resolve')
  assert.equal(resolving.phase, 'resolving')
  assert.equal(resolving.trackId, 'track-a')
  const preparing = playbackMachine.transition('preparing', 'track-a', 'test-prepare')
  assert.equal(preparing.previous, 'resolving')
  const playing = playbackMachine.transition('playing', 'track-a', 'test-play')
  assert.equal(playing.previous, 'preparing')
  assert.ok(playing.transitions >= 3)
})

test('rolling cache is persistent, app managed, and wired into Capacitor', () => {
  const rolling = read('native/android/RollingCachePlugin.java')
  const js = read('src/lib/rollingCache.ts')
  const patch = read('scripts/patch-android.mjs')
  assert.match(rolling, /getFilesDir\(\), "rolling-cache"/)
  assert.match(rolling, /DEFAULT_MAX_BYTES = 768L \* 1024L \* 1024L/)
  assert.match(rolling, /Rolling cache currently stores progressive media only/)
  assert.match(js, /pruneRollingCache\(keepIds: string\[\], maxBytes = 768 \* 1024 \* 1024\)/)
  assert.match(patch, /RollingCachePlugin\.java/)
  assert.match(patch, /registerPlugin\(RollingCachePlugin\.class\)/)
})

test('rolling cache keeps a previous/current/next window and fills next twenty', () => {
  const app = read('src/App.tsx')
  assert.match(app, /currentIndex - 20/)
  assert.match(app, /currentIndex \+ 20/)
  assert.match(app, /currentIndex \+ 21/)
  assert.match(app, /pruneRollingCache\(keepIds\)/)
  assert.match(app, /cacheRollingTrack\(candidate\)/)
  assert.match(app, /remaining >= 20/)
  assert.match(app, /slice\(0, 24\)/)
})

test('offline playback consults rolling bytes before any network resolver', () => {
  const app = read('src/App.tsx')
  const lookup = app.indexOf('rollingTarget = await lookupRollingCopy(track)')
  const resolver = app.indexOf('const needsResolution =')
  assert.ok(lookup >= 0)
  assert.ok(resolver > lookup)
  assert.match(app, /localCopy = explicitLocalCopy \|\| rollingTarget/)
})

test('download accelerator promotes rolling bytes and avoids double heavy extraction', () => {
  const app = read('src/App.tsx')
  const offline = read('src/lib/offlineMedia.ts')
  const native = read('native/android/OfflineMediaPlugin.java')
  const ytdlp = read('native/android/YtDlpPlugin.java')

  assert.match(app, /promoteRollingOfflineCopy\(track, rolling\)/)
  assert.match(app, /allowHeavyFallback: false/)
  assert.match(offline, /R10 DOWNLOAD ACCELERATOR/)
  assert.match(native, /promoteRolling\(PluginCall call\)/)
  assert.match(native, /SidePlayRollingPromote/)
  assert.match(native, /1024 \* 1024/)
  assert.match(ytdlp, /--concurrent-fragments/)
  assert.match(ytdlp, /downloadMode \? "4" : "1"/)
  assert.match(ytdlp, /--http-chunk-size/)
  assert.match(ytdlp, /if \(!audioOnly\) ensureFfmpegInitialized/)
})

test('Queue v2 canonical-dedupes while preserving manual intent ahead of autoplay', () => {
  const store = read('src/lib/store.tsx')
  assert.match(store, /const uniqueQueueTracks/)
  assert.match(store, /canonicalTrackKey\(raw\)/)
  assert.match(store, /existing\.queueOrigin === 'manual' \|\| raw\.queueOrigin === 'manual'/)
  assert.match(store, /const manual = upcoming\.filter/)
  assert.match(store, /const autoplay = upcoming\.filter/)
  assert.match(store, /\.\.\.manual,[\s\S]*\.\.\.incomingManual,[\s\S]*\.\.\.autoplay,[\s\S]*\.\.\.incomingAutoplay/)
})

test('resolver health router has breakers for all three YouTube engines', () => {
  const native = read('native/android/NativeYouTubePlugin.java')
  const ts = read('src/lib/nativeYouTube.ts')
  assert.match(native, /newPipeCooldownUntilMs/)
  assert.match(native, /innerTubeCooldownUntilMs/)
  assert.match(native, /ytdlpCooldownUntilMs/)
  assert.match(native, /newPipeFailureStreak >= 3/)
  assert.match(native, /innerTubeFailureStreak >= 3/)
  assert.match(ts, /newPipeCooldownMs: number/)
})

test('Taste is inspectable instead of opaque', () => {
  const taste = read('src/lib/tasteEngine.ts')
  const app = read('src/App.tsx')
  assert.match(taste, /export function getTasteDiagnostics/)
  assert.match(taste, /GLOBAL_HALF_LIFE/)
  assert.match(taste, /SESSION_HALF_LIFE/)
  assert.match(app, /function TasteProfileSettings/)
  assert.match(app, /Your Taste/)
  assert.match(app, /Taste leaders/)
})

test('HF3 cohesion repairs remain present in R10', () => {
  const app = read('src/App.tsx')
  const css = read('src/styles.css')
  const lyrics = read('src/lib/lyrics.ts')
  const identity = read('src/lib/trackIdentity.ts')
  assert.match(identity, /mergeTrackMetadata/)
  assert.match(identity, /untitled media/)
  assert.match(app, /searchRequestRef/)
  assert.match(app, /suggestionRequestRef/)
  assert.match(css, /\.now-playing\{[^}]*overflow-y:auto/)
  assert.match(lyrics, /lrclib\.net\/api/)
  assert.match(lyrics, /parseLrc/)
})

test('HF2 playback resurrection remains present in R10', () => {
  const service = read('native/android/PlaybackService.java')
  const diag = read('native/android/BackgroundAudioPlugin.java')
  assert.match(service, /START_STICKY/)
  assert.match(service, /recoverSnapshot/)
  assert.match(service, /process-resurrection/)
  assert.match(diag, /LOW_MEMORY/)
  assert.match(diag, /PACKAGE_UPDATED/)
})
