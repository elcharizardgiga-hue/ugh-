package app.sideplay.mobile;

import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.Collections;
import java.util.List;

@CapacitorPlugin(name = "SpotifySession")
public class SpotifySessionPlugin extends Plugin {
    private static final String SPOTIFY_PACKAGE = "com.spotify.music";

    @PluginMethod
    public void hasAccess(PluginCall call) {
        JSObject out = new JSObject();
        out.put("granted", notificationAccessGranted());
        out.put("spotifyInstalled", spotifyInstalled());
        call.resolve(out);
    }

    @PluginMethod
    public void openAccessSettings(PluginCall call) {
        try {
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open Notification Access settings.", e);
        }
    }

    @PluginMethod
    public void openSpotify(PluginCall call) {
        try {
            Intent intent = getContext().getPackageManager().getLaunchIntentForPackage(SPOTIFY_PACKAGE);
            if (intent == null) {
                call.reject("Spotify is not installed.");
                return;
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open Spotify.", e);
        }
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject out = buildStatus(findSpotifyController());
        out.put("accessGranted", notificationAccessGranted());
        out.put("spotifyInstalled", spotifyInstalled());
        call.resolve(out);
    }

    @PluginMethod
    public void playFromSearch(PluginCall call) {
        String query = call.getString("query", "").trim();
        String title = call.getString("title", "").trim();
        String artist = call.getString("artist", "").trim();
        if (query.isEmpty()) {
            call.reject("query is required.");
            return;
        }
        MediaController controller = requireController(call);
        if (controller == null) return;
        try {
            // Android's documented song-search contract: tell the receiving media
            // app that this is a SONG lookup and pass structured title/artist extras.
            // v0.3.2 only supplied the focus value, which let Spotify treat the
            // request as an ambiguous/resume-current command on some builds.
            Bundle extras = new Bundle();
            extras.putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio");
            extras.putString(SearchManager.QUERY, query);
            if (!title.isEmpty()) extras.putString(MediaStore.EXTRA_MEDIA_TITLE, title);
            if (!artist.isEmpty()) extras.putString(MediaStore.EXTRA_MEDIA_ARTIST, artist);

            controller.getTransportControls().playFromSearch(query, extras);
            JSObject out = buildStatus(controller);
            out.put("accepted", true);
            out.put("query", query);
            out.put("requestedTitle", title);
            out.put("requestedArtist", artist);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Spotify media session rejected play-from-search.", e);
        }
    }

    @PluginMethod
    public void playFromUri(PluginCall call) {
        String raw = call.getString("uri", "").trim();
        if (raw.isEmpty()) {
            call.reject("uri is required.");
            return;
        }
        MediaController controller = requireController(call);
        if (controller == null) return;
        try {
            controller.getTransportControls().playFromUri(Uri.parse(raw), Bundle.EMPTY);
            JSObject out = buildStatus(controller);
            out.put("accepted", true);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Spotify media session rejected play-from-uri.", e);
        }
    }

    @PluginMethod public void play(PluginCall call) { transport(call, "play"); }
    @PluginMethod public void pause(PluginCall call) { transport(call, "pause"); }
    @PluginMethod public void next(PluginCall call) { transport(call, "next"); }
    @PluginMethod public void previous(PluginCall call) { transport(call, "previous"); }

    @PluginMethod
    public void seek(PluginCall call) {
        Long position = call.getLong("positionMs");
        if (position == null) { call.reject("positionMs is required."); return; }
        MediaController controller = requireController(call);
        if (controller == null) return;
        try {
            controller.getTransportControls().seekTo(Math.max(0L, position));
            call.resolve(buildStatus(controller));
        } catch (Exception e) {
            call.reject("Spotify seek failed.", e);
        }
    }

    private void transport(PluginCall call, String action) {
        MediaController controller = requireController(call);
        if (controller == null) return;
        try {
            switch (action) {
                case "play": controller.getTransportControls().play(); break;
                case "pause": controller.getTransportControls().pause(); break;
                case "next": controller.getTransportControls().skipToNext(); break;
                case "previous": controller.getTransportControls().skipToPrevious(); break;
                default: throw new IllegalArgumentException("Unknown action");
            }
            call.resolve(buildStatus(controller));
        } catch (Exception e) {
            call.reject("Spotify " + action + " failed.", e);
        }
    }

    private MediaController requireController(PluginCall call) {
        if (!notificationAccessGranted()) {
            call.reject("SidePlay needs Notification Access to control Spotify's media session.");
            return null;
        }
        MediaController controller = findSpotifyController();
        if (controller == null) {
            call.reject("No active Spotify media session. Open Spotify and play anything once, then return to SidePlay.");
            return null;
        }
        return controller;
    }

    private MediaController findSpotifyController() {
        if (!notificationAccessGranted()) return null;
        try {
            MediaSessionManager manager = (MediaSessionManager) getContext().getSystemService(Context.MEDIA_SESSION_SERVICE);
            if (manager == null) return null;
            ComponentName listener = new ComponentName(getContext(), SpotifySessionListenerService.class);
            List<MediaController> controllers = manager.getActiveSessions(listener);
            if (controllers == null) controllers = Collections.emptyList();
            for (MediaController controller : controllers) {
                if (SPOTIFY_PACKAGE.equals(controller.getPackageName())) return controller;
            }
        } catch (SecurityException ignored) {
        }
        return null;
    }

    private boolean notificationAccessGranted() {
        String flat = Settings.Secure.getString(getContext().getContentResolver(), "enabled_notification_listeners");
        if (flat == null || flat.isEmpty()) return false;
        String packageName = getContext().getPackageName();
        for (String entry : flat.split(":")) {
            ComponentName component = ComponentName.unflattenFromString(entry);
            if (component != null && packageName.equals(component.getPackageName())) return true;
        }
        return false;
    }

    private boolean spotifyInstalled() {
        try {
            getContext().getPackageManager().getPackageInfo(SPOTIFY_PACKAGE, 0);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private JSObject buildStatus(MediaController controller) {
        JSObject out = new JSObject();
        out.put("sessionAvailable", controller != null);
        if (controller == null) return out;

        PlaybackState state = controller.getPlaybackState();
        long actions = state == null ? 0L : state.getActions();
        int stateCode = state == null ? PlaybackState.STATE_NONE : state.getState();
        long position = state == null ? 0L : Math.max(0L, state.getPosition());
        boolean playing = stateCode == PlaybackState.STATE_PLAYING || stateCode == PlaybackState.STATE_BUFFERING;

        out.put("packageName", controller.getPackageName());
        out.put("playing", playing);
        out.put("state", stateCode);
        out.put("positionMs", position);
        out.put("actions", actions);
        out.put("supportsPlayFromSearch", (actions & PlaybackState.ACTION_PLAY_FROM_SEARCH) != 0L);
        out.put("supportsPlayFromUri", (actions & PlaybackState.ACTION_PLAY_FROM_URI) != 0L);
        out.put("supportsSeek", (actions & PlaybackState.ACTION_SEEK_TO) != 0L);

        MediaMetadata metadata = controller.getMetadata();
        if (metadata != null) {
            out.put("title", metadata.getString(MediaMetadata.METADATA_KEY_TITLE));
            out.put("artist", metadata.getString(MediaMetadata.METADATA_KEY_ARTIST));
            out.put("album", metadata.getString(MediaMetadata.METADATA_KEY_ALBUM));
            out.put("mediaId", metadata.getString(MediaMetadata.METADATA_KEY_MEDIA_ID));
            out.put("durationMs", Math.max(0L, metadata.getLong(MediaMetadata.METADATA_KEY_DURATION)));
        } else {
            out.put("durationMs", 0L);
        }
        return out;
    }
}
