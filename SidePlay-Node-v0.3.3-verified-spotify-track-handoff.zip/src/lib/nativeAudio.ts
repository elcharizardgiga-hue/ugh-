import { Capacitor, registerPlugin, type PluginListenerHandle } from '@capacitor/core'

export type NativeMedia = {
  url: string
  title: string
  artist?: string
  artwork?: string
  positionMs?: number
}

export type NativePlaybackStatus = {
  active: boolean
  playing: boolean
  positionMs: number
  durationMs: number
  playbackState?: number
}

interface BackgroundAudioPlugin {
  play(options: NativeMedia): Promise<void>
  pause(): Promise<void>
  resume(): Promise<void>
  stop(): Promise<void>
  seek(options: { positionMs: number }): Promise<NativePlaybackStatus>
  getStatus(): Promise<NativePlaybackStatus>
  getBackgroundHealth(): Promise<{ unrestricted: boolean; androidVersion: number }>
  openBackgroundSettings(): Promise<void>
  addListener(eventName: 'playbackState', listener: (event: { state: 'playing' | 'paused' | 'ready' | 'buffering' | 'ended' | 'error'; positionMs?: number; durationMs?: number; message?: string }) => void): Promise<PluginListenerHandle>
}

interface SharedTextPlugin {
  getInitialShare(): Promise<{ text?: string }>
}

interface WebPlaybackPlugin {
  start(options: { title?: string; artist?: string }): Promise<{ active: boolean }>
  stop(): Promise<void>
  getStatus(): Promise<{ active: boolean; pipSupported?: boolean; inPip?: boolean }>
  setPipEnabled(options: { enabled: boolean }): Promise<{ enabled: boolean }>
}

export const BackgroundAudio = registerPlugin<BackgroundAudioPlugin>('BackgroundAudio')
export const SharedText = registerPlugin<SharedTextPlugin>('SharedText')
export const WebPlayback = registerPlugin<WebPlaybackPlugin>('WebPlayback')

export const isNative = () => Capacitor.isNativePlatform()

export type SpotifySessionStatus = {
  accessGranted?: boolean
  spotifyInstalled?: boolean
  sessionAvailable: boolean
  packageName?: string
  playing?: boolean
  state?: number
  positionMs?: number
  durationMs?: number
  actions?: number
  supportsPlayFromSearch?: boolean
  supportsPlayFromUri?: boolean
  supportsSeek?: boolean
  title?: string
  artist?: string
  album?: string
  mediaId?: string
  accepted?: boolean
  query?: string
}

interface SpotifySessionPlugin {
  hasAccess(): Promise<{ granted: boolean; spotifyInstalled: boolean }>
  openAccessSettings(): Promise<void>
  openSpotify(): Promise<void>
  getStatus(): Promise<SpotifySessionStatus>
  playFromSearch(options: { query: string; title?: string; artist?: string }): Promise<SpotifySessionStatus>
  playFromUri(options: { uri: string }): Promise<SpotifySessionStatus>
  play(): Promise<SpotifySessionStatus>
  pause(): Promise<SpotifySessionStatus>
  next(): Promise<SpotifySessionStatus>
  previous(): Promise<SpotifySessionStatus>
  seek(options: { positionMs: number }): Promise<SpotifySessionStatus>
}

export const SpotifySession = registerPlugin<SpotifySessionPlugin>('SpotifySession')
