# SidePlay v0.3.3 — verified Spotify track handoff

- Fixes the false-positive Spotify takeover seen in v0.3.2, where SidePlay showed `SPOTIFY · BACKGROUND` while Spotify simply resumed the previously loaded song.
- Sends Android's documented structured song-search extras: media focus, title, artist, and query.
- Pauses the old Spotify item before issuing the search so a later `play()` cannot accidentally resume the wrong track.
- Verifies Spotify metadata actually matches the requested SidePlay song before declaring the Spotify engine active.
- Only calls Spotify `play()` after the requested metadata has been observed.
- If Spotify ignores the requested song, SidePlay now reports the exact track Spotify stayed on.
- Removes the remaining PiP UI/setup code; Android patching continues to strip PiP from the manifest.
