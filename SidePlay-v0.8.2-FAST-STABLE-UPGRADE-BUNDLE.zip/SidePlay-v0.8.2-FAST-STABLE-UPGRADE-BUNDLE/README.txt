SIDEPLAY v0.8.2 — FAST / STABLE / HEADLESS UPGRADE BUNDLE

This bundle contains the exact v0.8.2 source patch and matching GitHub build workflow.

It upgrades the v0.8.1 STAY-INSIDE source to v0.8.2 with:
- lightweight YouTube catalog search (no yt-dlp/Python boot just to search)
- provider-specific heavy search only on explicit provider tabs
- headless normal Play path (no automatic MediaCaptureActivity/browser/YouTube handoff)
- lazy FFmpeg initialization only for download/merge work
- yt-dlp updater moved off the Play critical path
- bounded yt-dlp socket/retry settings
- PlaybackService marker updated to SidePlay/0.8.2
- build versionName 0.8.2 / versionCode 802
- ARM64-only APK in the supplied fast/stable workflow

PATCH SOURCE:
Run PATCH_SIDEPLAY_V082.py from the root of the extracted
SidePlay-Node-v0.8.1-STAY-INSIDE-BACKGROUND source tree.

GITHUB:
The workflow in .github/workflows/build-sideplay-v0.8.2.yml performs the patch/build automatically from the v0.8.1 source ZIP in repo root.

NOTE:
This is the v0.8.2 upgrade bundle, not a reconstructed copy of the complete v0.8.1 source archive.
