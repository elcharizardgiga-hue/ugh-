from pathlib import Path
import json, re

# ---------------- version ----------------
p = Path('package.json')
pkg = json.loads(p.read_text(encoding='utf-8'))
pkg['version'] = '0.8.2'
p.write_text(json.dumps(pkg, indent=2) + '\n', encoding='utf-8')

# ---------------- App: fast catalog search + headless playback ----------------
p = Path('src/App.tsx')
s = p.read_text(encoding='utf-8')

# Replace the Android yt-dlp-first YouTube catalog search with the already-existing
# lightweight keyless HTTP search. yt-dlp should not boot just to render results.
pat = re.compile(
    r"        if \(scope === 'all' \|\| scope === 'youtube'\) \{.*?\n        \}\n\n        // On Android, \"All\" also searches SoundCloud through yt-dlp itself\.",
    re.S,
)
replacement = '''        if (scope === 'all' || scope === 'youtube') {
          // v0.8.2 FAST PATH: catalog search stays lightweight. Python/yt-dlp
          // starts only after the user actually taps a result.
          jobs.push(searchYouTube(q, sp.state.youtubeApiKey)
            .then((found) => ({
              name: 'YouTube',
              tracks: found.slice(0, scope === 'all' ? 16 : 30).map((track) => ({
                ...track,
                provider: 'youtube' as const,
                sourceUrl: `https://www.youtube.com/watch?v=${track.videoId}`,
                ...(scope === 'all' ? { mediaKind: 'audio' as const, audioPreferred: true } : {})
              }))
            }))
            .catch((e: any) => ({ name: 'YouTube', tracks: [], error: e?.message || 'unavailable' })))
        }

        // SoundCloud's native yt-dlp search is intentionally explicit-tab only.'''
s2, n = pat.subn(replacement, s, count=1)
if n != 1:
    raise SystemExit(f'FAST SEARCH patch failed: expected 1 YouTube search block, found {n}')
s = s2

# Music is the fast default catalog. Provider-specific discovery remains in its
# own tabs instead of delaying every generic music search.
s, n_audius = re.subn(
    r"if \(scope === 'all' \|\| scope === 'audius'\) jobs\.push",
    "if (scope === 'audius') jobs.push",
    s,
    count=1,
)
s, n_peer = re.subn(
    r"if \(scope === 'all' \|\| scope === 'peertube'\) jobs\.push",
    "if (scope === 'peertube') jobs.push",
    s,
    count=1,
)
if n_audius != 1 or n_peer != 1:
    raise SystemExit(f'FAST SEARCH provider-scope patch failed: audius={n_audius}, peertube={n_peer}')

# In Music/All, don't block initial results on a second Python yt-dlp search.
s, n = re.subn(
    r"if \(\(scope === 'all' \|\| scope === 'soundcloud'\) && isNative\(\)\) jobs\.push\(searchWithYtDlp\(q, 'soundcloud', scope === 'all' \? 8 : 25\)",
    "if (scope === 'soundcloud' && isNative()) jobs.push(searchWithYtDlp(q, 'soundcloud', 25)",
    s,
    count=1,
)
if n != 1:
    raise SystemExit(f'FAST SEARCH patch failed: SoundCloud all-scope target count={n}')

# Normal Play must never launch MediaCaptureActivity. Keep explicit/manual capture
# controls elsewhere, but auto-catcher calls from play() become an inline failure.
play_start = s.find('  async function play(')
play_end = s.find('  function previous()', play_start)
if play_start < 0 or play_end < 0:
    raise SystemExit('Could not locate App.tsx play() function')
play = s[play_start:play_end]
catcher = "captureUniversalUrl(track.sourceUrl, { auto: true })"
catcher_count = play.count(catcher)
if catcher_count < 1:
    raise SystemExit('HEADLESS PLAY patch failed: no automatic catcher call in play()')
play = play.replace(catcher, "Promise.reject(new Error('SidePlay could not resolve a native stream for this result.'))")
s = s[:play_start] + play + s[play_end:]

# Make the UI promise match the architecture.
s = s.replace(
    'Search songs, artists, videos, or paste a link. SidePlay resolves playback automatically.',
    'Search instantly. SidePlay extracts only after you tap a result.'
)
p.write_text(s, encoding='utf-8')

# ---------------- yt-dlp: keep heavy work off critical path ----------------
p = Path('native/android/YtDlpPlugin.java')
s = p.read_text(encoding='utf-8')

# Add a separately-lazy FFmpeg init. Search/play stream extraction does not need it.
marker = 'private static volatile boolean initialized = false;'
if marker not in s:
    raise SystemExit('YtDlpPlugin initialized marker missing')
if 'ffmpegInitialized' not in s:
    s = s.replace(
        marker,
        marker + '\n    private static final Object FFMPEG_INIT_LOCK = new Object();\n    private static volatile boolean ffmpegInitialized = false;',
        1,
    )

# YoutubeDL init only. Do not initialize ~35MB FFmpeg or synchronously update yt-dlp
# before a simple playback resolution.
init_pat = re.compile(
    r"\s*YoutubeDL\.getInstance\(\)\.init\(context\);\s*\n\s*FFmpeg\.getInstance\(\)\.init\(context\);\s*\n\s*initialized = true;\s*\n\s*maybeUpdateExtractor\(context, false\);",
    re.M,
)
init_repl = '''
            YoutubeDL.getInstance().init(context);
            initialized = true;'''
s, n = init_pat.subn(init_repl, s, count=1)
if n != 1:
    # Accept an already-partially-patched tree, but still make sure FFmpeg is not in init.
    ensure_block = re.search(r'public static void ensureInitialized\(Context context\).*?\n    \}', s, re.S)
    if not ensure_block or 'FFmpeg.getInstance().init(context)' in ensure_block.group(0):
        raise SystemExit(f'YtDlpPlugin heavy init patch failed, count={n}')

# On extraction failure, return promptly and schedule the updater in the background.
# The old code updated over the network and retried synchronously, making a tap hang.
retry_pat = re.compile(
    r"        try \{\s*\n            return resolveInternal\(source, audioOnly\);\s*\n        \} catch \(Exception first\) \{\s*\n            maybeUpdateExtractor\(context, true\);\s*\n            return resolveInternal\(source, audioOnly\);\s*\n        \}",
    re.M,
)
retry_repl = '''        try {
            return resolveInternal(source, audioOnly);
        } catch (Exception first) {
            Context appContext = context.getApplicationContext();
            new Thread(() -> maybeUpdateExtractor(appContext, true), "SidePlayYtDlpUpdater").start();
            throw first;
        }'''
s, n = retry_pat.subn(retry_repl, s, count=1)
if n != 1 and 'SidePlayYtDlpUpdater' not in s:
    raise SystemExit(f'YtDlpPlugin sync-update retry patch failed, count={n}')

# Lazy FFmpeg helper.
anchor = '    public static JSObject resolveForPlayback(Context context, String source) throws Exception {'
if 'ensureFfmpegInitialized' not in s:
    helper = '''    private static void ensureFfmpegInitialized(Context context) throws Exception {
        if (ffmpegInitialized) return;
        synchronized (FFMPEG_INIT_LOCK) {
            if (ffmpegInitialized) return;
            FFmpeg.getInstance().init(context.getApplicationContext());
            ffmpegInitialized = true;
        }
    }

'''
    if anchor not in s:
        raise SystemExit('YtDlpPlugin resolveForPlayback anchor missing')
    s = s.replace(anchor, helper + anchor, 1)

# Offline download/merge is the place that actually needs FFmpeg.
download_idx = s.find('public void download(PluginCall call)')
if download_idx < 0:
    raise SystemExit('YtDlpPlugin download() missing')
next_method = s.find('\n    @PluginMethod', download_idx + 20)
if next_method < 0:
    next_method = len(s)
download_block = s[download_idx:next_method]
if 'ensureFfmpegInitialized(getContext())' not in download_block:
    pos = download_block.find('ensureInitialized();')
    if pos < 0:
        raise SystemExit('YtDlpPlugin download ensureInitialized() missing')
    pos += len('ensureInitialized();')
    download_block = download_block[:pos] + '\n                ensureFfmpegInitialized(getContext());' + download_block[pos:]
    s = s[:download_idx] + download_block + s[next_method:]

# Bound slow networks so extraction doesn't sit forever.
base_idx = s.find('private static YoutubeDLRequest baseRequest(String source)')
if base_idx < 0:
    raise SystemExit('YtDlpPlugin baseRequest missing')
base_end = s.find('\n    }', base_idx)
if base_end < 0:
    raise SystemExit('YtDlpPlugin baseRequest end missing')
base_block = s[base_idx:base_end]
if '--socket-timeout' not in base_block:
    req_line = '        YoutubeDLRequest request = new YoutubeDLRequest(source);'
    if req_line not in base_block:
        raise SystemExit('YtDlpPlugin baseRequest request line missing')
    injected = req_line + '''
        request.addOption("--socket-timeout", "8");
        request.addOption("--retries", "1");
        request.addOption("--extractor-retries", "1");'''
    s = s.replace(req_line, injected, 1)

p.write_text(s, encoding='utf-8')

# ---------------- playback marker ----------------
p = Path('native/android/PlaybackService.java')
s = p.read_text(encoding='utf-8')
if 'SidePlay/0.8.1 Android' not in s and 'SidePlay/0.8.2 Android' not in s:
    raise SystemExit('PlaybackService version marker missing')
s = s.replace('SidePlay/0.8.1 Android', 'SidePlay/0.8.2 Android')
p.write_text(s, encoding='utf-8')

Path('CHANGELOG_V0.8.2.md').write_text('''# SidePlay v0.8.2 — Fast / Stable\n\n- YouTube catalog search uses the lightweight keyless search path; it no longer boots Python/yt-dlp.\n- Music search no longer waits for SoundCloud yt-dlp before painting results.\n- Heavy extraction starts only after a result is tapped.\n- FFmpeg is lazy-loaded only for offline download/merge work.\n- yt-dlp updater no longer blocks a Play tap; failures schedule a background updater and return promptly.\n- yt-dlp network retries/timeouts are bounded.\n- Normal Android Play never launches MediaCaptureActivity, YouTube, or a browser.\n- Existing Media3 background service remains the playback owner once a stream resolves.\n- Build is ARM64-only to eliminate unused x86/32-bit native payloads on modern Samsung/Android devices.\n''', encoding='utf-8')

print('v0.8.2 fast/stable source patch complete')
