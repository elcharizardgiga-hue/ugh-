import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import type { OfflineCopy, Playlist, RepeatMode, SidePlayState, TasteEventKind, Track } from '../types'
import { repairTrackIdentity, repairTrackList } from './trackIdentity'

const KEY = 'sideplay.state.v3'
const LEGACY_KEYS = ['sideplay.state.v2', 'sideplay.state.v1']
const STATE_SCHEMA_VERSION = 3

const initial: SidePlayState = {
  schemaVersion: STATE_SCHEMA_VERSION,
  favorites: [],
  playlists: [],
  history: [],
  queue: [],
  currentIndex: -1,
  repeat: 'off',
  shuffle: false,
  youtubeApiKey: '',
  playCounts: {},
  skipCounts: {},
  completionCounts: {},
  tasteEvents: [],
  offline: {},
  preferOffline: true,
}

type Ctx = {
  state: SidePlayState
  current: Track | null
  setApiKey: (key: string) => void
  playNow: (track: Track, queue?: Track[], options?: { preserveQueue?: boolean }) => void
  addQueue: (track: Track) => void
  appendQueue: (tracks: Track[]) => void
  playNext: (track: Track) => void
  removeQueue: (index: number) => void
  moveQueue: (from: number, to: number) => void
  clearQueue: () => void
  next: () => Track | null
  previous: () => Track | null
  toggleFavorite: (track: Track) => void
  isFavorite: (videoId: string) => boolean
  createPlaylist: (name: string) => Playlist
  renamePlaylist: (id: string, name: string) => void
  deletePlaylist: (id: string) => void
  addToPlaylist: (id: string, track: Track) => void
  removeFromPlaylist: (id: string, videoId: string) => void
  movePlaylistTrack: (id: string, from: number, to: number) => void
  setRepeat: (mode: RepeatMode) => void
  setShuffle: (value: boolean) => void
  setOfflineCopy: (copy: OfflineCopy) => void
  removeOfflineCopy: (videoId: string) => void
  getOfflineCopy: (videoId: string) => OfflineCopy | null
  setPreferOffline: (value: boolean) => void
  recordSkip: (videoId: string, progress?: number) => void
  recordCompletion: (videoId: string, progress?: number) => void
  mergeHistory: (tracks: Track[]) => void
  clearHistory: () => void
  exportLibrary: () => string
  importLibrary: (json: string) => void
}

const SidePlayContext = createContext<Ctx | null>(null)

const MAX_TASTE_EVENTS = 1200
const addTasteEvent = (events: SidePlayState['tasteEvents'], videoId: string, kind: TasteEventKind, progress?: number) => {
  if (!videoId) return events || []
  const event = { videoId, kind, at: Date.now(), ...(typeof progress === 'number' ? { progress: Math.max(0, Math.min(1, progress)) } : {}) }
  return [event, ...(events || [])].slice(0, MAX_TASTE_EVENTS)
}

const uniqueTracks = (tracks: Track[]) => {
  const seen = new Set<string>()
  return tracks.filter((t) => !seen.has(t.videoId) && seen.add(t.videoId))
}

// Browser-captured request context may contain cookies/session tokens and must
// remain runtime-only. Extractor resolutions are different: SidePlay itself
// generated the clear media URL, and App.tsx already treats it as stale after
// 20 minutes. Preserve that short-lived resolver cache across an Android process
// restart so a crash/relaunch does not immediately force another heavy yt-dlp run.
const stripRequestContext = <T extends Track>(track: T): T => {
  const allowed = new Set(['user-agent', 'referer', 'origin', 'accept', 'accept-language'])
  const safeHeaders = Object.fromEntries(Object.entries(track.requestHeaders || {}).filter(([key]) => allowed.has(key.toLowerCase())))

  if (track.sessionBound) {
    if (track.refreshMode === 'extractor' || track.refreshMode === 'youtube-native') {
      // Extractor results may be cached briefly; App.tsx refreshes them after ~20m.
      // Persist only ordinary replay headers, never Cookie/Authorization/session state.
      if (Object.keys(safeHeaders).length) return { ...track, requestHeaders: safeHeaders }
      const { requestHeaders: _requestHeaders, ...safe } = track
      return safe as T
    }
    // Interactive browser captures remain ephemeral because they can carry session state.
    const { requestHeaders: _requestHeaders, playbackUrl: _playbackUrl, downloadUrl: _downloadUrl, capturedAt: _capturedAt, ...safe } = track
    return safe as T
  }

  if (Object.keys(safeHeaders).length) return { ...track, requestHeaders: safeHeaders }
  const { requestHeaders: _requestHeaders, ...safe } = track
  return safe as T
}

const migrateState = (value: unknown): SidePlayState => {
  const parsed = value && typeof value === 'object' ? value as Partial<SidePlayState> : {}
  const migrated: SidePlayState = {
    ...initial,
    ...parsed,
    schemaVersion: STATE_SCHEMA_VERSION,
    playCounts: { ...(parsed.playCounts || {}) },
    skipCounts: { ...(parsed.skipCounts || {}) },
    completionCounts: { ...(parsed.completionCounts || {}) },
    tasteEvents: Array.isArray(parsed.tasteEvents) ? parsed.tasteEvents.slice(0, MAX_TASTE_EVENTS) : [],
    offline: { ...(parsed.offline || {}) },
    favorites: repairTrackList(parsed.favorites || []),
    history: repairTrackList(parsed.history || []) as SidePlayState['history'],
    queue: repairTrackList(parsed.queue || []),
    playlists: (parsed.playlists || []).map((playlist) => ({ ...playlist, tracks: repairTrackList(playlist.tracks || []) })),
  }
  if (migrated.currentIndex >= migrated.queue.length) migrated.currentIndex = migrated.queue.length ? migrated.queue.length - 1 : -1
  if (migrated.currentIndex < -1) migrated.currentIndex = -1
  return migrated
}

const loadPersistedState = (): SidePlayState => {
  try {
    const raw = localStorage.getItem(KEY) || LEGACY_KEYS.map((key) => localStorage.getItem(key)).find(Boolean)
    return raw ? migrateState(JSON.parse(raw)) : initial
  } catch {
    return initial
  }
}

const persistableState = (state: SidePlayState): SidePlayState => ({
  ...state,
  schemaVersion: STATE_SCHEMA_VERSION,
  favorites: repairTrackList(state.favorites).map(stripRequestContext),
  history: repairTrackList(state.history).map(stripRequestContext),
  queue: repairTrackList(state.queue).map(stripRequestContext),
  playlists: state.playlists.map((playlist) => ({ ...playlist, tracks: repairTrackList(playlist.tracks).map(stripRequestContext) })),
})

export function SidePlayProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<SidePlayState>(() => persistableState(loadPersistedState()))

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(persistableState(state)))
  }, [state])

  const current = state.currentIndex >= 0 ? state.queue[state.currentIndex] ?? null : null

  const api = useMemo<Ctx>(() => ({
    state,
    current,
    setApiKey: (youtubeApiKey) => setState((s) => ({ ...s, youtubeApiKey })),
    playNow: (track, queue, options) => setState((s) => {
      const repairedTrack = repairTrackIdentity(track)
      let nextQueue: Track[]
      if (options?.preserveQueue) {
        const live = repairTrackList(s.queue)
        const existing = live.findIndex((item) => item.videoId === repairedTrack.videoId)
        if (existing >= 0) {
          nextQueue = live.map((item, index) => index === existing ? { ...item, ...repairedTrack, queueOrigin: item.queueOrigin || repairedTrack.queueOrigin } : item)
        } else {
          nextQueue = uniqueTracks([...live, repairedTrack])
        }
      } else if (queue?.length) {
        nextQueue = uniqueTracks(repairTrackList(queue)).map((item) => item.videoId === repairedTrack.videoId ? { ...item, ...repairedTrack, queueOrigin: item.queueOrigin || repairedTrack.queueOrigin } : item)
      } else {
        nextQueue = [repairedTrack]
      }
      const index = Math.max(0, nextQueue.findIndex((x) => x.videoId === repairedTrack.videoId))
      return {
        ...s,
        queue: nextQueue,
        currentIndex: index,
        history: [{ ...stripRequestContext(repairedTrack), playedAt: Date.now() }, ...s.history.filter((h) => h.videoId !== repairedTrack.videoId)].slice(0, 200),
        playCounts: { ...s.playCounts, [repairedTrack.videoId]: (s.playCounts?.[repairedTrack.videoId] ?? 0) + 1 },
        tasteEvents: addTasteEvent(s.tasteEvents, repairedTrack.videoId, 'play'),
      }
    }),
    // Queueing is passive: adding something to an empty queue must not start playback.
    addQueue: (track) => setState((s) => {
      const manual = { ...stripRequestContext(repairTrackIdentity(track)), queueOrigin: 'manual' as const }
      const existingIndex = s.queue.findIndex((item) => item.videoId === manual.videoId)
      // Never move the song that is already playing just because the user taps Add to queue.
      if (existingIndex === s.currentIndex && existingIndex >= 0) return s
      const without = s.queue.filter((item) => item.videoId !== manual.videoId)
      const currentIndex = s.currentIndex - (existingIndex >= 0 && existingIndex < s.currentIndex ? 1 : 0)
      const firstAutoplay = without.findIndex((item, index) => index > currentIndex && item.queueOrigin === 'autoplay')
      const insertAt = firstAutoplay >= 0 ? firstAutoplay : without.length
      const queue = [...without]
      queue.splice(insertAt, 0, manual)
      return { ...s, queue, currentIndex, tasteEvents: addTasteEvent(s.tasteEvents, manual.videoId, 'queue') }
    }),
    appendQueue: (tracks) => setState((s) => ({ ...s, queue: uniqueTracks([...s.queue, ...repairTrackList(tracks).map(stripRequestContext)]) })),
    playNext: (track) => setState((s) => {
      const repaired = { ...stripRequestContext(repairTrackIdentity(track)), queueOrigin: 'manual' as const }
      const existingIndex = s.queue.findIndex((x) => x.videoId === repaired.videoId)
      // Re-queueing the currently playing item must not corrupt currentIndex.
      if (existingIndex === s.currentIndex && existingIndex >= 0) return s
      if (s.currentIndex < 0) {
        const without = s.queue.filter((x) => x.videoId !== repaired.videoId)
        return { ...s, queue: [repaired, ...without], tasteEvents: addTasteEvent(s.tasteEvents, repaired.videoId, 'queue') }
      }
      const without = s.queue.filter((x) => x.videoId !== repaired.videoId)
      const currentIndex = s.currentIndex - (existingIndex >= 0 && existingIndex < s.currentIndex ? 1 : 0)
      const q = [...without]
      q.splice(currentIndex + 1, 0, repaired)
      return { ...s, queue: q, currentIndex, tasteEvents: addTasteEvent(s.tasteEvents, repaired.videoId, 'queue') }
    }),
    removeQueue: (index) => setState((s) => {
      const q = s.queue.filter((_, i) => i !== index)
      let currentIndex = s.currentIndex
      if (!q.length) currentIndex = -1
      else if (index < s.currentIndex) currentIndex -= 1
      else if (index === s.currentIndex) currentIndex = Math.min(currentIndex, q.length - 1)
      return { ...s, queue: q, currentIndex }
    }),
    moveQueue: (from, to) => setState((s) => {
      if (to < 0 || to >= s.queue.length || from === to) return s
      const q = [...s.queue]
      const [item] = q.splice(from, 1)
      q.splice(to, 0, item)
      let idx = s.currentIndex
      if (idx === from) idx = to
      else if (from < idx && to >= idx) idx -= 1
      else if (from > idx && to <= idx) idx += 1
      return { ...s, queue: q, currentIndex: idx }
    }),
    // 'Clear queue' means clear Up Next, not stop the song that is already playing.
    clearQueue: () => setState((s) => {
      if (s.currentIndex < 0) return { ...s, queue: [] }
      return { ...s, queue: s.queue.slice(0, s.currentIndex + 1) }
    }),
    // Queue navigation only chooses the target. `playNow` is the single place
    // that records history/play counts, avoiding double-counts when Next/Previous
    // immediately hand the selected item back through the resolver/player path.
    // Navigation must choose synchronously. React may defer functional state updaters,
    // so assigning `chosen` inside setState() and returning it immediately can return
    // null at end-of-track even when the queue has a valid next item.
    next: () => {
      if (!state.queue.length) return null
      let idx = state.currentIndex
      let chosen: Track | null = null
      if (idx < 0) {
        idx = 0
        chosen = state.queue[0] || null
      } else if (state.repeat === 'one') {
        chosen = state.queue[idx] || null
      } else if (state.shuffle && state.queue.length > 1) {
        do idx = Math.floor(Math.random() * state.queue.length)
        while (idx === state.currentIndex)
        chosen = state.queue[idx] || null
      } else if (idx + 1 < state.queue.length) {
        idx += 1
        chosen = state.queue[idx] || null
      } else if (state.repeat === 'all') {
        idx = 0
        chosen = state.queue[0] || null
      }
      if (!chosen) return null
      const targetId = chosen.videoId
      setState((s) => {
        const targetIndex = s.queue.findIndex((item) => item.videoId === targetId)
        return targetIndex >= 0 ? { ...s, currentIndex: targetIndex } : s
      })
      return chosen
    },
    previous: () => {
      if (!state.queue.length || state.currentIndex < 0) return null
      const idx = state.currentIndex > 0 ? state.currentIndex - 1 : (state.repeat === 'all' ? state.queue.length - 1 : 0)
      const chosen = state.queue[idx] || null
      if (!chosen) return null
      const targetId = chosen.videoId
      setState((s) => {
        const targetIndex = s.queue.findIndex((item) => item.videoId === targetId)
        return targetIndex >= 0 ? { ...s, currentIndex: targetIndex } : s
      })
      return chosen
    },
    toggleFavorite: (track) => setState((s) => {
      track = repairTrackIdentity(track)
      const exists = s.favorites.some((x) => x.videoId === track.videoId)
      return { ...s, favorites: exists ? s.favorites.filter((x) => x.videoId !== track.videoId) : [stripRequestContext(track), ...s.favorites], tasteEvents: addTasteEvent(s.tasteEvents, track.videoId, exists ? 'unlike' : 'like') }
    }),
    isFavorite: (videoId) => state.favorites.some((x) => x.videoId === videoId),
    createPlaylist: (name) => {
      const playlist: Playlist = { id: crypto.randomUUID(), name: name.trim() || 'Untitled playlist', tracks: [], createdAt: Date.now(), updatedAt: Date.now() }
      setState((s) => ({ ...s, playlists: [playlist, ...s.playlists] }))
      return playlist
    },
    renamePlaylist: (id, name) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, name: name.trim() || p.name, updatedAt: Date.now() } : p) })),
    deletePlaylist: (id) => setState((s) => ({ ...s, playlists: s.playlists.filter((p) => p.id !== id) })),
    addToPlaylist: (id, track) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, tracks: uniqueTracks([...p.tracks, stripRequestContext(repairTrackIdentity(track))]), updatedAt: Date.now() } : p), tasteEvents: addTasteEvent(s.tasteEvents, track.videoId, 'playlist') })),
    removeFromPlaylist: (id, videoId) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, tracks: p.tracks.filter((t) => t.videoId !== videoId), updatedAt: Date.now() } : p) })),
    movePlaylistTrack: (id, from, to) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => {
      if (p.id !== id || to < 0 || to >= p.tracks.length) return p
      const tracks = [...p.tracks]
      const [item] = tracks.splice(from, 1)
      tracks.splice(to, 0, item)
      return { ...p, tracks, updatedAt: Date.now() }
    }) })),
    setRepeat: (repeat) => setState((s) => ({ ...s, repeat })),
    setShuffle: (shuffle) => setState((s) => ({ ...s, shuffle })),
    setOfflineCopy: (copy) => setState((s) => ({ ...s, offline: { ...(s.offline || {}), [copy.videoId]: copy } })),
    removeOfflineCopy: (videoId) => setState((s) => { const offline = { ...(s.offline || {}) }; delete offline[videoId]; return { ...s, offline } }),
    getOfflineCopy: (videoId) => state.offline?.[videoId] || null,
    setPreferOffline: (preferOffline) => setState((s) => ({ ...s, preferOffline })),
    recordSkip: (videoId, progress) => setState((s) => !videoId ? s : ({ ...s, skipCounts: { ...s.skipCounts, [videoId]: (s.skipCounts?.[videoId] ?? 0) + 1 }, tasteEvents: addTasteEvent(s.tasteEvents, videoId, 'skip', progress) })),
    recordCompletion: (videoId, progress) => setState((s) => !videoId ? s : ({ ...s, completionCounts: { ...s.completionCounts, [videoId]: (s.completionCounts?.[videoId] ?? 0) + 1 }, tasteEvents: addTasteEvent(s.tasteEvents, videoId, 'complete', progress) })),
    clearHistory: () => setState((s) => ({ ...s, history: [] })),
    mergeHistory: (tracks) => setState((s) => {
      const now = Date.now()
      const imported = uniqueTracks(repairTrackList(tracks)).map((t, i) => ({ ...stripRequestContext(t), playedAt: now - i }))
      const seen = new Set(imported.map(t => t.videoId))
      return { ...s, history: [...imported, ...s.history.filter(h => !seen.has(h.videoId))].slice(0, 500) }
    }),
    exportLibrary: () => JSON.stringify(persistableState(state), null, 2),
    importLibrary: (json) => {
      const parsed = JSON.parse(json)
      setState(persistableState(migrateState(parsed)))
    },
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [state, current])

  return <SidePlayContext.Provider value={api}>{children}</SidePlayContext.Provider>
}

export function useSidePlay() {
  const ctx = useContext(SidePlayContext)
  if (!ctx) throw new Error('useSidePlay must be used inside SidePlayProvider')
  return ctx
}
