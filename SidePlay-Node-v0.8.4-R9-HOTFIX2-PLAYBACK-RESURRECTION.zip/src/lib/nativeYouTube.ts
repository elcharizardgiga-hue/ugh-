import { Capacitor, registerPlugin } from '@capacitor/core'
import type { LyricsResult, Track } from '../types'

export type NativeResolverHealth = {
  newPipeSuccesses: number
  newPipeFailures: number
  innerTubeSuccesses: number
  innerTubeFailures: number
  innerTubeFailureStreak: number
  innerTubeCooldownMs: number
  ytdlpSuccesses: number
  ytdlpFailures: number
  ytdlpFailureStreak: number
  ytdlpCooldownMs: number
  lastResolverEngine: string
  lastResolverTrail: string
  lastResolverError: string
  lastResolvedAt: number
  extractorIsolation: string
  newPipeVersion: string
  ytDlpAndroidVersion: string
}

interface NativeYouTubePlugin {
  search(options: { query: string; limit?: number }): Promise<{ tracks: Track[] }>
  getVideo(options: { videoId: string }): Promise<{ track: Track }>
  related(options: { videoId: string; limit?: number }): Promise<{ tracks: Track[]; source?: string }>
  suggest(options: { query: string; limit?: number; hl?: string; gl?: string }): Promise<{ suggestions: string[]; source?: string }>
  lyrics(options: { videoId: string }): Promise<LyricsResult>
  resolve(options: { url?: string; videoId?: string; audioOnly?: boolean; allowHeavyFallback?: boolean }): Promise<any>
  getResolverHealth(): Promise<NativeResolverHealth>
  resetResolverHealth(): Promise<void>
}

export const NativeYouTube = registerPlugin<NativeYouTubePlugin>('NativeYouTube')
export const hasNativeYouTubeSearch = () => Capacitor.isNativePlatform()
