import type { Track } from '../types'

const YOUTUBE_ID = /^[A-Za-z0-9_-]{11}$/

function youtubeIdFromUrl(value?: string) {
  if (!value) return null
  try {
    const url = new URL(value)
    const host = url.hostname.toLowerCase().replace(/^www\./, '')
    if (host === 'youtu.be') {
      const id = url.pathname.split('/').filter(Boolean)[0]
      return id && YOUTUBE_ID.test(id) ? id : null
    }
    if (host === 'youtube.com' || host.endsWith('.youtube.com')) {
      const direct = url.searchParams.get('v')
      if (direct && YOUTUBE_ID.test(direct)) return direct
      const parts = url.pathname.split('/').filter(Boolean)
      const marker = parts.findIndex((part) => ['shorts', 'embed', 'live'].includes(part))
      const id = marker >= 0 ? parts[marker + 1] : null
      return id && YOUTUBE_ID.test(id) ? id : null
    }
  } catch {}
  return null
}

function looksLikeYouTube(track: Track) {
  if (track.provider === 'youtube') return true
  if (youtubeIdFromUrl(track.sourceUrl)) return true
  if (!YOUTUBE_ID.test(track.videoId || '')) return false
  const fingerprint = `${track.thumbnail || ''} ${track.channel || ''}`.toLowerCase()
  return fingerprint.includes('ytimg.com') || fingerprint.includes('youtube')
}

/**
 * Repairs lightweight/legacy YouTube catalog entries before they reach the generic
 * Web resolver. Older SidePlay builds stored recommendations with only videoId,
 * title/channel and thumbnail, which made end-of-track autoplay degrade into
 * "Web could not be resolved" after persistence/relaunch.
 */
export function repairTrackIdentity<T extends Track>(input: T): T {
  if (!input) return input
  const urlId = youtubeIdFromUrl(input.sourceUrl)
  if (!looksLikeYouTube(input)) return input
  const videoId = urlId || input.videoId
  if (!videoId || !YOUTUBE_ID.test(videoId)) return input
  return {
    ...input,
    videoId,
    provider: 'youtube',
    sourceUrl: `https://www.youtube.com/watch?v=${videoId}`,
    mediaKind: input.mediaKind || 'audio',
    audioPreferred: input.audioPreferred ?? true,
  } as T
}

export function repairTrackList<T extends Track>(items: T[] | undefined | null): T[] {
  return (items || []).map((item) => repairTrackIdentity(item))
}

export function hasGenericYouTubeMetadata(track: Track) {
  if (track.provider !== 'youtube') return false
  const title = (track.title || '').trim().toLowerCase()
  const channel = (track.channel || '').trim().toLowerCase()
  return !title || title === 'untitled' || title === 'untitled media' ||
    !channel || channel === 'youtube' || channel === 'www.youtube.com' || channel === 'youtube.com'
}
