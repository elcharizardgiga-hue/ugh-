import type { LyricsResult, Track } from '../types'
import { NativeYouTube, hasNativeYouTubeSearch } from './nativeYouTube'

const KEY = 'sideplay.lyrics.cache.v1'
const MAX_CACHE = 80
const TTL = 14 * 24 * 60 * 60 * 1000

type Cache = Record<string, LyricsResult>

function readCache(): Cache {
  try { return JSON.parse(localStorage.getItem(KEY) || '{}') } catch { return {} }
}

function writeCache(cache: Cache) {
  try {
    const entries = Object.values(cache).sort((a, b) => (b.fetchedAt || 0) - (a.fetchedAt || 0)).slice(0, MAX_CACHE)
    localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(entries.map((item) => [item.videoId, item]))))
  } catch {}
}

export async function getLyrics(track: Track): Promise<LyricsResult> {
  if (!track?.videoId || !/^[A-Za-z0-9_-]{11}$/.test(track.videoId)) throw new Error('Lyrics are available for YouTube music tracks only.')
  const cache = readCache()
  const cached = cache[track.videoId]
  if (cached?.text && Date.now() - (cached.fetchedAt || 0) < TTL) return cached
  if (!hasNativeYouTubeSearch()) throw new Error('Lyrics lookup is currently available in the Android build.')
  const result = await NativeYouTube.lyrics({ videoId: track.videoId })
  if (!result?.text?.trim()) throw new Error('No lyrics were exposed for this track.')
  const normalized: LyricsResult = { ...result, videoId: track.videoId, fetchedAt: Date.now(), source: result.source || 'YouTube Music' }
  cache[track.videoId] = normalized
  writeCache(cache)
  return normalized
}
