import type { SidePlayState, TasteEventKind, Track } from '../types'
import { canonicalTrackKey, musicIdentity } from './musicIdentity'

const EVENT_WEIGHT: Record<TasteEventKind, number> = {
  play: 0.45,
  complete: 2.4,
  skip: -3.2,
  like: 5.2,
  unlike: -5.5,
  queue: 2.0,
  playlist: 2.8,
}

const DAY = 86_400_000
const GLOBAL_HALF_LIFE = 45 * DAY
const SESSION_HALF_LIFE = 2.5 * 60 * 60 * 1000

function decay(ageMs: number, halfLifeMs: number) {
  if (ageMs <= 0) return 1
  return Math.pow(0.5, ageMs / halfLifeMs)
}

function add(map: Map<string, number>, key: string, value: number) {
  if (!key || !Number.isFinite(value)) return
  map.set(key, (map.get(key) || 0) + value)
}

export type TasteProfile = {
  trackScores: Map<string, number>
  canonicalScores: Map<string, number>
  artistScores: Map<string, number>
  sessionArtistScores: Map<string, number>
  sessionTrackScores: Map<string, number>
  stronglySkipped: Set<string>
  knownArtists: Set<string>
}

/**
 * R9 Taste Engine. It is deliberately local and explainable: no account upload,
 * no opaque model. Long-term taste decays over weeks; session taste decays over
 * hours so one late-night rabbit hole can steer Autoplay without becoming your
 * permanent identity.
 */
export function buildTasteProfile(state: SidePlayState, now = Date.now()): TasteProfile {
  const trackScores = new Map<string, number>()
  const canonicalScores = new Map<string, number>()
  const artistScores = new Map<string, number>()
  const sessionArtistScores = new Map<string, number>()
  const sessionTrackScores = new Map<string, number>()
  const stronglySkipped = new Set<string>()
  const knownArtists = new Set<string>()

  const catalog = new Map<string, Track>()
  for (const track of [...state.history, ...state.favorites, ...state.playlists.flatMap((p) => p.tracks), ...state.queue]) {
    if (track?.videoId) catalog.set(track.videoId, track)
  }

  const scoreTrack = (track: Track | undefined, score: number, sessionScore = 0) => {
    if (!track?.videoId) return
    const id = musicIdentity(track)
    const canonical = canonicalTrackKey(track)
    add(trackScores, track.videoId, score)
    add(canonicalScores, canonical, score)
    if (id.artistKey) {
      add(artistScores, id.artistKey, score)
      knownArtists.add(id.artistKey)
      if (sessionScore) add(sessionArtistScores, id.artistKey, sessionScore)
    }
    if (sessionScore) add(sessionTrackScores, track.videoId, sessionScore)
  }

  // Legacy state remains useful after the schema migration, but is intentionally
  // lower-confidence than explicit R9 events.
  state.history.slice(0, 140).forEach((track, index) => {
    const age = Math.max(0, now - (track.playedAt || now))
    const long = Math.max(0.05, decay(age, GLOBAL_HALF_LIFE)) * Math.max(0.1, 1.05 - index * 0.006)
    const session = decay(age, SESSION_HALF_LIFE) * 0.85
    scoreTrack(track, long * 0.7, session)
  })
  state.favorites.forEach((track) => scoreTrack(track, 4.5))
  state.playlists.flatMap((p) => p.tracks).forEach((track) => scoreTrack(track, 1.7))

  for (const [videoId, count] of Object.entries(state.playCounts || {})) {
    scoreTrack(catalog.get(videoId), Math.log2(1 + Math.max(0, count)) * 0.45)
  }
  for (const [videoId, count] of Object.entries(state.completionCounts || {})) {
    scoreTrack(catalog.get(videoId), Math.min(5, Math.max(0, count)) * 0.7)
  }
  for (const [videoId, count] of Object.entries(state.skipCounts || {})) {
    scoreTrack(catalog.get(videoId), -Math.min(5, Math.max(0, count)) * 0.9)
    if (count >= 2) stronglySkipped.add(videoId)
  }

  for (const event of state.tasteEvents || []) {
    const track = catalog.get(event.videoId)
    if (!track) continue
    const age = Math.max(0, now - event.at)
    let base = EVENT_WEIGHT[event.kind]
    if (event.kind === 'skip' && typeof event.progress === 'number') {
      // A skip after 90% is barely negative; bailing in the first seconds is strong.
      base *= Math.max(0.15, 1 - Math.min(1, event.progress))
    }
    if (event.kind === 'complete' && typeof event.progress === 'number') {
      base *= 0.75 + 0.25 * Math.min(1, event.progress)
    }
    const long = base * decay(age, GLOBAL_HALF_LIFE)
    const session = base * decay(age, SESSION_HALF_LIFE)
    scoreTrack(track, long, session)
    if (event.kind === 'skip' && age < 14 * DAY && (event.progress ?? 0) < 0.35) stronglySkipped.add(event.videoId)
  }

  return { trackScores, canonicalScores, artistScores, sessionArtistScores, sessionTrackScores, stronglySkipped, knownArtists }
}

export function tasteScoreForTrack(track: Track, profile: TasteProfile) {
  const id = musicIdentity(track)
  return (profile.trackScores.get(track.videoId) || 0)
    + (profile.canonicalScores.get(canonicalTrackKey(track)) || 0) * 0.6
    + (profile.artistScores.get(id.artistKey) || 0) * 0.35
    + (profile.sessionArtistScores.get(id.artistKey) || 0) * 0.75
}

export function sessionAffinity(track: Track, profile: TasteProfile) {
  const id = musicIdentity(track)
  return (profile.sessionTrackScores.get(track.videoId) || 0) + (profile.sessionArtistScores.get(id.artistKey) || 0)
}
