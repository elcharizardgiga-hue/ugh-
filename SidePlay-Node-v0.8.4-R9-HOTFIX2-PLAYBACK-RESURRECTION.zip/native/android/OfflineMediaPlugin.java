package app.sideplay.mobile;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.os.StatFs;
import android.webkit.MimeTypeMap;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Iterator;
import java.util.Locale;

@CapacitorPlugin(name = "OfflineMedia")
public class OfflineMediaPlugin extends Plugin {
    public static final int REQUEST_MEDIA = 9422;
    private static PluginCall pendingCall;
    private static OfflineMediaPlugin activePlugin;

    @PluginMethod
    public void importAudio(PluginCall call) {
        // Backwards-compatible alias used by old SidePlay UI.
        openPicker(call, "audio/*");
    }

    @PluginMethod
    public void importMedia(PluginCall call) {
        openPicker(call, "*/*");
    }

    @PluginMethod
    public void importUri(PluginCall call) {
        String raw = call.getString("uri");
        String videoId = call.getString("videoId", "shared");
        String title = call.getString("title", "Shared media");
        if (raw == null || raw.trim().isEmpty()) { call.reject("uri is required."); return; }
        final Uri uri = Uri.parse(raw.trim());
        new Thread(() -> {
            try { call.resolve(copyIntoVault(uri, videoId, title)); }
            catch (Exception e) { call.reject("Could not import shared media: " + safe(e)); }
        }, "SidePlaySharedImport").start();
    }

    private void openPicker(PluginCall call, String type) {
        if (pendingCall != null) {
            call.reject("An offline import is already open.");
            return;
        }
        activePlugin = this;
        pendingCall = call;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(type);
        if ("*/*".equals(type)) intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        getActivity().startActivityForResult(intent, REQUEST_MEDIA);
    }

    public static boolean handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQUEST_MEDIA || pendingCall == null || activePlugin == null) return false;
        PluginCall call = pendingCall;
        pendingCall = null;

        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("Offline import cancelled.");
            return true;
        }

        Uri uri = data.getData();
        try {
            String mime = activePlugin.getContext().getContentResolver().getType(uri);
            if (mime != null && !(mime.startsWith("audio/") || mime.startsWith("video/"))) {
                call.reject("Choose an audio or video file.");
                return true;
            }
            JSObject result = activePlugin.copyIntoVault(uri,
                call.getString("videoId", "track"),
                call.getString("title", "SidePlay media"));
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Could not import media: " + safe(e));
        }
        return true;
    }

    @PluginMethod
    public void download(PluginCall call) {
        String raw = call.getString("url");
        String videoId = call.getString("videoId", "track");
        String title = call.getString("title", "SidePlay media");
        String provider = lower(call.getString("provider", "direct"));
        if (raw == null || !(raw.startsWith("https://") || raw.startsWith("http://"))) {
            call.reject("A direct http(s) media URL is required.");
            return;
        }
        if (provider.equals("spotify") || provider.equals("soundcloud")) {
            call.reject("SidePlay does not download media from " + provider + ".");
            return;
        }
        try {
            String host = lower(URI.create(raw).getHost());
            boolean youtubeCdn = host.endsWith("googlevideo.com");
            // R6: a YouTube watch page is still not a file. But when SidePlay's
            // own NewPipe resolver has already produced a clear progressive
            // googlevideo CDN URL which Media3 can play, Offline Vault may save
            // that verified media object using the same ordinary replay headers.
            if (provider.equals("youtube") && !youtubeCdn) {
                call.reject("YouTube page URLs must be resolved to a playable media object before download.");
                return;
            }
            if (host.equals("youtube.com") || host.endsWith(".youtube.com") || host.equals("youtu.be") ||
                host.endsWith("spotify.com") || host.endsWith("scdn.co") ||
                host.equals("soundcloud.com") || host.endsWith(".soundcloud.com") || host.endsWith("sndcdn.com")) {
                call.reject("This provider does not expose this file for SidePlay offline download.");
                return;
            }
        } catch (Exception ignored) {}
        if (isSegmented(raw, call.getString("mimeType", ""))) {
            call.reject("Offline saving for HLS/DASH playlists is not enabled yet. Use a progressive media file/download URL.");
            return;
        }

        final String requestedFilename = call.getString("filename");
        final JSObject requestHeaders = call.getObject("requestHeaders");
        new Thread(() -> {
            try {
                call.resolve(downloadIntoVault(raw, videoId, title, provider, requestedFilename, requestHeaders));
            } catch (Exception e) {
                call.reject("Offline download failed: " + safe(e));
            }
        }, "SidePlayOfflineDownload").start();
    }

    private JSObject downloadIntoVault(String raw, String videoId, String title, String provider, String requestedFilename, JSObject requestHeaders) throws Exception {
        HttpURLConnection connection = openDownloadConnection(raw, requestHeaders);
        int code = connection.getResponseCode();
        if (code < 200 || code >= 300) {
            connection.disconnect();
            throw new Exception("Server returned HTTP " + code + ".");
        }

        String finalUrl = connection.getURL().toString();
        String mimeType = stripParams(connection.getContentType());
        if (isSegmented(finalUrl, mimeType)) {
            connection.disconnect();
            throw new Exception("This URL is an HLS/DASH playlist, not a progressive downloadable file.");
        }
        MediaSafety.validateMetadata(finalUrl, connection.getHeaderField("Content-Disposition"), mimeType, requestedFilename);

        long total = connection.getContentLengthLong();
        if (total > MediaSafety.MAX_OFFLINE_BYTES) {
            connection.disconnect();
            throw new Exception("Media file is larger than SidePlay's 4 GiB offline safety limit.");
        }
        String filename = requestedFilename;
        if (filename == null || filename.trim().isEmpty()) {
            filename = filenameFrom(finalUrl, connection.getHeaderField("Content-Disposition"), title, mimeType);
        }
        filename = sanitize(filename);
        String ext = extension(filename);
        if (ext.isBlank()) {
            String inferred = extensionForMime(mimeType);
            if (!inferred.isBlank()) filename += "." + inferred;
        }

        File dir = vaultDir();
        long available = new StatFs(dir.getAbsolutePath()).getAvailableBytes();
        if (total > 0 && total + MediaSafety.STORAGE_RESERVE_BYTES > available) {
            connection.disconnect();
            throw new Exception("Not enough free storage to save this media safely.");
        }
        String base = sanitize(videoId == null ? "track" : videoId);
        String fileExt = extensionWithDot(filename);
        File temp = new File(dir, base + "-" + System.currentTimeMillis() + fileExt + ".part");
        File out = new File(dir, base + "-" + System.currentTimeMillis() + fileExt);

        long bytes = 0L;
        long lastEmit = 0L;
        try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream(), 128 * 1024); FileOutputStream output = new FileOutputStream(temp)) {
            input.mark(64 * 1024);
            byte[] prefix = new byte[8192];
            int prefixRead = input.read(prefix);
            if (prefixRead <= 0) throw new Exception("Downloaded file was empty.");
            MediaSafety.validatePrefix(prefix, prefixRead, mimeType, filename);
            input.reset();

            byte[] buffer = new byte[128 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                bytes += read;
                if (bytes > MediaSafety.MAX_OFFLINE_BYTES) throw new Exception("Download exceeded SidePlay's 4 GiB offline safety limit.");
                output.write(buffer, 0, read);
                long now = System.currentTimeMillis();
                if (now - lastEmit > 220L) {
                    emitProgress(videoId, bytes, total);
                    lastEmit = now;
                }
            }
            output.flush();
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
            throw e;
        } finally {
            connection.disconnect();
        }

        if (bytes <= 0L) {
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
            throw new Exception("Downloaded file was empty.");
        }
        if (!temp.renameTo(out)) {
            // Rename can fail across exotic filesystems; app-private files should normally be atomic.
            try (InputStream input = new java.io.FileInputStream(temp); FileOutputStream output = new FileOutputStream(out)) {
                byte[] buffer = new byte[128 * 1024];
                int read;
                while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            }
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        }

        emitProgress(videoId, bytes, bytes);
        JSObject result = new JSObject();
        result.put("localUri", Uri.fromFile(out).toString());
        result.put("filename", filename);
        result.put("mimeType", mimeType);
        result.put("bytes", bytes);
        result.put("provider", provider);
        result.put("sourceUrl", raw);
        result.put("mediaKind", mimeType.startsWith("video/") || looksVideo(finalUrl) ? "video" : "audio");
        return result;
    }

    private static HttpURLConnection openDownloadConnection(String raw, JSObject requestHeaders) throws Exception {
        URL original = new URL(raw);
        URL current = original;
        for (int redirect = 0; redirect <= 6; redirect++) {
            HttpURLConnection connection = (HttpURLConnection) current.openConnection();
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(30000);
            boolean sameOriginHost = sameHost(original, current);
            applyCapturedHeaders(connection, requestHeaders, sameOriginHost);
            if (!hasHeader(requestHeaders, "User-Agent")) connection.setRequestProperty("User-Agent", "SidePlay/0.5 Android");
            if (!hasHeader(requestHeaders, "Accept")) connection.setRequestProperty("Accept", "audio/*,video/*,application/octet-stream;q=0.8,*/*;q=0.2");

            int code = connection.getResponseCode();
            if (code == HttpURLConnection.HTTP_MOVED_PERM || code == HttpURLConnection.HTTP_MOVED_TEMP ||
                code == HttpURLConnection.HTTP_SEE_OTHER || code == 307 || code == 308) {
                String location = connection.getHeaderField("Location");
                if (location == null || location.isBlank()) return connection;
                URL next = new URL(current, location);
                connection.disconnect();
                if (!("http".equalsIgnoreCase(next.getProtocol()) || "https".equalsIgnoreCase(next.getProtocol()))) {
                    throw new Exception("Server redirected to an unsupported URL scheme.");
                }
                current = next;
                continue;
            }
            return connection;
        }
        throw new Exception("Too many download redirects.");
    }

    private static boolean sameHost(URL a, URL b) {
        if (a == null || b == null) return false;
        String ah = a.getHost() == null ? "" : a.getHost();
        String bh = b.getHost() == null ? "" : b.getHost();
        return ah.equalsIgnoreCase(bh);
    }

    private static void applyCapturedHeaders(HttpURLConnection connection, JSObject headers, boolean includeSensitive) {
        if (headers == null) return;
        Iterator<String> keys = headers.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            String value = headers.optString(key, "");
            if (key == null || key.isBlank() || value.isBlank()) continue;
            String lower = key.toLowerCase(Locale.ROOT);
            if (lower.equals("host") || lower.equals("content-length") || lower.equals("connection") || lower.equals("accept-encoding") || lower.equals("range") || lower.startsWith("sec-")) continue;
            if (!includeSensitive && (lower.equals("cookie") || lower.equals("authorization") || lower.equals("proxy-authorization") || lower.equals("x-csrf-token") || lower.equals("x-xsrf-token"))) continue;
            try { connection.setRequestProperty(key, value); } catch (Exception ignored) {}
        }
    }

    private static boolean hasHeader(JSObject headers, String wanted) {
        if (headers == null) return false;
        Iterator<String> keys = headers.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (key != null && key.equalsIgnoreCase(wanted) && !headers.optString(key, "").isBlank()) return true;
        }
        return false;
    }

    private void emitProgress(String videoId, long bytes, long total) {
        JSObject event = new JSObject();
        event.put("videoId", videoId);
        event.put("bytes", bytes);
        event.put("totalBytes", Math.max(0L, total));
        event.put("progress", total > 0L ? Math.min(1d, (double) bytes / (double) total) : -1d);
        notifyListeners("downloadProgress", event, true);
    }

    private JSObject copyIntoVault(Uri uri, String videoId, String title) throws Exception {
        String displayName = queryName(uri);
        String mimeType = getContext().getContentResolver().getType(uri);
        if (displayName == null || displayName.trim().isEmpty()) {
            String ext = extensionForMime(mimeType == null ? "" : mimeType);
            displayName = sanitize(title) + (ext.isBlank() ? ".media" : "." + ext);
        }
        displayName = sanitize(displayName);

        String ext = extensionWithDot(displayName);
        String base = sanitize(videoId == null ? "track" : videoId);
        File out = new File(vaultDir(), base + "-" + System.currentTimeMillis() + ext);

        MediaSafety.validateMetadata(uri.toString(), displayName, mimeType == null ? "" : mimeType, displayName);
        long bytes = 0;
        InputStream rawInput = getContext().getContentResolver().openInputStream(uri);
        if (rawInput == null) throw new Exception("Selected file could not be opened.");
        try (BufferedInputStream input = new BufferedInputStream(rawInput, 128 * 1024);
             FileOutputStream output = new FileOutputStream(out)) {
            input.mark(64 * 1024);
            byte[] prefix = new byte[8192];
            int prefixRead = input.read(prefix);
            if (prefixRead <= 0) throw new Exception("Selected media file is empty.");
            MediaSafety.validatePrefix(prefix, prefixRead, mimeType == null ? "" : mimeType, displayName);
            input.reset();
            byte[] buffer = new byte[128 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                bytes += read;
                if (bytes > MediaSafety.MAX_OFFLINE_BYTES) throw new Exception("Imported media exceeds SidePlay's 4 GiB offline safety limit.");
                output.write(buffer, 0, read);
            }
            output.flush();
        } catch (Exception e) {
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            throw e;
        }

        JSObject result = new JSObject();
        result.put("localUri", Uri.fromFile(out).toString());
        result.put("filename", displayName);
        result.put("mimeType", mimeType);
        result.put("bytes", bytes);
        result.put("mediaKind", mimeType != null && mimeType.startsWith("video/") ? "video" : "audio");
        return result;
    }

    private File vaultDir() throws Exception {
        File dir = new File(getContext().getFilesDir(), "offline");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create SidePlay offline storage.");
        return dir;
    }

    @PluginMethod
    public void remove(PluginCall call) {
        String raw = call.getString("localUri");
        if (raw == null || raw.isBlank()) { call.reject("localUri is required."); return; }
        try {
            Uri uri = Uri.parse(raw);
            File file = new File(uri.getPath());
            File root = vaultDir().getCanonicalFile();
            File canonical = file.getCanonicalFile();
            if (!canonical.getPath().startsWith(root.getPath() + File.separator)) {
                call.reject("SidePlay will only remove files from its offline vault.");
                return;
            }
            if (canonical.exists() && !canonical.delete()) {
                call.reject("Could not delete offline file.");
                return;
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not remove offline file: " + safe(e));
        }
    }

    private String queryName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContext().getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return null;
    }

    private String filenameFrom(String raw, String disposition, String title, String mimeType) {
        if (disposition != null) {
            int p = lower(disposition).indexOf("filename=");
            if (p >= 0) {
                String n = disposition.substring(p + 9).replace("\"", "").trim();
                int semi = n.indexOf(';');
                if (semi >= 0) n = n.substring(0, semi);
                if (!n.isBlank()) return n;
            }
        }
        try {
            String path = URI.create(raw).getPath();
            String n = path == null ? "" : path.substring(path.lastIndexOf('/') + 1);
            n = URLDecoder.decode(n, "UTF-8");
            if (!n.isBlank() && n.contains(".")) return n;
        } catch (Exception ignored) {}
        String ext = extensionForMime(mimeType);
        return sanitize(title == null || title.isBlank() ? "SidePlay media" : title) + (ext.isBlank() ? "" : "." + ext);
    }

    private String extensionForMime(String mime) {
        if (mime == null || mime.isBlank()) return "";
        String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(stripParams(mime));
        return ext == null ? "" : ext;
    }

    private static String extension(String name) {
        if (name == null) return "";
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        int dot = name.lastIndexOf('.');
        return dot > slash && dot < name.length() - 1 ? name.substring(dot + 1) : "";
    }

    private static String extensionWithDot(String name) {
        String ext = extension(name);
        return ext.isBlank() ? "" : "." + ext;
    }

    private static boolean isSegmented(String url, String mime) {
        String u = lower(url);
        String m = lower(mime);
        return u.matches(".*\\.(m3u8|mpd)(?:[?#].*)?$") || m.contains("mpegurl") || m.contains("dash+xml");
    }

    private static boolean looksVideo(String url) {
        return lower(url).matches(".*\\.(mp4|m4v|mov|3gp|webm|mkv|flv|f4v|mpg|mpeg|mpegts|ts|mts|m2ts)(?:[?#].*)?$");
    }

    private String sanitize(String input) {
        String out = input == null ? "media" : input.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (out.length() > 120) out = out.substring(0, 120);
        return out.isBlank() ? "media" : out;
    }

    private static String stripParams(String value) {
        if (value == null) return "";
        int semi = value.indexOf(';');
        return (semi >= 0 ? value.substring(0, semi) : value).trim().toLowerCase(Locale.ROOT);
    }

    private static String lower(String value) { return value == null ? "" : value.toLowerCase(Locale.ROOT); }
    private static String safe(Exception e) { String m = e.getMessage(); return m == null || m.isBlank() ? e.getClass().getSimpleName() : m; }
}
