SidePlay v0.8.2 FAST / STABLE upgrade bundle — FIXED

Base source required in repo root:
  SidePlay-Node-v0.8.1-STAY-INSIDE-BACKGROUND.zip
  SHA-256: 9d7f0b8f14a5f26f543862fda18d0296395174f7e9c4c1b3bfbac4c139c11242

Use ONE workflow:
  .github/workflows/build-sideplay-v0.8.2.yml          manual workflow_dispatch
  .github/workflows/build-sideplay-v0.8.2-AUTORUN.yml  push/manual autorun variant

This fixed bundle corrects invalid Bash quoting around `node -p require(...)` in both the
v0.8.1 base-version check and the post-patch v0.8.2 version check.

Validated before packaging:
  - YAML parses
  - every shell `run:` block passes `bash -n`
  - PATCH_SIDEPLAY_V082.py passes Python bytecode compilation
  - ZIP integrity tested
