$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
$LocalBase = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } else { Join-Path $env:USERPROFILE "AppData\Local" }
$Tools = Join-Path $LocalBase "SidePlay\tools"
$Jdk = Join-Path $Tools "jdk"
$Sdk = Join-Path $Tools "android-sdk"
$SdkManager = Join-Path $Sdk "cmdline-tools\latest\bin\sdkmanager.bat"
$Log = Join-Path $Root "sideplay-build.log"
New-Item -ItemType Directory -Force -Path $Tools | Out-Null

function Log([string]$Text) {
  $line = "[$(Get-Date -Format 'HH:mm:ss')] $Text"
  Write-Host $line
}

function Download([string]$Url, [string]$OutFile) {
  if (Get-Command curl.exe -ErrorAction SilentlyContinue) {
    & curl.exe -L --fail --retry 3 --retry-delay 2 --progress-bar $Url -o $OutFile
    if ($LASTEXITCODE -ne 0) { throw "curl failed downloading $Url" }
  } else {
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $OutFile
  }
}

if (!(Test-Path (Join-Path $Jdk "bin\java.exe"))) {
  Log "JDK 21 cache missing; downloading once."
  $zip = Join-Path $Tools "jdk.zip"
  $tmp = Join-Path $Tools "jdk-extract"
  Remove-Item $zip,$tmp -Recurse -Force -ErrorAction SilentlyContinue
  Download "https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jdk/hotspot/normal/eclipse" $zip
  Expand-Archive $zip -DestinationPath $tmp -Force
  $folder = Get-ChildItem $tmp -Directory | Select-Object -First 1
  if (!$folder) { throw "JDK archive extracted without a root folder." }
  Remove-Item $Jdk -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force -Path $Jdk | Out-Null
  Copy-Item (Join-Path $folder.FullName "*") $Jdk -Recurse -Force
  Remove-Item $zip,$tmp -Recurse -Force -ErrorAction SilentlyContinue
} else {
  Log "JDK cache ready; skipping download."
}

if (!(Test-Path $SdkManager)) {
  Log "Android command-line tools cache missing; downloading once."
  $zip = Join-Path $Tools "android-tools.zip"
  $tmp = Join-Path $Tools "android-tools-extract"
  Remove-Item $zip,$tmp -Recurse -Force -ErrorAction SilentlyContinue
  Download "https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip" $zip
  Expand-Archive $zip -DestinationPath $tmp -Force
  $latest = Join-Path $Sdk "cmdline-tools\latest"
  Remove-Item $latest -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force -Path $latest | Out-Null
  Copy-Item (Join-Path $tmp "cmdline-tools\*") $latest -Recurse -Force
  Remove-Item $zip,$tmp -Recurse -Force -ErrorAction SilentlyContinue
} else {
  Log "Android command-line tools cache ready; skipping download."
}

$env:JAVA_HOME = $Jdk
$env:ANDROID_HOME = $Sdk
$env:ANDROID_SDK_ROOT = $Sdk
$env:Path = "$(Join-Path $Jdk 'bin');$(Join-Path $Sdk 'platform-tools');$(Join-Path $Sdk 'cmdline-tools\latest\bin');$env:Path"

$Required = @(
  (Join-Path $Sdk "platform-tools\adb.exe"),
  (Join-Path $Sdk "platforms\android-36\android.jar"),
  (Join-Path $Sdk "build-tools\36.0.0\aapt2.exe")
)
$Missing = @($Required | Where-Object { !(Test-Path $_) })
if ($Missing.Count -gt 0) {
  Log "Android SDK 36/build tools missing; installing once."
  # Licenses only matter when packages need installing; don't waste time on every build.
  1..80 | ForEach-Object { "y" } | & $SdkManager --licenses | Out-Null
  & $SdkManager --install "platform-tools" "platforms;android-36" "build-tools;36.0.0"
  if ($LASTEXITCODE -ne 0) { throw "sdkmanager failed with exit code $LASTEXITCODE" }
} else {
  Log "Android SDK 36 + build tools already cached; skipping sdkmanager."
}

foreach ($item in $Required) {
  if (!(Test-Path $item)) { throw "Required Android SDK file is still missing: $item" }
}

$localProperties = Join-Path $Root "android\local.properties"
if (Test-Path (Split-Path $localProperties)) {
  $sdkEscaped = $Sdk.Replace('\','/')
  "sdk.dir=$sdkEscaped" | Set-Content -Encoding ASCII $localProperties
}

# Export paths to the parent BAT via a tiny generated batch file.
$envBat = Join-Path $Tools "sideplay-env.bat"
@(
  "@echo off",
  "set `"JAVA_HOME=$Jdk`"",
  "set `"ANDROID_HOME=$Sdk`"",
  "set `"ANDROID_SDK_ROOT=$Sdk`"",
  "set `"PATH=$Jdk\bin;$Sdk\platform-tools;$Sdk\cmdline-tools\latest\bin;%PATH%`""
) | Set-Content -Encoding ASCII $envBat
Log "Android toolchain ready: $Tools"
