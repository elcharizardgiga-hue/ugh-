import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const android = path.join(root, 'android')
if (!fs.existsSync(android)) throw new Error('android/ does not exist. Run: npx cap add android')

const nativeFiles = ['PlaybackService.java', 'BackgroundAudioPlugin.java', 'SharedTextPlugin.java', 'NativeYouTubePlugin.java', 'DirectDownloadPlugin.java', 'OfflineMediaPlugin.java', 'WebPlaybackKeepAliveService.java', 'WebPlaybackPlugin.java', 'SpotifySessionListenerService.java', 'SpotifySessionPlugin.java']
for (const file of nativeFiles) {
  const source = path.join(root, 'native', 'android', file)
  if (!fs.existsSync(source)) throw new Error(`Missing native Android source: native/android/${file}. Re-extract a complete SidePlay release.`)
}

const pkgDir = path.join(android, 'app', 'src', 'main', 'java', 'app', 'sideplay', 'mobile')
fs.mkdirSync(pkgDir, { recursive: true })
for (const file of nativeFiles) {
  fs.copyFileSync(path.join(root, 'native', 'android', file), path.join(pkgDir, file))
}

const mainActivity = path.join(pkgDir, 'MainActivity.java')
fs.writeFileSync(mainActivity, `package app.sideplay.mobile;\n\nimport android.content.Intent;\nimport android.os.Bundle;\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n  @Override\n  public void onCreate(Bundle savedInstanceState) {\n    registerPlugin(BackgroundAudioPlugin.class);\n    registerPlugin(SharedTextPlugin.class);\n    registerPlugin(NativeYouTubePlugin.class);\n    registerPlugin(DirectDownloadPlugin.class);\n    registerPlugin(OfflineMediaPlugin.class);\n    registerPlugin(WebPlaybackPlugin.class);\n    registerPlugin(SpotifySessionPlugin.class);\n    super.onCreate(savedInstanceState);\n  }\n\n  // Kept for WebPlaybackPlugin compatibility. PiP is deliberately disabled.\n  public void setSidePlayPipEnabled(boolean enabled) {}\n  public void setWebPlaybackWanted(boolean wanted) {}\n\n  @Override\n  protected void onActivityResult(int requestCode, int resultCode, Intent data) {\n    if (OfflineMediaPlugin.handleActivityResult(requestCode, resultCode, data)) return;\n    super.onActivityResult(requestCode, resultCode, data);\n  }\n\n  @Override\n  protected void onNewIntent(Intent intent) {\n    super.onNewIntent(intent);\n    setIntent(intent);\n  }\n}\n`)

const gradle = path.join(android, 'app', 'build.gradle')
let g = fs.readFileSync(gradle, 'utf8')
if (!g.includes('media3-exoplayer')) {
  g = g.replace(/dependencies\s*\{/, `dependencies {\n    implementation "androidx.media3:media3-exoplayer:1.8.1"\n    implementation "androidx.media3:media3-session:1.8.1"`)
}

fs.writeFileSync(gradle, g)

const manifest = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml')
let m = fs.readFileSync(manifest, 'utf8')
const perms = [
  '<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
  '<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />',
  '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '<uses-permission android:name="android.permission.WAKE_LOCK" />'
]
for (const p of perms) if (!m.includes(p)) m = m.replace(/<application/, `    ${p}\n    <application`)

// Picture-in-Picture intentionally disabled in v0.3.2.


// Ensure PiP is absent even when rebuilding over a previously patched project.
m = m.replace(/\s+android:supportsPictureInPicture="true"/g, '')
if (!m.includes('PlaybackService')) {
  m = m.replace(/<\/application>/, `        <service\n            android:name=".PlaybackService"\n            android:stopWithTask="false"\n            android:foregroundServiceType="mediaPlayback"\n            android:exported="true">\n            <intent-filter>\n                <action android:name="androidx.media3.session.MediaSessionService" />\n            </intent-filter>\n        </service>\n    </application>`)
} else if (!/android:name="\.PlaybackService"[\s\S]*?android:stopWithTask=/.test(m)) {
  m = m.replace(/android:name="\.PlaybackService"/, 'android:name=".PlaybackService"\n            android:stopWithTask="false"')
}

if (!m.includes('WebPlaybackKeepAliveService')) {
  m = m.replace(/<\/application>/, `        <service
            android:name=".WebPlaybackKeepAliveService"
            android:stopWithTask="true"
            android:foregroundServiceType="mediaPlayback"
            android:exported="false" />
    </application>`)
}
if (!m.includes('com.spotify.music')) {
  m = m.replace(/<application/, `    <queries>
        <package android:name="com.spotify.music" />
    </queries>
    <application`)
}
if (!m.includes('SpotifySessionListenerService')) {
  m = m.replace(/<\/application>/, `        <service
            android:name=".SpotifySessionListenerService"
            android:label="SidePlay Spotify control"
            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.service.notification.NotificationListenerService" />
            </intent-filter>
        </service>
    </application>`)
}
if (!m.includes('android.intent.action.SEND')) {
  m = m.replace(/(<activity[\s\S]*?<intent-filter>[\s\S]*?<\/intent-filter>)/, `$1\n            <intent-filter>\n                <action android:name="android.intent.action.SEND" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <data android:mimeType="text/plain" />\n            </intent-filter>`)
}
fs.writeFileSync(manifest, m)
console.log('Android project patched: Media3 + Spotify MediaSession engine + no-PiP Spotify-first handoff + WebView foreground fallback, keyless search, offline vault, downloads, and Share intent.')
