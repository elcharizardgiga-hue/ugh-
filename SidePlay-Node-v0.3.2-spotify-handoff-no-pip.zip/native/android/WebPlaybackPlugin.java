package app.sideplay.mobile;

import android.content.Intent;
import android.os.Build;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "WebPlayback")
public class WebPlaybackPlugin extends Plugin {
    @PluginMethod
    public void start(PluginCall call) {
        try {
            MainActivity activity = (MainActivity) getActivity();
            if (activity != null) activity.setWebPlaybackWanted(true);

            Intent intent = new Intent(getContext(), WebPlaybackKeepAliveService.class);
            intent.setAction(WebPlaybackKeepAliveService.ACTION_START);
            intent.putExtra("title", call.getString("title", "SidePlay"));
            intent.putExtra("artist", call.getString("artist", ""));
            ContextCompat.startForegroundService(getContext(), intent);

            JSObject out = new JSObject();
            out.put("active", true);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Could not start SidePlay web background engine.", e);
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try {
            MainActivity activity = (MainActivity) getActivity();
            if (activity != null) activity.setWebPlaybackWanted(false);
            Intent intent = new Intent(getContext(), WebPlaybackKeepAliveService.class);
            intent.setAction(WebPlaybackKeepAliveService.ACTION_STOP);
            getContext().startService(intent);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not stop SidePlay web background engine.", e);
        }
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject out = new JSObject();
        MainActivity activity = (MainActivity) getActivity();
        out.put("active", WebPlaybackKeepAliveService.isActive());
        out.put("pipSupported", Build.VERSION.SDK_INT >= 26);
        out.put("inPip", activity != null && activity.isInPictureInPictureMode());
        call.resolve(out);
    }

    @PluginMethod
    public void setPipEnabled(PluginCall call) {
        try {
            boolean enabled = call.getBoolean("enabled", true);
            MainActivity activity = (MainActivity) getActivity();
            if (activity != null) activity.setSidePlayPipEnabled(enabled);
            JSObject out = new JSObject();
            out.put("enabled", enabled);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Could not update SidePlay PiP mode.", e);
        }
    }
}
