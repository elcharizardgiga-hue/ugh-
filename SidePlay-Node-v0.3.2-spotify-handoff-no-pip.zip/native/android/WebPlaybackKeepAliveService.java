package app.sideplay.mobile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;

/**
 * Keeps the app process, CPU and Wi-Fi available while the Capacitor WebView is
 * the active playback engine. It does NOT extract media from YouTube; it only
 * prevents Android from eagerly suspending/killing SidePlay's already-running
 * WebView playback experiment.
 */
public class WebPlaybackKeepAliveService extends Service {
    public static final String ACTION_START = "app.sideplay.mobile.WEB_PLAYBACK_START";
    public static final String ACTION_STOP = "app.sideplay.mobile.WEB_PLAYBACK_STOP";
    public static final String CHANNEL_ID = "sideplay_web_playback";
    public static final int NOTIFICATION_ID = 2207;

    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private static volatile boolean active = false;

    public static boolean isActive() { return active; }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopKeepAlive();
            return START_NOT_STICKY;
        }

        String title = intent == null ? null : intent.getStringExtra("title");
        String artist = intent == null ? null : intent.getStringExtra("artist");
        active = true;
        acquireLocks();
        startForeground(NOTIFICATION_ID, buildNotification(title, artist));
        return START_STICKY;
    }

    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && (wakeLock == null || !wakeLock.isHeld())) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SidePlay:WebPlayback");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire();
            }
        } catch (Exception ignored) {}

        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null && (wifiLock == null || !wifiLock.isHeld())) {
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "SidePlay:WebPlaybackWifi");
                wifiLock.setReferenceCounted(false);
                wifiLock.acquire();
            }
        } catch (Exception ignored) {}
    }

    private Notification buildNotification(String title, String artist) {
        Intent launch = new Intent(this, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 2207, launch, piFlags);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);

        String safeTitle = title == null || title.isBlank() ? "SidePlay" : title;
        String safeArtist = artist == null || artist.isBlank() ? "Keeping web playback active" : artist;
        return b
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(safeTitle)
            .setContentText(safeArtist)
            .setContentIntent(pending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID,
            "SidePlay web playback",
            NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Keeps SidePlay's active web player alive when the app is not visible.");
        channel.setShowBadge(false);
        nm.createNotificationChannel(channel);
    }

    private void stopKeepAlive() {
        active = false;
        releaseLocks();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        stopSelf();
    }

    private void releaseLocks() {
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) {}
        wakeLock = null;
        wifiLock = null;
    }

    @Override
    public void onTaskRemoved(@Nullable Intent rootIntent) {
        // The WebView belongs to the Activity. If the user explicitly removes the
        // task, there is no renderer left for this helper service to preserve.
        stopKeepAlive();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        active = false;
        releaseLocks();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
