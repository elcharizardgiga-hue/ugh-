package app.sideplay.mobile;

import android.service.notification.NotificationListenerService;

/**
 * Gives SidePlay user-authorized access to active Android media sessions.
 * No notifications are read or persisted by this service.
 */
public class SpotifySessionListenerService extends NotificationListenerService {
}
