package app.sideplay.mobile;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

@CapacitorPlugin(name = "OfflineMedia")
public class OfflineMediaPlugin extends Plugin {
    public static final int REQUEST_AUDIO = 9422;
    private static PluginCall pendingCall;
    private static OfflineMediaPlugin activePlugin;

    @PluginMethod
    public void importAudio(PluginCall call) {
        if (pendingCall != null) {
            call.reject("An offline import is already open.");
            return;
        }
        activePlugin = this;
        pendingCall = call;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("audio/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        getActivity().startActivityForResult(intent, REQUEST_AUDIO);
    }

    public static boolean handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQUEST_AUDIO || pendingCall == null || activePlugin == null) return false;
        PluginCall call = pendingCall;
        pendingCall = null;

        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("Offline import cancelled.");
            return true;
        }

        Uri uri = data.getData();
        try {
            JSObject result = activePlugin.copyIntoVault(uri, call.getString("videoId", "track"), call.getString("title", "SidePlay track"));
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Could not import audio: " + safe(e));
        }
        return true;
    }

    private JSObject copyIntoVault(Uri uri, String videoId, String title) throws Exception {
        String displayName = queryName(uri);
        if (displayName == null || displayName.trim().isEmpty()) displayName = sanitize(title) + ".audio";
        displayName = sanitize(displayName);

        String ext = "";
        int dot = displayName.lastIndexOf('.');
        if (dot >= 0 && dot < displayName.length() - 1) ext = displayName.substring(dot);
        String base = sanitize(videoId == null ? "track" : videoId);
        File dir = new File(getContext().getFilesDir(), "offline");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("Could not create SidePlay offline storage.");
        File out = new File(dir, base + "-" + System.currentTimeMillis() + ext);

        long bytes = 0;
        try (InputStream input = getContext().getContentResolver().openInputStream(uri);
             FileOutputStream output = new FileOutputStream(out)) {
            if (input == null) throw new Exception("Selected file could not be opened.");
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
                bytes += read;
            }
            output.flush();
        }

        JSObject result = new JSObject();
        result.put("localUri", Uri.fromFile(out).toString());
        result.put("filename", displayName);
        result.put("mimeType", getContext().getContentResolver().getType(uri));
        result.put("bytes", bytes);
        return result;
    }

    @PluginMethod
    public void remove(PluginCall call) {
        String raw = call.getString("localUri");
        if (raw == null || raw.isBlank()) { call.reject("localUri is required."); return; }
        try {
            Uri uri = Uri.parse(raw);
            File file = new File(uri.getPath());
            File vault = new File(getContext().getFilesDir(), "offline").getCanonicalFile();
            File target = file.getCanonicalFile();
            if (!target.getPath().startsWith(vault.getPath() + File.separator)) {
                call.reject("SidePlay will only delete files inside its offline vault.");
                return;
            }
            if (target.exists() && !target.delete()) {
                call.reject("Could not delete the offline file.");
                return;
            }
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not delete offline file: " + safe(e));
        }
    }

    private String queryName(Uri uri) {
        try (Cursor cursor = getContext().getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return null;
    }

    private String sanitize(String value) {
        return value.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
    }

    private static String safe(Exception e) {
        String m = e.getMessage();
        return (m == null || m.isBlank()) ? e.getClass().getSimpleName() : m;
    }
}
