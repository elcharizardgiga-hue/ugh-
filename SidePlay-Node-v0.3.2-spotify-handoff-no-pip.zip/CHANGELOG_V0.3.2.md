# SidePlay v0.3.2 — Spotify handoff repair

- Removed Android Picture-in-Picture entirely.
- Spotify-first mode no longer silently falls back to YouTube.
- After `playFromSearch`, SidePlay explicitly sends `play()` and polls the Spotify media session for up to ~3.5 seconds.
- Handoff failures are surfaced to the UI instead of being hidden.
- YouTube is labeled foreground-only when Spotify mode is disabled.
- Existing local/offline Media3 background playback remains unchanged.

Important: Android MediaSession `PLAY_FROM_SEARCH` is an experimental control path. Spotify may advertise the action yet still reject/ignore it on some app versions/accounts. This build makes that failure visible rather than masking it with YouTube/PiP.
