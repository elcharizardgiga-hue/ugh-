import { Capacitor, registerPlugin } from '@capacitor/core'
import type { Track } from '../types'

interface NativeYouTubePlugin {
  search(options: { query: string; limit?: number }): Promise<{ tracks: Track[] }>
  getVideo(options: { videoId: string }): Promise<{ track: Track }>
}

export const NativeYouTube = registerPlugin<NativeYouTubePlugin>('NativeYouTube')
export const hasNativeYouTubeSearch = () => Capacitor.isNativePlatform()
