import type { SidePlayState, Track } from '../types'
import { searchYouTube } from './youtube'

export type Mix = {
  id: string
  title: string
  subtitle: string
  tracks: Track[]
  accent: 'rose' | 'amber' | 'peach' | 'berry'
}

const unique = (tracks: Track[]) => {
  const seen = new Set<string>()
  return tracks.filter((t) => t?.videoId && !seen.has(t.videoId) && seen.add(t.videoId))
}

function hash(input: string) {
  let h = 2166136261
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

function seededShuffle<T>(items: T[], seed: string) {
  const out = [...items]
  let s = hash(seed) || 1
  const rand = () => {
    s ^= s << 13; s ^= s >>> 17; s ^= s << 5
    return (s >>> 0) / 4294967296
  }
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1))
    ;[out[i], out[j]] = [out[j], out[i]]
  }
  return out
}

export function localMixes(state: SidePlayState): Mix[] {
  const day = new Date().toISOString().slice(0, 10)
  const playlistPool = state.playlists.flatMap((p) => p.tracks)
  const rotation = unique([
    ...[...state.history].sort((a, b) => (state.playCounts?.[b.videoId] ?? 0) - (state.playCounts?.[a.videoId] ?? 0)),
    ...state.favorites,
    ...playlistPool,
  ])
  const liked = unique(state.favorites)
  const everything = unique([...state.history, ...liked, ...playlistPool])
  const offline = unique(Object.values(state.offline || {}).map((copy) => ({
    videoId: copy.videoId,
    title: copy.title || copy.filename,
    channel: copy.channel || 'Offline audio',
    thumbnail: copy.thumbnail || '',
  })))

  const mixes: Mix[] = []
  if (everything.length) {
    mixes.push({
      id: 'daily-1',
      title: 'Daily Mix',
      subtitle: 'A warm shuffle of your recent rotation',
      tracks: seededShuffle(everything, `${day}:daily`).slice(0, 24),
      accent: 'rose',
    })
  }
  if (liked.length) {
    mixes.push({
      id: 'liked-radio',
      title: 'Liked Songs Radio',
      subtitle: 'Built from the songs you hearted',
      tracks: seededShuffle(liked, `${day}:liked`).slice(0, 24),
      accent: 'berry',
    })
  }
  const populated = state.playlists.filter((p) => p.tracks.length)
  if (populated.length) {
    const blend = unique(populated.slice(0, 4).flatMap((p) => seededShuffle(p.tracks, `${day}:${p.id}`).slice(0, 8)))
    mixes.push({
      id: 'playlist-blend',
      title: 'Playlist Blend',
      subtitle: 'A little bit of everything you saved',
      tracks: seededShuffle(blend, `${day}:blend`).slice(0, 24),
      accent: 'amber',
    })
  }
  if (rotation.length) {
    mixes.push({
      id: 'rotation',
      title: 'Your Rotation',
      subtitle: 'The tracks you keep coming back to',
      tracks: rotation.slice(0, 24),
      accent: 'peach',
    })
  }
  if (offline.length) {
    mixes.push({
      id: 'offline-mix',
      title: 'No Signal Mix',
      subtitle: 'Everything you can play without internet',
      tracks: seededShuffle(offline, `${day}:offline`).slice(0, 24),
      accent: 'amber',
    })
  }
  if (liked.length >= 4) {
    const rediscover = [...liked].sort((a, b) => (state.playCounts?.[a.videoId] ?? 0) - (state.playCounts?.[b.videoId] ?? 0))
    mixes.push({
      id: 'rediscover',
      title: 'Rediscover',
      subtitle: 'Liked songs you have not spun as much lately',
      tracks: seededShuffle(rediscover.slice(0, Math.max(8, Math.ceil(rediscover.length * .65))), `${day}:rediscover`).slice(0, 24),
      accent: 'berry',
    })
  }
  return mixes
}

function cleanTitle(title: string) {
  return title
    .replace(/\((official|lyrics?|audio|video|visualizer).*?\)/ig, '')
    .replace(/\[(official|lyrics?|audio|video|visualizer).*?\]/ig, '')
    .replace(/\s+/g, ' ')
    .trim()
}

export async function discoverRecommendations(state: SidePlayState, limit = 24): Promise<Track[]> {
  const local = unique([...state.history, ...state.favorites, ...state.playlists.flatMap((p) => p.tracks)])
  const recent = local.slice(0, 4)
  let subscriptions: { title?: string }[] = []
  try { subscriptions = JSON.parse(localStorage.getItem('sideplay.youtube.subscriptions') || '[]') } catch {}

  const queries: string[] = []
  for (const track of recent.slice(0, 3)) {
    const title = cleanTitle(track.title).split(/[-–—]/)[0]?.trim()
    queries.push(`${track.channel} ${title || 'music'}`)
  }
  if (subscriptions[0]?.title) queries.push(`${subscriptions[0].title} music`)
  if (!queries.length) queries.push('music mix')

  const known = new Set(local.map((t) => t.videoId))
  const out: Track[] = []
  for (const q of queries.slice(0, 4)) {
    try {
      const found = await searchYouTube(q, state.youtubeApiKey)
      for (const track of found) {
        if (!known.has(track.videoId) && !out.some((x) => x.videoId === track.videoId)) out.push(track)
        if (out.length >= limit) return out
      }
    } catch {}
  }
  return out.slice(0, limit)
}
