import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import type { OfflineCopy, Playlist, RepeatMode, SidePlayState, Track } from '../types'

const KEY = 'sideplay.state.v1'

const initial: SidePlayState = {
  favorites: [],
  playlists: [],
  history: [],
  queue: [],
  currentIndex: -1,
  repeat: 'off',
  shuffle: false,
  youtubeApiKey: '',
  playCounts: {},
  offline: {},
  preferOffline: true,
}

type Ctx = {
  state: SidePlayState
  current: Track | null
  setApiKey: (key: string) => void
  playNow: (track: Track, queue?: Track[]) => void
  addQueue: (track: Track) => void
  playNext: (track: Track) => void
  removeQueue: (index: number) => void
  moveQueue: (from: number, to: number) => void
  clearQueue: () => void
  next: () => Track | null
  previous: () => Track | null
  toggleFavorite: (track: Track) => void
  isFavorite: (videoId: string) => boolean
  createPlaylist: (name: string) => Playlist
  renamePlaylist: (id: string, name: string) => void
  deletePlaylist: (id: string) => void
  addToPlaylist: (id: string, track: Track) => void
  removeFromPlaylist: (id: string, videoId: string) => void
  movePlaylistTrack: (id: string, from: number, to: number) => void
  setRepeat: (mode: RepeatMode) => void
  setShuffle: (value: boolean) => void
  setOfflineCopy: (copy: OfflineCopy) => void
  removeOfflineCopy: (videoId: string) => void
  getOfflineCopy: (videoId: string) => OfflineCopy | null
  setPreferOffline: (value: boolean) => void
  mergeHistory: (tracks: Track[]) => void
  clearHistory: () => void
  exportLibrary: () => string
  importLibrary: (json: string) => void
}

const SidePlayContext = createContext<Ctx | null>(null)

const uniqueTracks = (tracks: Track[]) => {
  const seen = new Set<string>()
  return tracks.filter((t) => !seen.has(t.videoId) && seen.add(t.videoId))
}

export function SidePlayProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<SidePlayState>(() => {
    try {
      const raw = localStorage.getItem(KEY)
      return raw ? { ...initial, ...JSON.parse(raw) } : initial
    } catch {
      return initial
    }
  })

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(state))
  }, [state])

  const current = state.currentIndex >= 0 ? state.queue[state.currentIndex] ?? null : null

  const api = useMemo<Ctx>(() => ({
    state,
    current,
    setApiKey: (youtubeApiKey) => setState((s) => ({ ...s, youtubeApiKey })),
    playNow: (track, queue) => setState((s) => {
      const nextQueue = queue?.length ? uniqueTracks(queue) : [track]
      const index = Math.max(0, nextQueue.findIndex((x) => x.videoId === track.videoId))
      return {
        ...s,
        queue: nextQueue,
        currentIndex: index,
        history: [{ ...track, playedAt: Date.now() }, ...s.history.filter((h) => h.videoId !== track.videoId)].slice(0, 200),
        playCounts: { ...s.playCounts, [track.videoId]: (s.playCounts?.[track.videoId] ?? 0) + 1 },
      }
    }),
    // Queueing is passive: adding something to an empty queue must not start playback.
    addQueue: (track) => setState((s) => ({ ...s, queue: uniqueTracks([...s.queue, track]) })),
    playNext: (track) => setState((s) => {
      if (s.currentIndex < 0) {
        const without = s.queue.filter((x) => x.videoId !== track.videoId)
        return { ...s, queue: [track, ...without] }
      }
      const without = s.queue.filter((x) => x.videoId !== track.videoId)
      const q = [...without]
      q.splice(s.currentIndex + 1, 0, track)
      return { ...s, queue: q }
    }),
    removeQueue: (index) => setState((s) => {
      const q = s.queue.filter((_, i) => i !== index)
      let currentIndex = s.currentIndex
      if (!q.length) currentIndex = -1
      else if (index < s.currentIndex) currentIndex -= 1
      else if (index === s.currentIndex) currentIndex = Math.min(currentIndex, q.length - 1)
      return { ...s, queue: q, currentIndex }
    }),
    moveQueue: (from, to) => setState((s) => {
      if (to < 0 || to >= s.queue.length || from === to) return s
      const q = [...s.queue]
      const [item] = q.splice(from, 1)
      q.splice(to, 0, item)
      let idx = s.currentIndex
      if (idx === from) idx = to
      else if (from < idx && to >= idx) idx -= 1
      else if (from > idx && to <= idx) idx += 1
      return { ...s, queue: q, currentIndex: idx }
    }),
    // 'Clear queue' means clear Up Next, not stop the song that is already playing.
    clearQueue: () => setState((s) => {
      if (s.currentIndex < 0) return { ...s, queue: [] }
      return { ...s, queue: s.queue.slice(0, s.currentIndex + 1) }
    }),
    next: () => {
      let chosen: Track | null = null
      setState((s) => {
        if (!s.queue.length) return s
        let idx = s.currentIndex
        if (idx < 0) {
          idx = 0
          chosen = s.queue[0]
          return { ...s, currentIndex: 0, history: [{ ...chosen, playedAt: Date.now() }, ...s.history.filter((h) => h.videoId !== chosen!.videoId)].slice(0, 200), playCounts: { ...s.playCounts, [chosen!.videoId]: (s.playCounts?.[chosen!.videoId] ?? 0) + 1 } }
        }
        if (s.repeat === 'one') chosen = s.queue[idx]
        else if (s.shuffle && s.queue.length > 1) {
          do idx = Math.floor(Math.random() * s.queue.length)
          while (idx === s.currentIndex)
          chosen = s.queue[idx]
        } else if (idx + 1 < s.queue.length) {
          idx += 1; chosen = s.queue[idx]
        } else if (s.repeat === 'all') {
          idx = 0; chosen = s.queue[0]
        }
        if (!chosen) return s
        return { ...s, currentIndex: idx, history: [{ ...chosen, playedAt: Date.now() }, ...s.history.filter((h) => h.videoId !== chosen!.videoId)].slice(0, 200), playCounts: { ...s.playCounts, [chosen!.videoId]: (s.playCounts?.[chosen!.videoId] ?? 0) + 1 } }
      })
      return chosen
    },
    previous: () => {
      let chosen: Track | null = null
      setState((s) => {
        if (!s.queue.length || s.currentIndex < 0) return s
        const idx = s.currentIndex > 0 ? s.currentIndex - 1 : (s.repeat === 'all' ? s.queue.length - 1 : 0)
        chosen = s.queue[idx]
        return { ...s, currentIndex: idx, history: [{ ...chosen, playedAt: Date.now() }, ...s.history.filter((h) => h.videoId !== chosen!.videoId)].slice(0, 200), playCounts: { ...s.playCounts, [chosen!.videoId]: (s.playCounts?.[chosen!.videoId] ?? 0) + 1 } }
      })
      return chosen
    },
    toggleFavorite: (track) => setState((s) => {
      const exists = s.favorites.some((x) => x.videoId === track.videoId)
      return { ...s, favorites: exists ? s.favorites.filter((x) => x.videoId !== track.videoId) : [track, ...s.favorites] }
    }),
    isFavorite: (videoId) => state.favorites.some((x) => x.videoId === videoId),
    createPlaylist: (name) => {
      const playlist: Playlist = { id: crypto.randomUUID(), name: name.trim() || 'Untitled playlist', tracks: [], createdAt: Date.now(), updatedAt: Date.now() }
      setState((s) => ({ ...s, playlists: [playlist, ...s.playlists] }))
      return playlist
    },
    renamePlaylist: (id, name) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, name: name.trim() || p.name, updatedAt: Date.now() } : p) })),
    deletePlaylist: (id) => setState((s) => ({ ...s, playlists: s.playlists.filter((p) => p.id !== id) })),
    addToPlaylist: (id, track) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, tracks: uniqueTracks([...p.tracks, track]), updatedAt: Date.now() } : p) })),
    removeFromPlaylist: (id, videoId) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => p.id === id ? { ...p, tracks: p.tracks.filter((t) => t.videoId !== videoId), updatedAt: Date.now() } : p) })),
    movePlaylistTrack: (id, from, to) => setState((s) => ({ ...s, playlists: s.playlists.map((p) => {
      if (p.id !== id || to < 0 || to >= p.tracks.length) return p
      const tracks = [...p.tracks]
      const [item] = tracks.splice(from, 1)
      tracks.splice(to, 0, item)
      return { ...p, tracks, updatedAt: Date.now() }
    }) })),
    setRepeat: (repeat) => setState((s) => ({ ...s, repeat })),
    setShuffle: (shuffle) => setState((s) => ({ ...s, shuffle })),
    setOfflineCopy: (copy) => setState((s) => ({ ...s, offline: { ...(s.offline || {}), [copy.videoId]: copy } })),
    removeOfflineCopy: (videoId) => setState((s) => { const offline = { ...(s.offline || {}) }; delete offline[videoId]; return { ...s, offline } }),
    getOfflineCopy: (videoId) => state.offline?.[videoId] || null,
    setPreferOffline: (preferOffline) => setState((s) => ({ ...s, preferOffline })),
    clearHistory: () => setState((s) => ({ ...s, history: [] })),
    mergeHistory: (tracks) => setState((s) => {
      const now = Date.now()
      const imported = uniqueTracks(tracks).map((t, i) => ({ ...t, playedAt: now - i }))
      const seen = new Set(imported.map(t => t.videoId))
      return { ...s, history: [...imported, ...s.history.filter(h => !seen.has(h.videoId))].slice(0, 500) }
    }),
    exportLibrary: () => JSON.stringify(state, null, 2),
    importLibrary: (json) => {
      const parsed = JSON.parse(json)
      setState({ ...initial, ...parsed })
    },
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [state, current])

  return <SidePlayContext.Provider value={api}>{children}</SidePlayContext.Provider>
}

export function useSidePlay() {
  const ctx = useContext(SidePlayContext)
  if (!ctx) throw new Error('useSidePlay must be used inside SidePlayProvider')
  return ctx
}
