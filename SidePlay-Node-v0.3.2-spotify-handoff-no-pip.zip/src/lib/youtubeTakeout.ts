import JSZip from 'jszip'
import type { Track } from '../types'

export type ImportedSubscription = { title: string; url?: string; channelId?: string }
export type ImportedPlaylist = { name: string; tracks: Track[] }
export type YouTubeLocalImport = {
  playlists: ImportedPlaylist[]
  favorites: Track[]
  history: Track[]
  subscriptions: ImportedSubscription[]
  filesRead: number
}

const VIDEO_RE = /(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:[^#]*&)?v=|shorts\/|embed\/))([A-Za-z0-9_-]{11})/i
const BARE_VIDEO_RE = /^[A-Za-z0-9_-]{11}$/

function videoIdFrom(value: unknown): string | null {
  const s = String(value ?? '').trim()
  const m = s.match(VIDEO_RE)
  if (m?.[1]) return m[1]
  return BARE_VIDEO_RE.test(s) ? s : null
}
function thumb(id: string) { return `https://i.ytimg.com/vi/${id}/hqdefault.jpg` }
function cleanTitle(value: unknown, id: string) {
  return String(value ?? '').replace(/^Watched\s+/i, '').trim() || `YouTube video ${id}`
}
function makeTrack(id: string, title?: unknown, channel?: unknown): Track {
  return { videoId: id, title: cleanTitle(title, id), channel: String(channel ?? '').trim() || 'YouTube', thumbnail: thumb(id) }
}
function uniqueTracks(items: Track[]) {
  const seen = new Set<string>()
  return items.filter(t => t.videoId && !seen.has(t.videoId) && seen.add(t.videoId))
}
function uniqueSubscriptions(items: ImportedSubscription[]) {
  const seen = new Set<string>()
  return items.filter(s => {
    const k = (s.channelId || s.url || s.title).toLowerCase()
    return !!k && !seen.has(k) && seen.add(k)
  })
}

// Small RFC4180-ish CSV reader. Takeout CSVs are simple but titles can contain
// commas and quotes, so split(',') is not good enough.
function parseCsv(text: string): string[][] {
  const rows: string[][] = []
  let row: string[] = [], cell = '', quoted = false
  for (let i = 0; i < text.length; i++) {
    const c = text[i]
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { cell += '"'; i++ }
      else if (c === '"') quoted = false
      else cell += c
    } else {
      if (c === '"') quoted = true
      else if (c === ',') { row.push(cell); cell = '' }
      else if (c === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = '' }
      else cell += c
    }
  }
  if (cell.length || row.length) { row.push(cell.replace(/\r$/, '')); rows.push(row) }
  return rows.filter(r => r.some(c => c.trim()))
}
function norm(s: string) { return s.trim().toLowerCase().replace(/[\s_-]+/g, ' ') }
function findCol(headers: string[], names: string[]) {
  const h = headers.map(norm)
  for (const n of names) { const i = h.indexOf(norm(n)); if (i >= 0) return i }
  return -1
}
function baseName(path: string) {
  const name = path.replace(/\\/g, '/').split('/').pop() || 'YouTube playlist'
  return name.replace(/\.(csv|json|html?)$/i, '').trim() || 'YouTube playlist'
}

function parseSubscriptionsCsv(text: string): ImportedSubscription[] {
  const rows = parseCsv(text); if (rows.length < 2) return []
  const headers = rows[0]
  const titleCol = findCol(headers, ['Channel Title','Channel Name','Title'])
  const urlCol = findCol(headers, ['Channel Url','Channel URL','URL'])
  const idCol = findCol(headers, ['Channel Id','Channel ID'])
  return rows.slice(1).map(r => ({
    title: (titleCol >= 0 ? r[titleCol] : '')?.trim() || (idCol >= 0 ? r[idCol] : '')?.trim() || 'YouTube channel',
    url: urlCol >= 0 ? r[urlCol]?.trim() : undefined,
    channelId: idCol >= 0 ? r[idCol]?.trim() : undefined,
  })).filter(s => s.title)
}

function parseTrackCsv(text: string): Track[] {
  const rows = parseCsv(text); if (rows.length < 2) return []
  const headers = rows[0]
  const idCol = findCol(headers, ['Video ID','Video Id','Content ID','ID'])
  const urlCol = findCol(headers, ['Video URL','Video Url','URL','Link'])
  const titleCol = findCol(headers, ['Video Title','Title'])
  const channelCol = findCol(headers, ['Channel Title','Channel','Artist','Video Publisher'])
  const out: Track[] = []
  for (const r of rows.slice(1)) {
    let id = idCol >= 0 ? videoIdFrom(r[idCol]) : null
    if (!id && urlCol >= 0) id = videoIdFrom(r[urlCol])
    if (!id) { for (const cell of r) { id = videoIdFrom(cell); if (id) break } }
    if (!id) continue
    out.push(makeTrack(id, titleCol >= 0 ? r[titleCol] : undefined, channelCol >= 0 ? r[channelCol] : undefined))
  }
  return uniqueTracks(out)
}

function parseWatchJson(text: string): Track[] {
  let data: any
  try { data = JSON.parse(text) } catch { return [] }
  const out: Track[] = []
  const walk = (node: any) => {
    if (!node) return
    if (Array.isArray(node)) { node.forEach(walk); return }
    if (typeof node !== 'object') return
    const id = videoIdFrom(node.titleUrl || node.url || node.link)
    if (id) {
      const channel = Array.isArray(node.subtitles) ? node.subtitles[0]?.name : node.channelTitle || node.channel
      out.push(makeTrack(id, node.title, channel))
    }
    for (const v of Object.values(node)) if (typeof v === 'object') walk(v)
  }
  walk(data)
  return uniqueTracks(out)
}

function parseWatchHtml(text: string): Track[] {
  const doc = new DOMParser().parseFromString(text, 'text/html')
  const out: Track[] = []
  for (const a of Array.from(doc.querySelectorAll<HTMLAnchorElement>('a[href]'))) {
    const id = videoIdFrom(a.href)
    if (!id) continue
    const title = a.textContent?.trim()
    // Takeout watch-history pages usually put the uploader link near the video link.
    const parent = a.parentElement
    const links = parent ? Array.from(parent.querySelectorAll<HTMLAnchorElement>('a[href]')) : []
    const channel = links.find(x => !videoIdFrom(x.href) && x.textContent?.trim())?.textContent?.trim()
    out.push(makeTrack(id, title, channel))
  }
  return uniqueTracks(out)
}

function mergeInto(result: YouTubeLocalImport, path: string, text: string) {
  const lower = path.toLowerCase().replace(/\\/g, '/')
  result.filesRead++
  if (lower.endsWith('.csv') && lower.includes('subscription')) {
    result.subscriptions.push(...parseSubscriptionsCsv(text)); return
  }
  if ((lower.endsWith('.json') || lower.endsWith('.html') || lower.endsWith('.htm')) && lower.includes('watch') && lower.includes('history')) {
    result.history.push(...(lower.endsWith('.json') ? parseWatchJson(text) : parseWatchHtml(text))); return
  }
  if (lower.endsWith('.csv') && (lower.includes('playlist') || lower.includes('liked') || lower.includes('music'))) {
    const tracks = parseTrackCsv(text)
    if (!tracks.length) return
    const name = baseName(path)
    if (/liked videos?|likes?/i.test(name)) result.favorites.push(...tracks)
    else result.playlists.push({ name, tracks })
    return
  }
  // Single JSON Takeout history file with an unexpected localized filename.
  if (lower.endsWith('.json')) {
    const tracks = parseWatchJson(text)
    if (tracks.length) result.history.push(...tracks)
  }
}

function finalize(result: YouTubeLocalImport) {
  result.favorites = uniqueTracks(result.favorites)
  result.history = uniqueTracks(result.history)
  result.subscriptions = uniqueSubscriptions(result.subscriptions)
  const byName = new Map<string, Track[]>()
  for (const p of result.playlists) byName.set(p.name, uniqueTracks([...(byName.get(p.name) || []), ...p.tracks]))
  result.playlists = [...byName].map(([name, tracks]) => ({ name, tracks })).filter(p => p.tracks.length)
  return result
}

export async function parseYouTubeExportFile(file: File): Promise<YouTubeLocalImport> {
  const result: YouTubeLocalImport = { playlists: [], favorites: [], history: [], subscriptions: [], filesRead: 0 }
  const lower = file.name.toLowerCase()
  if (lower.endsWith('.zip')) {
    const zip = await JSZip.loadAsync(file)
    const entries = (Object.values(zip.files) as any[]).filter(e => !e.dir && /\.(csv|json|html?)$/i.test(e.name))
    if (!entries.length) throw new Error('No CSV/JSON/HTML data files were found in this ZIP.')
    for (const entry of entries.slice(0, 5000)) {
      // Ignore unrelated Google products to avoid chewing through a full account Takeout.
      const p = entry.name.toLowerCase()
      if (!/(youtube|subscriptions?|playlists?|history|liked|watch)/.test(p)) continue
      try { mergeInto(result, entry.name, await entry.async('string')) } catch {}
    }
  } else {
    mergeInto(result, file.name, await file.text())
  }
  return finalize(result)
}
