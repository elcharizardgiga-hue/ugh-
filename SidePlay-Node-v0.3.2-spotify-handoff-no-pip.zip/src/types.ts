export type Track = {
  videoId: string
  title: string
  channel: string
  thumbnail: string
  publishedAt?: string
}

export type Playlist = {
  id: string
  name: string
  tracks: Track[]
  createdAt: number
  updatedAt: number
}

export type HistoryEntry = Track & {
  playedAt: number
}

export type RepeatMode = 'off' | 'all' | 'one'

export type OfflineCopy = {
  videoId: string
  localUri: string
  filename: string
  mimeType?: string
  bytes?: number
  addedAt: number
  platform: 'android' | 'pc'
  title?: string
  channel?: string
  thumbnail?: string
}

export type SidePlayState = {
  favorites: Track[]
  playlists: Playlist[]
  history: HistoryEntry[]
  queue: Track[]
  currentIndex: number
  repeat: RepeatMode
  shuffle: boolean
  youtubeApiKey: string
  playCounts: Record<string, number>
  offline: Record<string, OfflineCopy>
  preferOffline: boolean
}
