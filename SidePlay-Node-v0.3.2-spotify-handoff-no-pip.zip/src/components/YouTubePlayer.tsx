import { useEffect, useRef } from 'react'

declare global {
  interface Window {
    YT: any
    onYouTubeIframeAPIReady?: () => void
  }
}

type Props = {
  videoId: string
  onEnded: () => void
  onReady?: () => void
  onPlaybackState?: (state: 'playing' | 'paused' | 'buffering' | 'ended' | 'cued') => void
  controllerRef: React.MutableRefObject<any | null>
}

let apiPromise: Promise<void> | null = null
function loadApi() {
  if (window.YT?.Player) return Promise.resolve()
  if (apiPromise) return apiPromise
  apiPromise = new Promise((resolve) => {
    const previous = window.onYouTubeIframeAPIReady
    window.onYouTubeIframeAPIReady = () => {
      previous?.()
      resolve()
    }
    const script = document.createElement('script')
    script.src = 'https://www.youtube.com/iframe_api'
    document.head.appendChild(script)
  })
  return apiPromise
}

export function YouTubePlayer({ videoId, onEnded, onReady, onPlaybackState, controllerRef }: Props) {
  const host = useRef<HTMLDivElement>(null)
  const player = useRef<any>(null)
  const endedRef = useRef(onEnded)
  const readyRef = useRef(onReady)
  const playbackStateRef = useRef(onPlaybackState)
  endedRef.current = onEnded
  readyRef.current = onReady
  playbackStateRef.current = onPlaybackState

  useEffect(() => {
    let disposed = false
    loadApi().then(() => {
      if (disposed || !host.current) return
      player.current = new window.YT.Player(host.current, {
        videoId,
        width: '100%',
        height: '100%',
        playerVars: {
          autoplay: 1,
          playsinline: 1,
          controls: 0,
          fs: 0,
          disablekb: 1,
          iv_load_policy: 3,
          rel: 0,
          origin: window.location.origin.startsWith('http') ? window.location.origin : undefined,
        },
        events: {
          onReady: (event: any) => {
            controllerRef.current = event.target
            // Important: do NOT force playVideo() here. autoplay handles a newly-created
            // player, and forcing playback here could resurrect a track after a pause.
            readyRef.current?.()
          },
          onStateChange: (event: any) => {
            const s = window.YT.PlayerState
            if (event.data === s.ENDED) {
              playbackStateRef.current?.('ended')
              endedRef.current()
            } else if (event.data === s.PLAYING) playbackStateRef.current?.('playing')
            else if (event.data === s.PAUSED) playbackStateRef.current?.('paused')
            else if (event.data === s.BUFFERING) playbackStateRef.current?.('buffering')
            else if (event.data === s.CUED) playbackStateRef.current?.('cued')
          },
        },
      })
    })
    return () => {
      disposed = true
      controllerRef.current = null
      try { player.current?.destroy?.() } catch {}
      player.current = null
    }
    // Only recreate the iframe when the actual video changes. Callback identity changes
    // from normal React re-renders must never destroy/recreate the player.
  }, [videoId, controllerRef])

  return <div className="yt-host"><div ref={host} /></div>
}
