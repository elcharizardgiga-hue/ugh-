# StickerForge v2
Android WhatsApp sticker maker with multi-pack management, multi-image/text layer compositing, static sticker export, animated WebP pack support, and native Add to WhatsApp integration.

## WhatsApp rules enforced / represented
- 3–30 stickers per pack
- packs are static OR animated, never mixed
- static: 512x512 WebP, <=100 KB
- animated: WebP <=500 KB; WhatsApp also requires <=10 seconds and >=8ms/frame (import UI notes this; full frame parser/encoder is the next step)
- native ContentProvider + ENABLE_STICKER_PACK intent

## Build
Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17, compileSdk 35.
Run `gradle assembleDebug` or use the GitHub Actions workflow supplied separately.
